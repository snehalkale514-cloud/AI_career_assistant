import fs from 'fs';

// Parse CSV
const csvText = fs.readFileSync('src/data/placement_ml_sample_1000.csv', 'utf-8');
const lines = csvText.trim().split('\n').filter(l => l.trim().length > 0);
const header = lines[0].split(',').map(s => s.trim());

interface Sample {
  id: string;
  features: number[];
  label: number; // 1 for Placed, 0 for Not Placed
}

// Features to use
// Categorical mappings
const branchMap: Record<string, number> = { CSE: 0, IT: 1, AIML: 2, ECE: 3, EEE: 4, Mechanical: 5, Civil: 6, Chemical: 7 };
const tierMap: Record<string, number> = { 'Tier-1': 1, 'Tier-2': 2, 'Tier-3': 3 };

const samples: Sample[] = [];
for (let i = 1; i < lines.length; i++) {
  const parts = lines[i].split(',').map(s => s.trim());
  if (parts.length < header.length) continue;
  
  const studentId = parts[0];
  const age = parseFloat(parts[1]) || 21;
  const gender = parts[2] === 'Female' ? 1 : (parts[2] === 'Male' ? 0 : 2);
  const branch = branchMap[parts[4]] ?? 0;
  const tier = tierMap[parts[5]] ?? 2;
  const cgpa = parseFloat(parts[6]) || 7.0;
  const attendance = parseFloat(parts[7]) || 75.0;
  const dsa = parseFloat(parts[8]) || 150;
  const aptitude = parseFloat(parts[9]) || 40;
  const comm = parseFloat(parts[10]) || 50;
  const projects = parseFloat(parts[11]) || 3;
  const internships = parseFloat(parts[12]) || 1;
  const certs = parseFloat(parts[13]) || 2;
  const openSource = parseFloat(parts[14]) || 50;
  const github = parseFloat(parts[15]) || 400;
  const linkedin = parseFloat(parts[16]) || 25;
  const hackathons = parseFloat(parts[17]) || 2;
  const cpRating = parseFloat(parts[18]) || 1000;
  const studyHours = parseFloat(parts[19]) || 15;
  const softSkills = parseFloat(parts[20]) || 50;
  const leadership = parts[21] === 'Yes' ? 1 : 0;
  const extracurriculars = parseFloat(parts[22]) || 2;
  const status = parts[23] === 'Placed' ? 1 : 0;

  const feat = [
    cgpa, dsa, cpRating, github, aptitude, comm, softSkills,
    internships, projects, certs, openSource, hackathons,
    attendance, leadership, tier, branch, studyHours, extracurriculars
  ];

  samples.push({ id: studentId, features: feat, label: status });
}

console.log(`Total parsed samples: ${samples.length}`);
const placedCount = samples.filter(s => s.label === 1).length;
console.log(`Placed: ${placedCount}, Not Placed: ${samples.length - placedCount}`);

// Let's do a deterministic 80/20 train/test split
// Seeded shuffle
function seededShuffle(arr: Sample[], seed: number) {
  const result = [...arr];
  let m = result.length, t, i;
  while (m) {
    seed = (seed * 9301 + 49297) % 233280;
    i = Math.floor((seed / 233280) * m--);
    t = result[m];
    result[m] = result[i];
    result[i] = t;
  }
  return result;
}

const shuffled = seededShuffle(samples, 42);
const splitIdx = Math.floor(shuffled.length * 0.8);
const trainSet = shuffled.slice(0, splitIdx);
const testSet = shuffled.slice(splitIdx);

console.log(`Train count: ${trainSet.length}, Test count: ${testSet.length}`);

// Decision Tree Classifier Implementation
interface TreeNode {
  isLeaf: boolean;
  prediction?: number;
  prob?: number;
  featureIdx?: number;
  threshold?: number;
  left?: TreeNode;
  right?: TreeNode;
}

function gini(labels: number[]): number {
  if (labels.length === 0) return 0;
  const p1 = labels.filter(l => l === 1).length / labels.length;
  const p0 = 1 - p1;
  return 1 - (p1 * p1 + p0 * p0);
}

function buildTree(data: Sample[], depth: number, maxDepth: number, minSamplesSplit: number): TreeNode {
  const labels = data.map(d => d.label);
  const ones = labels.filter(l => l === 1).length;
  const prob = ones / labels.length;
  const pred = prob >= 0.5 ? 1 : 0;

  if (depth >= maxDepth || data.length < minSamplesSplit || gini(labels) === 0) {
    return { isLeaf: true, prediction: pred, prob };
  }

  let bestGain = -1;
  let bestFeat = -1;
  let bestThresh = 0;
  let bestLeft: Sample[] = [];
  let bestRight: Sample[] = [];

  const currentGini = gini(labels);
  const numFeatures = data[0].features.length;

  for (let f = 0; f < numFeatures; f++) {
    const vals = data.map(d => d.features[f]).sort((a, b) => a - b);
    // test percentiles as split candidates
    const step = Math.max(1, Math.floor(vals.length / 10));
    for (let i = step; i < vals.length; i += step) {
      const thresh = (vals[i - 1] + vals[i]) / 2;
      const left = data.filter(d => d.features[f] <= thresh);
      const right = data.filter(d => d.features[f] > thresh);

      if (left.length === 0 || right.length === 0) continue;

      const pL = left.length / data.length;
      const pR = right.length / data.length;
      const gain = currentGini - (pL * gini(left.map(d => d.label)) + pR * gini(right.map(d => d.label)));

      if (gain > bestGain) {
        bestGain = gain;
        bestFeat = f;
        bestThresh = thresh;
        bestLeft = left;
        bestRight = right;
      }
    }
  }

  if (bestGain <= 0.001 || bestLeft.length === 0 || bestRight.length === 0) {
    return { isLeaf: true, prediction: pred, prob };
  }

  return {
    isLeaf: false,
    featureIdx: bestFeat,
    threshold: bestThresh,
    left: buildTree(bestLeft, depth + 1, maxDepth, minSamplesSplit),
    right: buildTree(bestRight, depth + 1, maxDepth, minSamplesSplit)
  };
}

function predictTree(node: TreeNode, features: number[]): { pred: number; prob: number } {
  if (node.isLeaf) {
    return { pred: node.prediction!, prob: node.prob! };
  }
  if (features[node.featureIdx!] <= node.threshold!) {
    return predictTree(node.left!, features);
  } else {
    return predictTree(node.right!, features);
  }
}

// Build a Forest of 15 trees (Random Forest) with bootstrap sampling & random feature subsets
interface ForestTree {
  tree: TreeNode;
  featuresUsed: number[];
}

function buildForest(data: Sample[], numTrees: number): ForestTree[] {
  const forest: ForestTree[] = [];
  const numFeatures = data[0].features.length;
  const numSubFeatures = Math.floor(Math.sqrt(numFeatures)) + 2;

  for (let t = 0; t < numTrees; t++) {
    // Bootstrap sample
    const sampleIndices = Array.from({ length: data.length }, () => Math.floor(Math.random() * data.length));
    const bootstrap = sampleIndices.map(idx => data[idx]);

    // Build tree
    const tree = buildTree(bootstrap, 0, 6, 4);
    forest.push({ tree, featuresUsed: [] });
  }
  return forest;
}

// Evaluate single Decision Tree and Random Forest
const dt = buildTree(trainSet, 0, 5, 4);

let tp = 0, fp = 0, fn = 0, tn = 0;
for (const testSample of testSet) {
  const { pred } = predictTree(dt, testSample.features);
  if (testSample.label === 1 && pred === 1) tp++;
  else if (testSample.label === 0 && pred === 1) fp++;
  else if (testSample.label === 1 && pred === 0) fn++;
  else if (testSample.label === 0 && pred === 0) tn++;
}

const total = testSet.length;
const accuracy = (tp + tn) / total;
const precision = tp / (tp + fp || 1);
const recall = tp / (tp + fn || 1);
const f1 = (2 * precision * recall) / (precision + recall || 1);

console.log("=== Model Evaluation on Test Set ===");
console.log(`Accuracy: ${(accuracy * 100).toFixed(2)}%`);
console.log(`Precision: ${(precision * 100).toFixed(2)}%`);
console.log(`Recall: ${(recall * 100).toFixed(2)}%`);
console.log(`F1 Score: ${(f1 * 100).toFixed(2)}%`);
console.log(`Confusion Matrix: TN=${tn}, FP=${fp}, FN=${fn}, TP=${tp}`);

// Save metrics & model configuration
fs.writeFileSync('scripts/metrics.json', JSON.stringify({
  accuracy,
  precision,
  recall,
  f1,
  confusionMatrix: { tn, fp, fn, tp },
  testTotal: total,
  dtModel: dt
}, null, 2));
