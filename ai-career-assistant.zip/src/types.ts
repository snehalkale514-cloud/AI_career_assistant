export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  location: string;
  college: string;
  degree: string;
  branch: string;
  graduationYear: string;
  currentSemester: string;
  targetRole: string;
  experienceLevel: 'Beginner' | 'Intermediate' | 'Advanced';
  careerGoal: string;
  avatarUrl?: string;
  careerReadiness: number;
  resumeScore: number;
  skillsMatched: number;
  totalRequiredSkills: number;
  preferredCompanies?: string[];
  preferredLocation?: string;
  workPreference?: 'Remote' | 'Hybrid' | 'On-site' | 'Flexible';
  githubConnected?: boolean;
  githubUsername?: string;
  linkedinConnected?: boolean;
  linkedinProfileUrl?: string;
}

export interface SkillItem {
  id: string;
  name: string;
  category: 'Technical' | 'Analytical' | 'Soft Skills' | 'Tools';
  currentLevel: number; // 0 - 100
  requiredLevel: number; // 0 - 100
  status: 'Strong' | 'Good' | 'Needs Improvement' | 'Priority Gap';
  recommendedRoadmapStage?: string;
  lastTestedDate?: string;
  previousLevel?: number;
  improvementPct?: number;
  strongTopics?: string[];
  weakTopics?: string[];
  recommendedPractice?: string[];
  baselineScore?: number;
  validatedScore?: number;
  validationStatus?: 'unvalidated' | 'passed' | 'review_needed';
}

export interface JobItem {
  id: string;
  title: string;
  company: string;
  location: string;
  type: 'Full-time' | 'Internship' | 'Contract';
  workplace: 'Remote' | 'On-site' | 'Hybrid';
  experience: string;
  salary: string;
  matchScore: number;
  requiredSkills: string[];
  matchedSkills: string[];
  missingSkills: string[];
  description: string;
  responsibilities: string[];
  requirements: string[];
  postedDaysAgo: number;
  isSaved?: boolean;
  applicationStatus?: 'Saved' | 'Applied' | 'Interview' | 'Rejected' | 'Selected';
  applicationUrl?: string;
  dateFetched?: string;
  isLive?: boolean;
  companyId?: string;
  status?: 'Published' | 'Draft' | 'Closed';
  isCompanyPartner?: boolean;
  applicantsCount?: number;
}

export interface ApplicationItem {
  id: string;
  company: string;
  role: string;
  location: string;
  appliedDate: string;
  status: 'Application Started' | 'Saved' | 'Applied' | 'Assessment' | 'Interview' | 'Shortlisted' | 'Offer' | 'Rejected';
  salary?: string;
  notes?: string;
  nextStep?: string;
  jobId?: string;
  companyId?: string;
  studentId?: string;
  resumeFileName?: string;
  atsScore?: number;
}

export interface LearningResource {
  title: string;
  provider: string;
  url: string;
  cost: 'Free' | 'Paid' | 'Free Option Available';
  isVerified: boolean;
  type?: 'Documentation' | 'Interactive Tutorial' | 'Official Guide' | 'Course';
}

export interface PracticalExercise {
  title: string;
  task: string;
  completionCriteria: string;
}

export type RoadmapPhase =
  | 'Foundations'
  | 'Core Role-Specific Skills'
  | 'Applied Practice'
  | 'Portfolio Project'
  | 'Resume and Interview Preparation'
  | 'Job Application Preparation';

export interface RoadmapStage {
  id: string;
  stepNumber: number;
  title: string;
  status: 'Completed' | 'In Progress' | 'Upcoming';
  skillName: string;
  currentLevel: number;
  targetLevel: number;
  estimatedTime: string;
  goal: string;
  whyItMatters: string;
  learningModules: { title: string; completed: boolean; hours: string }[];
  practiceTasks: string[];
  suggestedProject: string;
  targetRole?: string;
  conceptsToLearn?: string[];
  learningResources?: LearningResource[];
  practicalExercise?: PracticalExercise;
  completionCriteria?: string;
  isPriorityGap?: boolean;
  phase?: RoadmapPhase;
  prerequisites?: string[];
  taskKey?: string;
  isAssessed?: boolean;
  assessmentScore?: number | null;
  difficulty?: 'Easy' | 'Moderate' | 'Hard';
  baselineScore?: number | null;
  validatedScore?: number | null;
  validationStatus?: 'unvalidated' | 'passed' | 'review_needed';
  lastValidatedDate?: string;
}

export interface SimpleRoadmapStageGroup {
  id: string;
  stageNumber: number;
  title: string;
  shortDescription: string;
  status: 'Completed' | 'In Progress' | 'Not Started';
  tasks: RoadmapStage[];
  completedCount: number;
  totalCount: number;
}

export interface ProjectItem {
  id: string;
  title: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  skills: string[];
  estimatedHours: string;
  description: string;
  whyRecommended: string;
  deliverables: string[];
  status: 'Not Started' | 'In Progress' | 'Completed';
  isSaved?: boolean;
  inPortfolio?: boolean;
  hasGithubRepo?: boolean;
  repoUrl?: string;
  githubRepoName?: string;
}

export interface AssessmentQuestion {
  id: string;
  category: string;
  question: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
  difficulty?: 'Easy' | 'Moderate' | 'Hard';
  topic?: string;
}

export interface AssessmentHistoryItem {
  id: string;
  date: string;
  targetRole: string;
  skillName?: string;
  overallScore: number;
  status: 'Completed' | 'In Progress';
  categoryScores: Record<string, number>;
  strongSkills: string[];
  weakSkills: string[];
  improvementPct?: number;
  previousScore?: number;
  knowledgeLevel?: 'Beginner' | 'Intermediate' | 'Advanced';
  strongTopics?: string[];
  weakTopics?: string[];
  recommendedPractice?: string[];
  difficulty?: 'Easy' | 'Moderate' | 'Hard';
  isBaseline?: boolean;
  isValidation?: boolean;
  stageId?: string;
  questionCount?: number;
  correctCount?: number;
  accuracy?: number;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  type: 'job' | 'roadmap' | 'assessment' | 'achievement' | 'github' | 'linkedin' | 'system';
  isRead: boolean;
  actionUrl?: string;
}

export interface AchievementItem {
  id: string;
  title: string;
  organization: string;
  category:
    | 'Certification'
    | 'Internship'
    | 'Hackathon'
    | 'Competition'
    | 'Award'
    | 'Course'
    | 'Project'
    | 'Workshop'
    | 'College Achievement'
    | 'Volunteering'
    | 'Leadership'
    | 'Other';
  date: string;
  description: string;
  certificateUrl?: string;
  certificateFileName?: string;
  skillsRelated: string[];
  visibility: 'Public' | 'Private';
  status: 'Verified' | 'Pending' | 'Completed';
  inResume: boolean;
  inPortfolio: boolean;
  linkedinPosted: boolean;
}

export interface GitHubProjectItem {
  id: string;
  name: string;
  repoName: string;
  description: string;
  visibility: 'public' | 'private';
  projectType: string;
  technologies: string[];
  stars: number;
  forks: number;
  languages: { [key: string]: number };
  lastUpdated: string;
  readmeMarkdown?: string;
  url?: string;
  inPortfolio: boolean;
}

export interface CertificateItem {
  id: string;
  title: string;
  organization: string;
  issueDate: string;
  credentialId?: string;
  credentialUrl?: string;
  certificateFileName?: string;
  certificateFileUrl?: string;
  certificateType:
    | 'Course'
    | 'Internship'
    | 'Workshop'
    | 'Hackathon'
    | 'Training'
    | 'Professional';
  relatedSkill: string;
  skillsGained?: string[];
  description?: string;
  verificationStatus: 'Verified' | 'Pending';
  createdAt: string;
  linkedInPostGenerated?: boolean;
  linkedInPostId?: string;
}

export interface CareerProgressEvent {
  id: string;
  date: string;
  eventType:
    | 'Assessment'
    | 'Skill'
    | 'Roadmap'
    | 'Project'
    | 'Certificate'
    | 'Achievement'
    | 'Interview'
    | 'GitHub'
    | 'Placement';
  title: string;
  description: string;
  relatedSkill?: string;
  previousValue?: string | number;
  newValue?: string | number;
  delta?: string | number;
  isMeaningful: boolean;
  linkedInStatus: 'Not Generated' | 'Draft Ready' | 'Published';
  linkedInPostId?: string;
  sourceMetadata?: Record<string, any>;
}

export interface LinkedInSettings {
  isConnected: boolean;
  profileName: string;
  profileHeadline: string;
  profileUrl: string;
  avatarUrl?: string;
  connectedAt?: string;
  postingPreference: 'ask_before_post' | 'auto_create_drafts' | 'auto_publish_approved';
  includeHashtags: boolean;
  autoPublishApprovedProgress: boolean;
  defaultTone: 'Professional' | 'Enthusiastic' | 'Learning journey' | 'Concise';
  includeCredentialUrls: boolean;
  includeMetricsByDefault: boolean;
  monitoredEventTypes: Array<
    | 'Assessment'
    | 'Skill'
    | 'Roadmap'
    | 'Project'
    | 'Certificate'
    | 'Achievement'
    | 'Interview'
    | 'GitHub'
    | 'Placement'
  >;
}

export interface LinkedInPostItem {
  id: string;
  title: string;
  hook: string;
  content: string;
  hashtags: string[];
  date: string;
  achievementId?: string;
  projectId?: string;
  certificateId?: string;
  progressEventId?: string;
  postType:
    | 'Certificate'
    | 'Assessment Progress'
    | 'Skill Verified'
    | 'Roadmap Milestone'
    | 'Project Launch'
    | 'Placement Readiness'
    | 'Mock Interview'
    | 'Hackathon / Achievement'
    | 'General';
  status: 'Published' | 'Draft' | 'Approved';
  publishedUrl?: string;
  likes: number;
  comments: number;
  isAutoPublished?: boolean;
  tone?: 'Professional' | 'Enthusiastic' | 'Learning journey' | 'Concise';
  includeMetrics?: boolean;
  includeCredentialUrl?: boolean;
}

export interface InterviewHistoryItem {
  id: string;
  date: string;
  interviewType: string;
  role: string;
  score: number;
  durationMinutes: number;
  status: 'Passed' | 'Review Needed' | 'Exceptional' | 'Terminated';
  feedback: string;
  categoryBreakdown: {
    technical: number;
    communication: number;
    confidence: number;
    completeness: number;
    coding?: number;
    problemSolving?: number;
  };
  codingScore?: number;
  integrityWarnings?: number;
  questionsCount?: number;
  difficulty?: string;
  detailedReport?: any;
  proctoringStatus?: 'Clean' | 'Warnings Recorded' | 'Terminated';
  terminationReason?: string;
}

export interface CompanyProfile {
  id: string;
  name: string;
  tagline?: string;
  industry: string;
  location: string;
  website: string;
  size: string;
  description: string;
  logoUrl?: string;
  contactEmail: string;
  verified: boolean;
  foundedYear?: string;
  headquarters?: string;
}

export interface CompanyUser {
  id: string;
  email: string;
  name: string;
  role: 'company';
  companyId: string;
  jobTitle: string;
  createdAt: string;
  avatarUrl?: string;
}

export interface CompanyJobPosting {
  id: string;
  companyId: string;
  companyName: string;
  title: string;
  type: 'Full-time' | 'Internship' | 'Contract';
  workplace: 'Remote' | 'On-site' | 'Hybrid';
  location: string;
  experience: string;
  salary: string;
  requiredSkills: string[];
  description: string;
  responsibilities: string[];
  requirements: string[];
  status: 'Published' | 'Draft' | 'Closed';
  postedAt: string;
  updatedAt: string;
  viewsCount?: number;
  applicantsCount: number;
}

export interface CompanyApplicantRecord {
  id: string;
  jobId: string;
  jobTitle: string;
  companyId: string;
  studentId: string;
  candidateName: string;
  candidateEmail: string;
  candidateCollege: string;
  candidateDegree: string;
  candidateBranch: string;
  candidateGraduationYear: string;
  appliedDate: string;
  status: 'Applied' | 'Screening' | 'Assessment' | 'Interview' | 'Shortlisted' | 'Offer' | 'Rejected';
  matchScore: number;
  verifiedSkills: string[];
  notes?: string;
  hasSharedResume: boolean;
  hasSharedPortfolio: boolean;
  resumeFileName?: string;
  nextStep?: string;
  interviewScheduledDate?: string;
}
