import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { CareerProvider } from './context/CareerContext.tsx';
import { CompanyProvider } from './context/CompanyContext.tsx';
import { AppLayout } from './components/layout/AppLayout.tsx';
import { CareerMentor } from './components/careerMentor/CareerMentor.tsx';
import { LandingPage } from './pages/LandingPage.tsx';
import { LoginPage } from './pages/auth/LoginPage.tsx';
import { SignupPage } from './pages/auth/SignupPage.tsx';
import { ForgotPasswordPage } from './pages/auth/ForgotPasswordPage.tsx';
import { OnboardingPage } from './pages/onboarding/OnboardingPage.tsx';
import { DashboardPage } from './pages/dashboard/DashboardPage.tsx';
import { ProfilePage } from './pages/profile/ProfilePage.tsx';
import { SkillAssessmentPage } from './pages/assessment/SkillAssessmentPage.tsx';
import { AssessmentHistoryPage } from './pages/assessment/AssessmentHistoryPage.tsx';
import { ResumeAnalyzerPage } from './pages/resume/ResumeAnalyzerPage.tsx';
import { ResumeBuilderPage } from './pages/resume/ResumeBuilderPage.tsx';
import { SkillAnalyticsPage } from './pages/analytics/SkillAnalyticsPage.tsx';
import { CareerRoadmapPage } from './pages/roadmap/CareerRoadmapPage.tsx';
import { ProjectsPage } from './pages/projects/ProjectsPage.tsx';
import { JobRecommendationsPage } from './pages/jobs/JobRecommendationsPage.tsx';
import { SavedJobsPage } from './pages/jobs/SavedJobsPage.tsx';
import { InterviewPrepPage } from './pages/interview/InterviewPrepPage.tsx';
import { ApplicationTrackerPage } from './pages/applications/ApplicationTrackerPage.tsx';
import { PlacementReadinessPage } from './pages/readiness/PlacementReadinessPage.tsx';
import { SettingsPage } from './pages/settings/SettingsPage.tsx';
import { CareerHubPage } from './pages/careerhub/CareerHubPage.tsx';
import { CertificatesPage } from './pages/careerhub/CertificatesPage.tsx';
import { AchievementsPage } from './pages/careerhub/AchievementsPage.tsx';
import { GithubPage } from './pages/careerhub/GithubPage.tsx';
import { LinkedinPage } from './pages/careerhub/LinkedinPage.tsx';
import { PortfolioPage } from './pages/careerhub/PortfolioPage.tsx';

// Company / Recruiter Portal
import { CompanyProtectedRoute } from './components/company/CompanyProtectedRoute.tsx';
import { CompanyLayout } from './components/company/CompanyLayout.tsx';
import { CompanyLoginPage } from './pages/company/CompanyLoginPage.tsx';
import { CompanyRegisterPage } from './pages/company/CompanyRegisterPage.tsx';
import { CompanyDashboardPage } from './pages/company/CompanyDashboardPage.tsx';
import { CompanyPostingsPage } from './pages/company/CompanyPostingsPage.tsx';
import { CompanyApplicantsPage } from './pages/company/CompanyApplicantsPage.tsx';
import { CompanyProfilePage } from './pages/company/CompanyProfilePage.tsx';

interface ErrorBoundaryProps {
  children: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class AppErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('App caught unhandled error in AppErrorBoundary:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
          <div className="max-w-md w-full bg-white border border-slate-200 rounded-2xl shadow-xl p-8 text-center space-y-4">
            <div className="w-12 h-12 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center mx-auto font-bold text-xl">
              !
            </div>
            <h2 className="text-xl font-bold text-slate-900">Application Notice</h2>
            <p className="text-sm text-slate-600">
              A temporary display issue occurred. Click below to reload the workspace.
            </p>
            <button
              type="button"
              onClick={() => {
                this.setState({ hasError: false, error: null });
                window.location.reload();
              }}
              className="inline-flex items-center justify-center px-5 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold transition-colors shadow-xs cursor-pointer"
            >
              Reload Platform
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  return (
    <AppErrorBoundary>
      <CareerProvider>
        <CompanyProvider>
          <BrowserRouter>
            <Routes>
              {/* Public Landing & Marketing */}
              <Route path="/" element={<LandingPage />} />

              {/* Student Authentication Routes */}
              <Route path="/login" element={<LoginPage />} />
              <Route path="/signup" element={<SignupPage />} />
              <Route path="/forgot-password" element={<ForgotPasswordPage />} />

              {/* Company / Recruiter Authentication */}
              <Route path="/company/login" element={<CompanyLoginPage />} />
              <Route path="/company/register" element={<CompanyRegisterPage />} />
              <Route path="/company/signup" element={<CompanyRegisterPage />} />

              {/* Protected Company / Recruiter Workspace */}
              <Route element={<CompanyProtectedRoute />}>
                <Route element={<CompanyLayout />}>
                  <Route path="/company" element={<Navigate to="/company/dashboard" replace />} />
                  <Route path="/company/dashboard" element={<CompanyDashboardPage />} />
                  <Route path="/company/jobs" element={<CompanyPostingsPage />} />
                  <Route path="/company/postings" element={<CompanyPostingsPage />} />
                  <Route path="/company/applicants" element={<CompanyApplicantsPage />} />
                  <Route path="/company/profile" element={<CompanyProfilePage />} />
                </Route>
              </Route>

              {/* Onboarding Wizard */}
              <Route path="/onboarding" element={<OnboardingPage />} />

              {/* Authenticated Application Workspace - Top Level Clean URLs */}
              <Route element={<AppLayout />}>
                <Route path="/dashboard" element={<DashboardPage />} />
                <Route path="/profile" element={<ProfilePage />} />
                <Route path="/assessment" element={<SkillAssessmentPage />} />
                <Route path="/assessment-history" element={<AssessmentHistoryPage />} />
                <Route path="/resume-analyzer" element={<ResumeAnalyzerPage />} />
                <Route path="/resume-builder" element={<ResumeBuilderPage />} />
                <Route path="/skill-analytics" element={<SkillAnalyticsPage />} />
                <Route path="/roadmap" element={<CareerRoadmapPage />} />
                <Route path="/projects" element={<ProjectsPage />} />
                <Route path="/jobs" element={<JobRecommendationsPage />} />
                <Route path="/saved-jobs" element={<SavedJobsPage />} />
                <Route path="/job-alerts" element={<JobRecommendationsPage />} />
                <Route path="/interview" element={<InterviewPrepPage />} />
                <Route path="/interview-prep" element={<InterviewPrepPage />} />
                <Route path="/interview-practice" element={<InterviewPrepPage />} />
                <Route path="/interview-history" element={<InterviewPrepPage />} />
                <Route path="/applications" element={<ApplicationTrackerPage />} />
                <Route path="/readiness" element={<PlacementReadinessPage />} />
                <Route path="/placement-readiness" element={<PlacementReadinessPage />} />
                <Route path="/career-hub" element={<CareerHubPage />} />
                <Route path="/certificates" element={<CertificatesPage />} />
                <Route path="/career-hub/certificates" element={<CertificatesPage />} />
                <Route path="/achievements" element={<AchievementsPage />} />
                <Route path="/github" element={<GithubPage />} />
                <Route path="/linkedin" element={<LinkedinPage />} />
                <Route path="/portfolio" element={<PortfolioPage />} />
                <Route path="/settings" element={<SettingsPage />} />

                {/* Backwards compatible /app/* aliases */}
                <Route path="/app" element={<Navigate to="/dashboard" replace />} />
                <Route path="/app/dashboard" element={<DashboardPage />} />
                <Route path="/app/profile" element={<ProfilePage />} />
                <Route path="/app/assessment" element={<SkillAssessmentPage />} />
                <Route path="/app/assessment-history" element={<AssessmentHistoryPage />} />
                <Route path="/app/resume-analyzer" element={<ResumeAnalyzerPage />} />
                <Route path="/app/resume-builder" element={<ResumeBuilderPage />} />
                <Route path="/app/skill-analytics" element={<SkillAnalyticsPage />} />
                <Route path="/app/roadmap" element={<CareerRoadmapPage />} />
                <Route path="/app/projects" element={<ProjectsPage />} />
                <Route path="/app/jobs" element={<JobRecommendationsPage />} />
                <Route path="/app/saved-jobs" element={<SavedJobsPage />} />
                <Route path="/app/interview" element={<InterviewPrepPage />} />
                <Route path="/app/interview-prep" element={<InterviewPrepPage />} />
                <Route path="/app/applications" element={<ApplicationTrackerPage />} />
                <Route path="/app/readiness" element={<PlacementReadinessPage />} />
                <Route path="/app/settings" element={<SettingsPage />} />
              </Route>

              {/* Fallback */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>

            {/* Global Floating AI Career Mentor Companion */}
            <CareerMentor />
          </BrowserRouter>
        </CompanyProvider>
      </CareerProvider>
    </AppErrorBoundary>
  );
}
