import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  UserProfile,
  SkillItem,
  JobItem,
  ApplicationItem,
  RoadmapStage,
  ProjectItem,
  NotificationItem,
  AchievementItem,
  GitHubProjectItem,
  LinkedInPostItem,
  AssessmentHistoryItem,
  InterviewHistoryItem,
  CertificateItem,
  CareerProgressEvent,
  LinkedInSettings,
  CompanyJobPosting,
} from '../types.ts';
import {
  initialUserProfile,
  initialSkills,
  initialJobs,
  initialRoadmapStages,
  initialProjects,
  initialApplications,
  initialNotifications,
  initialAchievements,
  initialAssessmentHistory,
  initialInterviewHistory,
} from '../data/mockData.ts';
import { initialCompanyJobPostings } from '../data/companyMockData.ts';
import { initialGitHubProjects } from '../services/github.ts';
import {
  initialLinkedInPosts,
  initialCertificates,
  initialProgressEvents,
  defaultLinkedInSettings,
  linkedinService,
} from '../services/linkedin.ts';
import { liveJobsService, LiveJobFetchResult, areSkillsMatching, canonicalizeSkill, getRoleBenchmarkSkills } from '../services/liveJobsService.ts';
import { generatePersonalizedRoadmap } from '../services/careerRoadmapService.ts';

export interface ResumeAnalysisData {
  hasUploadedResume?: boolean;
  atsScore: number;
  atsCompatibility: number;
  keywordMatch: number;
  formattingScore: number;
  skillsMatch: number;
  experienceMatch: number;
  strengths: string[];
  missingSkills: string[];
  keywordSuggestions: string[];
  improvements: { original: string; suggested: string; reason: string }[];
  analyzedFileName: string;
  warningMessage?: string;
  detectedSkills?: string[];
  extractedTextLength?: number;
}

interface CareerContextType {
  user: UserProfile;
  updateUser: (updates: Partial<UserProfile>) => void;
  isStudentAuthenticated: boolean;
  loginStudent: (email: string, password?: string) => boolean;
  logoutStudent: () => void;
  skills: SkillItem[];
  addSkill: (name: string, category?: SkillItem['category']) => { success: boolean; error?: string; skill?: SkillItem };
  updateSkillLevel: (id: string, newLevel: number) => void;
  jobs: JobItem[];
  liveJobState: LiveJobFetchResult | null;
  isLoadingJobs: boolean;
  refreshLiveJobs: () => Promise<void>;
  toggleSaveJob: (id: string) => void;
  savedJobs: JobItem[];
  applications: ApplicationItem[];
  addApplication: (item: Omit<ApplicationItem, 'id'> & { id?: string }) => void;
  updateApplicationStatus: (id: string, status: ApplicationItem['status']) => void;
  deleteApplication: (id: string) => void;
  roadmapStages: RoadmapStage[];
  toggleRoadmapStageComplete: (id: string) => void;
  calibrateRoadmapForRole: (targetRole?: string) => void;
  projects: ProjectItem[];
  addProject: (item: Omit<ProjectItem, 'id'>) => ProjectItem;
  toggleSaveProject: (id: string) => void;
  updateProjectStatus: (id: string, status: ProjectItem['status']) => void;
  toggleProjectInPortfolio: (id: string) => void;
  notifications: NotificationItem[];
  addNotification: (item: Omit<NotificationItem, 'id' | 'timestamp' | 'isRead'>) => void;
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  jobAlerts: {
    company: string;
    role: string;
    emailAlerts: boolean;
    jobAlerts: boolean;
    roadmapReminders: boolean;
    interviewReminders: boolean;
  };
  updateJobAlerts: (updates: Partial<CareerContextType['jobAlerts']>) => void;
  resumeAnalysis: ResumeAnalysisData;
  updateResumeAnalysis: (data: Partial<ResumeAnalysisData>) => void;
  assessmentScores: {
    lastTakenDate: string | null;
    overallScore: number;
    categoryScores: Record<string, number>;
  } | null;
  submitAssessmentResult: (
    overallScore: number,
    categoryScores: Record<string, number>,
    options?: {
      difficulty?: 'Easy' | 'Moderate' | 'Hard';
      questionCount?: number;
      correctCount?: number;
      accuracy?: number;
      isBaseline?: boolean;
      strongTopics?: string[];
      weakTopics?: string[];
      recommendedPractice?: string[];
    }
  ) => void;
  validateRoadmapStage: (params: {
    stageId: string;
    skillName: string;
    score: number;
    difficulty: 'Easy' | 'Moderate' | 'Hard';
    correctCount: number;
    totalQuestions: number;
    strongTopics?: string[];
    weakTopics?: string[];
    recommendedPractice?: string[];
  }) => { status: 'passed' | 'review_needed'; score: number };
  submitSkillAssessmentResult: (result: {
    skillName: string;
    calculatedScore: number;
    knowledgeLevel: 'Beginner' | 'Intermediate' | 'Advanced';
    strongAreas: string[];
    needsImprovement: string[];
    recommendedPractice: string[];
    previousScore?: number;
    improvementPct?: number;
    difficulty?: 'Easy' | 'Moderate' | 'Hard';
    isValidation?: boolean;
    stageId?: string;
  }) => void;
  
  // Career Hub: Achievements
  achievements: AchievementItem[];
  addAchievement: (item: Omit<AchievementItem, 'id'>) => AchievementItem;
  updateAchievement: (id: string, updates: Partial<AchievementItem>) => void;
  deleteAchievement: (id: string) => void;
  toggleAchievementInResume: (id: string) => void;
  toggleAchievementInPortfolio: (id: string) => void;

  // Career Hub: GitHub
  githubProjects: GitHubProjectItem[];
  addGitHubRepository: (item: Omit<GitHubProjectItem, 'id' | 'stars' | 'forks' | 'lastUpdated'>) => GitHubProjectItem;
  updateGitHubProject: (id: string, updates: Partial<GitHubProjectItem>) => void;
  connectGitHubAccount: (username: string) => void;

  // Career Hub: Certificates
  certificates: CertificateItem[];
  addCertificate: (item: Omit<CertificateItem, 'id' | 'createdAt'>) => CertificateItem;
  updateCertificate: (id: string, updates: Partial<CertificateItem>) => void;
  deleteCertificate: (id: string) => void;

  // Career Hub: Career Progress Events
  progressEvents: CareerProgressEvent[];
  recordProgressEvent: (event: Omit<CareerProgressEvent, 'id' | 'date'>) => CareerProgressEvent;
  dismissProgressEvent: (id: string) => void;

  // Career Hub: LinkedIn & Auto-Post
  linkedinPosts: LinkedInPostItem[];
  linkedInSettings: LinkedInSettings;
  updateLinkedInSettings: (updates: Partial<LinkedInSettings>) => void;
  publishLinkedInPost: (post: Omit<LinkedInPostItem, 'id' | 'date' | 'likes' | 'comments'>) => LinkedInPostItem;
  publishLinkedInPostById: (id: string) => Promise<{ success: boolean; url?: string; message?: string }>;
  connectLinkedInAccount: () => Promise<void>;
  disconnectLinkedInAccount: () => void;
  createLinkedInDraftFromCertificate: (certificateId: string) => LinkedInPostItem;
  createLinkedInDraftFromProgress: (progressEventId: string) => LinkedInPostItem;
  addLinkedInPost: (post: Omit<LinkedInPostItem, 'id' | 'date' | 'likes' | 'comments'>) => LinkedInPostItem;
  updateLinkedInPost: (id: string, updates: Partial<LinkedInPostItem>) => void;
  deleteLinkedInPost: (id: string) => void;

  // Assessment & Interview Histories
  assessmentHistory: AssessmentHistoryItem[];
  interviewHistory: InterviewHistoryItem[];
  recordInterviewAttempt: (item: Omit<InterviewHistoryItem, 'id'>) => void;
}

const defaultResumeAnalysis: ResumeAnalysisData = {
  hasUploadedResume: false,
  atsScore: 84,
  atsCompatibility: 84,
  keywordMatch: 78,
  formattingScore: 90,
  skillsMatch: 82,
  experienceMatch: 75,
  strengths: [
    'Strong technical foundations in Python & Relational Databases (SQL)',
    'Clear education timeline (BTech AI & DS, 2024–2028 cohort at VPKBIET)',
    'Concrete hands-on project portfolio with measurable technical depth',
    'Standard reverse-chronological structure with clean standard heading tags'
  ],
  missingSkills: [
    'Power BI (Enterprise Dashboarding)',
    'Advanced Business Statistics & A/B Testing',
    'Data Visualization (Interactive charts)'
  ],
  keywordSuggestions: [
    'Data Visualization',
    'Power BI',
    'DAX Modeling',
    'SQL Query Optimization',
    'Exploratory Data Analysis (EDA)',
    'Data Cleansing & Transformation'
  ],
  improvements: [
    {
      original: 'Worked on data project using Python and SQL to analyze sales data.',
      suggested: 'Engineered an automated data analytics pipeline analyzing 100K+ transactional records using Python (Pandas) and PostgreSQL, revealing 14% margin optimization opportunities.',
      reason: 'Replaces passive verbs with active metrics (100K+ records, 14% optimization) following the Google X-Y-Z formula.'
    },
    {
      original: 'Helped prepare reports and charts for college presentation.',
      suggested: 'Synthesized multidimensional business performance metrics into 4 interactive dashboards in Power BI, presenting quantitative insights to 120+ student peers and faculty.',
      reason: 'Adds scope, specific tooling, and quantitative stakeholder impact.'
    },
    {
      original: 'Created machine learning model for churn prediction.',
      suggested: 'Trained and validated XGBoost & Random Forest classifiers on 7,000+ subscriber records, achieving 86% ROC-AUC with SHAP value interpretability.',
      reason: 'Specifies model algorithms, performance benchmark (86% ROC-AUC), and explainability methods.'
    }
  ],
  analyzedFileName: 'Snehal_Kale_Resume_DataAnalyst.pdf'
};

/**
 * Safely reads and parses JSON from localStorage with comprehensive fallback.
 * Gracefully handles:
 * - sandboxed iframes (DOMException: Access is denied)
 * - disabled or partitioned storage
 * - missing keys
 * - malformed JSON (SyntaxError)
 */
function safeGetStorage<T>(key: string, fallback: T): T {
  try {
    if (typeof window === 'undefined' || !window.localStorage) {
      return fallback;
    }
    const saved = window.localStorage.getItem(key);
    if (!saved || saved === 'undefined' || saved === 'null') {
      return fallback;
    }
    const parsed = JSON.parse(saved);
    return parsed !== null && parsed !== undefined ? parsed : fallback;
  } catch {
    return fallback;
  }
}

/**
 * Safely writes JSON to localStorage without crashing in sandboxed or restricted iframes.
 */
function safeSetStorage<T>(key: string, value: T): void {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(key, JSON.stringify(value));
    }
  } catch {
    // Graceful no-op when storage is denied or quota exceeded
  }
}

function getPublishedCompanyJobItems(
  studentSkillInputs: { name: string; currentLevel: number }[],
  targetRole: string,
  workPreference: string,
  savedJobIds: string[]
): JobItem[] {
  const allCompanyPostings = safeGetStorage<CompanyJobPosting[]>(
    'company_job_postings',
    initialCompanyJobPostings
  );
  if (!Array.isArray(allCompanyPostings)) return [];

  const published = allCompanyPostings.filter((p) => p.status === 'Published');
  return published.map((p) => {
    const gap = liveJobsService.calculateSkillGaps(
      studentSkillInputs,
      p.requiredSkills,
      p.title,
      p.workplace === 'Remote',
      targetRole,
      workPreference
    );
    return {
      id: p.id,
      companyId: p.companyId,
      title: p.title,
      company: p.companyName,
      location: p.location,
      type: p.type,
      workplace: p.workplace,
      experience: p.experience,
      salary: p.salary,
      matchScore: gap.matchScore,
      requiredSkills: p.requiredSkills,
      matchedSkills: gap.matched,
      missingSkills: gap.missing,
      description: p.description,
      responsibilities: p.responsibilities,
      requirements: p.requirements,
      postedDaysAgo: 1,
      isSaved: savedJobIds.includes(p.id),
      isLive: false,
      isCompanyPartner: true,
      status: p.status,
      applicantsCount: p.applicantsCount || 0,
    };
  });
}

const CareerContext = createContext<CareerContextType | undefined>(undefined);

export const CareerProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile>(() =>
    safeGetStorage<UserProfile>('career_user', initialUserProfile)
  );

  const [isStudentAuthenticated, setIsStudentAuthenticated] = useState<boolean>(() =>
    safeGetStorage<boolean>('career_student_authenticated', true)
  );

  useEffect(() => {
    safeSetStorage('career_student_authenticated', isStudentAuthenticated);
  }, [isStudentAuthenticated]);

  const loginStudent = (_email: string, _password?: string): boolean => {
    setIsStudentAuthenticated(true);
    return true;
  };

  const logoutStudent = (): void => {
    setIsStudentAuthenticated(false);
  };

  const [skills, setSkills] = useState<SkillItem[]>(() =>
    safeGetStorage<SkillItem[]>('career_skills', initialSkills)
  );

  const [jobs, setJobs] = useState<JobItem[]>(() => {
    const parsed = safeGetStorage<JobItem[] | null>('career_jobs', null);
    if (Array.isArray(parsed) && parsed.length > 0 && parsed[0]?.isLive) {
      return parsed;
    }
    return [];
  });

  const [savedJobIds, setSavedJobIds] = useState<string[]>(() =>
    safeGetStorage<string[]>('career_saved_job_ids', [])
  );

  const [liveJobState, setLiveJobState] = useState<LiveJobFetchResult | null>(null);
  const [isLoadingJobs, setIsLoadingJobs] = useState<boolean>(true);

  const [applications, setApplications] = useState<ApplicationItem[]>(() => {
    const stored = safeGetStorage<ApplicationItem[]>('career_applications', initialApplications);
    const applicantRecords = safeGetStorage<any[]>('company_applicant_records', []);
    if (Array.isArray(applicantRecords) && applicantRecords.length > 0) {
      return stored.map((app) => {
        const matchingRecord = applicantRecords.find(
          (r) => r.jobId === app.jobId || r.id === app.id
        );
        if (matchingRecord) {
          return {
            ...app,
            status: matchingRecord.status === 'Screening' ? 'Shortlisted' : matchingRecord.status,
            notes: matchingRecord.notes || app.notes,
            nextStep: matchingRecord.nextStep || app.nextStep,
          };
        }
        return app;
      });
    }
    return stored;
  });

  const [roadmapStages, setRoadmapStages] = useState<RoadmapStage[]>(() => {
    const stored = safeGetStorage<RoadmapStage[] | null>('career_roadmap', null);
    if (Array.isArray(stored) && stored.length > 0) {
      return stored;
    }
    const savedUser = safeGetStorage<UserProfile>('career_user', initialUserProfile);
    const savedSkills = safeGetStorage<SkillItem[]>('career_skills', initialSkills);
    const savedHistory = safeGetStorage<AssessmentHistoryItem[]>('career_assessment_history', initialAssessmentHistory);
    return generatePersonalizedRoadmap(
      savedUser.targetRole,
      savedSkills,
      ['SQL', 'Power BI', 'Statistics'],
      initialRoadmapStages,
      savedHistory
    );
  });

  const [projects, setProjects] = useState<ProjectItem[]>(() =>
    safeGetStorage<ProjectItem[]>('career_projects', initialProjects)
  );

  const [notifications, setNotifications] = useState<NotificationItem[]>(() =>
    safeGetStorage<NotificationItem[]>('career_notifications', initialNotifications)
  );

  const [achievements, setAchievements] = useState<AchievementItem[]>(() =>
    safeGetStorage<AchievementItem[]>('career_achievements', initialAchievements)
  );

  const [githubProjects, setGithubProjects] = useState<GitHubProjectItem[]>(() =>
    safeGetStorage<GitHubProjectItem[]>('career_github_projects', initialGitHubProjects)
  );

  const [linkedinPosts, setLinkedinPosts] = useState<LinkedInPostItem[]>(() =>
    safeGetStorage<LinkedInPostItem[]>('career_linkedin_posts', initialLinkedInPosts)
  );

  const [certificates, setCertificates] = useState<CertificateItem[]>(() =>
    safeGetStorage<CertificateItem[]>('career_certificates', initialCertificates)
  );

  const [progressEvents, setProgressEvents] = useState<CareerProgressEvent[]>(() =>
    safeGetStorage<CareerProgressEvent[]>('career_progress_events', initialProgressEvents)
  );

  const [linkedInSettings, setLinkedInSettings] = useState<LinkedInSettings>(() =>
    safeGetStorage<LinkedInSettings>('career_linkedin_settings', defaultLinkedInSettings)
  );

  const [assessmentHistory, setAssessmentHistory] = useState<AssessmentHistoryItem[]>(() =>
    safeGetStorage<AssessmentHistoryItem[]>('career_assessment_history', initialAssessmentHistory)
  );

  const [interviewHistory, setInterviewHistory] = useState<InterviewHistoryItem[]>(() =>
    safeGetStorage<InterviewHistoryItem[]>('career_interview_history', initialInterviewHistory)
  );

  const [jobAlerts, setJobAlerts] = useState({
    company: 'TechNova / TCS / Deloitte',
    role: 'Data Analyst & BI Engineer',
    emailAlerts: true,
    jobAlerts: true,
    roadmapReminders: true,
    interviewReminders: true,
  });

  const [resumeAnalysis, setResumeAnalysis] = useState<ResumeAnalysisData>(() => {
    const parsed = safeGetStorage<ResumeAnalysisData | null>('career_resume_analysis', null);
    if (parsed && typeof parsed.atsScore === 'number') {
      return parsed;
    }
    return defaultResumeAnalysis;
  });

  const [assessmentScores, setAssessmentScores] = useState<{
    lastTakenDate: string | null;
    overallScore: number;
    categoryScores: Record<string, number>;
  } | null>({
    lastTakenDate: '15 Sep 2026',
    overallScore: 76,
    categoryScores: {
      Python: 88,
      SQL: 78,
      Statistics: 62,
      'Data Analysis': 76,
      'Machine Learning': 70,
      'Power BI': 52,
    },
  });

  // Sync state to LocalStorage with safe wrappers
  useEffect(() => {
    safeSetStorage('career_user', user);
  }, [user]);

  useEffect(() => {
    safeSetStorage('career_skills', skills);
  }, [skills]);

  useEffect(() => {
    safeSetStorage('career_jobs', jobs);
  }, [jobs]);

  useEffect(() => {
    safeSetStorage('career_applications', applications);
  }, [applications]);

  useEffect(() => {
    safeSetStorage('career_roadmap', roadmapStages);
  }, [roadmapStages]);

  useEffect(() => {
    safeSetStorage('career_projects', projects);
  }, [projects]);

  useEffect(() => {
    safeSetStorage('career_saved_job_ids', savedJobIds);
  }, [savedJobIds]);

  useEffect(() => {
    safeSetStorage('career_achievements', achievements);
  }, [achievements]);

  useEffect(() => {
    safeSetStorage('career_github_projects', githubProjects);
  }, [githubProjects]);

  useEffect(() => {
    safeSetStorage('career_linkedin_posts', linkedinPosts);
  }, [linkedinPosts]);

  useEffect(() => {
    safeSetStorage('career_certificates', certificates);
  }, [certificates]);

  useEffect(() => {
    safeSetStorage('career_progress_events', progressEvents);
  }, [progressEvents]);

  useEffect(() => {
    safeSetStorage('career_linkedin_settings', linkedInSettings);
  }, [linkedInSettings]);

  useEffect(() => {
    safeSetStorage('career_notifications', notifications);
  }, [notifications]);

  useEffect(() => {
    safeSetStorage('career_assessment_history', assessmentHistory);
  }, [assessmentHistory]);

  useEffect(() => {
    safeSetStorage('career_interview_history', interviewHistory);
  }, [interviewHistory]);

  useEffect(() => {
    safeSetStorage('career_resume_analysis', resumeAnalysis);
  }, [resumeAnalysis]);

  const updateUser = (updates: Partial<UserProfile>) => {
    setUser((prev) => {
      const nextUser = { ...prev, ...updates };
      if (updates.targetRole && updates.targetRole.trim().toLowerCase() !== prev.targetRole.trim().toLowerCase()) {
        setRoadmapStages((prevStages) =>
          generatePersonalizedRoadmap(updates.targetRole!, skills, [], prevStages, assessmentHistory)
        );
      }
      return nextUser;
    });
  };

  const calibrateRoadmapForRole = (targetRoleOverride?: string) => {
    const activeRole = targetRoleOverride || user.targetRole || 'Data Analyst';
    const roleBenchmarks = getRoleBenchmarkSkills(activeRole, skills);
    const roleGaps = roleBenchmarks
      .filter((b) => {
        const matchingSkill = skills.find((s) => areSkillsMatching(s.name, b.name));
        return (
          !matchingSkill ||
          matchingSkill.currentLevel < b.required ||
          matchingSkill.status === 'Priority Gap' ||
          matchingSkill.status === 'Needs Improvement'
        );
      })
      .map((b) => b.name);

    setRoadmapStages((prev) => {
      return generatePersonalizedRoadmap(activeRole, skills, roleGaps, prev, assessmentHistory);
    });
  };

  const addSkill = (name: string, category: SkillItem['category'] = 'Technical'): { success: boolean; error?: string; skill?: SkillItem } => {
    const trimmed = name.trim();
    if (!trimmed) {
      return { success: false, error: 'Skill name cannot be empty.' };
    }
    const existing = skills.find(s => s.name.toLowerCase() === trimmed.toLowerCase());
    if (existing) {
      addNotification({
        title: 'Skill Exists',
        message: `"${trimmed}" is already present in your skills inventory.`,
        type: 'system',
      });
      return { success: false, error: `"${trimmed}" is already present in your skills inventory.` };
    }

    const newSkill: SkillItem = {
      id: `skill_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: trimmed,
      category,
      currentLevel: 0, // Unverified until tested
      requiredLevel: 75,
      status: 'Priority Gap',
      strongTopics: [],
      weakTopics: [],
      recommendedPractice: [`Take ${trimmed} Competency Assessment to verify knowledge level`],
    };

    setSkills((prev) => {
      const updated = [...prev, newSkill];
      safeSetStorage('career_skills', updated);
      return updated;
    });

    addNotification({
      title: `Skill Added: ${trimmed}`,
      message: `"${trimmed}" added to profile. Click "Test Your Skill" to calculate verified proficiency.`,
      type: 'assessment',
      actionUrl: '/profile',
    });

    return { success: true, skill: newSkill };
  };

  const updateSkillLevel = (id: string, newLevel: number) => {
    setSkills((prev) =>
      prev.map((s) => {
        if (s.id !== id) return s;
        let status: SkillItem['status'] = 'Good';
        if (newLevel >= 80) status = 'Strong';
        else if (newLevel < 50) status = 'Priority Gap';
        else if (newLevel < 65) status = 'Needs Improvement';
        return { ...s, currentLevel: newLevel, status };
      })
    );
  };

  const refreshLiveJobs = async () => {
    setIsLoadingJobs(true);
    const studentSkillInputs = skills.map((s) => ({
      name: s.name,
      currentLevel: s.currentLevel,
    }));
    const companyJobs = getPublishedCompanyJobItems(
      studentSkillInputs,
      user.targetRole,
      user.workPreference || 'Remote',
      savedJobIds
    );

    try {
      const result = await liveJobsService.fetchCurrentJobs();
      setLiveJobState(result);
      if (result.jobs && result.jobs.length > 0) {
        const calibrated = result.jobs.map((job) => {
          const gap = liveJobsService.calculateSkillGaps(
            studentSkillInputs,
            job.requiredSkills,
            job.title,
            job.workplace === 'Remote',
            user.targetRole,
            user.workPreference
          );
          return {
            ...job,
            matchedSkills: gap.matched,
            missingSkills: gap.missing,
            matchScore: gap.matchScore,
            isSaved: savedJobIds.includes(job.id),
            isLive: true,
          };
        });
        setJobs([...companyJobs, ...calibrated]);
      } else {
        setJobs(companyJobs);
      }
    } catch (err) {
      console.warn('Live API request failed or timed out:', err);
      setLiveJobState({
        jobs: [],
        source: 'Unavailable',
        lastUpdated: new Date().toLocaleDateString(),
        isLive: false,
        statusMessage: 'Live job data is temporarily unavailable.'
      });
      setJobs(companyJobs);
    } finally {
      setIsLoadingJobs(false);
    }
  };

  useEffect(() => {
    refreshLiveJobs();
  }, []);

  // Recalibrate live jobs when student skills, targetRole, or workPreference updates
  useEffect(() => {
    setJobs((prevJobs) => {
      if (prevJobs.length === 0) return prevJobs;
      const studentSkillInputs = skills.map((s) => ({
        name: s.name,
        currentLevel: s.currentLevel,
      }));
      return prevJobs.map((job) => {
        const gap = liveJobsService.calculateSkillGaps(
          studentSkillInputs,
          job.requiredSkills,
          job.title,
          job.workplace === 'Remote',
          user.targetRole,
          user.workPreference
        );
        return {
          ...job,
          matchedSkills: gap.matched,
          missingSkills: gap.missing,
          matchScore: gap.matchScore,
        };
      });
    });
  }, [skills, user.targetRole, user.workPreference]);

  const toggleSaveJob = (id: string) => {
    setJobs((prev) =>
      prev.map((j) => (j.id === id ? { ...j, isSaved: !j.isSaved } : j))
    );
    setSavedJobIds((prev) => {
      const next = prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id];
      localStorage.setItem('career_saved_job_ids', JSON.stringify(next));
      return next;
    });
  };

  const savedJobs = jobs.filter((j) => j.isSaved || savedJobIds.includes(j.id));

  const addApplication = (item: Omit<ApplicationItem, 'id'>) => {
    const newApp: ApplicationItem = {
      ...item,
      id: `app_${Date.now()}`,
    };
    setApplications((prev) => [newApp, ...prev]);
    const notifTitle = item.status === 'Application Started'
      ? 'Application Started'
      : 'Application Tracked';
    const notifMessage = item.status === 'Application Started'
      ? `Application started for ${item.role} at ${item.company}. Complete the application on the employer's website.`
      : `Application for ${item.role} at ${item.company} recorded with status: ${item.status}.`;
    addNotification({
      title: notifTitle,
      message: notifMessage,
      type: 'job',
      actionUrl: '/applications',
    });
  };

  const updateApplicationStatus = (id: string, status: ApplicationItem['status']) => {
    setApplications((prev) =>
      prev.map((a) => (a.id === id ? { ...a, status } : a))
    );
  };

  const deleteApplication = (id: string) => {
    setApplications((prev) => prev.filter((a) => a.id !== id));
  };

  const recordProgressEvent = (eventData: Omit<CareerProgressEvent, 'id' | 'date'>): CareerProgressEvent => {
    const todayStr = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    const newEvent: CareerProgressEvent = {
      ...eventData,
      id: `prog_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      date: todayStr,
      isMeaningful: eventData.isMeaningful ?? true,
      linkedInStatus: eventData.linkedInStatus || 'Draft Ready',
    };
    setProgressEvents((prev) => [newEvent, ...prev]);

    // Check if auto-publish is active and event is monitored
    if (
      linkedInSettings.autoPublishApprovedProgress &&
      linkedInSettings.monitoredEventTypes.includes(eventData.eventType) &&
      newEvent.linkedInStatus !== 'Published'
    ) {
      const generated = linkedinService.generatePostFromProgress(newEvent, {
        tone: linkedInSettings.defaultTone,
        includeHashtags: linkedInSettings.includeHashtags,
        includeMetrics: linkedInSettings.includeMetricsByDefault
      });
      const publishedPost: LinkedInPostItem = {
        id: `li_${Date.now()}`,
        title: generated.title,
        hook: generated.hook,
        content: generated.content,
        hashtags: generated.hashtags,
        date: 'Just now',
        postType: eventData.eventType === 'Assessment' ? 'Assessment Progress'
                : eventData.eventType === 'Skill' ? 'Skill Verified'
                : eventData.eventType === 'Roadmap' ? 'Roadmap Milestone'
                : eventData.eventType === 'Project' ? 'Project Launch'
                : 'General',
        progressEventId: newEvent.id,
        status: 'Published',
        publishedUrl: `https://www.linkedin.com/feed/update/urn:li:activity:${Date.now()}/`,
        isAutoPublished: true,
        tone: generated.tone,
        likes: 1,
        comments: 0
      };
      setLinkedinPosts((prev) => [publishedPost, ...prev]);
      newEvent.linkedInStatus = 'Published';
      newEvent.linkedInPostId = publishedPost.id;
    } else if (linkedInSettings.postingPreference === 'auto_create_drafts') {
      const generated = linkedinService.generatePostFromProgress(newEvent, {
        tone: linkedInSettings.defaultTone,
        includeHashtags: linkedInSettings.includeHashtags,
        includeMetrics: linkedInSettings.includeMetricsByDefault
      });
      const draftPost: LinkedInPostItem = {
        id: `li_${Date.now()}`,
        title: generated.title,
        hook: generated.hook,
        content: generated.content,
        hashtags: generated.hashtags,
        date: todayStr,
        progressEventId: newEvent.id,
        postType: eventData.eventType === 'Assessment' ? 'Assessment Progress'
                : eventData.eventType === 'Skill' ? 'Skill Verified'
                : eventData.eventType === 'Roadmap' ? 'Roadmap Milestone'
                : eventData.eventType === 'Project' ? 'Project Launch'
                : 'General',
        status: 'Draft',
        likes: 0,
        comments: 0,
        tone: generated.tone
      };
      setLinkedinPosts((prev) => [draftPost, ...prev]);
      newEvent.linkedInStatus = 'Draft Ready';
      newEvent.linkedInPostId = draftPost.id;
    }

    return newEvent;
  };

  const dismissProgressEvent = (id: string) => {
    setProgressEvents((prev) => prev.filter((p) => p.id !== id));
  };

  const toggleRoadmapStageComplete = (id: string) => {
    setRoadmapStages((prev) => {
      const targetStage = prev.find((s) => s.id === id);
      const wasCompleted = targetStage?.status === 'Completed';

      // 1. Toggle completion of the target stage
      const intermediate = prev.map((s) => {
        if (s.id !== id) return s;
        const newStatus: 'Upcoming' | 'Completed' = wasCompleted ? 'Upcoming' : 'Completed';
        return {
          ...s,
          status: newStatus,
        };
      });

      // 2. Collect all completed skills in the roadmap
      const completedSkillSet = new Set<string>();
      intermediate.forEach((s) => {
        if (s.status === 'Completed') {
          completedSkillSet.add(s.skillName.toLowerCase().trim());
          const canon = canonicalizeSkill(s.skillName);
          if (canon) completedSkillSet.add(canon.toLowerCase().trim());
        }
      });

      // 3. Re-resolve: exactly ONE incomplete task whose prerequisites are met is marked In Progress
      let hasAssignedActive = false;
      const updated = intermediate.map((s) => {
        if (s.status === 'Completed') return s;

        const prereqsMet =
          !s.prerequisites ||
          s.prerequisites.length === 0 ||
          s.prerequisites.every((prereq) => {
            const pLower = prereq.toLowerCase().trim();
            const canon = canonicalizeSkill(prereq)?.toLowerCase().trim();
            return (
              completedSkillSet.has(pLower) ||
              (canon && completedSkillSet.has(canon)) ||
              skills.some((sk) => sk.currentLevel >= 75 && areSkillsMatching(sk.name, prereq))
            );
          });

        if (!hasAssignedActive && prereqsMet) {
          hasAssignedActive = true;
          return { ...s, status: 'In Progress' as const };
        }
        return { ...s, status: 'Upcoming' as const };
      });

      if (!hasAssignedActive) {
        const firstIncomplete = updated.find((s) => s.status !== 'Completed');
        if (firstIncomplete) {
          firstIncomplete.status = 'In Progress';
        }
      }

      const completedCount = updated.filter((s) => s.status === 'Completed').length;
      const calculatedPct = Math.round((completedCount / updated.length) * 100);
      setUser((u) => ({ ...u, careerReadiness: Math.min(96, Math.max(50, 40 + Math.round(calculatedPct * 0.5))) }));

      if (targetStage && !wasCompleted) {
        recordProgressEvent({
          eventType: 'Roadmap',
          title: `Completed "${targetStage.title}" Milestone`,
          description: `Finished ${targetStage.title} modules and tasks on the ${user.targetRole} career pathway.`,
          relatedSkill: targetStage.skillName,
          newValue: 'Milestone Completed',
          isMeaningful: true,
          linkedInStatus: 'Draft Ready',
        });
      }

      return updated;
    });
  };

  const addProject = (item: Omit<ProjectItem, 'id'>) => {
    const newProj: ProjectItem = {
      ...item,
      id: `proj_${Date.now()}`,
      inPortfolio: true,
    };
    setProjects((prev) => [newProj, ...prev]);

    // Section 37 Global Profile Sync: automatically add to GitHub Projects and available in Portfolio
    const repoSlug = item.title.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const newGhRepo: GitHubProjectItem = {
      id: `gh_${Date.now()}`,
      name: item.title,
      repoName: repoSlug,
      description: item.description,
      visibility: 'public',
      projectType: 'Data Project',
      technologies: item.skills,
      stars: 1,
      forks: 0,
      languages: { Python: 85, SQL: 15 },
      lastUpdated: 'Just now',
      url: `https://github.com/snehalkale/${repoSlug}`,
      inPortfolio: true,
    };
    setGithubProjects((prev) => [newGhRepo, ...prev]);

    recordProgressEvent({
      eventType: 'Project',
      title: `Completed Project: ${item.title}`,
      description: item.description,
      relatedSkill: item.skills[0] || 'Data Analytics',
      newValue: 'Production Project',
      isMeaningful: true,
      linkedInStatus: 'Draft Ready',
      sourceMetadata: { projectId: newProj.id },
    });

    addNotification({
      title: 'Project Added to Shared Profile',
      message: `"${item.title}" is now synced across Portfolio, GitHub and LinkedIn Generator.`,
      type: 'github',
      actionUrl: '/github',
    });

    return newProj;
  };

  const toggleSaveProject = (id: string) => {
    setProjects((prev) =>
      prev.map((p) => (p.id === id ? { ...p, isSaved: !p.isSaved } : p))
    );
  };

  const updateProjectStatus = (id: string, status: ProjectItem['status']) => {
    setProjects((prev) =>
      prev.map((p) => (p.id === id ? { ...p, status } : p))
    );
  };

  const toggleProjectInPortfolio = (id: string) => {
    setProjects((prev) =>
      prev.map((p) => (p.id === id ? { ...p, inPortfolio: !p.inPortfolio } : p))
    );
  };

  const addNotification = (item: Omit<NotificationItem, 'id' | 'timestamp' | 'isRead'>) => {
    const newNotif: NotificationItem = {
      ...item,
      id: `notif_${Date.now()}`,
      timestamp: 'Just now',
      isRead: false,
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
    );
  };

  const markAllNotificationsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  };

  const updateJobAlerts = (updates: Partial<CareerContextType['jobAlerts']>) => {
    setJobAlerts((prev) => ({ ...prev, ...updates }));
  };

  const updateResumeAnalysis = (data: Partial<ResumeAnalysisData>) => {
    setResumeAnalysis((prev) => ({ ...prev, ...data }));
    if (data.atsScore) {
      setUser((prev) => ({ ...prev, resumeScore: data.atsScore! }));
    }
  };

  const submitAssessmentResult = (
    overallScore: number,
    categoryScores: Record<string, number>,
    options?: {
      difficulty?: 'Easy' | 'Moderate' | 'Hard';
      questionCount?: number;
      correctCount?: number;
      accuracy?: number;
      isBaseline?: boolean;
      strongTopics?: string[];
      weakTopics?: string[];
      recommendedPractice?: string[];
    }
  ) => {
    setAssessmentScores({
      lastTakenDate: 'Just now',
      overallScore,
      categoryScores,
    });

    // Record in historical attempts
    const strongSkills: string[] = [];
    const weakSkills: string[] = [];
    Object.entries(categoryScores).forEach(([cat, val]) => {
      if (val >= 75) strongSkills.push(cat);
      else weakSkills.push(cat);
    });

    const previousLatest = assessmentHistory[0]?.overallScore || 64;
    const diff = overallScore - previousLatest;

    const newHistoryItem: AssessmentHistoryItem = {
      id: `ah_${Date.now()}`,
      date: 'Today',
      targetRole: user.targetRole,
      overallScore,
      status: 'Completed',
      categoryScores,
      strongSkills,
      weakSkills,
      improvementPct: diff > 0 ? diff : 0,
      difficulty: options?.difficulty || 'Moderate',
      isBaseline: options?.isBaseline ?? true,
      questionCount: options?.questionCount,
      correctCount: options?.correctCount,
      accuracy: options?.accuracy ?? overallScore,
      strongTopics: options?.strongTopics || strongSkills,
      weakTopics: options?.weakTopics || weakSkills,
      recommendedPractice: options?.recommendedPractice,
    };
    setAssessmentHistory((prev) => [newHistoryItem, ...prev]);

    // update skill levels & baseline scores based on category scores
    let updatedSkillsList: SkillItem[] = [];
    setSkills((prev) => {
      const updated = prev.map((s) => {
        const foundScore = categoryScores[s.name];
        if (foundScore !== undefined) {
          let status: SkillItem['status'] = 'Good';
          if (foundScore >= 80) status = 'Strong';
          else if (foundScore < 50) status = 'Priority Gap';
          else if (foundScore < 65) status = 'Needs Improvement';
          return {
            ...s,
            currentLevel: foundScore,
            baselineScore: s.baselineScore !== undefined ? s.baselineScore : foundScore,
            status
          };
        }
        return s;
      });
      updatedSkillsList = updated;
      return updated;
    });

    // Recalibrate roadmap with updated assessment history and skills
    setRoadmapStages((prev) => {
      const updatedHistory = [newHistoryItem, ...assessmentHistory];
      return generatePersonalizedRoadmap(
        user.targetRole,
        updatedSkillsList.length > 0 ? updatedSkillsList : skills,
        [],
        prev,
        updatedHistory
      );
    });

    addNotification({
      title: options?.isBaseline ? 'Baseline Assessment Completed' : 'Assessment Completed',
      message: `Scored ${overallScore}% (${options?.difficulty || 'Moderate'} difficulty) in ${user.targetRole} diagnostic assessment. Readiness updated!`,
      type: 'assessment',
      actionUrl: '/assessment-history',
    });
  };

  const validateRoadmapStage = (params: {
    stageId: string;
    skillName: string;
    score: number;
    difficulty: 'Easy' | 'Moderate' | 'Hard';
    correctCount: number;
    totalQuestions: number;
    strongTopics?: string[];
    weakTopics?: string[];
    recommendedPractice?: string[];
  }): { status: 'passed' | 'review_needed'; score: number } => {
    const todayStr = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    const isPassed = params.score >= 75;
    const validationStatus: 'passed' | 'review_needed' = isPassed ? 'passed' : 'review_needed';
    const accuracy = Math.round((params.correctCount / params.totalQuestions) * 100);

    // 1. Update Roadmap Stages: update stage validation status and unlock next stage if passed
    setRoadmapStages((prevStages) => {
      let nextStageIdToUnlock: string | null = null;

      const updated = prevStages.map((stage, idx) => {
        if (stage.id === params.stageId || stage.skillName.toLowerCase() === params.skillName.toLowerCase()) {
          const newStatus = isPassed ? 'Completed' : 'In Progress';
          if (isPassed && idx + 1 < prevStages.length) {
            nextStageIdToUnlock = prevStages[idx + 1].id;
          }
          return {
            ...stage,
            status: newStatus as 'Completed' | 'In Progress',
            validatedScore: params.score,
            validationStatus,
            lastValidatedDate: todayStr,
            difficulty: params.difficulty,
          };
        }
        return stage;
      });

      if (isPassed && nextStageIdToUnlock) {
        return updated.map((stage) => {
          if (stage.id === nextStageIdToUnlock && stage.status !== 'Completed') {
            return { ...stage, status: 'In Progress' as const };
          }
          return stage;
        });
      }

      return updated;
    });

    // 2. Update Student Skill Profile with verified validated score
    setSkills((prevSkills) => {
      return prevSkills.map((sk) => {
        if (sk.name.toLowerCase() === params.skillName.toLowerCase()) {
          const baseline = sk.baselineScore ?? sk.currentLevel;
          const newLevel = Math.max(sk.currentLevel, params.score);
          let newStatus = sk.status;
          if (params.score >= 80) newStatus = 'Strong';
          else if (params.score >= 65) newStatus = 'Good';
          else if (params.score < 50) newStatus = 'Priority Gap';
          else newStatus = 'Needs Improvement';

          return {
            ...sk,
            currentLevel: newLevel,
            baselineScore: baseline,
            validatedScore: params.score,
            validationStatus,
            status: newStatus,
            lastTestedDate: todayStr,
            improvementPct: params.score - baseline,
            strongTopics: params.strongTopics || sk.strongTopics,
            weakTopics: params.weakTopics || sk.weakTopics,
            recommendedPractice: params.recommendedPractice || sk.recommendedPractice,
          };
        }
        return sk;
      });
    });

    // 3. Record in assessmentHistory
    const validationHistoryItem: AssessmentHistoryItem = {
      id: `ash_val_${Date.now()}`,
      date: todayStr,
      skillName: params.skillName,
      targetRole: user.targetRole,
      overallScore: params.score,
      status: 'Completed',
      categoryScores: { [params.skillName]: params.score },
      strongSkills: params.strongTopics || [],
      weakSkills: params.weakTopics || [],
      strongTopics: params.strongTopics,
      weakTopics: params.weakTopics,
      recommendedPractice: params.recommendedPractice,
      difficulty: params.difficulty,
      isValidation: true,
      stageId: params.stageId,
      questionCount: params.totalQuestions,
      correctCount: params.correctCount,
      accuracy,
    };
    setAssessmentHistory((prev) => [validationHistoryItem, ...prev]);

    // 4. Update career readiness score dynamically
    setUser((prev) => ({
      ...prev,
      careerReadiness: Math.min(
        98,
        Math.max(50, Math.round(prev.careerReadiness * 0.7 + params.score * 0.3))
      ),
    }));

    // 5. Celebration or remediation notifications
    if (isPassed) {
      recordProgressEvent({
        eventType: 'Assessment',
        title: `Stage Validated: ${params.skillName} (${params.score}%)`,
        description: `Passed learning validation with ${params.score}% (${params.difficulty} difficulty). Milestone unlocked on career roadmap!`,
        relatedSkill: params.skillName,
        newValue: `${params.score}% Validated`,
        isMeaningful: true,
        linkedInStatus: 'Draft Ready',
      });

      addNotification({
        title: `Milestone Validated!`,
        message: `Congratulations! You scored ${params.score}% on ${params.skillName} validation test. Next milestone is unlocked.`,
        type: 'roadmap',
        actionUrl: '/roadmap',
      });
    } else {
      addNotification({
        title: `Validation Review Needed`,
        message: `Scored ${params.score}% on ${params.skillName}. Score requirement is 75%. Review the recommended practice tasks and retry!`,
        type: 'assessment',
        actionUrl: '/roadmap',
      });
    }

    return { status: validationStatus, score: params.score };
  };

  const submitSkillAssessmentResult = (result: {
    skillName: string;
    calculatedScore: number;
    knowledgeLevel: 'Beginner' | 'Intermediate' | 'Advanced';
    strongAreas: string[];
    needsImprovement: string[];
    recommendedPractice: string[];
    previousScore?: number;
    improvementPct?: number;
    difficulty?: 'Easy' | 'Moderate' | 'Hard';
    isValidation?: boolean;
    isBaseline?: boolean;
    stageId?: string;
    questionCount?: number;
    correctCount?: number;
    accuracy?: number;
  }) => {
    const todayStr = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    const isPassed = result.calculatedScore >= 75;
    const diff = result.previousScore !== undefined
      ? result.calculatedScore - result.previousScore
      : result.improvementPct || 0;

    let updatedSkillsList: SkillItem[] = [];

    // 1. Upsert Skill in skills list with baseline preservation
    setSkills((prev) => {
      const exists = prev.some(s => s.name.toLowerCase() === result.skillName.toLowerCase());
      let nextSkills: SkillItem[];
      if (exists) {
        nextSkills = prev.map((s) => {
          if (s.name.toLowerCase() === result.skillName.toLowerCase()) {
            const prevLevel = s.currentLevel;
            const baseline = s.baselineScore !== undefined ? s.baselineScore : prevLevel;
            let status: SkillItem['status'] = 'Good';
            if (result.calculatedScore >= 80) status = 'Strong';
            else if (result.calculatedScore < 50) status = 'Priority Gap';
            else if (result.calculatedScore < 65) status = 'Needs Improvement';

            return {
              ...s,
              currentLevel: result.calculatedScore,
              baselineScore: baseline,
              validatedScore: result.isValidation ? result.calculatedScore : s.validatedScore,
              validationStatus: result.isValidation ? (isPassed ? 'passed' : 'review_needed') : s.validationStatus,
              previousLevel: result.previousScore !== undefined ? result.previousScore : prevLevel,
              improvementPct: diff,
              lastTestedDate: todayStr,
              strongTopics: result.strongAreas,
              weakTopics: result.needsImprovement,
              recommendedPractice: result.recommendedPractice,
              status
            };
          }
          return s;
        });
      } else {
        let status: SkillItem['status'] = 'Good';
        if (result.calculatedScore >= 80) status = 'Strong';
        else if (result.calculatedScore < 50) status = 'Priority Gap';
        else if (result.calculatedScore < 65) status = 'Needs Improvement';

        const newSkill: SkillItem = {
          id: `skill_${Date.now()}`,
          name: result.skillName,
          category: 'Technical',
          currentLevel: result.calculatedScore,
          requiredLevel: 75,
          baselineScore: result.isBaseline ? result.calculatedScore : 50,
          validatedScore: result.isValidation ? result.calculatedScore : undefined,
          validationStatus: result.isValidation ? (isPassed ? 'passed' : 'review_needed') : undefined,
          previousLevel: result.previousScore,
          improvementPct: result.improvementPct,
          lastTestedDate: todayStr,
          strongTopics: result.strongAreas,
          weakTopics: result.needsImprovement,
          recommendedPractice: result.recommendedPractice,
          status
        };
        nextSkills = [...prev, newSkill];
      }
      updatedSkillsList = nextSkills;
      return nextSkills;
    });

    // 2. Build complete verified history item
    const newHistoryItem: AssessmentHistoryItem = {
      id: `ash_${Date.now()}`,
      date: todayStr,
      skillName: result.skillName,
      targetRole: user.targetRole,
      overallScore: result.calculatedScore,
      previousScore: result.previousScore,
      improvementPct: diff,
      knowledgeLevel: result.knowledgeLevel,
      status: 'Completed',
      categoryScores: { [result.skillName]: result.calculatedScore },
      strongSkills: result.strongAreas,
      weakSkills: result.needsImprovement,
      strongTopics: result.strongAreas,
      weakTopics: result.needsImprovement,
      recommendedPractice: result.recommendedPractice,
      difficulty: result.difficulty || 'Moderate',
      isValidation: result.isValidation,
      isBaseline: result.isBaseline,
      stageId: result.stageId,
      questionCount: result.questionCount,
      correctCount: result.correctCount,
      accuracy: result.accuracy ?? result.calculatedScore,
    };

    setAssessmentHistory((prev) => [newHistoryItem, ...prev]);

    // 3. Synchronize Career Roadmap stages based on verified assessment result
    setRoadmapStages((prev) => {
      const updatedHistory = [newHistoryItem, ...assessmentHistory];
      const regenerated = generatePersonalizedRoadmap(
        user.targetRole,
        updatedSkillsList.length > 0 ? updatedSkillsList : skills,
        [],
        prev,
        updatedHistory
      );

      // If stageId is provided, also ensure the specific stage status is updated
      if (result.stageId || result.isValidation) {
        return regenerated.map((st) => {
          if (st.id === result.stageId || st.skillName.toLowerCase() === result.skillName.toLowerCase()) {
            return {
              ...st,
              status: isPassed ? 'Completed' : 'In Progress',
              validatedScore: result.calculatedScore,
              validationStatus: isPassed ? 'passed' : 'review_needed',
              lastValidatedDate: todayStr,
              difficulty: result.difficulty || st.difficulty || 'Moderate'
            };
          }
          return st;
        });
      }

      return regenerated;
    });

    // 4. Update assessmentScores
    setAssessmentScores((prev) => ({
      lastTakenDate: todayStr,
      overallScore: result.calculatedScore,
      categoryScores: {
        ...(prev?.categoryScores || {}),
        [result.skillName]: result.calculatedScore
      }
    }));

    // 5. Recalculate user readiness dynamically
    setUser((prev) => ({
      ...prev,
      careerReadiness: Math.min(96, Math.max(50, Math.round(result.calculatedScore * 0.35 + prev.careerReadiness * 0.65)))
    }));

    // 6. Automatic Progress Detection
    if (result.previousScore !== undefined && result.calculatedScore >= result.previousScore + 3) {
      recordProgressEvent({
        eventType: 'Assessment',
        title: `${result.skillName} Score Improved (${result.previousScore}% → ${result.calculatedScore}%)`,
        description: `Verified assessment score improved from ${result.previousScore}% to ${result.calculatedScore}% (+${result.calculatedScore - result.previousScore}%).`,
        relatedSkill: result.skillName,
        previousValue: `${result.previousScore}%`,
        newValue: `${result.calculatedScore}%`,
        delta: `+${result.calculatedScore - result.previousScore}%`,
        isMeaningful: true,
        linkedInStatus: 'Draft Ready',
        sourceMetadata: {
          skill: result.skillName,
          strongTopics: result.strongAreas,
          weakTopics: result.needsImprovement
        }
      });
    }

    addNotification({
      title: result.isValidation ? `Stage Validated: ${result.skillName}` : `Skill Assessed: ${result.skillName}`,
      message: `Scored ${result.calculatedScore}% (${result.difficulty || 'Moderate'} difficulty) in ${result.skillName}. ${isPassed ? 'Passed proficiency threshold!' : 'Practice recommended.'}`,
      type: 'assessment',
      actionUrl: '/assessment-history',
    });
  };


  // Career Hub: Achievements
  const addAchievement = (item: Omit<AchievementItem, 'id'>) => {
    const newAch: AchievementItem = {
      ...item,
      id: `ach_${Date.now()}`,
    };
    setAchievements((prev) => [newAch, ...prev]);

    recordProgressEvent({
      eventType: 'Achievement',
      title: `Added Achievement: ${item.title}`,
      description: `${item.organization} • ${item.category}: ${item.description}`,
      relatedSkill: item.skillsRelated?.[0],
      newValue: item.category,
      isMeaningful: true,
      linkedInStatus: 'Draft Ready'
    });

    addNotification({
      title: 'Achievement Added',
      message: `"${item.title}" added to your shared profile, resume, and portfolio.`,
      type: 'achievement',
      actionUrl: '/achievements',
    });

    return newAch;
  };

  const updateAchievement = (id: string, updates: Partial<AchievementItem>) => {
    setAchievements((prev) =>
      prev.map((a) => (a.id === id ? { ...a, ...updates } : a))
    );
  };

  const deleteAchievement = (id: string) => {
    setAchievements((prev) => prev.filter((a) => a.id !== id));
  };

  const toggleAchievementInResume = (id: string) => {
    setAchievements((prev) =>
      prev.map((a) => (a.id === id ? { ...a, inResume: !a.inResume } : a))
    );
  };

  const toggleAchievementInPortfolio = (id: string) => {
    setAchievements((prev) =>
      prev.map((a) => (a.id === id ? { ...a, inPortfolio: !a.inPortfolio } : a))
    );
  };

  // Career Hub: GitHub
  const addGitHubRepository = (item: Omit<GitHubProjectItem, 'id' | 'stars' | 'forks' | 'lastUpdated'>) => {
    const newRepo: GitHubProjectItem = {
      ...item,
      id: `gh_${Date.now()}`,
      stars: 1,
      forks: 0,
      lastUpdated: 'Just now',
    };
    setGithubProjects((prev) => [newRepo, ...prev]);

    recordProgressEvent({
      eventType: 'GitHub',
      title: `Connected Repository: ${item.repoName}`,
      description: `Added project repository "${item.repoName}" (${item.technologies.slice(0, 3).join(', ')}) to portfolio.`,
      relatedSkill: item.technologies[0] || 'Software Engineering',
      newValue: 'Public Repository',
      isMeaningful: true,
      linkedInStatus: 'Draft Ready'
    });

    addNotification({
      title: 'GitHub Repository Created',
      message: `Repository "${item.repoName}" created and synced with your portfolio.`,
      type: 'github',
      actionUrl: '/github',
    });

    return newRepo;
  };

  const updateGitHubProject = (id: string, updates: Partial<GitHubProjectItem>) => {
    setGithubProjects((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updates } : p))
    );
  };

  const connectGitHubAccount = (username: string) => {
    setUser((prev) => ({ ...prev, githubConnected: true, githubUsername: username }));
    addNotification({
      title: 'GitHub Connected',
      message: `Linked GitHub account @${username} to your Career Hub.`,
      type: 'github',
      actionUrl: '/github',
    });
  };

  // Career Hub: Certificates
  const addCertificate = (item: Omit<CertificateItem, 'id' | 'createdAt'>): CertificateItem => {
    const todayStr = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    const newCert: CertificateItem = {
      ...item,
      id: `cert_${Date.now()}`,
      createdAt: todayStr,
      verificationStatus: 'Verified',
      skillsGained: item.skillsGained && item.skillsGained.length > 0 ? item.skillsGained : [`${item.relatedSkill} Proficiency`],
      linkedInPostGenerated: false,
    };

    setCertificates((prev) => [newCert, ...prev]);

    // Also link or add skill if not existing
    if (item.relatedSkill) {
      const exists = skills.some((s) => s.name.toLowerCase() === item.relatedSkill.toLowerCase());
      if (!exists) {
        addSkill(item.relatedSkill, 'Technical');
      }
    }

    // Meaningful progress event
    const event = recordProgressEvent({
      eventType: 'Certificate',
      title: `Earned ${item.title} (${item.organization})`,
      description: `Verified ${item.certificateType.toLowerCase()} certificate in ${item.relatedSkill} issued by ${item.organization}.`,
      relatedSkill: item.relatedSkill,
      newValue: item.organization,
      isMeaningful: true,
      linkedInStatus: linkedInSettings.autoPublishApprovedProgress ? 'Published' : 'Draft Ready',
      sourceMetadata: { certificateId: newCert.id }
    });

    if (linkedInSettings.autoPublishApprovedProgress) {
      const postDraft = linkedinService.generatePostFromCertificate(newCert, {
        tone: linkedInSettings.defaultTone,
        includeHashtags: linkedInSettings.includeHashtags,
        includeCredentialUrl: linkedInSettings.includeCredentialUrls,
      });
      const published = publishLinkedInPost({
        title: postDraft.title,
        hook: postDraft.hook,
        content: postDraft.content,
        hashtags: postDraft.hashtags,
        postType: 'Certificate',
        certificateId: newCert.id,
        progressEventId: event.id,
        status: 'Published',
        publishedUrl: `https://www.linkedin.com/feed/update/urn:li:activity:${Date.now()}/`,
        isAutoPublished: true,
        tone: postDraft.tone
      });
      newCert.linkedInPostGenerated = true;
      newCert.linkedInPostId = published.id;
    }

    addNotification({
      title: 'Certificate Added',
      message: `"${item.title}" from ${item.organization} verified and ready for LinkedIn share.`,
      type: 'achievement',
      actionUrl: '/certificates',
    });

    return newCert;
  };

  const updateCertificate = (id: string, updates: Partial<CertificateItem>) => {
    setCertificates((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...updates } : c))
    );
  };

  const deleteCertificate = (id: string) => {
    setCertificates((prev) => prev.filter((c) => c.id !== id));
  };


  // Career Hub: LinkedIn
  const updateLinkedInSettings = (updates: Partial<LinkedInSettings>) => {
    setLinkedInSettings((prev) => ({ ...prev, ...updates }));
    if (updates.isConnected !== undefined) {
      setUser((prev) => ({ ...prev, linkedinConnected: updates.isConnected! }));
    }
  };

  const publishLinkedInPost = (post: Omit<LinkedInPostItem, 'id' | 'date' | 'likes' | 'comments'>): LinkedInPostItem => {
    const newPost: LinkedInPostItem = {
      ...post,
      id: `li_${Date.now()}`,
      date: 'Just now',
      likes: 1,
      comments: 0,
      status: 'Published',
      publishedUrl: post.publishedUrl || `https://www.linkedin.com/feed/update/urn:li:activity:${Date.now()}/`,
    };
    setLinkedinPosts((prev) => [newPost, ...prev]);

    if (post.achievementId) {
      setAchievements((prev) =>
        prev.map((a) => (a.id === post.achievementId ? { ...a, linkedinPosted: true } : a))
      );
    }
    if (post.certificateId) {
      setCertificates((prev) =>
        prev.map((c) => (c.id === post.certificateId ? { ...c, linkedInPostGenerated: true, linkedInPostId: newPost.id } : c))
      );
    }
    if (post.progressEventId) {
      setProgressEvents((prev) =>
        prev.map((e) => (e.id === post.progressEventId ? { ...e, linkedInStatus: 'Published', linkedInPostId: newPost.id } : e))
      );
    }

    addNotification({
      title: 'LinkedIn Post Published',
      message: `Your post "${post.title}" is now published on LinkedIn!`,
      type: 'linkedin',
      actionUrl: '/linkedin',
    });

    return newPost;
  };

  const publishLinkedInPostById = async (id: string): Promise<{ success: boolean; url?: string; message?: string }> => {
    const post = linkedinPosts.find((p) => p.id === id);
    if (!post) {
      return { success: false, message: 'Post not found' };
    }
    const publicUrl = `https://www.linkedin.com/feed/update/urn:li:activity:${Date.now()}/`;
    setLinkedinPosts((prev) =>
      prev.map((p) =>
        p.id === id
          ? {
              ...p,
              status: 'Published',
              publishedUrl: publicUrl,
              date: 'Just now',
            }
          : p
      )
    );

    if (post.progressEventId) {
      setProgressEvents((prev) =>
        prev.map((e) =>
          e.id === post.progressEventId ? { ...e, linkedInStatus: 'Published', linkedInPostId: id } : e
        )
      );
    }
    if (post.certificateId) {
      setCertificates((prev) =>
        prev.map((c) =>
          c.id === post.certificateId ? { ...c, linkedInPostGenerated: true, linkedInPostId: id } : c
        )
      );
    }

    addNotification({
      title: 'LinkedIn Post Live',
      message: `Your post "${post.title}" is published on LinkedIn!`,
      type: 'linkedin',
      actionUrl: '/linkedin',
    });

    return { success: true, url: publicUrl };
  };

  const connectLinkedInAccount = async (): Promise<void> => {
    const res = await linkedinService.requestOAuthConnection();
    if (res.success) {
      setUser((prev) => ({ ...prev, linkedinConnected: true }));
      setLinkedInSettings((prev) => ({
        ...prev,
        ...res.settings,
        isConnected: true
      }));
      addNotification({
        title: 'LinkedIn Account Linked',
        message: `Successfully connected LinkedIn account (@${user.name}) with verified authorization.`,
        type: 'linkedin',
        actionUrl: '/linkedin',
      });
    }
  };

  const disconnectLinkedInAccount = () => {
    setUser((prev) => ({ ...prev, linkedinConnected: false }));
    setLinkedInSettings((prev) => ({ ...prev, isConnected: false }));
    addNotification({
      title: 'LinkedIn Disconnected',
      message: 'LinkedIn profile disconnected. Your post drafts and history remain saved locally.',
      type: 'system',
      actionUrl: '/linkedin',
    });
  };

  const createLinkedInDraftFromCertificate = (certificateId: string): LinkedInPostItem => {
    const cert = certificates.find((c) => c.id === certificateId);
    if (!cert) {
      throw new Error(`Certificate with ID ${certificateId} not found.`);
    }
    const generated = linkedinService.generatePostFromCertificate(cert, {
      tone: linkedInSettings.defaultTone,
      includeHashtags: linkedInSettings.includeHashtags,
      includeCredentialUrl: linkedInSettings.includeCredentialUrls,
    });

    const newPost: LinkedInPostItem = {
      id: `li_${Date.now()}`,
      title: generated.title,
      hook: generated.hook,
      content: generated.content,
      hashtags: generated.hashtags,
      date: 'Draft',
      certificateId: cert.id,
      postType: 'Certificate',
      status: 'Draft',
      likes: 0,
      comments: 0,
      tone: generated.tone,
      includeCredentialUrl: linkedInSettings.includeCredentialUrls,
      includeMetrics: true,
    };

    setLinkedinPosts((prev) => [newPost, ...prev]);
    setCertificates((prev) =>
      prev.map((c) => (c.id === cert.id ? { ...c, linkedInPostGenerated: true, linkedInPostId: newPost.id } : c))
    );

    addNotification({
      title: 'LinkedIn Draft Created',
      message: `Generated post draft for "${cert.title}". Review and edit before publishing.`,
      type: 'linkedin',
      actionUrl: '/linkedin',
    });

    return newPost;
  };

  const createLinkedInDraftFromProgress = (progressEventId: string): LinkedInPostItem => {
    const event = progressEvents.find((e) => e.id === progressEventId);
    if (!event) {
      throw new Error(`Progress event with ID ${progressEventId} not found.`);
    }
    const generated = linkedinService.generatePostFromProgress(event, {
      tone: linkedInSettings.defaultTone,
      includeHashtags: linkedInSettings.includeHashtags,
      includeMetrics: linkedInSettings.includeMetricsByDefault,
    });

    let postType: LinkedInPostItem['postType'] = 'General';
    if (event.eventType === 'Assessment') postType = 'Assessment Progress';
    else if (event.eventType === 'Skill') postType = 'Skill Verified';
    else if (event.eventType === 'Roadmap') postType = 'Roadmap Milestone';
    else if (event.eventType === 'Project') postType = 'Project Launch';
    else if (event.eventType === 'Certificate') postType = 'Certificate';
    else if (event.eventType === 'Placement') postType = 'Placement Readiness';
    else if (event.eventType === 'Interview') postType = 'Mock Interview';
    else if (event.eventType === 'Achievement') postType = 'Hackathon / Achievement';

    const newPost: LinkedInPostItem = {
      id: `li_${Date.now()}`,
      title: generated.title,
      hook: generated.hook,
      content: generated.content,
      hashtags: generated.hashtags,
      date: 'Draft',
      progressEventId: event.id,
      postType,
      status: 'Draft',
      likes: 0,
      comments: 0,
      tone: generated.tone,
      includeMetrics: linkedInSettings.includeMetricsByDefault,
    };

    setLinkedinPosts((prev) => [newPost, ...prev]);
    setProgressEvents((prev) =>
      prev.map((ev) => (ev.id === event.id ? { ...ev, linkedInStatus: 'Draft Ready', linkedInPostId: newPost.id } : ev))
    );

    addNotification({
      title: 'LinkedIn Draft Created',
      message: `Generated draft for milestone "${event.title}". Ready for review.`,
      type: 'linkedin',
      actionUrl: '/linkedin',
    });

    return newPost;
  };

  const addLinkedInPost = (post: Omit<LinkedInPostItem, 'id' | 'date' | 'likes' | 'comments'>): LinkedInPostItem => {
    const newPost: LinkedInPostItem = {
      ...post,
      id: `li_${Date.now()}`,
      date: post.status === 'Published' ? 'Just now' : 'Draft',
      likes: post.status === 'Published' ? 1 : 0,
      comments: 0,
    };
    setLinkedinPosts((prev) => [newPost, ...prev]);
    return newPost;
  };

  const updateLinkedInPost = (id: string, updates: Partial<LinkedInPostItem>) => {
    setLinkedinPosts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updates } : p))
    );
  };

  const deleteLinkedInPost = (id: string) => {
    setLinkedinPosts((prev) => prev.filter((p) => p.id !== id));
  };

  const recordInterviewAttempt = (item: Omit<InterviewHistoryItem, 'id'>) => {
    const newRecord: InterviewHistoryItem = {
      ...item,
      id: `ih_${Date.now()}`,
    };
    setInterviewHistory((prev) => [newRecord, ...prev]);

    // Meaningful progress event if good score
    if (item.score >= 75) {
      recordProgressEvent({
        eventType: 'Interview',
        title: `Completed Mock Interview: ${item.interviewType} (${item.score}%)`,
        description: `Achieved ${item.score}% passing score in ${item.role} technical readiness interview simulation.`,
        newValue: `${item.score}%`,
        isMeaningful: true,
        linkedInStatus: 'Draft Ready'
      });
    }

    addNotification({
      title: 'Interview Practice Scored',
      message: `Completed ${item.interviewType} session with ${item.score}% score.`,
      type: 'system',
      actionUrl: '/interview/history',
    });
  };

  return (
    <CareerContext.Provider
      value={{
        user,
        updateUser,
        isStudentAuthenticated,
        loginStudent,
        logoutStudent,
        skills,
        addSkill,
        updateSkillLevel,
        jobs,
        liveJobState,
        isLoadingJobs,
        refreshLiveJobs,
        toggleSaveJob,
        savedJobs,
        applications,
        addApplication,
        updateApplicationStatus,
        deleteApplication,
        roadmapStages,
        toggleRoadmapStageComplete,
        calibrateRoadmapForRole,
        projects,
        addProject,
        toggleSaveProject,
        updateProjectStatus,
        toggleProjectInPortfolio,
        notifications,
        addNotification,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        jobAlerts,
        updateJobAlerts,
        resumeAnalysis,
        updateResumeAnalysis,
        assessmentScores,
        submitAssessmentResult,
        validateRoadmapStage,
        submitSkillAssessmentResult,
        achievements,
        addAchievement,
        updateAchievement,
        deleteAchievement,
        toggleAchievementInResume,
        toggleAchievementInPortfolio,
        githubProjects,
        addGitHubRepository,
        updateGitHubProject,
        connectGitHubAccount,

        // Career Hub: Certificates
        certificates,
        addCertificate,
        updateCertificate,
        deleteCertificate,

        // Career Hub: Career Progress Events
        progressEvents,
        recordProgressEvent,
        dismissProgressEvent,

        // Career Hub: LinkedIn
        linkedinPosts,
        linkedInSettings,
        updateLinkedInSettings,
        publishLinkedInPost,
        publishLinkedInPostById,
        connectLinkedInAccount,
        disconnectLinkedInAccount,
        createLinkedInDraftFromCertificate,
        createLinkedInDraftFromProgress,
        addLinkedInPost,
        updateLinkedInPost,
        deleteLinkedInPost,

        // Histories
        assessmentHistory,
        interviewHistory,
        recordInterviewAttempt,
      }}
    >
      {children}
    </CareerContext.Provider>
  );
};

export const useCareer = () => {
  const context = useContext(CareerContext);
  if (!context) {
    throw new Error('useCareer must be used within a CareerProvider');
  }
  return context;
};
