import React, { createContext, useContext, useState, useEffect } from 'react';
import { CompanyProfile, CompanyUser, CompanyJobPosting, CompanyApplicantRecord } from '../types.ts';
import {
  initialCompanyProfiles,
  initialCompanyUsers,
  initialCompanyJobPostings,
  initialCompanyApplicants,
} from '../data/companyMockData.ts';

export interface RegisterCompanyParams {
  companyName: string;
  industry: string;
  location: string;
  website: string;
  size?: string;
  description?: string;
  recruiterName: string;
  recruiterEmail: string;
  recruiterTitle: string;
  password?: string;
}

export interface CreatePostingParams {
  title: string;
  type: 'Full-time' | 'Internship' | 'Contract';
  workplace: 'Remote' | 'On-site' | 'Hybrid';
  location: string;
  experience: string;
  salary: string;
  requiredSkills: string[];
  description: string;
  responsibilities: string[];
  requirements: string[];
  status?: 'Published' | 'Draft' | 'Closed';
}

export interface SubmitStudentApplicationParams {
  jobId: string;
  studentId: string;
  candidateName: string;
  candidateEmail: string;
  candidateCollege: string;
  candidateDegree: string;
  candidateBranch?: string;
  candidateGraduationYear: string;
  verifiedSkills: string[];
  matchScore: number;
  resumeFileName?: string;
  atsScore?: number;
  notes?: string;
}

export interface CompanyContextType {
  // Auth & Session
  companyUser: CompanyUser | null;
  companyProfile: CompanyProfile | null;
  isAuthenticated: boolean;
  loginCompany: (email: string, password?: string) => { success: boolean; error?: string };
  registerCompany: (params: RegisterCompanyParams) => { success: boolean; error?: string };
  logoutCompany: () => void;
  updateCompanyProfile: (updates: Partial<CompanyProfile>) => { success: boolean; error?: string };

  // Multi-Company Data
  allCompanies: CompanyProfile[];
  
  // Scoped to Logged-in Company
  postings: CompanyJobPosting[];
  allPostings: CompanyJobPosting[];
  applicants: CompanyApplicantRecord[];
  allApplicants: CompanyApplicantRecord[];
  
  // Posting Management with Multi-Company Authorization
  createPosting: (params: CreatePostingParams) => { success: boolean; posting?: CompanyJobPosting; error?: string };
  updatePosting: (id: string, updates: Partial<CompanyJobPosting>) => { success: boolean; error?: string };
  changePostingStatus: (id: string, status: 'Published' | 'Draft' | 'Closed') => { success: boolean; error?: string };
  deletePosting: (id: string) => { success: boolean; error?: string };

  // Candidate Management with Student Privacy Boundaries
  updateApplicantStatus: (
    applicantId: string,
    status: CompanyApplicantRecord['status'],
    notes?: string,
    nextStep?: string
  ) => { success: boolean; error?: string };
  getApplicantById: (applicantId: string) => CompanyApplicantRecord | null;

  // Student Application Submission Bridge
  submitStudentApplication: (
    params: SubmitStudentApplicationParams
  ) => { success: boolean; applicant?: CompanyApplicantRecord; error?: string };

  // Security helper
  isAuthorizedForCompany: (targetCompanyId: string) => boolean;
}

function safeGetStorage<T>(key: string, fallback: T): T {
  try {
    if (typeof window === 'undefined' || !window.localStorage) {
      return fallback;
    }
    const saved = window.localStorage.getItem(key);
    if (!saved || saved === 'undefined' || saved === 'null') {
      return fallback;
    }
    const parsed = JSON.parse(saved);
    return parsed !== null && parsed !== undefined ? parsed : fallback;
  } catch {
    return fallback;
  }
}

function safeSetStorage<T>(key: string, value: T): void {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(key, JSON.stringify(value));
    }
  } catch {
    // Graceful no-op
  }
}

const CompanyContext = createContext<CompanyContextType | undefined>(undefined);

export const CompanyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Stored state
  const [companyUser, setCompanyUser] = useState<CompanyUser | null>(() =>
    safeGetStorage<CompanyUser | null>('company_active_user', initialCompanyUsers[0])
  );

  const [companyProfiles, setCompanyProfiles] = useState<CompanyProfile[]>(() =>
    safeGetStorage<CompanyProfile[]>('company_all_profiles', initialCompanyProfiles)
  );

  const [companyUsers, setCompanyUsers] = useState<CompanyUser[]>(() =>
    safeGetStorage<CompanyUser[]>('company_all_users', initialCompanyUsers)
  );

  const [allPostings, setAllPostings] = useState<CompanyJobPosting[]>(() =>
    safeGetStorage<CompanyJobPosting[]>('company_job_postings', initialCompanyJobPostings)
  );

  const [allApplicants, setAllApplicants] = useState<CompanyApplicantRecord[]>(() =>
    safeGetStorage<CompanyApplicantRecord[]>('company_applicant_records', initialCompanyApplicants)
  );

  // Sync state to localStorage
  useEffect(() => {
    safeSetStorage('company_active_user', companyUser);
  }, [companyUser]);

  useEffect(() => {
    safeSetStorage('company_all_profiles', companyProfiles);
  }, [companyProfiles]);

  useEffect(() => {
    safeSetStorage('company_all_users', companyUsers);
  }, [companyUsers]);

  useEffect(() => {
    safeSetStorage('company_job_postings', allPostings);
  }, [allPostings]);

  useEffect(() => {
    safeSetStorage('company_applicant_records', allApplicants);
  }, [allApplicants]);

  // Derived current company profile
  const companyProfile = companyUser
    ? companyProfiles.find((p) => p.id === companyUser.companyId) || null
    : null;

  // Authorization helper: Check if active session owns the target company data
  const isAuthorizedForCompany = (targetCompanyId: string): boolean => {
    if (!companyUser || !companyUser.companyId) return false;
    return companyUser.companyId === targetCompanyId;
  };

  // Scoped postings for the logged-in company only
  const postings = companyUser
    ? allPostings.filter((job) => job.companyId === companyUser.companyId)
    : [];

  // Scoped applicants for the logged-in company only
  // Privacy rule: Company can ONLY view applicants who applied to its own postings
  const applicants = companyUser
    ? allApplicants.filter((app) => app.companyId === companyUser.companyId)
    : [];

  // Login handler
  const loginCompany = (email: string, _password?: string): { success: boolean; error?: string } => {
    const trimmedEmail = email.trim().toLowerCase();
    const foundUser = companyUsers.find((u) => u.email.toLowerCase() === trimmedEmail);

    if (!foundUser) {
      // If email matches a company profile contact email, look it up or auto-match
      const matchedProfile = companyProfiles.find((p) => p.contactEmail.toLowerCase() === trimmedEmail);
      if (matchedProfile) {
        const fallbackUser: CompanyUser = {
          id: `cuser_${Date.now()}`,
          email: matchedProfile.contactEmail,
          name: `${matchedProfile.name} Recruiter`,
          role: 'company',
          companyId: matchedProfile.id,
          jobTitle: 'Hiring Manager',
          createdAt: new Date().toISOString(),
        };
        setCompanyUsers((prev) => [...prev, fallbackUser]);
        setCompanyUser(fallbackUser);
        return { success: true };
      }
      return { success: false, error: 'No company account found with this email. Please register.' };
    }

    setCompanyUser(foundUser);
    return { success: true };
  };

  // Registration handler
  const registerCompany = (params: RegisterCompanyParams): { success: boolean; error?: string } => {
    if (!params.companyName.trim() || !params.recruiterEmail.trim() || !params.recruiterName.trim()) {
      return { success: false, error: 'Company name, recruiter name, and work email are required.' };
    }

    const trimmedEmail = params.recruiterEmail.trim().toLowerCase();
    const existing = companyUsers.find((u) => u.email.toLowerCase() === trimmedEmail);
    if (existing) {
      return { success: false, error: 'An account with this recruiter email already exists. Please sign in.' };
    }

    const companyId = `comp_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const userId = `cuser_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

    const newProfile: CompanyProfile = {
      id: companyId,
      name: params.companyName.trim(),
      industry: params.industry.trim() || 'Technology & Services',
      location: params.location.trim() || 'Pune / Remote',
      website: params.website.trim() || 'https://example.com',
      size: params.size || '50–200 employees',
      description: params.description?.trim() || `${params.companyName.trim()} is hiring student talent for technical roles and internships.`,
      contactEmail: trimmedEmail,
      verified: true,
      foundedYear: String(new Date().getFullYear()),
      headquarters: params.location.trim() || 'India',
    };

    const newUser: CompanyUser = {
      id: userId,
      email: trimmedEmail,
      name: params.recruiterName.trim(),
      role: 'company',
      companyId: companyId,
      jobTitle: params.recruiterTitle.trim() || 'Campus Recruitment Manager',
      createdAt: new Date().toISOString(),
    };

    setCompanyProfiles((prev) => [...prev, newProfile]);
    setCompanyUsers((prev) => [...prev, newUser]);
    setCompanyUser(newUser);

    return { success: true };
  };

  const logoutCompany = () => {
    setCompanyUser(null);
  };

  const updateCompanyProfile = (updates: Partial<CompanyProfile>): { success: boolean; error?: string } => {
    if (!companyUser || !companyProfile) {
      return { success: false, error: 'Unauthorized: Must be logged in to update profile.' };
    }

    setCompanyProfiles((prev) =>
      prev.map((p) => (p.id === companyProfile.id ? { ...p, ...updates } : p))
    );
    return { success: true };
  };

  // Create posting with ownership validation
  const createPosting = (
    params: CreatePostingParams
  ): { success: boolean; posting?: CompanyJobPosting; error?: string } => {
    if (!companyUser || !companyProfile) {
      return { success: false, error: 'Unauthorized: Recruiter sign-in required to create postings.' };
    }

    if (!params.title.trim()) {
      return { success: false, error: 'Job title is required.' };
    }

    const newPosting: CompanyJobPosting = {
      id: `job_${companyUser.companyId}_${Date.now()}`,
      companyId: companyUser.companyId,
      companyName: companyProfile.name,
      title: params.title.trim(),
      type: params.type || 'Full-time',
      workplace: params.workplace || 'Hybrid',
      location: params.location.trim() || companyProfile.location,
      experience: params.experience.trim() || 'Fresh Graduates / Interns',
      salary: params.salary.trim() || 'Competitive Stipend / Package',
      requiredSkills: params.requiredSkills || [],
      description: params.description.trim() || `Exciting opening for ${params.title.trim()} at ${companyProfile.name}.`,
      responsibilities: params.responsibilities && params.responsibilities.length > 0
        ? params.responsibilities
        : ['Collaborate with core technical teams', 'Deliver verified milestones'],
      requirements: params.requirements && params.requirements.length > 0
        ? params.requirements
        : ['Strong foundational problem-solving skills', 'Relevant coursework'],
      status: params.status || 'Published',
      postedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      viewsCount: 0,
      applicantsCount: 0,
    };

    setAllPostings((prev) => [newPosting, ...prev]);
    return { success: true, posting: newPosting };
  };

  // Update posting with STRICT multi-company isolation check
  const updatePosting = (
    id: string,
    updates: Partial<CompanyJobPosting>
  ): { success: boolean; error?: string } => {
    if (!companyUser) {
      return { success: false, error: 'Unauthorized: Recruiter login required.' };
    }

    const targetPosting = allPostings.find((p) => p.id === id);
    if (!targetPosting) {
      return { success: false, error: 'Job posting not found.' };
    }

    // Role-based Multi-Company Isolation: One company cannot edit another company's posting
    if (targetPosting.companyId !== companyUser.companyId) {
      return {
        success: false,
        error: 'Forbidden: You cannot modify postings belonging to another company.',
      };
    }

    setAllPostings((prev) =>
      prev.map((p) =>
        p.id === id
          ? {
              ...p,
              ...updates,
              companyId: targetPosting.companyId, // Immutable
              updatedAt: new Date().toISOString(),
            }
          : p
      )
    );

    return { success: true };
  };

  // Change posting status (Publish, Draft, Close) with ownership check
  const changePostingStatus = (
    id: string,
    status: 'Published' | 'Draft' | 'Closed'
  ): { success: boolean; error?: string } => {
    return updatePosting(id, { status });
  };

  // Delete posting with STRICT multi-company isolation check
  const deletePosting = (id: string): { success: boolean; error?: string } => {
    if (!companyUser) {
      return { success: false, error: 'Unauthorized: Recruiter login required.' };
    }

    const targetPosting = allPostings.find((p) => p.id === id);
    if (!targetPosting) {
      return { success: false, error: 'Job posting not found.' };
    }

    if (targetPosting.companyId !== companyUser.companyId) {
      return {
        success: false,
        error: 'Forbidden: You cannot delete postings belonging to another company.',
      };
    }

    setAllPostings((prev) => prev.filter((p) => p.id !== id));
    return { success: true };
  };

  // Update applicant review status with ownership check
  const updateApplicantStatus = (
    applicantId: string,
    status: CompanyApplicantRecord['status'],
    notes?: string,
    nextStep?: string
  ): { success: boolean; error?: string } => {
    if (!companyUser) {
      return { success: false, error: 'Unauthorized: Recruiter login required.' };
    }

    const targetApplicant = allApplicants.find((a) => a.id === applicantId);
    if (!targetApplicant) {
      return { success: false, error: 'Applicant record not found.' };
    }

    if (targetApplicant.companyId !== companyUser.companyId) {
      return {
        success: false,
        error: 'Forbidden: You cannot view or modify applicants for another company.',
      };
    }

    setAllApplicants((prev) =>
      prev.map((a) =>
        a.id === applicantId
          ? {
              ...a,
              status,
              notes: notes !== undefined ? notes : a.notes,
              nextStep: nextStep !== undefined ? nextStep : a.nextStep,
            }
          : a
      )
    );

    // Sync to student career_applications in localStorage if matching jobId exists
    try {
      const rawStudentApps = localStorage.getItem('career_applications');
      if (rawStudentApps) {
        const studentApps = JSON.parse(rawStudentApps);
        if (Array.isArray(studentApps)) {
          const mappedApps = studentApps.map((sa: any) => {
            if (sa.jobId === targetApplicant.jobId || sa.id === targetApplicant.id) {
              return {
                ...sa,
                status: status === 'Screening' ? 'Shortlisted' : status,
                notes: notes !== undefined ? notes : sa.notes,
                nextStep: nextStep !== undefined ? nextStep : sa.nextStep,
              };
            }
            return sa;
          });
          localStorage.setItem('career_applications', JSON.stringify(mappedApps));
        }
      }
    } catch {
      // Graceful local storage sync
    }

    return { success: true };
  };

  // Student Privacy boundary: Never expose applicant data to companies that the student did not apply to
  const getApplicantById = (applicantId: string): CompanyApplicantRecord | null => {
    if (!companyUser) return null;
    const applicant = allApplicants.find((a) => a.id === applicantId);
    if (!applicant) return null;
    if (applicant.companyId !== companyUser.companyId) return null;
    return applicant;
  };

  // Student Application Submission Bridge
  const submitStudentApplication = (
    params: SubmitStudentApplicationParams
  ): { success: boolean; applicant?: CompanyApplicantRecord; error?: string } => {
    const targetJob = allPostings.find((j) => j.id === params.jobId);
    if (!targetJob) {
      return { success: false, error: 'Job opening not found or has been removed.' };
    }

    if (targetJob.status !== 'Published') {
      return { success: false, error: 'This position is currently not open for new applications.' };
    }

    // Prevent duplicate applications
    const isDuplicate = allApplicants.some(
      (a) =>
        a.jobId === params.jobId &&
        (a.studentId === params.studentId ||
          a.candidateEmail.toLowerCase() === params.candidateEmail.trim().toLowerCase())
    );

    if (isDuplicate) {
      return {
        success: false,
        error: 'You have already submitted an application for this position.',
      };
    }

    const newApplicant: CompanyApplicantRecord = {
      id: `appl_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      jobId: targetJob.id,
      jobTitle: targetJob.title,
      companyId: targetJob.companyId,
      studentId: params.studentId,
      candidateName: params.candidateName.trim(),
      candidateEmail: params.candidateEmail.trim(),
      candidateCollege: params.candidateCollege.trim(),
      candidateDegree: params.candidateDegree.trim(),
      candidateBranch: params.candidateBranch?.trim() || 'AI & Data Science',
      candidateGraduationYear: params.candidateGraduationYear.trim(),
      appliedDate: new Date().toISOString().split('T')[0],
      status: 'Applied',
      matchScore: params.matchScore,
      verifiedSkills: params.verifiedSkills,
      notes: params.notes || `Direct student application. ATS Score: ${params.atsScore || 84}/100.`,
      hasSharedResume: true,
      hasSharedPortfolio: true,
      resumeFileName: params.resumeFileName || 'Snehal_Kale_Resume_DataAnalyst.pdf',
      nextStep: 'Application submitted. Pending recruiter screening.',
    };

    setAllApplicants((prev) => [newApplicant, ...prev]);

    // Increment applicantsCount on target posting
    setAllPostings((prev) =>
      prev.map((j) =>
        j.id === targetJob.id ? { ...j, applicantsCount: (j.applicantsCount || 0) + 1 } : j
      )
    );

    return { success: true, applicant: newApplicant };
  };

  return (
    <CompanyContext.Provider
      value={{
        companyUser,
        companyProfile,
        isAuthenticated: !!companyUser,
        loginCompany,
        registerCompany,
        logoutCompany,
        updateCompanyProfile,
        allCompanies: companyProfiles,
        postings,
        allPostings,
        applicants,
        allApplicants,
        createPosting,
        updatePosting,
        changePostingStatus,
        deletePosting,
        updateApplicantStatus,
        getApplicantById,
        submitStudentApplication,
        isAuthorizedForCompany,
      }}
    >
      {children}
    </CompanyContext.Provider>
  );
};

export const useCompany = (): CompanyContextType => {
  const context = useContext(CompanyContext);
  if (!context) {
    throw new Error('useCompany must be used within a CompanyProvider');
  }
  return context;
};
