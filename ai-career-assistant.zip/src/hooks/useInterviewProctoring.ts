import { useState, useEffect, useRef, useCallback } from 'react';
import { IntegrityViolationEvent } from '../services/interviewService.ts';
import {
  FacePresenceMonitor,
  FaceDetectorStatus,
  FaceDetectorAdapter
} from '../services/faceDetectionService.ts';

export interface ProctoringWarningModal {
  count: number;
  title: string;
  description: string;
  timestamp: string;
  type: IntegrityViolationEvent['type'];
}

export interface UseInterviewProctoringOptions {
  isActive: boolean;
  initialMediaStream: MediaStream | null;
  videoElementRef?: React.RefObject<HTMLVideoElement | null>;
  onTerminate: (data: {
    reason: string;
    warningCount: number;
    integrityEvents: IntegrityViolationEvent[];
  }) => void;
  faceDetectionOptions?: {
    enabled?: boolean;
    intervalMs?: number;
    gracePeriodMs?: number;
    maxTransientErrors?: number;
    detectorAdapter?: FaceDetectorAdapter;
    getCurrentTime?: () => number;
  };
}

/**
 * Checks whether an incoming violation event should be suppressed by the deduplication cooldown.
 * Rapid concurrent OS events (e.g. window blur + tab switch + fullscreen exit) within 1800ms are suppressed.
 * 'face_missing' is explicitly exempt from the cooldown because FacePresenceMonitor already enforces
 * an unbroken 5-second grace period and deduplicates continuous absence internally.
 */
export function isViolationSuppressedByCooldown(
  type: IntegrityViolationEvent['type'],
  now: number,
  lastViolationTime: number,
  cooldownMs = 1800
): boolean {
  if (type === 'face_missing') {
    return false;
  }
  if (lastViolationTime === 0) {
    return false;
  }
  return now - lastViolationTime < cooldownMs;
}

export function useInterviewProctoring({
  isActive,
  initialMediaStream,
  videoElementRef,
  onTerminate,
  faceDetectionOptions
}: UseInterviewProctoringOptions) {
  // Streams & Device States
  const [mediaStream, setMediaStream] = useState<MediaStream | null>(initialMediaStream);
  const [isCameraActive, setIsCameraActive] = useState<boolean>(true);
  const [isMicActive, setIsMicActive] = useState<boolean>(true);
  const [mediaError, setMediaError] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(() => !!document.fullscreenElement);

  // Proctoring States
  const [warningCount, setWarningCount] = useState<number>(0);
  const [isTerminated, setIsTerminated] = useState<boolean>(false);
  const [terminationReason, setTerminationReason] = useState<string | null>(null);
  const [integrityEvents, setIntegrityEvents] = useState<IntegrityViolationEvent[]>([]);
  const [activeWarningModal, setActiveWarningModal] = useState<ProctoringWarningModal | null>(null);
  const [latestWarningBanner, setLatestWarningBanner] = useState<string | null>(null);

  // Face Detection Proctoring States
  const [faceDetectorStatus, setFaceDetectorStatus] = useState<FaceDetectorStatus>('idle');
  const [faceDetectorMessage, setFaceDetectorMessage] = useState<string>('');
  const [isFacePresent, setIsFacePresent] = useState<boolean | null>(null);

  const internalVideoRef = useRef<HTMLVideoElement | null>(null);
  const activeVideoRef = videoElementRef || internalVideoRef;
  const facePresenceMonitorRef = useRef<FacePresenceMonitor | null>(null);

  // Deduplication & State Guard Refs
  const lastViolationTimeRef = useRef<number>(0);
  const isPageHiddenRef = useRef<boolean>(false);
  const isWindowBlurredRef = useRef<boolean>(false);
  const wasFullscreenRef = useRef<boolean>(typeof document !== 'undefined' ? !!document.fullscreenElement : false);
  const cameraViolatedRef = useRef<boolean>(false);
  const micViolatedRef = useRef<boolean>(false);
  const violationCountRef = useRef<number>(0);
  const isTerminatedRef = useRef<boolean>(false);
  const bannerTimeoutRef = useRef<any>(null);

  // Synchronized refs to prevent dependency instability from triggering Effect restarts
  const onTerminateRef = useRef(onTerminate);
  onTerminateRef.current = onTerminate;

  const mediaStreamRef = useRef<MediaStream | null>(mediaStream);
  mediaStreamRef.current = mediaStream;

  const integrityEventsRef = useRef<IntegrityViolationEvent[]>([]);
  integrityEventsRef.current = integrityEvents;

  // Keep mediaStream in sync if initialMediaStream updates
  useEffect(() => {
    if (initialMediaStream && !mediaStream) {
      setMediaStream(initialMediaStream);
    }
  }, [initialMediaStream]);

  // Subtle Web Audio alert beep
  const playWarningBeep = useCallback(() => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime);
      osc.frequency.setValueAtTime(880, ctx.currentTime + 0.1);
      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.35);
    } catch {
      // AudioContext unavailable or blocked by browser policy
    }
  }, []);

  // Centralized Violation Recorder with Deduplication & Strict 3-Warning Flow
  const recordViolation = useCallback(
    (type: IntegrityViolationEvent['type'], description: string) => {
      if (!isActive) {
        console.debug('[recordViolation] Ignored: proctoring not active');
        return;
      }
      if (isTerminatedRef.current) {
        console.debug('[recordViolation] Ignored: interview is already terminated');
        return;
      }

      const now = Date.now();
      // Deduplication cooldown: ignore rapid concurrent events (e.g. tab switch + window blur) within 1800ms.
      // face_missing is exempt so that valid absence warnings are not suppressed by preceding events.
      if (isViolationSuppressedByCooldown(type, now, lastViolationTimeRef.current, 1800)) {
        console.debug('[recordViolation] Ignored: suppressed by cooldown for event type:', type);
        return;
      }
      lastViolationTimeRef.current = now;

      const newCount = violationCountRef.current + 1;
      violationCountRef.current = newCount;
      setWarningCount(newCount);
      console.debug('[recordViolation] Violation successfully recorded:', type, 'New warning count:', newCount);

      const timestamp = new Date().toLocaleTimeString('en-US', { hour12: false });
      const event: IntegrityViolationEvent = { type, timestamp, description };

      setIntegrityEvents((prev) => [...prev, event]);
      playWarningBeep();

      // Warning Banner update
      if (bannerTimeoutRef.current) clearTimeout(bannerTimeoutRef.current);
      setLatestWarningBanner(`Warning ${Math.min(newCount, 3)} of 3: ${description}`);
      bannerTimeoutRef.current = setTimeout(() => {
        setLatestWarningBanner(null);
      }, 7000);

      if (newCount === 1) {
        console.debug('[recordViolation] Setting activeWarningModal for Warning 1 (type:', type, ')');
        setActiveWarningModal({
          count: 1,
          title: 'Warning 1 of 3',
          description,
          timestamp,
          type
        });
      } else if (newCount === 2) {
        console.debug('[recordViolation] Setting activeWarningModal for Warning 2 (type:', type, ')');
        setActiveWarningModal({
          count: 2,
          title: 'Warning 2 of 3',
          description,
          timestamp,
          type
        });
      } else if (newCount === 3) {
        console.debug('[recordViolation] Setting activeWarningModal for Warning 3 (type:', type, ')');
        setActiveWarningModal({
          count: 3,
          title: 'Warning 3 of 3',
          description: `${description} One more proctoring violation will terminate this interview.`,
          timestamp,
          type
        });
      } else if (newCount >= 4) {
        console.debug('[recordViolation] Violation 4 reached: triggering immediate termination');
        // Violation 4: Immediate Termination!
        isTerminatedRef.current = true;
        setIsTerminated(true);
        setTerminationReason(description);
        setActiveWarningModal(null);
        setLatestWarningBanner(null);

        // Safely destroy face presence monitor
        if (facePresenceMonitorRef.current) {
          facePresenceMonitorRef.current.destroy();
          facePresenceMonitorRef.current = null;
        }

        // Safely end media tracks
        if (mediaStreamRef.current) {
          mediaStreamRef.current.getTracks().forEach((track) => track.stop());
        }
        setIsCameraActive(false);
        setIsMicActive(false);

        // Safely exit fullscreen
        if (document.fullscreenElement) {
          document.exitFullscreen().catch(() => {});
        }

        onTerminateRef.current?.({
          reason: description,
          warningCount: 4,
          integrityEvents: [...integrityEventsRef.current, event]
        });
      }
    },
    [isActive, playWarningBeep]
  );

  const recordViolationRef = useRef(recordViolation);
  recordViolationRef.current = recordViolation;

  // Fullscreen Management
  const requestFullscreen = useCallback(async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
        setIsFullscreen(true);
        wasFullscreenRef.current = true;
      }
    } catch (err) {
      console.warn('Fullscreen request blocked or not permitted:', err);
    }
  }, []);

  const exitFullscreen = useCallback(async () => {
    try {
      if (document.fullscreenElement) {
        await document.exitFullscreen();
        setIsFullscreen(false);
      }
    } catch (err) {
      console.warn('Exit fullscreen error:', err);
    }
  }, []);

  // Camera Re-initialization
  const retryCamera = useCallback(async () => {
    try {
      setMediaError(null);
      const newStream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 640 }, height: { ideal: 360 } },
        audio: true
      });
      setMediaStream(newStream);
      setIsCameraActive(true);
      setIsMicActive(true);
      cameraViolatedRef.current = false;
      micViolatedRef.current = false;
    } catch (err: any) {
      setMediaError('Failed to re-initialize camera: ' + (err.message || 'Permission denied'));
    }
  }, []);

  // Dismiss Warning Modal
  const acknowledgeWarning = useCallback(() => {
    setActiveWarningModal(null);
  }, []);

  // Voluntary session termination
  const terminateSession = useCallback(
    (reason = 'Candidate manually ended the session.') => {
      if (isTerminatedRef.current) return;
      isTerminatedRef.current = true;
      setIsTerminated(true);
      setTerminationReason(reason);
      if (facePresenceMonitorRef.current) {
        facePresenceMonitorRef.current.destroy();
        facePresenceMonitorRef.current = null;
      }
      if (mediaStream) {
        mediaStream.getTracks().forEach((track) => track.stop());
      }
      setIsCameraActive(false);
      setIsMicActive(false);
      if (document.fullscreenElement) {
        document.exitFullscreen().catch(() => {});
      }
    },
    [mediaStream]
  );

  // 1. Initial Fullscreen attempt when interview becomes active
  useEffect(() => {
    if (isActive && !isTerminated) {
      requestFullscreen().catch(() => {});
    }
  }, [isActive, isTerminated, requestFullscreen]);

  // 2. Tab / Page Visibility Monitoring
  useEffect(() => {
    if (!isActive) return;

    const handleVisibilityChange = () => {
      if (!isActive || isTerminatedRef.current) return;

      if (document.visibilityState === 'hidden') {
        if (!isPageHiddenRef.current) {
          isPageHiddenRef.current = true;
          recordViolation(
            'tab_switch',
            'Interview page was left. Please remain on the interview screen.'
          );
        }
      } else if (document.visibilityState === 'visible') {
        // Wait until page becomes visible again before allowing another visibility-related warning
        isPageHiddenRef.current = false;
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [isActive, recordViolation]);

  // 3. Window Blur / Focus Loss Monitoring (with Deduplication against Tab Switch)
  useEffect(() => {
    if (!isActive) return;

    const handleWindowBlur = () => {
      if (!isActive || isTerminatedRef.current) return;

      // Avoid duplicate warnings when blur and visibilitychange fire for the same action (tab switch)
      if (document.hidden || isPageHiddenRef.current) {
        return;
      }

      const now = Date.now();
      if (now - lastViolationTimeRef.current < 1800) {
        return;
      }

      if (!isWindowBlurredRef.current) {
        isWindowBlurredRef.current = true;
        recordViolation(
          'window_blur',
          'Interview focus was lost because the interview window was left. Please return to the interview screen.'
        );
      }
    };

    const handleWindowFocus = () => {
      // When focus returns, allow monitoring again
      isWindowBlurredRef.current = false;
    };

    window.addEventListener('blur', handleWindowBlur);
    window.addEventListener('focus', handleWindowFocus);
    return () => {
      window.removeEventListener('blur', handleWindowBlur);
      window.removeEventListener('focus', handleWindowFocus);
    };
  }, [isActive, recordViolation]);

  // 4. Fullscreen Exit Monitoring
  useEffect(() => {
    if (!isActive) return;

    const handleFullscreenChange = () => {
      if (!isActive || isTerminatedRef.current) return;

      const active = !!document.fullscreenElement;
      setIsFullscreen(active);

      if (active) {
        wasFullscreenRef.current = true;
      } else {
        // If candidate previously entered fullscreen and now exited during active interview
        if (wasFullscreenRef.current) {
          wasFullscreenRef.current = false;
          recordViolation(
            'fullscreen_exit',
            'Fullscreen mode was exited. Please return to fullscreen to continue the interview.'
          );
        }
      }
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, [isActive, recordViolation]);

  // 5. MediaStream Camera Track Interruption
  useEffect(() => {
    if (!mediaStream || !isActive) return;
    const videoTrack = mediaStream.getVideoTracks()[0];
    if (!videoTrack) return;

    const handleVideoEnded = () => {
      setIsCameraActive(false);
      setMediaError('Camera access was interrupted. Camera must remain enabled during the interview.');
      if (!cameraViolatedRef.current) {
        cameraViolatedRef.current = true;
        recordViolation(
          'camera_interruption',
          'Camera access was interrupted. Camera must remain enabled during the interview.'
        );
      }
    };

    videoTrack.addEventListener('ended', handleVideoEnded);
    return () => {
      videoTrack.removeEventListener('ended', handleVideoEnded);
    };
  }, [mediaStream, isActive, recordViolation]);

  // 6. MediaStream Microphone Track Interruption
  useEffect(() => {
    if (!mediaStream || !isActive) return;
    const audioTrack = mediaStream.getAudioTracks()[0];
    if (!audioTrack) return;

    const handleAudioEnded = () => {
      setIsMicActive(false);
      setMediaError('Microphone access was interrupted. Microphone must remain enabled during the interview.');
      if (!micViolatedRef.current) {
        micViolatedRef.current = true;
        recordViolation(
          'mic_interruption',
          'Microphone access was interrupted. Microphone must remain enabled during the interview.'
        );
      }
    };

    audioTrack.addEventListener('ended', handleAudioEnded);
    return () => {
      audioTrack.removeEventListener('ended', handleAudioEnded);
    };
  }, [mediaStream, isActive, recordViolation]);

  // 7. Navigation Away / Browser BeforeUnload Safeguard
  useEffect(() => {
    if (!isActive || isTerminated) return;

    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = 'You have an active proctored interview. Leaving will terminate your session.';
      return e.returnValue;
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [isActive, isTerminated]);

  // 8. Stream Track & Detector Disposal on Component Unmount
  useEffect(() => {
    return () => {
      if (bannerTimeoutRef.current) clearTimeout(bannerTimeoutRef.current);
      if (facePresenceMonitorRef.current) {
        facePresenceMonitorRef.current.destroy();
        facePresenceMonitorRef.current = null;
      }
      if (mediaStream) {
        mediaStream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [mediaStream]);

  // 9. Face-Presence Detection Monitoring
  useEffect(() => {
    if (!isActive || isTerminated || !isCameraActive) {
      if (facePresenceMonitorRef.current) {
        facePresenceMonitorRef.current.destroy();
        facePresenceMonitorRef.current = null;
      }
      return;
    }

    if (faceDetectionOptions?.enabled === false) {
      setFaceDetectorStatus('idle');
      setFaceDetectorMessage('Face presence detection is disabled.');
      return;
    }

    const monitor = new FacePresenceMonitor({
      adapter: faceDetectionOptions?.detectorAdapter,
      intervalMs: faceDetectionOptions?.intervalMs ?? 1000,
      gracePeriodMs: faceDetectionOptions?.gracePeriodMs ?? 5000,
      maxTransientErrors: faceDetectionOptions?.maxTransientErrors ?? 3,
      getCurrentTime: faceDetectionOptions?.getCurrentTime,
      onViolation: (type, description) => {
        console.debug('[FacePresenceMonitor onViolation callback fired]:', type);
        recordViolationRef.current(type, description);
      },
      onStatusChange: (status, message) => {
        setFaceDetectorStatus(status);
        if (message) {
          setFaceDetectorMessage(message);
        }
      },
      onPresenceChange: (present) => {
        setIsFacePresent(present);
      }
    });

    facePresenceMonitorRef.current = monitor;

    // Start detector polling using the active video element ref
    monitor.start(() => activeVideoRef.current).catch((err) => {
      console.warn('FacePresenceMonitor start encountered an issue:', err);
    });

    return () => {
      monitor.destroy();
      facePresenceMonitorRef.current = null;
    };
  }, [
    isActive,
    isTerminated,
    isCameraActive,
    faceDetectionOptions?.enabled,
    faceDetectionOptions?.intervalMs,
    faceDetectionOptions?.gracePeriodMs,
    faceDetectionOptions?.maxTransientErrors,
    faceDetectionOptions?.detectorAdapter,
    faceDetectionOptions?.getCurrentTime,
    activeVideoRef
  ]);

  return {
    mediaStream,
    setMediaStream,
    isCameraActive,
    isMicActive,
    mediaError,
    isFullscreen,
    warningCount,
    isTerminated,
    terminationReason,
    integrityEvents,
    activeWarningModal,
    latestWarningBanner,
    faceDetectorStatus,
    faceDetectorMessage,
    isFacePresent,
    setVideoElement: (el: HTMLVideoElement | null) => {
      internalVideoRef.current = el;
    },
    requestFullscreen,
    exitFullscreen,
    retryCamera,
    acknowledgeWarning,
    terminateSession,
    recordViolation
  };
}
