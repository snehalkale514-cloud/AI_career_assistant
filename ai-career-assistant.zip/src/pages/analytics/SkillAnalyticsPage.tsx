import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  BarChart2,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  Compass,
  ArrowRight,
  Plus,
  Sparkles,
  Layers,
  Target
} from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';
import { ProgressBar } from '../../components/common/ProgressBar.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';
import { AIInsight } from '../../components/common/AIInsight.tsx';
import {
  areSkillsMatching,
  getRoleBenchmarkSkills,
  isJobRelevantForCandidate,
  isJobRelevantToRole
} from '../../services/liveJobsService.ts';

export const SkillAnalyticsPage: React.FC = () => {
  const navigate = useNavigate();
  const { skills, user, jobs, addSkill } = useCareer();
  const [addedRoadmapSuccess, setAddedRoadmapSuccess] = useState<string | null>(null);

  // Filter jobs relevant to user's targetRole and location/work preference
  const relevantJobs = (jobs || []).filter((j) => isJobRelevantForCandidate(j, user));

  // Dynamically derive benchmarks for user.targetRole (never defaulting to Data Analyst if another role is chosen)
  const benchmarkDefinitions = getRoleBenchmarkSkills(user.targetRole, skills, relevantJobs);

  const targetBenchmarks = benchmarkDefinitions.map((b) => {
    const studentSkill = skills.find((s) => areSkillsMatching(s.name, b.name));
    const current = studentSkill ? studentSkill.currentLevel : 0;
    const gap = Math.max(0, b.required - current);

    let priority = 'Satisfied';
    let status: 'Strong' | 'Good' | 'Needs Improvement' | 'Priority Gap' = 'Strong';

    if (gap >= 30) {
      priority = 'Critical';
      status = 'Priority Gap';
    } else if (gap >= 15) {
      priority = 'High';
      status = 'Needs Improvement';
    } else if (gap > 0) {
      priority = 'Moderate';
      status = 'Good';
    }

    return {
      name: b.name,
      current,
      required: b.required,
      gap,
      priority,
      status,
    };
  });

  const overallScore = targetBenchmarks.length > 0
    ? Math.round(targetBenchmarks.reduce((acc, b) => acc + b.current, 0) / targetBenchmarks.length)
    : 0;

  const strongSkills = targetBenchmarks.filter((b) => b.gap === 0 || b.status === 'Strong' || b.current >= b.required);
  const topGaps = targetBenchmarks.filter((b) => b.gap > 0).sort((a, b) => b.gap - a.gap);

  const handleAddToRoadmap = (skillName: string) => {
    if (!skills.some((s) => s.name.toLowerCase() === skillName.toLowerCase())) {
      addSkill(skillName);
    }
    setAddedRoadmapSuccess(skillName);
    setTimeout(() => {
      setAddedRoadmapSuccess(null);
      navigate('/app/roadmap');
    }, 1200);
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/dashboard" />
      </div>

      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-600 flex items-center gap-1">
              <BarChart2 className="w-3.5 h-3.5" />
              Recruitment Benchmarks
            </span>
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            Skill Analytics &amp; Gap Analysis
          </h2>
          <p className="text-xs text-slate-500">
            Compare your verified competencies against recruiter requisitions for <strong>{user.targetRole}</strong>.
          </p>
        </div>

        <button
          onClick={() => navigate('/app/roadmap')}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors cursor-pointer"
        >
          <Compass className="w-3.5 h-3.5" />
          <span>View Career Roadmap</span>
        </button>
      </div>

      {addedRoadmapSuccess && (
        <div className="p-3.5 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>
              <strong>{addedRoadmapSuccess}</strong> has been added to your priority roadmap queue! Redirecting...
            </span>
          </div>
        </div>
      )}

      {/* AI Diagnostic Insight */}
      <AIInsight
        type="AI ANALYSIS"
        title="Recruiter Skill Gap Assessment"
        actionLabel="Go to Roadmap"
        onAction={() => navigate('/app/roadmap')}
      >
        <p className="font-semibold text-slate-900 text-sm">
          {topGaps.length > 0
            ? `Critical Focus: ${topGaps.slice(0, 2).map((g) => `${g.name} (-${g.gap}%)`).join(' and ')}`
            : `All Core Requisitions for ${user.targetRole} Satisfied`}
        </p>
        <p className="text-slate-600 text-xs mt-1">
          {strongSkills.length > 0
            ? `Your verified competencies in ${strongSkills.slice(0, 3).map((s) => s.name).join(', ')} provide a strong technical foundation for ${user.targetRole}. `
            : `Building proficiency in foundational ${user.targetRole} competencies will accelerate your placement readiness. `}
          {topGaps.length > 0
            ? `Bridging ${topGaps[0].name} to ${topGaps[0].required}% will elevate your placement readiness for recruiter screening rounds.`
            : 'Maintain readiness through mock interviews and hands-on repository projects.'}
        </p>
      </AIInsight>

      {/* Top 3 High Level Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-xs space-y-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Overall Skill Score
          </span>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-mono font-bold text-slate-900 tabular-nums">
              {overallScore}%
            </span>
            <span className="text-xs font-medium text-blue-600 font-mono">Role Readiness</span>
          </div>
          <p className="text-2xs text-slate-500">Across {targetBenchmarks.length} key {user.targetRole} domains</p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-xs space-y-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Strong Competencies
          </span>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-mono font-bold text-blue-700 tabular-nums">{strongSkills.length} Skills</span>
            <span className="text-xs text-slate-500 truncate max-w-[140px]">{strongSkills.slice(0, 3).map((s) => s.name).join(', ') || 'Building profile'}</span>
          </div>
          <p className="text-2xs text-slate-500">Exceeds standard entry thresholds</p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-xs space-y-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Priority Skill Gaps
          </span>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-mono font-bold text-amber-600 tabular-nums">{topGaps.length} Gaps</span>
            <span className="text-xs text-slate-500 truncate max-w-[140px]">
              {topGaps.slice(0, 2).map((g) => `${g.name} (${g.gap}%)`).join(', ') || 'None identified'}
            </span>
          </div>
          <p className="text-2xs text-slate-500">Mapped to active roadmap milestones</p>
        </div>
      </div>

      {/* Main Section: Skill Gap Analysis Comparison Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-6 sm:p-8 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-4 border-b border-slate-100 gap-2">
          <div>
            <h3 className="text-base font-bold text-slate-900 tracking-tight">
              Skill Gap Matrix: Your Skills vs. Target Role Requirements
            </h3>
            <p className="text-xs text-slate-500">
              Target Role: <strong>{user.targetRole}</strong> (Derived from 50+ campus recruitment specs)
            </p>
          </div>
          <span className="text-2xs font-mono text-slate-500 bg-slate-100 px-2.5 py-1 rounded">
            Threshold: 75%+
          </span>
        </div>

        {/* Matrix List / Grid */}
        <div className="space-y-4">
          {targetBenchmarks.map((item) => (
            <div
              key={item.name}
              className={`p-4 rounded-xl border transition-all ${
                item.priority === 'Critical'
                  ? 'border-amber-300 bg-amber-50/20'
                  : 'border-slate-200 bg-slate-50/40 hover:bg-slate-50/80'
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                {/* Skill Name & Status */}
                <div className="min-w-44 space-y-1">
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-bold text-slate-900">{item.name}</h4>
                    <span
                      className={`text-3xs px-2 py-0.5 rounded font-semibold ${
                        item.priority === 'Critical'
                          ? 'bg-amber-100 text-amber-800'
                          : item.priority === 'Satisfied'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}
                    >
                      {item.priority === 'Critical' ? 'Priority Gap' : item.status}
                    </span>
                  </div>
                  <p className="text-2xs text-slate-500">
                    Required: <span className="font-mono font-medium">{item.required}%</span>
                  </p>
                </div>

                {/* Progress Bar & Visual Comparison */}
                <div className="flex-1 max-w-lg space-y-1.5">
                  <div className="flex justify-between text-2xs font-mono">
                    <span className="text-slate-600">Current: <strong>{item.current}%</strong></span>
                    <span className="text-slate-500">Target: <strong>{item.required}%</strong></span>
                  </div>
                  <div className="relative h-3 w-full bg-slate-200 rounded-full overflow-hidden">
                    {/* Required marker line */}
                    <div
                      className="absolute top-0 bottom-0 w-0.5 bg-slate-800 z-10"
                      style={{ left: `${item.required}%` }}
                      title={`Target Requirement: ${item.required}%`}
                    />
                    {/* Current level bar */}
                    <div
                      className={`h-full rounded-full ${
                        item.current >= item.required
                          ? 'bg-emerald-600'
                          : item.gap > 25
                          ? 'bg-amber-500'
                          : 'bg-blue-600'
                      }`}
                      style={{ width: `${item.current}%` }}
                    />
                  </div>
                </div>

                {/* Gap Metric & Action */}
                <div className="flex items-center justify-between md:justify-end gap-4 shrink-0">
                  <div className="text-right">
                    <span
                      className={`text-xs font-mono font-bold block ${
                        item.gap === 0 ? 'text-emerald-600' : 'text-amber-600'
                      }`}
                    >
                      {item.gap === 0 ? 'Exceeded' : `-${item.gap}% Gap`}
                    </span>
                    <span className="text-3xs text-slate-400">vs Live Job Spec</span>
                  </div>

                  {item.gap > 0 ? (
                    <button
                      onClick={() => handleAddToRoadmap(item.name)}
                      className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-2xs transition-colors cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add to Roadmap</span>
                    </button>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 px-3 py-1.5 bg-emerald-50 rounded-lg border border-emerald-200">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Mastered</span>
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Structured Category Breakdowns */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl border border-slate-200/90 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-emerald-700 font-bold text-xs">
            <CheckCircle2 className="w-4 h-4" />
            <span>Strong Skills (Above 80%)</span>
          </div>
          <ul className="text-xs text-slate-700 space-y-2">
            <li className="flex justify-between p-2 rounded bg-slate-50">
              <span>Python (Pandas &amp; EDA)</span>
              <span className="font-mono font-bold text-slate-900">88%</span>
            </li>
            <li className="flex justify-between p-2 rounded bg-slate-50">
              <span>Advanced Excel Modeling</span>
              <span className="font-mono font-bold text-slate-900">80%</span>
            </li>
          </ul>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200/90 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-blue-700 font-bold text-xs">
            <TrendingUp className="w-4 h-4" />
            <span>Good (65% – 79%)</span>
          </div>
          <ul className="text-xs text-slate-700 space-y-2">
            <li className="flex justify-between p-2 rounded bg-slate-50">
              <span>SQL Queries &amp; Joins</span>
              <span className="font-mono font-bold text-slate-900">72%</span>
            </li>
            <li className="flex justify-between p-2 rounded bg-slate-50">
              <span>Data Visualization &amp; Charts</span>
              <span className="font-mono font-bold text-slate-900">68%</span>
            </li>
            <li className="flex justify-between p-2 rounded bg-slate-50">
              <span>Machine Learning Basics</span>
              <span className="font-mono font-bold text-slate-900">65%</span>
            </li>
          </ul>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200/90 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-amber-700 font-bold text-xs">
            <AlertTriangle className="w-4 h-4" />
            <span>Priority Gaps (Below 60%)</span>
          </div>
          <ul className="text-xs text-slate-700 space-y-2">
            <li className="flex justify-between p-2 rounded bg-amber-50/70 border border-amber-200/60">
              <span>Power BI &amp; DAX Modeling</span>
              <span className="font-mono font-bold text-amber-800">42%</span>
            </li>
            <li className="flex justify-between p-2 rounded bg-amber-50/70 border border-amber-200/60">
              <span>Inferential Statistics</span>
              <span className="font-mono font-bold text-amber-800">55%</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};
