import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  History,
  TrendingUp,
  ArrowRight,
  RotateCcw,
  CheckCircle2,
  Calendar,
  Award,
  Sparkles,
  ChevronRight,
  ShieldCheck,
  AlertTriangle,
  SlidersHorizontal,
  Target,
  BarChart3,
  Check,
  BookOpen,
  Filter
} from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';
import { ProgressBar } from '../../components/common/ProgressBar.tsx';

type FilterType = 'all' | 'baseline' | 'validation';

export const AssessmentHistoryPage: React.FC = () => {
  const navigate = useNavigate();
  const { assessmentHistory, user, skills, roadmapStages } = useCareer();

  const [activeFilter, setActiveFilter] = useState<FilterType>('all');

  // Baseline attempt (explicitly flagged or oldest attempt)
  const baselineAttempt = useMemo(() => {
    return (
      assessmentHistory.find((item) => item.isBaseline) ||
      assessmentHistory[assessmentHistory.length - 1] || {
        id: 'baseline_default',
        date: 'Aug 10, 2026',
        overallScore: 62,
        targetRole: user.targetRole,
        categoryScores: { Python: 60, SQL: 58, Statistics: 45, 'Data Analysis': 62, 'Power BI': 35 },
        difficulty: 'Moderate' as const,
        isBaseline: true,
      }
    );
  }, [assessmentHistory, user.targetRole]);

  // Latest attempt
  const latestAttempt = useMemo(() => {
    return assessmentHistory[0] || baselineAttempt;
  }, [assessmentHistory, baselineAttempt]);

  const overallGrowthDelta = latestAttempt.overallScore - baselineAttempt.overallScore;

  // Filtered attempt list
  const filteredAttempts = useMemo(() => {
    if (activeFilter === 'baseline') {
      return assessmentHistory.filter((item) => item.isBaseline || (!item.isValidation && !item.stageId));
    }
    if (activeFilter === 'validation') {
      return assessmentHistory.filter((item) => item.isValidation || Boolean(item.stageId));
    }
    return assessmentHistory;
  }, [assessmentHistory, activeFilter]);

  // Dynamic skill-by-skill before-vs-after matrix
  const skillComparisons = useMemo(() => {
    return skills.map((skill) => {
      const baseScore =
        skill.baselineScore !== undefined && skill.baselineScore !== null
          ? skill.baselineScore
          : baselineAttempt.categoryScores?.[skill.name] ?? (skill.currentLevel > 15 ? skill.currentLevel - 15 : skill.currentLevel);

      const currentScore = skill.validatedScore ?? skill.currentLevel;
      const diff = currentScore - baseScore;

      // Find difficulty from latest assessment for this skill
      const specificAttempt = assessmentHistory.find(
        (a) => a.skillName?.toLowerCase() === skill.name.toLowerCase()
      );
      const difficulty = specificAttempt?.difficulty || 'Moderate';

      // Transition detection
      let transitionType: 'gap_to_strong' | 'weak_to_good' | 'upgraded' | 'mastery' | 'baseline' = 'baseline';
      let transitionLabel = 'Baseline Recorded';
      let badgeStyle = 'bg-slate-100 text-slate-700 border-slate-200';

      if (baseScore < 60 && currentScore >= 80) {
        transitionType = 'gap_to_strong';
        transitionLabel = 'Weak → Strong';
        badgeStyle = 'bg-emerald-100 text-emerald-900 border-emerald-300 font-bold';
      } else if (baseScore < 65 && currentScore >= 70) {
        transitionType = 'weak_to_good';
        transitionLabel = 'Needs Work → Good';
        badgeStyle = 'bg-blue-100 text-blue-900 border-blue-300 font-semibold';
      } else if (diff > 0) {
        transitionType = 'upgraded';
        transitionLabel = `+${diff}% Upgraded`;
        badgeStyle = 'bg-teal-50 text-teal-800 border-teal-200 font-semibold';
      } else if (currentScore >= 85) {
        transitionType = 'mastery';
        transitionLabel = 'Mastery Verified';
        badgeStyle = 'bg-purple-100 text-purple-900 border-purple-200 font-semibold';
      }

      return {
        name: skill.name,
        baseScore,
        currentScore,
        diff,
        difficulty,
        transitionType,
        transitionLabel,
        badgeStyle,
        validationStatus: skill.validationStatus || (currentScore >= 75 ? 'passed' : 'unvalidated'),
      };
    });
  }, [skills, baselineAttempt, assessmentHistory]);

  const validatedMilestonesCount = roadmapStages.filter((s) => s.validationStatus === 'passed').length;
  const upgradedSkillsCount = skillComparisons.filter((s) => s.diff > 0).length;

  return (
    <div className="max-w-4xl mx-auto space-y-7 pb-12">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/dashboard" />
        <div className="flex items-center gap-2">
          <button
            onClick={() => navigate('/roadmap')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-2xs transition-colors cursor-pointer"
          >
            <BookOpen className="w-3.5 h-3.5 text-indigo-600" />
            <span>Career Roadmap</span>
          </button>
          <button
            onClick={() => navigate('/assessment')}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-2xs transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>New Assessment</span>
          </button>
        </div>
      </div>

      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 flex items-center gap-1">
            <History className="w-3.5 h-3.5" />
            Objective Progress Engine
          </span>
          <span className="text-slate-400">·</span>
          <span className="text-xs font-semibold text-slate-600">
            {user.targetRole} Preparation
          </span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Before vs. After Progress Tracking
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 leading-relaxed max-w-2xl">
          Compare your initial diagnostic baseline against verified milestones. Measure score progression, skill transitions, and campus placement readiness growth over time.
        </p>
      </div>

      {/* 1. Before vs. After Summary Scorecard */}
      <div className="bg-gradient-to-br from-indigo-950 via-slate-900 to-indigo-900 rounded-2xl border border-indigo-800/40 p-6 sm:p-7 text-white shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-indigo-800/60 pb-4">
          <div>
            <span className="text-3xs font-bold uppercase tracking-wider text-indigo-300 block">
              Objective Progression Scorecard
            </span>
            <h3 className="text-lg font-bold text-white tracking-tight">
              Diagnostic Baseline vs. Current Verified Standing
            </h3>
          </div>
          <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-emerald-500/20 border border-emerald-400/30 rounded-xl text-emerald-300 font-mono text-xs font-bold">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <span>{overallGrowthDelta >= 0 ? `+${overallGrowthDelta}%` : `${overallGrowthDelta}%`} Overall Progress Delta</span>
          </div>
        </div>

        {/* Core Metric Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
          <div className="p-4 bg-white/5 rounded-xl border border-white/10 space-y-1">
            <span className="text-3xs font-semibold uppercase text-indigo-200 block">
              Initial Baseline
            </span>
            <span className="font-mono text-2xl sm:text-3xl font-extrabold text-slate-200 block">
              {baselineAttempt.overallScore}%
            </span>
            <span className="text-3xs text-indigo-300 block">{baselineAttempt.date}</span>
          </div>

          <div className="p-4 bg-white/5 rounded-xl border border-white/10 space-y-1">
            <span className="text-3xs font-semibold uppercase text-indigo-200 block">
              Latest Verified
            </span>
            <span className="font-mono text-2xl sm:text-3xl font-extrabold text-blue-300 block">
              {latestAttempt.overallScore}%
            </span>
            <span className="text-3xs text-blue-200 block">{latestAttempt.date}</span>
          </div>

          <div className="p-4 bg-emerald-500/10 rounded-xl border border-emerald-500/30 space-y-1">
            <span className="text-3xs font-semibold uppercase text-emerald-300 block">
              Placement Readiness
            </span>
            <span className="font-mono text-2xl sm:text-3xl font-extrabold text-emerald-400 block">
              {user.careerReadiness}%
            </span>
            <span className="text-3xs text-emerald-300 block">Verified Profile</span>
          </div>

          <div className="p-4 bg-indigo-500/10 rounded-xl border border-indigo-500/30 space-y-1">
            <span className="text-3xs font-semibold uppercase text-indigo-300 block">
              Milestones Validated
            </span>
            <span className="font-mono text-2xl sm:text-3xl font-extrabold text-indigo-200 block">
              {validatedMilestonesCount} / {roadmapStages.length}
            </span>
            <span className="text-3xs text-indigo-300 block">{upgradedSkillsCount} Skills Upgraded</span>
          </div>
        </div>

        {/* Validation Pass Criteria Information */}
        <div className="p-3.5 bg-white/5 border border-white/10 rounded-xl flex items-center gap-3 text-xs text-indigo-200">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>
            <strong>Validation Standard:</strong> Scoring <strong>≥75%</strong> on a milestone test confirms genuine competency and unlocks advanced roadmap stages.
          </span>
        </div>
      </div>

      {/* 2. Skill-by-Skill Before-vs-After Matrix */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-indigo-600" />
              <span>Skill-by-Skill Progress &amp; Transition Matrix</span>
            </h3>
            <p className="text-2xs text-slate-500">
              Direct comparison of baseline capability versus latest validated performance.
            </p>
          </div>
          <span className="text-3xs font-semibold text-slate-500 bg-slate-50 px-2 py-1 rounded border border-slate-200">
            Passing Benchmark: 75%
          </span>
        </div>

        <div className="divide-y divide-slate-100">
          {skillComparisons.map((item) => (
            <div key={item.name} className="py-3.5 first:pt-1 last:pb-1 space-y-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-bold text-xs text-slate-900">{item.name}</span>
                  <span
                    className={`text-3xs px-2 py-0.5 rounded-md border ${
                      item.difficulty === 'Easy'
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                        : item.difficulty === 'Hard'
                        ? 'bg-purple-50 text-purple-800 border-purple-200'
                        : 'bg-blue-50 text-blue-800 border-blue-200'
                    }`}
                  >
                    {item.difficulty}
                  </span>
                  <span className={`text-3xs px-2 py-0.5 rounded-md border ${item.badgeStyle}`}>
                    {item.transitionLabel}
                  </span>
                </div>

                <div className="flex items-center gap-3 font-mono text-xs">
                  <span className="text-slate-500 text-3xs">
                    Baseline: <strong className="text-slate-700">{item.baseScore}%</strong>
                  </span>
                  <ArrowRight className="w-3 h-3 text-slate-400" />
                  <span className="text-slate-900 font-bold">
                    Current: <strong className="text-blue-700">{item.currentScore}%</strong>
                  </span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-3xs font-bold ${
                      item.diff > 0
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : item.diff < 0
                        ? 'bg-amber-50 text-amber-700 border border-amber-200'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {item.diff >= 0 ? `+${item.diff}%` : `${item.diff}%`}
                  </span>
                </div>
              </div>

              {/* Progress bar comparison */}
              <div className="space-y-1">
                <ProgressBar
                  value={item.currentScore}
                  color={item.currentScore >= 75 ? 'emerald' : 'blue'}
                  size="sm"
                  showValueText={false}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 3. Chronological Recorded Attempts History */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
          <div>
            <h3 className="text-base font-bold text-slate-900 tracking-tight">
              Attempt History Log
            </h3>
            <p className="text-2xs text-slate-500">
              Authentic record of all diagnostic baselines and milestone validation tests.
            </p>
          </div>

          {/* Filter Tabs */}
          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs">
            <button
              onClick={() => setActiveFilter('all')}
              className={`px-2.5 py-1 rounded-lg font-semibold transition-colors cursor-pointer text-2xs ${
                activeFilter === 'all'
                  ? 'bg-white text-slate-900 shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All ({assessmentHistory.length})
            </button>
            <button
              onClick={() => setActiveFilter('baseline')}
              className={`px-2.5 py-1 rounded-lg font-semibold transition-colors cursor-pointer text-2xs ${
                activeFilter === 'baseline'
                  ? 'bg-white text-slate-900 shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Baselines
            </button>
            <button
              onClick={() => setActiveFilter('validation')}
              className={`px-2.5 py-1 rounded-lg font-semibold transition-colors cursor-pointer text-2xs ${
                activeFilter === 'validation'
                  ? 'bg-white text-slate-900 shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Stage Validations
            </button>
          </div>
        </div>

        <div className="space-y-3">
          {filteredAttempts.length === 0 ? (
            <div className="p-8 text-center bg-slate-50 rounded-xl border border-dashed border-slate-200 text-xs text-slate-500">
              No recorded attempts match the selected filter.
            </div>
          ) : (
            filteredAttempts.map((item, idx) => {
              const isValidationTest = item.isValidation || Boolean(item.stageId);
              const isBaselineTest = item.isBaseline;
              const isPassed = item.overallScore >= 75;

              return (
                <div
                  key={item.id}
                  className="p-4 rounded-xl border border-slate-200 hover:border-slate-300 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white"
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-bold text-slate-900">
                        {isBaselineTest
                          ? `Diagnostic Baseline · ${item.targetRole}`
                          : isValidationTest
                          ? `Milestone Validation: ${item.skillName || item.targetRole}`
                          : `Skill Assessment: ${item.skillName || item.targetRole}`}
                      </span>

                      {/* Test Type Badge */}
                      <span
                        className={`text-3xs font-bold px-2 py-0.5 rounded border ${
                          isBaselineTest
                            ? 'bg-blue-50 text-blue-800 border-blue-200'
                            : isValidationTest
                            ? 'bg-indigo-50 text-indigo-800 border-indigo-200'
                            : 'bg-slate-50 text-slate-700 border-slate-200'
                        }`}
                      >
                        {isBaselineTest ? 'Baseline' : isValidationTest ? 'Stage Validation' : 'Skill Test'}
                      </span>

                      {/* Difficulty Badge */}
                      <span
                        className={`text-3xs font-semibold px-2 py-0.5 rounded border ${
                          item.difficulty === 'Easy'
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                            : item.difficulty === 'Hard'
                            ? 'bg-purple-50 text-purple-800 border-purple-200'
                            : 'bg-blue-50 text-blue-800 border-blue-200'
                        }`}
                      >
                        {item.difficulty || 'Moderate'}
                      </span>

                      {/* Pass/Fail Status */}
                      <span
                        className={`text-3xs font-bold px-2 py-0.5 rounded flex items-center gap-1 ${
                          isPassed
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                            : 'bg-amber-100 text-amber-900 border border-amber-300'
                        }`}
                      >
                        {isPassed ? <CheckCircle2 className="w-3 h-3 text-emerald-600" /> : <AlertTriangle className="w-3 h-3 text-amber-600" />}
                        <span>{isPassed ? 'Passed (≥75%)' : 'Needs Review (<75%)'}</span>
                      </span>
                    </div>

                    <div className="flex items-center gap-3 text-2xs text-slate-500 flex-wrap">
                      <span className="flex items-center gap-1 font-mono">
                        <Calendar className="w-3 h-3 text-slate-400" />
                        {item.date}
                      </span>
                      {item.questionCount !== undefined && (
                        <>
                          <span>·</span>
                          <span>
                            {item.correctCount !== undefined ? `${item.correctCount}/${item.questionCount} correct` : `${item.questionCount} questions`}
                            {item.accuracy !== undefined ? ` (${item.accuracy}% accuracy)` : ''}
                          </span>
                        </>
                      )}
                    </div>

                    {/* Strong / Weak Topic Tags */}
                    {item.strongTopics && item.strongTopics.length > 0 && (
                      <div className="flex items-center gap-1.5 flex-wrap pt-0.5 text-3xs">
                        <span className="font-semibold text-emerald-800">Strengths:</span>
                        {item.strongTopics.slice(0, 3).map((topic, i) => (
                          <span key={i} className="px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                            {topic}
                          </span>
                        ))}
                      </div>
                    )}

                    {item.weakTopics && item.weakTopics.length > 0 && (
                      <div className="flex items-center gap-1.5 flex-wrap text-3xs">
                        <span className="font-semibold text-amber-800">Practice Needed:</span>
                        {item.weakTopics.slice(0, 3).map((topic, i) => (
                          <span key={i} className="px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200">
                            {topic}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-4 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                    <div className="text-right">
                      <span className="font-mono text-2xl font-extrabold text-slate-900 tabular-nums block">
                        {item.overallScore}%
                      </span>
                      {item.improvementPct !== undefined && item.improvementPct > 0 ? (
                        <span className="font-mono text-3xs font-semibold text-emerald-600 block">
                          +{item.improvementPct}% growth
                        </span>
                      ) : (
                        <span className="text-3xs text-slate-400 block font-mono">Verified Score</span>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => navigate('/roadmap')}
                        className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                      >
                        Roadmap
                      </button>
                      <button
                        onClick={() => navigate('/assessment')}
                        className="px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-2xs transition-colors cursor-pointer"
                      >
                        Retake
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};

export default AssessmentHistoryPage;
