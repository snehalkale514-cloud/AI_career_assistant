import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  GraduationCap,
  Clock,
  BookOpen,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  BarChart3,
  History,
  SlidersHorizontal,
  Layers,
  ShieldCheck,
  Target
} from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';
import { ProgressBar } from '../../components/common/ProgressBar.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';
import {
  skillAssessmentService,
  SkillQuestion
} from '../../services/skillAssessmentService.ts';

type AssessmentMode = 'role_baseline' | 'single_skill';
type DifficultyLevel = 'Easy' | 'Moderate' | 'Hard';

export const SkillAssessmentPage: React.FC = () => {
  const navigate = useNavigate();
  const {
    submitAssessmentResult,
    assessmentScores,
    user,
    assessmentHistory,
    skills
  } = useCareer();

  // Test setup configuration
  const [assessmentMode, setAssessmentMode] = useState<AssessmentMode>('role_baseline');
  const [difficulty, setDifficulty] = useState<DifficultyLevel>('Moderate');
  const [selectedSkill, setSelectedSkill] = useState<string>(skills[0]?.name || 'Python');

  // Test execution state
  const [assessmentState, setAssessmentState] = useState<'intro' | 'active' | 'completed'>('intro');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [calculatedResult, setCalculatedResult] = useState<{
    overall: number;
    breakdown: Record<string, number>;
    strengths: string[];
    weaknesses: string[];
    correctCount: number;
    totalQuestions: number;
    accuracy: number;
    difficulty: DifficultyLevel;
  } | null>(null);

  // Generate questions dynamically according to chosen target role, skill, and difficulty
  const activeQuestions: (SkillQuestion & { category: string })[] = useMemo(() => {
    if (assessmentMode === 'single_skill') {
      const list = skillAssessmentService.getQuestionsForSkill(selectedSkill, difficulty);
      return list.map((q) => ({
        ...q,
        category: q.skillName || selectedSkill
      }));
    }
    return skillAssessmentService.getBaselineQuestions(user.targetRole, difficulty);
  }, [assessmentMode, selectedSkill, difficulty, user.targetRole]);

  const totalQuestions = activeQuestions.length;
  const currentQ = activeQuestions[currentQuestionIndex];

  const handleSelectOption = (optionIndex: number) => {
    if (!currentQ) return;
    setSelectedAnswers((prev) => ({
      ...prev,
      [currentQ.id]: optionIndex,
    }));
  };

  const handleNext = () => {
    if (currentQuestionIndex < totalQuestions - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      finishAssessment();
    }
  };

  const handlePrev = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  const finishAssessment = () => {
    const resultObj = skillAssessmentService.evaluateDiagnosticAssessment(
      activeQuestions,
      selectedAnswers,
      difficulty
    );

    setCalculatedResult(resultObj);

    // Collect strong and weak topics for targeted feedback
    const strongTopics: string[] = [];
    const weakTopics: string[] = [];
    activeQuestions.forEach((q) => {
      const isCorrect = selectedAnswers[q.id] === q.correctAnswerIndex;
      if (isCorrect) {
        if (!strongTopics.includes(q.topic)) strongTopics.push(q.topic);
      } else {
        if (!weakTopics.includes(q.topic)) weakTopics.push(q.topic);
      }
    });

    const recommendedPractice = weakTopics.map((t) => `${t} Remediation Exercises`);
    if (recommendedPractice.length === 0) {
      recommendedPractice.push(`Advanced ${user.targetRole} Scenario Challenges`);
    }

    // Submit with complete authentic tracking metadata
    submitAssessmentResult(resultObj.overall, resultObj.breakdown, {
      difficulty,
      questionCount: resultObj.totalQuestions,
      correctCount: resultObj.correctCount,
      accuracy: resultObj.accuracy,
      isBaseline: true,
      strongTopics,
      weakTopics,
      recommendedPractice
    });

    setAssessmentState('completed');
  };

  const resetTest = () => {
    setSelectedAnswers({});
    setCurrentQuestionIndex(0);
    setCalculatedResult(null);
    setAssessmentState('intro');
  };

  // Find previous baseline for before-vs-after comparison
  const previousBaseline = useMemo(() => {
    return assessmentHistory.find((item) => item.isBaseline) || assessmentHistory[0] || null;
  }, [assessmentHistory]);

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/dashboard" />
        <button
          onClick={() => navigate('/assessment-history')}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-2xs transition-colors cursor-pointer"
        >
          <History className="w-3.5 h-3.5 text-blue-600" />
          <span>Assessment History</span>
        </button>
      </div>

      {/* STATE 1: INTRO & CONFIGURATION SCREEN */}
      {assessmentState === 'intro' && (
        <div className="bg-white rounded-2xl border border-slate-200/90 p-6 sm:p-8 shadow-xs space-y-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-blue-50 text-blue-700 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Diagnostic Baseline Assessment · {user.targetRole}</span>
            </div>
            <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">
              Establish Your Skills Baseline
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Assess your skills before starting your roadmap. This objective baseline diagnostic benchmarks your real capabilities to calibrate your learning path, prioritize weak areas, and track genuine before-vs-after progress.
            </p>
          </div>

          {/* Difficulty Level Selection (Easy, Moderate, Hard) */}
          <div className="space-y-2 pt-1">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <SlidersHorizontal className="w-3.5 h-3.5 text-indigo-600" />
                Select Assessment Difficulty:
              </span>
              <span className="text-3xs text-slate-500 font-medium">Adaptive Question Suite</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {(
                [
                  {
                    level: 'Easy',
                    label: 'Foundational (Easy)',
                    desc: 'Core syntax, primary concepts, and terminology.',
                    pillColor: 'border-emerald-200 bg-emerald-50/50 text-emerald-900',
                    activeRing: 'ring-2 ring-emerald-500 border-emerald-500 bg-emerald-50'
                  },
                  {
                    level: 'Moderate',
                    label: 'Applied (Moderate)',
                    desc: 'Standard workflows, problem solving, queries & joins.',
                    pillColor: 'border-blue-200 bg-blue-50/50 text-blue-900',
                    activeRing: 'ring-2 ring-blue-500 border-blue-500 bg-blue-50'
                  },
                  {
                    level: 'Hard',
                    label: 'Advanced (Hard)',
                    desc: 'Optimization, window functions, concurrency & edge cases.',
                    pillColor: 'border-purple-200 bg-purple-50/50 text-purple-900',
                    activeRing: 'ring-2 ring-purple-500 border-purple-500 bg-purple-50'
                  }
                ] as const
              ).map((diffOpt) => {
                const isSelected = difficulty === diffOpt.level;
                return (
                  <button
                    key={diffOpt.level}
                    type="button"
                    onClick={() => setDifficulty(diffOpt.level)}
                    className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                      isSelected
                        ? diffOpt.activeRing
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-bold text-slate-900">{diffOpt.label}</span>
                      {isSelected && (
                        <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                      )}
                    </div>
                    <p className="text-3xs text-slate-500 leading-snug">{diffOpt.desc}</p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Assessment Mode Selection: Role Baseline or Single Skill */}
          <div className="space-y-2 pt-1">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-700 block">
              Assessment Scope:
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setAssessmentMode('role_baseline')}
                className={`p-3.5 rounded-xl border text-left cursor-pointer transition-all ${
                  assessmentMode === 'role_baseline'
                    ? 'border-indigo-600 bg-indigo-50/60 ring-2 ring-indigo-400'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <Target className="w-4 h-4 text-indigo-600" />
                  <span className="text-xs font-bold text-slate-900">
                    Full {user.targetRole} Baseline
                  </span>
                </div>
                <p className="text-3xs text-slate-500">
                  Comprehensive multi-skill diagnostic covering Python, SQL, Statistics, Excel &amp; Power BI.
                </p>
              </button>

              <button
                type="button"
                onClick={() => setAssessmentMode('single_skill')}
                className={`p-3.5 rounded-xl border text-left cursor-pointer transition-all ${
                  assessmentMode === 'single_skill'
                    ? 'border-indigo-600 bg-indigo-50/60 ring-2 ring-indigo-400'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <Layers className="w-4 h-4 text-indigo-600" />
                  <span className="text-xs font-bold text-slate-900">
                    Specific Skill Diagnostic
                  </span>
                </div>
                <p className="text-3xs text-slate-500">
                  Evaluate a single targeted technology to benchmark topic-level mastery.
                </p>
              </button>
            </div>

            {/* Skill Selector when in single skill mode */}
            {assessmentMode === 'single_skill' && (
              <div className="pt-2 flex items-center gap-2">
                <span className="text-xs font-semibold text-slate-700">Choose Skill:</span>
                <select
                  value={selectedSkill}
                  onChange={(e) => setSelectedSkill(e.target.value)}
                  className="bg-white border border-slate-300 text-slate-800 text-xs font-semibold px-3 py-1.5 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                >
                  {skills.map((s) => (
                    <option key={s.id} value={s.name}>
                      {s.name} (Current: {s.currentLevel}%)
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          {/* Test Overview Metric Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80">
              <BookOpen className="w-4 h-4 text-blue-600 mb-1" />
              <span className="text-3xs text-slate-500 block">Questions to Answer</span>
              <span className="text-xs font-bold text-slate-900">{totalQuestions} Standardized Items</span>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80">
              <Clock className="w-4 h-4 text-indigo-600 mb-1" />
              <span className="text-3xs text-slate-500 block">Recommended Duration</span>
              <span className="text-xs font-bold text-slate-900">{totalQuestions * 2} Minutes</span>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80">
              <BarChart3 className="w-4 h-4 text-emerald-600 mb-1" />
              <span className="text-3xs text-slate-500 block">Difficulty Benchmark</span>
              <span className="text-xs font-bold text-slate-900">{difficulty} Tier</span>
            </div>
          </div>

          {/* Previous baseline display if exists */}
          {previousBaseline && (
            <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-200 flex items-center justify-between text-xs">
              <div>
                <span className="font-bold text-blue-950 block">Previous Baseline Recorded</span>
                <span className="text-slate-600 text-2xs">
                  {previousBaseline.date} · {previousBaseline.difficulty || 'Moderate'} Difficulty
                </span>
              </div>
              <div className="text-right">
                <span className="font-mono text-base font-bold text-blue-700 block">
                  {previousBaseline.overallScore}% Overall
                </span>
                <span className="text-3xs text-slate-500 font-mono">
                  {previousBaseline.accuracy ? `${previousBaseline.accuracy}% Accuracy` : 'Diagnostic'}
                </span>
              </div>
            </div>
          )}

          <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
            <button
              type="button"
              onClick={() => navigate('/assessment-history')}
              className="text-xs text-slate-500 hover:text-slate-800 underline cursor-pointer"
            >
              View Historical Progress &amp; Delts →
            </button>
            <button
              type="button"
              onClick={() => setAssessmentState('active')}
              className="inline-flex items-center gap-2 px-6 py-3 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm transition-all cursor-pointer"
            >
              <span>Begin Baseline Assessment ({difficulty})</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STATE 2: ACTIVE QUESTION RUNNER */}
      {assessmentState === 'active' && currentQ && (
        <div className="bg-white rounded-2xl border border-slate-200/90 p-6 sm:p-8 shadow-xs space-y-6">
          {/* Header & Question Counter */}
          <div className="space-y-3 pb-4 border-b border-slate-100">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-blue-600 uppercase tracking-wider text-2xs bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                  {currentQ.category}
                </span>
                <span className={`text-3xs font-bold uppercase px-2 py-0.5 rounded border ${
                  currentQ.difficulty === 'Easy'
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                    : currentQ.difficulty === 'Hard'
                    ? 'bg-purple-50 text-purple-800 border-purple-200'
                    : 'bg-blue-50 text-blue-800 border-blue-200'
                }`}>
                  {currentQ.difficulty || difficulty}
                </span>
              </div>
              <span className="font-mono text-slate-500 font-medium text-xs">
                Question {currentQuestionIndex + 1} of {totalQuestions}
              </span>
            </div>
            <ProgressBar
              value={currentQuestionIndex + 1}
              max={totalQuestions}
              showValueText={false}
              size="sm"
            />
          </div>

          {/* Question Text */}
          <div className="space-y-2">
            <span className="text-3xs font-bold uppercase tracking-wider text-slate-400">
              Topic: {currentQ.topic}
            </span>
            <h3 className="text-base sm:text-lg font-bold text-slate-900 leading-snug">
              {currentQ.question}
            </h3>

            {currentQ.codeSnippet && (
              <pre className="p-3 rounded-xl bg-slate-900 text-emerald-400 font-mono text-xs overflow-x-auto">
                {currentQ.codeSnippet}
              </pre>
            )}
          </div>

          {/* Options */}
          <div className="space-y-2.5">
            {currentQ.options.map((option, optIdx) => {
              const isSelected = selectedAnswers[currentQ.id] === optIdx;
              return (
                <div
                  key={optIdx}
                  onClick={() => handleSelectOption(optIdx)}
                  className={`p-4 rounded-xl border text-xs sm:text-sm font-medium transition-all cursor-pointer flex items-start gap-3 ${
                    isSelected
                      ? 'border-blue-600 bg-blue-50/70 text-blue-900 shadow-2xs ring-1 ring-blue-300'
                      : 'border-slate-200 hover:border-slate-300 bg-white text-slate-700'
                  }`}
                >
                  <span
                    className={`w-6 h-6 rounded-md flex items-center justify-center text-xs font-bold shrink-0 transition-colors ${
                      isSelected
                        ? 'bg-blue-600 text-white'
                        : 'bg-slate-100 text-slate-500'
                    }`}
                  >
                    {String.fromCharCode(65 + optIdx)}
                  </span>
                  <span className="pt-0.5 leading-relaxed">{option}</span>
                </div>
              );
            })}
          </div>

          {/* Controls */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
            <button
              type="button"
              onClick={handlePrev}
              disabled={currentQuestionIndex === 0}
              className={`inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                currentQuestionIndex === 0
                  ? 'text-slate-300 cursor-not-allowed'
                  : 'text-slate-700 bg-slate-100 hover:bg-slate-200'
              }`}
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Previous</span>
            </button>

            <button
              type="button"
              onClick={handleNext}
              disabled={selectedAnswers[currentQ.id] === undefined}
              className={`inline-flex items-center gap-1.5 px-5 py-2.5 text-xs font-semibold text-white rounded-lg transition-all cursor-pointer ${
                selectedAnswers[currentQ.id] === undefined
                  ? 'bg-slate-300 cursor-not-allowed'
                  : 'bg-blue-600 hover:bg-blue-700 shadow-xs'
              }`}
            >
              <span>{currentQuestionIndex === totalQuestions - 1 ? 'Finish & Score Baseline' : 'Next Question'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* STATE 3: ASSESSMENT COMPLETED SCREEN */}
      {assessmentState === 'completed' && calculatedResult && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200/90 p-6 sm:p-8 shadow-xs space-y-6">
            <div className="text-center space-y-2 pb-6 border-b border-slate-100">
              <div className="w-14 h-14 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto border border-emerald-100">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
                Baseline Assessment Completed!
              </h2>
              <p className="text-xs text-slate-500">
                Scores have been verified and saved to your diagnostic baseline profile. Unattempted skills are strictly unverified.
              </p>

              {/* Score Badges */}
              <div className="pt-4 flex flex-wrap items-center justify-center gap-3">
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-center min-w-44">
                  <span className="text-3xs font-semibold uppercase tracking-wider text-slate-400 block">
                    Overall Baseline Score
                  </span>
                  <span className="text-3xl font-mono font-bold text-slate-900 tabular-nums">
                    {calculatedResult.overall}%
                  </span>
                  <span className="text-3xs text-slate-500 font-mono mt-0.5 block">
                    {calculatedResult.correctCount} of {calculatedResult.totalQuestions} questions correct ({calculatedResult.accuracy}% accuracy)
                  </span>
                  <span className="inline-block mt-1 text-3xs font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-800">
                    {calculatedResult.difficulty} Difficulty Level
                  </span>
                </div>

                {/* Before-vs-After Comparison Card */}
                {previousBaseline && (
                  <div className="p-4 rounded-xl bg-indigo-50/60 border border-indigo-200 text-center min-w-44">
                    <span className="text-3xs font-semibold uppercase tracking-wider text-indigo-800 block">
                      Before vs. After Delta
                    </span>
                    <div className="flex items-center justify-center gap-2 mt-1">
                      <span className="text-slate-500 text-xs font-mono">{previousBaseline.overallScore}%</span>
                      <span className="text-slate-400 text-xs">→</span>
                      <span className="text-indigo-900 font-mono font-bold text-lg">{calculatedResult.overall}%</span>
                    </div>
                    {(() => {
                      const delta = calculatedResult.overall - previousBaseline.overallScore;
                      return (
                        <span
                          className={`text-3xs font-mono font-bold block mt-1 ${
                            delta >= 0 ? 'text-emerald-700' : 'text-slate-600'
                          }`}
                        >
                          {delta >= 0 ? `+${delta}% Improvement` : `${delta}% vs Prior Baseline`}
                        </span>
                      );
                    })()}
                  </div>
                )}
              </div>
            </div>

            {/* Skill-wise Score Breakdown */}
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-slate-900 flex items-center justify-between">
                <span>Skill-Wise Baseline Breakdown</span>
                <span className="text-2xs font-normal text-slate-500">Benchmark Goal: ≥75%</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {Object.entries(calculatedResult.breakdown).map(([skill, score]) => (
                  <div
                    key={skill}
                    className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 space-y-1.5"
                  >
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-semibold text-slate-800">{skill}</span>
                      <span className="font-mono font-bold text-slate-900">{score}%</span>
                    </div>
                    <ProgressBar
                      value={score}
                      color={score >= 75 ? 'emerald' : score < 50 ? 'amber' : 'blue'}
                      size="sm"
                      showValueText={false}
                    />
                    <div className="flex items-center justify-between text-3xs text-slate-500 pt-0.5">
                      <span>
                        {score >= 75 ? 'Strong Proficiency' : score < 50 ? 'Priority Gap' : 'Needs Practice'}
                      </span>
                      <span className="font-mono">{score >= 75 ? 'Verified' : 'Remediation Needed'}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Strengths & Weak Areas Categorization */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-4 rounded-xl bg-emerald-50/60 border border-emerald-200 space-y-2">
                <div className="flex items-center gap-2 text-emerald-800 font-bold text-xs">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Strong Skills (≥75% Verified)</span>
                </div>
                {calculatedResult.strengths.length > 0 ? (
                  <ul className="text-xs text-emerald-900 space-y-1 pl-5 list-disc">
                    {calculatedResult.strengths.map((skill) => (
                      <li key={skill}>
                        {skill}: Strong ({calculatedResult.breakdown[skill]}%)
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-xs text-slate-500 italic">
                    No skills scored at or above the 75% threshold. Focus on early foundation stages.
                  </p>
                )}
              </div>

              <div className="p-4 rounded-xl bg-amber-50/60 border border-amber-200 space-y-2">
                <div className="flex items-center gap-2 text-amber-900 font-bold text-xs">
                  <AlertCircle className="w-4 h-4" />
                  <span>Identified Gaps &amp; Weaknesses (&lt;75%)</span>
                </div>
                {calculatedResult.weaknesses.length > 0 ? (
                  <ul className="text-xs text-amber-900 space-y-1 pl-5 list-disc">
                    {calculatedResult.weaknesses.map((skill) => (
                      <li key={skill}>
                        {skill}: {calculatedResult.breakdown[skill] < 50 ? 'Priority Gap' : 'Needs Practice'} ({calculatedResult.breakdown[skill]}%)
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-xs text-emerald-700 font-medium">
                    Mastery demonstrated! All evaluated competencies met passing benchmark.
                  </p>
                )}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={resetTest}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 rounded-lg transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Retake with Different Difficulty</span>
                </button>
                <button
                  type="button"
                  onClick={() => navigate('/assessment-history')}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg transition-colors cursor-pointer"
                >
                  <History className="w-3.5 h-3.5 text-blue-600" />
                  <span>View Full History</span>
                </button>
              </div>

              <button
                type="button"
                onClick={() => navigate('/roadmap')}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm transition-all cursor-pointer"
              >
                <span>View Personalized Roadmap</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SkillAssessmentPage;
