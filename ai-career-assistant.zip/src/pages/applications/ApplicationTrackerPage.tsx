import React, { useState } from 'react';
import {
  ListTodo,
  Plus,
  Building2,
  Calendar,
  MapPin,
  Trash2,
  ExternalLink,
  CheckCircle2,
  Clock,
  Briefcase,
  AlertCircle
} from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';
import { Modal } from '../../components/common/Modal.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';
import { StatCard } from '../../components/common/StatCard.tsx';
import { ApplicationItem } from '../../types.ts';

export interface ApplicationTrackerSummary {
  totalApps: number;
  interviewsCount: number;
  shortlistedCount: number;
  offersCount: number;
  interviewTrend: { value: string; isPositive: boolean };
  offerTrend: { value: string; isPositive: boolean };
}

export function calculateApplicationTrackerSummary(
  applications: ApplicationItem[]
): ApplicationTrackerSummary {
  const totalApps = applications.length;
  const interviewApps = applications.filter((a) => a.status === 'Interview');
  const interviewsCount = interviewApps.length;
  const shortlistedCount = applications.filter((a) => a.status === 'Shortlisted').length;
  const offerApps = applications.filter((a) => a.status === 'Offer');
  const offersCount = offerApps.length;

  const interviewTrend = interviewsCount > 0
    ? {
        value: interviewsCount === 1 ? interviewApps[0].company : `${interviewApps[0].company} (+${interviewsCount - 1})`,
        isPositive: true,
      }
    : {
        value: 'No interview tracked',
        isPositive: false,
      };

  const offerTrend = offersCount > 0
    ? {
        value: offersCount === 1 ? offerApps[0].company : `${offerApps[0].company} (+${offersCount - 1})`,
        isPositive: true,
      }
    : {
        value: 'No offer tracked',
        isPositive: false,
      };

  return {
    totalApps,
    interviewsCount,
    shortlistedCount,
    offersCount,
    interviewTrend,
    offerTrend,
  };
}

export const ApplicationTrackerPage: React.FC = () => {
  const { applications, addApplication, updateApplicationStatus, deleteApplication } = useCareer();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedAppForEdit, setSelectedAppForEdit] = useState<ApplicationItem | null>(null);

  // New Application Form State
  const [newCompany, setNewCompany] = useState('');
  const [newRole, setNewRole] = useState('Data Analyst');
  const [newLocation, setNewLocation] = useState('Pune, Maharashtra');
  const [newSalary, setNewSalary] = useState('₹7.0 – 9.0 LPA');
  const [newStatus, setNewStatus] = useState<ApplicationItem['status']>('Application Started');
  const [newNotes, setNewNotes] = useState('');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const statuses: ApplicationItem['status'][] = [
    'Application Started',
    'Applied',
    'Interview',
    'Shortlisted',
    'Offer',
    'Rejected',
  ];

  // Derive dynamic summary metrics from live student application records
  const summary = calculateApplicationTrackerSummary(applications);

  const handleCreateApplication = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCompany.trim() || !newRole.trim()) return;

    addApplication({
      company: newCompany.trim(),
      role: newRole.trim(),
      location: newLocation.trim(),
      appliedDate: 'Just now',
      status: newStatus,
      salary: newSalary,
      notes: newNotes,
      nextStep: newStatus === 'Application Started'
        ? 'Complete external application on employer website.'
        : 'Recruitment screening updates.',
    });

    setStatusMessage(`Application for ${newCompany.trim()} (${newRole.trim()}) recorded successfully!`);
    setTimeout(() => setStatusMessage(null), 3500);

    setNewCompany('');
    setNewNotes('');
    setIsAddModalOpen(false);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/dashboard" />
      </div>

      {statusMessage && (
        <div className="p-3 text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{statusMessage}</span>
          </div>
          <button onClick={() => setStatusMessage(null)} className="text-emerald-700 cursor-pointer">
            &times;
          </button>
        </div>
      )}

      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-600 flex items-center gap-1">
              <ListTodo className="w-3.5 h-3.5" />
              Recruitment Pipeline
            </span>
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            Application Tracker
          </h2>
          <p className="text-xs text-slate-500">
            Manage campus drives and off-campus opportunities through every recruitment stage.
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Application</span>
        </button>
      </div>

      {/* Top Statistics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Applications"
          value={summary.totalApps}
          subtext="Tracked opportunities"
          icon={Briefcase}
        />
        <StatCard
          title="Active Interviews"
          value={summary.interviewsCount}
          subtext="Self-tracked interview rounds"
          icon={Clock}
          trend={summary.interviewTrend}
        />
        <StatCard
          title="Shortlisted"
          value={summary.shortlistedCount}
          subtext="Screening cleared"
          icon={CheckCircle2}
        />
        <StatCard
          title="Offers Received"
          value={summary.offersCount}
          subtext="Self-tracked offer records"
          icon={CheckCircle2}
          trend={summary.offerTrend}
        />
      </div>

      {/* Kanban Stage Columns View */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 items-start">
        {statuses.map((colStatus) => {
          const appsInColumn = applications.filter((a) => a.status === colStatus);

          const colHeaderColor: Record<ApplicationItem['status'], string> = {
            'Application Started': 'text-amber-800 bg-amber-50 border-amber-200',
            Saved: 'text-slate-600 bg-slate-50 border-slate-200',
            Applied: 'text-slate-700 bg-slate-100 border-slate-200',
            Assessment: 'text-amber-700 bg-amber-50 border-amber-200',
            Interview: 'text-blue-700 bg-blue-50 border-blue-200',
            Shortlisted: 'text-indigo-700 bg-indigo-50 border-indigo-200',
            Offer: 'text-emerald-800 bg-emerald-50 border-emerald-200',
            Rejected: 'text-rose-700 bg-rose-50 border-rose-200',
          };

          return (
            <div
              key={colStatus}
              className="bg-white/80 rounded-2xl border border-slate-200 p-3 space-y-3 min-h-[460px] flex flex-col"
            >
              {/* Column Header */}
              <div
                className={`p-2.5 rounded-xl border flex items-center justify-between font-bold text-xs ${colHeaderColor[colStatus]}`}
              >
                <span>{colStatus}</span>
                <span className="font-mono text-2xs px-1.5 py-0.2 rounded-full bg-white/90">
                  {appsInColumn.length}
                </span>
              </div>

              {/* Cards inside column */}
              <div className="space-y-3 flex-1 overflow-y-auto">
                {appsInColumn.map((app) => (
                  <div
                    key={app.id}
                    className="p-3.5 rounded-xl border border-slate-200/90 bg-white hover:border-slate-300 hover:shadow-xs transition-all space-y-2 group"
                  >
                    <div className="flex items-start justify-between gap-1">
                      <h4 className="text-xs font-bold text-slate-900 leading-snug">{app.role}</h4>
                      <button
                        onClick={() => deleteApplication(app.id)}
                        className="text-slate-300 hover:text-rose-600 p-0.5 rounded transition-colors opacity-0 group-hover:opacity-100 cursor-pointer"
                        title="Delete application"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <p className="text-2xs text-slate-600 font-semibold">{app.company}</p>

                    <div className="text-3xs text-slate-400 space-y-0.5 font-mono">
                      <div>Applied: {app.appliedDate}</div>
                      <div>{app.location}</div>
                      {app.salary && <div className="text-slate-600 font-semibold">{app.salary}</div>}
                    </div>

                    {app.notes && (
                      <p className="text-3xs text-slate-500 bg-slate-50 p-2 rounded border border-slate-100 leading-relaxed">
                        {app.notes}
                      </p>
                    )}

                    {/* Quick Move Status Selector */}
                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-2xs">
                      <span className="text-3xs text-slate-400">Move:</span>
                      <select
                        value={app.status}
                        onChange={(e) =>
                          updateApplicationStatus(app.id, e.target.value as ApplicationItem['status'])
                        }
                        className="text-3xs bg-slate-50 border border-slate-200 rounded px-1.5 py-0.5 text-slate-700 font-medium focus:outline-hidden"
                      >
                        {statuses.map((s) => (
                          <option key={s} value={s}>
                            {s}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                ))}

                {appsInColumn.length === 0 && (
                  <div className="h-32 flex items-center justify-center text-3xs text-slate-400 italic">
                    No items in {colStatus}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Application Modal */}
      {isAddModalOpen && (
        <Modal
          isOpen={true}
          onClose={() => setIsAddModalOpen(false)}
          title="Track New Application"
          subtitle="Log a campus drive or external job application into your tracker"
          maxWidth="md"
        >
          <form onSubmit={handleCreateApplication} className="space-y-4 text-xs">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Company Name</label>
              <input
                type="text"
                required
                value={newCompany}
                onChange={(e) => setNewCompany(e.target.value)}
                placeholder="e.g. Barclays, Cognizant, TechNova"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Job Title / Role</label>
              <input
                type="text"
                required
                value={newRole}
                onChange={(e) => setNewRole(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Location</label>
                <input
                  type="text"
                  value={newLocation}
                  onChange={(e) => setNewLocation(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Initial Status</label>
                <select
                  value={newStatus}
                  onChange={(e) => setNewStatus(e.target.value as ApplicationItem['status'])}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
                >
                  {statuses.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Offered / Target CTC</label>
              <input
                type="text"
                value={newSalary}
                onChange={(e) => setNewSalary(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Notes &amp; Next Action</label>
              <textarea
                rows={2}
                value={newNotes}
                onChange={(e) => setNewNotes(e.target.value)}
                placeholder="e.g. Coding round scheduled for Tuesday at 3 PM..."
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
              />
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="px-4 py-2 text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg font-semibold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 text-white bg-blue-600 hover:bg-blue-700 rounded-lg font-semibold shadow-xs"
              >
                Save Application
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
};
