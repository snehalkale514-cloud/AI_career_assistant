import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Building2, User, Mail, Lock, Globe, MapPin, ArrowRight, Sparkles } from 'lucide-react';
import { useCompany } from '../../context/CompanyContext.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';

export const CompanyRegisterPage: React.FC = () => {
  const navigate = useNavigate();
  const { registerCompany } = useCompany();

  const [companyName, setCompanyName] = useState('Acme Data Systems');
  const [industry, setIndustry] = useState('Data Analytics & AI Solutions');
  const [website, setWebsite] = useState('https://acmedata.example.com');
  const [location, setLocation] = useState('Pune / Bengaluru, India');
  const [size, setSize] = useState('100–250 employees');
  const [description, setDescription] = useState(
    'Acme Data Systems develops modern enterprise analytics and automated decision pipelines for financial and manufacturing leaders.'
  );

  const [recruiterName, setRecruiterName] = useState('Siddharth Joshi');
  const [recruiterEmail, setRecruiterEmail] = useState('siddharth@acmedata.example.com');
  const [recruiterTitle, setRecruiterTitle] = useState('Lead Technical Recruiter');
  const [password, setPassword] = useState('Password123!');
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    const result = registerCompany({
      companyName,
      industry,
      location,
      website,
      size,
      description,
      recruiterName,
      recruiterEmail,
      recruiterTitle,
      password,
    });

    if (result.success) {
      navigate('/company/dashboard');
    } else {
      setErrorMessage(result.error || 'Failed to register company account.');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative">
      <div className="absolute top-4 left-4 sm:top-6 sm:left-6">
        <BackButton fallback="/company/login" />
      </div>

      <div className="sm:mx-auto sm:w-full sm:max-w-xl text-center">
        <Link to="/" className="inline-flex items-center gap-2.5 group">
          <div className="w-9 h-9 rounded-lg bg-indigo-600 flex items-center justify-center text-white shadow-xs group-hover:scale-105 transition-transform">
            <Building2 className="w-5 h-5" />
          </div>
          <span className="text-xl font-extrabold text-slate-900 tracking-tight">
            Employer & Recruiter Portal
          </span>
        </Link>
        <h2 className="mt-6 text-2xl font-bold tracking-tight text-slate-900">
          Register company hiring profile
        </h2>
        <p className="mt-1 text-xs text-slate-500">
          Connect directly with verified engineering and data science college talent.
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-xl px-4">
        <div className="bg-white py-8 px-6 shadow-sm border border-slate-200/90 rounded-2xl sm:px-10">
          <form className="space-y-4" onSubmit={handleSubmit}>
            {errorMessage && (
              <div className="p-3 text-xs text-rose-700 bg-rose-50 border border-rose-200 rounded-lg">
                {errorMessage}
              </div>
            )}

            <div className="border-b border-slate-100 pb-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-indigo-700">
                1. Organization Details
              </h3>
            </div>

            {/* Company Name & Industry */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Company Name <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Building2 className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600"
                    placeholder="e.g. Acme Technologies"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Industry</label>
                <input
                  type="text"
                  required
                  value={industry}
                  onChange={(e) => setIndustry(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600"
                  placeholder="e.g. Software & Analytics"
                />
              </div>
            </div>

            {/* Website & Location */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Website URL</label>
                <div className="relative">
                  <Globe className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="url"
                    required
                    value={website}
                    onChange={(e) => setWebsite(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600"
                    placeholder="https://company.com"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Headquarters / Office Location
                </label>
                <div className="relative">
                  <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600"
                    placeholder="e.g. Pune / Bengaluru"
                  />
                </div>
              </div>
            </div>

            <div className="border-b border-slate-100 pt-3 pb-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-indigo-700">
                2. Recruiter Account Credentials
              </h3>
            </div>

            {/* Recruiter Name & Title */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Recruiter Full Name <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    value={recruiterName}
                    onChange={(e) => setRecruiterName(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600"
                    placeholder="e.g. Siddharth Joshi"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Designation / Role
                </label>
                <input
                  type="text"
                  required
                  value={recruiterTitle}
                  onChange={(e) => setRecruiterTitle(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600"
                  placeholder="e.g. Head of Campus Recruitment"
                />
              </div>
            </div>

            {/* Work Email & Password */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Work Email Address <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="email"
                    required
                    value={recruiterEmail}
                    onChange={(e) => setRecruiterEmail(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600"
                    placeholder="recruiter@company.com"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Password <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600"
                    placeholder="••••••••"
                  />
                </div>
              </div>
            </div>

            {/* Company Description */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Company Brief & Hiring Focus
              </label>
              <textarea
                rows={2}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600"
                placeholder="Describe your organization, mission, and typical campus roles..."
              />
            </div>

            <button
              type="submit"
              className="w-full mt-3 inline-flex items-center justify-center gap-2 py-2.5 px-4 border border-transparent rounded-lg shadow-xs text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-hidden focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all cursor-pointer"
            >
              <span>Complete Company Registration & Enter Dashboard</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </form>

          <div className="mt-6 pt-4 border-t border-slate-100 flex flex-col space-y-2 text-center text-xs">
            <div>
              Already have a recruiter account?{' '}
              <Link to="/company/login" className="font-semibold text-indigo-600 hover:text-indigo-800">
                Sign in to existing account
              </Link>
            </div>
            <div>
              <Link to="/signup" className="text-slate-500 hover:text-blue-600 transition-colors">
                Student looking for career mentoring? Register as Student &rarr;
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
