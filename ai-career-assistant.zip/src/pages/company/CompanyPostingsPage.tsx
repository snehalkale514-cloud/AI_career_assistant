import React, { useState } from 'react';
import {
  Briefcase,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  Edit,
  Trash2,
  Users,
  MapPin,
  Clock,
  Sparkles,
  ArrowUpRight,
} from 'lucide-react';
import { useCompany } from '../../context/CompanyContext.tsx';
import { CompanyJobPosting } from '../../types.ts';
import { JobPostingModal } from '../../components/company/JobPostingModal.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';
import { Link } from 'react-router-dom';

export const CompanyPostingsPage: React.FC = () => {
  const { postings, applicants, changePostingStatus, deletePosting, companyProfile } = useCompany();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [editingPosting, setEditingPosting] = useState<CompanyJobPosting | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const handleTogglePublish = (posting: CompanyJobPosting) => {
    const newStatus = posting.status === 'Published' ? 'Closed' : 'Published';
    const res = changePostingStatus(posting.id, newStatus);
    if (res.success) {
      setStatusMessage(`Posting marked as ${newStatus}.`);
      setTimeout(() => setStatusMessage(null), 3000);
    }
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this job posting? This action cannot be undone.')) {
      const res = deletePosting(id);
      if (res.success) {
        setStatusMessage('Job posting deleted.');
        setTimeout(() => setStatusMessage(null), 3000);
      }
    }
  };

  const filteredPostings = postings.filter((p) => {
    const matchesSearch =
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.requiredSkills.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase())) ||
      p.location.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (filterType === 'published') return p.status === 'Published';
    if (filterType === 'draft') return p.status === 'Draft';
    if (filterType === 'closed') return p.status === 'Closed';
    if (filterType === 'internship') return p.type === 'Internship';
    if (filterType === 'full-time') return p.type === 'Full-time';

    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/company/dashboard" />
      </div>

      {statusMessage && (
        <div className="p-3 text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{statusMessage}</span>
          </div>
          <button onClick={() => setStatusMessage(null)} className="text-emerald-700">
            &times;
          </button>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">
            Job & Internship Postings
          </h1>
          <p className="text-xs text-slate-500">
            Manage active campus listings, configure skill requirements, and track student candidate traffic
          </p>
        </div>
        <button
          onClick={() => setEditingPosting({} as any)}
          className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs hover:shadow-sm transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Post New Opening</span>
        </button>
      </div>

      {/* Search and Filters Bar */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-4 shadow-2xs flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by title, skill (Python, SQL)..."
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:border-indigo-600"
          />
        </div>

        <div className="flex items-center gap-1.5 flex-wrap w-full md:w-auto">
          {[
            { id: 'all', label: `All (${postings.length})` },
            { id: 'published', label: `Published (${postings.filter((p) => p.status === 'Published').length})` },
            { id: 'draft', label: `Draft (${postings.filter((p) => p.status === 'Draft').length})` },
            { id: 'closed', label: `Closed (${postings.filter((p) => p.status === 'Closed').length})` },
            { id: 'internship', label: 'Internships' },
            { id: 'full-time', label: 'Full-time' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterType(tab.id)}
              className={`px-3 py-1.5 text-2xs font-semibold rounded-lg transition-colors cursor-pointer ${
                filterType === tab.id
                  ? 'bg-indigo-600 text-white shadow-2xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Postings List */}
      {filteredPostings.length === 0 ? (
        <div className="bg-white border border-slate-200/90 rounded-2xl p-10 text-center space-y-3">
          <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto">
            <Briefcase className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-slate-800">No matching postings found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Try adjusting your search criteria or create a new job posting for {companyProfile?.name}.
          </p>
          <button
            onClick={() => setEditingPosting({} as any)}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create New Opening</span>
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredPostings.map((job) => {
            const jobApplicants = applicants.filter((a) => a.jobId === job.id);
            const isPublished = job.status === 'Published';
            return (
              <div
                key={job.id}
                className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs hover:border-slate-300 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="space-y-2 min-w-0 max-w-2xl">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h2 className="text-base font-bold text-slate-900">{job.title}</h2>
                    <span
                      className={`px-2 py-0.5 rounded-full text-3xs font-bold uppercase tracking-wider ${
                        job.status === 'Published'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : job.status === 'Draft'
                          ? 'bg-amber-50 text-amber-700 border border-amber-200'
                          : 'bg-slate-100 text-slate-600 border border-slate-200'
                      }`}
                    >
                      {job.status}
                    </span>
                    <span className="px-2 py-0.5 rounded-md text-3xs font-medium bg-slate-100 text-slate-700">
                      {job.type}
                    </span>
                    <span className="px-2 py-0.5 rounded-md text-3xs font-medium bg-indigo-50 text-indigo-700">
                      {job.workplace}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 line-clamp-2">{job.description}</p>

                  <div className="flex items-center gap-4 text-xs text-slate-500 flex-wrap">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      {job.location}
                    </span>
                    <span>&bull;</span>
                    <span className="font-semibold text-slate-700">{job.salary}</span>
                    <span>&bull;</span>
                    <span>{job.experience}</span>
                  </div>

                  {/* Skills badges */}
                  <div className="flex items-center gap-1.5 pt-1 flex-wrap">
                    <span className="text-3xs text-slate-400 font-medium">Required Skills:</span>
                    {job.requiredSkills.map((s) => (
                      <span
                        key={s}
                        className="px-2 py-0.5 rounded text-3xs font-medium bg-indigo-50 text-indigo-700 border border-indigo-100"
                      >
                        {s}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Right Column: Applicants & Action Buttons */}
                <div className="flex md:flex-col items-center md:items-end justify-between gap-3 shrink-0 pt-3 md:pt-0 border-t md:border-t-0 border-slate-100">
                  <Link
                    to="/company/applicants"
                    className="flex items-center gap-2 p-2 rounded-lg bg-indigo-50/80 hover:bg-indigo-100 border border-indigo-100 transition-colors"
                  >
                    <Users className="w-4 h-4 text-indigo-600" />
                    <div className="text-left">
                      <div className="text-xs font-bold text-indigo-900 leading-none">
                        {jobApplicants.length} Candidates
                      </div>
                      <div className="text-3xs text-indigo-600">Review Pipeline &rarr;</div>
                    </div>
                  </Link>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleTogglePublish(job)}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                        isPublished
                          ? 'text-slate-600 bg-white border-slate-200 hover:bg-slate-50'
                          : 'text-white bg-emerald-600 border-emerald-600 hover:bg-emerald-700'
                      }`}
                    >
                      {isPublished ? 'Close Opening' : 'Publish Opening'}
                    </button>

                    <button
                      onClick={() => setEditingPosting(job)}
                      className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors cursor-pointer"
                      title="Edit Opening"
                    >
                      <Edit className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => handleDelete(job.id)}
                      className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                      title="Delete Opening"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Edit / Create Modal */}
      {editingPosting && (
        <JobPostingModal
          isOpen={!!editingPosting}
          onClose={() => setEditingPosting(null)}
          postingToEdit={editingPosting.id ? editingPosting : null}
        />
      )}
    </div>
  );
};
