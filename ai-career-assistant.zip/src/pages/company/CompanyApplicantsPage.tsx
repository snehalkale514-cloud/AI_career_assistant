import React, { useState } from 'react';
import {
  Users,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  FileText,
  Calendar,
  AlertCircle,
  ExternalLink,
  ShieldCheck,
  Award,
  ChevronDown,
} from 'lucide-react';
import { useCompany } from '../../context/CompanyContext.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';
import { CompanyApplicantRecord } from '../../types.ts';

export const CompanyApplicantsPage: React.FC = () => {
  const { applicants, postings, updateApplicantStatus, companyProfile } = useCompany();

  const [selectedJobId, setSelectedJobId] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedApplicant, setSelectedApplicant] = useState<CompanyApplicantRecord | null>(null);
  const [candidateNotes, setCandidateNotes] = useState('');
  const [candidateNextStep, setCandidateNextStep] = useState('');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const filteredApplicants = applicants.filter((app) => {
    if (selectedJobId !== 'all' && app.jobId !== selectedJobId) return false;
    if (selectedStatus !== 'all' && app.status !== selectedStatus) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matches =
        app.candidateName.toLowerCase().includes(q) ||
        app.candidateEmail.toLowerCase().includes(q) ||
        app.candidateCollege.toLowerCase().includes(q) ||
        app.jobTitle.toLowerCase().includes(q) ||
        app.verifiedSkills.some((s) => s.toLowerCase().includes(q));
      if (!matches) return false;
    }

    return true;
  });

  const handleOpenDetail = (app: CompanyApplicantRecord) => {
    setSelectedApplicant(app);
    setCandidateNotes(app.notes || '');
    setCandidateNextStep(app.nextStep || '');
  };

  const handleSaveApplicantReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedApplicant) return;

    const res = updateApplicantStatus(
      selectedApplicant.id,
      selectedApplicant.status,
      candidateNotes,
      candidateNextStep
    );

    if (res.success) {
      setStatusMessage('Candidate review details and next steps updated.');
      setSelectedApplicant(null);
      setTimeout(() => setStatusMessage(null), 3000);
    }
  };

  const handleQuickStatusChange = (
    applicantId: string,
    status: CompanyApplicantRecord['status']
  ) => {
    const res = updateApplicantStatus(applicantId, status);
    if (res.success) {
      setStatusMessage(`Candidate status changed to ${status}.`);
      setTimeout(() => setStatusMessage(null), 3000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/company/dashboard" />
      </div>

      {statusMessage && (
        <div className="p-3 text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{statusMessage}</span>
          </div>
          <button onClick={() => setStatusMessage(null)} className="text-emerald-700">
            &times;
          </button>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">
              Candidate Applications & Pipeline
            </h1>
            <span className="text-3xs font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
              Privacy Secured
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Review verified student candidates who explicitly submitted applications to {companyProfile?.name}
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-4 shadow-2xs flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search candidate, skill, college..."
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:border-indigo-600"
          />
        </div>

        <div className="flex items-center gap-2.5 flex-wrap w-full md:w-auto">
          {/* Job Filter */}
          <select
            value={selectedJobId}
            onChange={(e) => setSelectedJobId(e.target.value)}
            className="px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 font-medium focus:outline-hidden focus:border-indigo-600"
          >
            <option value="all">All Openings ({applicants.length})</option>
            {postings.map((p) => (
              <option key={p.id} value={p.id}>
                {p.title}
              </option>
            ))}
          </select>

          {/* Status Filter */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 font-medium focus:outline-hidden focus:border-indigo-600"
          >
            <option value="all">All Stages</option>
            <option value="Applied">Applied</option>
            <option value="Screening">Screening</option>
            <option value="Interview">Interview</option>
            <option value="Shortlisted">Shortlisted</option>
            <option value="Offer">Offer</option>
            <option value="Rejected">Rejected</option>
          </select>
        </div>
      </div>

      {/* Applicants List / Table */}
      {filteredApplicants.length === 0 ? (
        <div className="bg-white border border-slate-200/90 rounded-2xl p-10 text-center space-y-2">
          <div className="w-12 h-12 rounded-xl bg-slate-100 text-slate-500 flex items-center justify-center mx-auto">
            <Users className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-slate-800">No candidate applications found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            No applications match your selected filters. Note: Student profiles are only accessible when students explicitly apply to your job postings.
          </p>
        </div>
      ) : (
        <div className="bg-white border border-slate-200/90 rounded-2xl shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/80 text-3xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-100">
                  <th className="py-3 px-5">Candidate Name</th>
                  <th className="py-3 px-4">Applied Position</th>
                  <th className="py-3 px-4">College & Cohort</th>
                  <th className="py-3 px-4">Verified Match</th>
                  <th className="py-3 px-4">Pipeline Status</th>
                  <th className="py-3 px-4">Next Step Notes</th>
                  <th className="py-3 px-5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {filteredApplicants.map((app) => (
                  <tr key={app.id} className="hover:bg-slate-50/70 transition-colors">
                    {/* Candidate */}
                    <td className="py-3.5 px-5">
                      <div className="font-bold text-slate-900">{app.candidateName}</div>
                      <div className="text-2xs text-slate-500">{app.candidateEmail}</div>
                      {app.resumeFileName && (
                        <div className="mt-1 flex items-center gap-1 text-3xs text-indigo-600 font-medium">
                          <FileText className="w-3 h-3" />
                          <span>{app.resumeFileName}</span>
                        </div>
                      )}
                    </td>

                    {/* Applied Position */}
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-slate-800">{app.jobTitle}</div>
                      <div className="text-3xs text-slate-400">Date: {app.appliedDate}</div>
                    </td>

                    {/* Academic info */}
                    <td className="py-3.5 px-4">
                      <div className="text-slate-800 font-medium truncate max-w-[200px]">
                        {app.candidateCollege}
                      </div>
                      <div className="text-3xs text-slate-500">
                        {app.candidateDegree} &bull; {app.candidateBranch} ({app.candidateGraduationYear})
                      </div>
                    </td>

                    {/* Verified Match & Skills */}
                    <td className="py-3.5 px-4">
                      <div className="inline-flex items-center px-2 py-0.5 rounded-full text-2xs font-extrabold bg-indigo-50 text-indigo-700 border border-indigo-200">
                        {app.matchScore}% Match
                      </div>
                      <div className="mt-1 flex flex-wrap gap-1 max-w-[200px]">
                        {app.verifiedSkills.slice(0, 3).map((s) => (
                          <span
                            key={s}
                            className="px-1.5 py-0.2 rounded text-3xs bg-slate-100 text-slate-600"
                          >
                            {s}
                          </span>
                        ))}
                      </div>
                    </td>

                    {/* Status */}
                    <td className="py-3.5 px-4">
                      <select
                        value={app.status}
                        onChange={(e) =>
                          handleQuickStatusChange(app.id, e.target.value as any)
                        }
                        className="px-2 py-1 text-2xs font-semibold bg-white border border-slate-200 rounded-md text-slate-800 focus:outline-hidden focus:border-indigo-600 cursor-pointer"
                      >
                        <option value="Applied">Applied</option>
                        <option value="Screening">Screening</option>
                        <option value="Interview">Interview</option>
                        <option value="Shortlisted">Shortlisted</option>
                        <option value="Offer">Offer</option>
                        <option value="Rejected">Rejected</option>
                      </select>
                    </td>

                    {/* Next step notes */}
                    <td className="py-3.5 px-4 max-w-[200px]">
                      <div className="text-2xs text-slate-600 truncate">
                        {app.nextStep || app.notes || 'No active notes'}
                      </div>
                    </td>

                    {/* Actions */}
                    <td className="py-3.5 px-5 text-right">
                      <button
                        onClick={() => handleOpenDetail(app)}
                        className="px-3 py-1.5 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors cursor-pointer"
                      >
                        Review
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Review Modal */}
      {selectedApplicant && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs"
            onClick={() => setSelectedApplicant(null)}
          />
          <div className="relative bg-white rounded-2xl shadow-xl border border-slate-200 max-w-lg w-full p-6 z-10 space-y-4">
            <div className="flex items-start justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  {selectedApplicant.candidateName}
                </h3>
                <p className="text-xs text-slate-500">
                  Applied for {selectedApplicant.jobTitle} &bull; {selectedApplicant.appliedDate}
                </p>
              </div>
              <button
                onClick={() => setSelectedApplicant(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                &times;
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2 p-3 bg-slate-50 rounded-xl">
                <div>
                  <span className="text-3xs text-slate-400 uppercase font-semibold">Degree</span>
                  <div className="font-semibold text-slate-800">
                    {selectedApplicant.candidateDegree} — {selectedApplicant.candidateBranch}
                  </div>
                </div>
                <div>
                  <span className="text-3xs text-slate-400 uppercase font-semibold">College</span>
                  <div className="font-semibold text-slate-800">
                    {selectedApplicant.candidateCollege}
                  </div>
                </div>
              </div>

              <div>
                <span className="block font-semibold text-slate-700 mb-1">Verified Skills</span>
                <div className="flex flex-wrap gap-1">
                  {selectedApplicant.verifiedSkills.map((s) => (
                    <span
                      key={s}
                      className="px-2 py-0.5 rounded text-2xs font-medium bg-indigo-50 text-indigo-700 border border-indigo-100"
                    >
                      {s}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Stage & Status
                </label>
                <select
                  value={selectedApplicant.status}
                  onChange={(e) =>
                    setSelectedApplicant({
                      ...selectedApplicant,
                      status: e.target.value as any,
                    })
                  }
                  className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:border-indigo-600"
                >
                  <option value="Applied">Applied</option>
                  <option value="Screening">Screening</option>
                  <option value="Interview">Interview</option>
                  <option value="Shortlisted">Shortlisted</option>
                  <option value="Offer">Offer</option>
                  <option value="Rejected">Rejected</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Internal Recruiter Screening Notes
                </label>
                <textarea
                  rows={2}
                  value={candidateNotes}
                  onChange={(e) => setCandidateNotes(e.target.value)}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:border-indigo-600"
                  placeholder="e.g. Strong foundational SQL knowledge demonstrated..."
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Next Step / Interview Schedule Reminder
                </label>
                <input
                  type="text"
                  value={candidateNextStep}
                  onChange={(e) => setCandidateNextStep(e.target.value)}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:border-indigo-600"
                  placeholder="e.g. Technical interview scheduled for Friday 2 PM"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setSelectedApplicant(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveApplicantReview}
                className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs"
              >
                Save Candidate Review
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
