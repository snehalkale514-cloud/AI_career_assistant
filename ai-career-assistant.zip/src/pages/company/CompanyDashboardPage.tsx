import React, { useState } from 'react';
import { Link, useOutletContext } from 'react-router-dom';
import {
  Building2,
  Briefcase,
  Users,
  CheckCircle2,
  Clock,
  Plus,
  ExternalLink,
  MapPin,
  Globe,
  ArrowUpRight,
  ShieldCheck,
  TrendingUp,
  FileText,
  Calendar,
  AlertCircle,
  MoreVertical,
  Edit,
  Trash2,
  Eye,
  Check,
} from 'lucide-react';
import { useCompany } from '../../context/CompanyContext.tsx';
import { CompanyJobPosting, CompanyApplicantRecord } from '../../types.ts';
import { JobPostingModal } from '../../components/company/JobPostingModal.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';

export const CompanyDashboardPage: React.FC = () => {
  const {
    companyUser,
    companyProfile,
    postings,
    applicants,
    changePostingStatus,
    deletePosting,
    updateApplicantStatus,
  } = useCompany();

  const [editingPosting, setEditingPosting] = useState<CompanyJobPosting | null>(null);
  const [selectedApplicant, setSelectedApplicant] = useState<CompanyApplicantRecord | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const activePostings = postings.filter((p) => p.status === 'Published');
  const draftPostings = postings.filter((p) => p.status === 'Draft');
  const closedPostings = postings.filter((p) => p.status === 'Closed');

  // Summary counts
  const totalApplications = applicants.length;
  const inInterviewCount = applicants.filter((a) => a.status === 'Interview').length;
  const inScreeningCount = applicants.filter(
    (a) => a.status === 'Screening' || a.status === 'Applied'
  ).length;
  const offersCount = applicants.filter((a) => a.status === 'Offer' || a.status === 'Shortlisted')
    .length;

  const handleTogglePublish = (posting: CompanyJobPosting) => {
    const newStatus = posting.status === 'Published' ? 'Closed' : 'Published';
    const res = changePostingStatus(posting.id, newStatus);
    if (res.success) {
      setStatusMessage(`Posting marked as ${newStatus}.`);
      setTimeout(() => setStatusMessage(null), 3000);
    }
  };

  const handleDeletePosting = (id: string) => {
    if (window.confirm('Are you sure you want to delete this job posting?')) {
      const res = deletePosting(id);
      if (res.success) {
        setStatusMessage('Posting deleted.');
        setTimeout(() => setStatusMessage(null), 3000);
      }
    }
  };

  const handleApplicantStatusChange = (
    applicantId: string,
    newStatus: CompanyApplicantRecord['status']
  ) => {
    const res = updateApplicantStatus(applicantId, newStatus);
    if (res.success) {
      setStatusMessage(`Applicant status updated to ${newStatus}.`);
      setTimeout(() => setStatusMessage(null), 3000);
    }
  };

  return (
    <div className="space-y-6">
      {statusMessage && (
        <div className="p-3 text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between transition-all">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{statusMessage}</span>
          </div>
          <button
            onClick={() => setStatusMessage(null)}
            className="text-emerald-700 hover:text-emerald-900"
          >
            &times;
          </button>
        </div>
      )}

      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/" />
      </div>

      {/* 1. Company Profile Hero Overview */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-xl bg-gradient-to-tr from-indigo-600 to-indigo-800 flex items-center justify-center text-white shadow-xs shrink-0">
              <Building2 className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-xl font-bold text-slate-900">
                  {companyProfile?.name || 'Company Portal'}
                </h1>
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-2xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200/60">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  Verified Employer Partner
                </span>
                <span className="px-2 py-0.5 rounded-full text-2xs font-medium bg-slate-100 text-slate-700">
                  {companyProfile?.industry}
                </span>
              </div>
              <p className="mt-1 text-xs text-slate-600 max-w-2xl leading-relaxed">
                {companyProfile?.description}
              </p>
              <div className="mt-2.5 flex items-center gap-4 text-xs text-slate-500 flex-wrap">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  {companyProfile?.location}
                </span>
                <a
                  href={companyProfile?.website}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-1 text-indigo-600 hover:underline"
                >
                  <Globe className="w-3.5 h-3.5" />
                  {companyProfile?.website.replace('https://', '')}
                </a>
                <span className="text-slate-400">&bull;</span>
                <span className="text-slate-600 font-medium">
                  Logged in: <strong className="text-slate-800">{companyUser?.name}</strong> (
                  {companyUser?.jobTitle})
                </span>
              </div>
            </div>
          </div>

          <div className="flex sm:flex-col gap-2 shrink-0">
            <button
              onClick={() => setEditingPosting({} as any)}
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs hover:shadow-sm transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Create New Posting</span>
            </button>
            <Link
              to="/company/profile"
              className="inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors text-center"
            >
              <span>Edit Company Profile</span>
            </Link>
          </div>
        </div>
      </div>

      {/* 2. Key Metrics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white border border-slate-200/90 rounded-xl p-4 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Active Postings</span>
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
              <Briefcase className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 text-2xl font-bold text-slate-900">{activePostings.length}</div>
          <div className="mt-1 text-2xs text-slate-500">
            {draftPostings.length} drafts &bull; {closedPostings.length} closed
          </div>
        </div>

        <div className="bg-white border border-slate-200/90 rounded-xl p-4 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Total Applicants</span>
            <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 text-2xl font-bold text-slate-900">{totalApplications}</div>
          <div className="mt-1 text-2xs text-slate-500">
            {inScreeningCount} awaiting screening
          </div>
        </div>

        <div className="bg-white border border-slate-200/90 rounded-xl p-4 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Interview Stage</span>
            <div className="p-2 rounded-lg bg-amber-50 text-amber-600">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 text-2xl font-bold text-slate-900">{inInterviewCount}</div>
          <div className="mt-1 text-2xs text-slate-500">Technical & HR rounds scheduled</div>
        </div>

        <div className="bg-white border border-slate-200/90 rounded-xl p-4 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Offers & Shortlisted</span>
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 text-2xl font-bold text-slate-900">{offersCount}</div>
          <div className="mt-1 text-2xs text-slate-500">Final hiring pipeline</div>
        </div>
      </div>

      {/* 3. Active Job & Internship Postings */}
      <div className="bg-white border border-slate-200/90 rounded-2xl shadow-xs overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h2 className="text-sm sm:text-base font-bold text-slate-900">
              Active Job & Internship Postings
            </h2>
            <p className="text-2xs text-slate-500">
              Manage live campus recruitment listings and review student applicants
            </p>
          </div>
          <Link
            to="/company/jobs"
            className="inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-800"
          >
            <span>View All ({postings.length})</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {postings.length === 0 ? (
          <div className="p-8 text-center space-y-3">
            <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto">
              <Briefcase className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-bold text-slate-800">No job postings created yet</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Post your first internship or full-time opening to begin receiving verified student applications.
            </p>
            <button
              onClick={() => setEditingPosting({} as any)}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create Opening Now</span>
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {postings.slice(0, 5).map((job) => {
              const jobApplicants = applicants.filter((a) => a.jobId === job.id);
              const isPublished = job.status === 'Published';
              return (
                <div
                  key={job.id}
                  className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50/70 transition-colors"
                >
                  <div className="min-w-0 space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="text-sm font-bold text-slate-900 hover:text-indigo-600">
                        {job.title}
                      </h3>
                      <span
                        className={`px-2 py-0.5 rounded-full text-3xs font-bold uppercase tracking-wider ${
                          job.status === 'Published'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : job.status === 'Draft'
                            ? 'bg-amber-50 text-amber-700 border border-amber-200'
                            : 'bg-slate-100 text-slate-600 border border-slate-200'
                        }`}
                      >
                        {job.status}
                      </span>
                      <span className="px-2 py-0.5 rounded-md text-3xs font-medium bg-slate-100 text-slate-700">
                        {job.type}
                      </span>
                      <span className="px-2 py-0.5 rounded-md text-3xs font-medium bg-indigo-50 text-indigo-700">
                        {job.workplace}
                      </span>
                    </div>

                    <div className="flex items-center gap-3 text-xs text-slate-500 flex-wrap">
                      <span>{job.location}</span>
                      <span>&bull;</span>
                      <span className="font-semibold text-slate-700">{job.salary}</span>
                      <span>&bull;</span>
                      <span>{job.experience}</span>
                    </div>

                    {/* Skill tags */}
                    <div className="flex items-center gap-1.5 pt-1 flex-wrap">
                      <span className="text-3xs text-slate-400">Required Skills:</span>
                      {job.requiredSkills.map((s) => (
                        <span
                          key={s}
                          className="px-1.5 py-0.5 rounded text-3xs font-medium bg-slate-100 text-slate-600"
                        >
                          {s}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Actions & Applicant Counts */}
                  <div className="flex items-center gap-3 shrink-0 self-end sm:self-center">
                    <div className="text-right sm:pr-3 sm:border-r sm:border-slate-200">
                      <div className="text-sm font-extrabold text-indigo-600">
                        {jobApplicants.length}
                      </div>
                      <div className="text-3xs text-slate-400 uppercase font-semibold">
                        Applicants
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleTogglePublish(job)}
                        className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                          isPublished
                            ? 'text-slate-600 bg-white border-slate-200 hover:bg-slate-50'
                            : 'text-white bg-emerald-600 border-emerald-600 hover:bg-emerald-700'
                        }`}
                      >
                        {isPublished ? 'Close Opening' : 'Publish Live'}
                      </button>

                      <button
                        onClick={() => setEditingPosting(job)}
                        className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors cursor-pointer"
                        title="Edit Posting"
                      >
                        <Edit className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => handleDeletePosting(job.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                        title="Delete Posting"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 4. Recent Student Applications (Role-Based & Privacy Protected) */}
      <div className="bg-white border border-slate-200/90 rounded-2xl shadow-xs overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm sm:text-base font-bold text-slate-900">
                Recent Campus Candidate Applications
              </h2>
              <span className="text-3xs font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                Privacy Enforced &bull; Submitted Applications Only
              </span>
            </div>
            <p className="text-2xs text-slate-500">
              Only students who explicitly submitted applications to {companyProfile?.name} are accessible here
            </p>
          </div>
          <Link
            to="/company/applicants"
            className="inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-800"
          >
            <span>View All Applicants ({applicants.length})</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {applicants.length === 0 ? (
          <div className="p-8 text-center text-slate-500 text-xs">
            No applications received yet for active postings.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/80 text-3xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-100">
                  <th className="py-3 px-5">Candidate</th>
                  <th className="py-3 px-4">Applied Role</th>
                  <th className="py-3 px-4">College & Cohort</th>
                  <th className="py-3 px-4 text-center">Match Score</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {applicants.slice(0, 6).map((app) => (
                  <tr key={app.id} className="hover:bg-slate-50/70 transition-colors">
                    {/* Candidate */}
                    <td className="py-3.5 px-5">
                      <div className="font-bold text-slate-900">{app.candidateName}</div>
                      <div className="text-2xs text-slate-500">{app.candidateEmail}</div>
                    </td>

                    {/* Applied Role */}
                    <td className="py-3.5 px-4 font-medium text-slate-800">
                      {app.jobTitle}
                      <div className="text-3xs text-slate-400">Applied: {app.appliedDate}</div>
                    </td>

                    {/* College & Degree */}
                    <td className="py-3.5 px-4">
                      <div className="text-slate-800 font-medium truncate max-w-[220px]">
                        {app.candidateCollege}
                      </div>
                      <div className="text-3xs text-slate-500">
                        {app.candidateDegree} &bull; {app.candidateBranch} ({app.candidateGraduationYear})
                      </div>
                    </td>

                    {/* Match Score */}
                    <td className="py-3.5 px-4 text-center">
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-2xs font-extrabold bg-indigo-50 text-indigo-700 border border-indigo-200">
                        {app.matchScore}% Match
                      </span>
                    </td>

                    {/* Status */}
                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-3xs font-semibold ${
                          app.status === 'Interview'
                            ? 'bg-amber-50 text-amber-700 border border-amber-200'
                            : app.status === 'Offer'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : app.status === 'Shortlisted'
                            ? 'bg-blue-50 text-blue-700 border border-blue-200'
                            : app.status === 'Rejected'
                            ? 'bg-rose-50 text-rose-700 border border-rose-200'
                            : 'bg-slate-100 text-slate-700 border border-slate-200'
                        }`}
                      >
                        {app.status}
                      </span>
                    </td>

                    {/* Actions */}
                    <td className="py-3.5 px-5 text-right">
                      <div className="inline-flex items-center gap-1">
                        <select
                          value={app.status}
                          onChange={(e) =>
                            handleApplicantStatusChange(app.id, e.target.value as any)
                          }
                          className="px-2 py-1 text-2xs bg-white border border-slate-200 rounded-md text-slate-700 font-medium focus:outline-hidden focus:border-indigo-600 cursor-pointer"
                        >
                          <option value="Applied">Applied</option>
                          <option value="Screening">Screening</option>
                          <option value="Interview">Interview</option>
                          <option value="Shortlisted">Shortlisted</option>
                          <option value="Offer">Offer</option>
                          <option value="Rejected">Rejected</option>
                        </select>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Edit / Create Posting Modal */}
      {editingPosting && (
        <JobPostingModal
          isOpen={!!editingPosting}
          onClose={() => setEditingPosting(null)}
          postingToEdit={editingPosting.id ? editingPosting : null}
        />
      )}
    </div>
  );
};
