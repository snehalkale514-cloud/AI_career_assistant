import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Building2, Mail, Lock, ArrowRight, ShieldCheck, CheckCircle2, Sparkles } from 'lucide-react';
import { useCompany } from '../../context/CompanyContext.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';

export const CompanyLoginPage: React.FC = () => {
  const navigate = useNavigate();
  const { loginCompany, allCompanies } = useCompany();

  const [email, setEmail] = useState('recruiter@technova.com');
  const [password, setPassword] = useState('••••••••••••');
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    const result = loginCompany(email, password);
    if (result.success) {
      navigate('/company/dashboard');
    } else {
      setErrorMessage(result.error || 'Authentication failed. Please check your credentials.');
    }
  };

  const handleQuickDemoLogin = (demoEmail: string) => {
    setEmail(demoEmail);
    const result = loginCompany(demoEmail);
    if (result.success) {
      navigate('/company/dashboard');
    } else {
      setErrorMessage(result.error || 'Failed to sign in.');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative">
      <div className="absolute top-4 left-4 sm:top-6 sm:left-6">
        <BackButton fallback="/" />
      </div>

      {/* Brand & Heading */}
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <Link to="/" className="inline-flex items-center gap-2.5 group">
          <div className="w-9 h-9 rounded-lg bg-indigo-600 flex items-center justify-center text-white shadow-xs group-hover:scale-105 transition-transform">
            <Building2 className="w-5 h-5" />
          </div>
          <span className="text-xl font-extrabold text-slate-900 tracking-tight">
            Employer & Recruiter Portal
          </span>
        </Link>
        <h2 className="mt-6 text-2xl font-bold tracking-tight text-slate-900">
          Sign in to your hiring account
        </h2>
        <p className="mt-1 text-xs text-slate-500">
          Post campus internships, evaluate student applicants, and manage recruitment.
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md px-4">
        <div className="bg-white py-8 px-6 shadow-sm border border-slate-200/90 rounded-2xl sm:px-10">
          {/* Quick Demo Switcher */}
          <div className="mb-6 p-3 bg-indigo-50/70 border border-indigo-100 rounded-xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-2xs font-bold text-indigo-900 uppercase tracking-wider">
                Instant Demo Access
              </span>
              <span className="text-3xs text-indigo-600 font-medium">One-click recruiter sign-in</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('recruiter@technova.com')}
                className="p-2 text-left bg-white hover:bg-indigo-100/50 border border-indigo-200/80 rounded-lg text-xs transition-colors cursor-pointer"
              >
                <div className="font-bold text-slate-900 truncate">TechNova Solutions</div>
                <div className="text-3xs text-slate-500 truncate">Priya S. (Campus Lead)</div>
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('hiring@analyticshub.io')}
                className="p-2 text-left bg-white hover:bg-indigo-100/50 border border-indigo-200/80 rounded-lg text-xs transition-colors cursor-pointer"
              >
                <div className="font-bold text-slate-900 truncate">AnalyticsHub</div>
                <div className="text-3xs text-slate-500 truncate">Vikram S. (Talent Lead)</div>
              </button>
            </div>
          </div>

          {/* Form */}
          <form className="space-y-4" onSubmit={handleSubmit}>
            {errorMessage && (
              <div className="p-3 text-xs text-rose-700 bg-rose-50 border border-rose-200 rounded-lg">
                {errorMessage}
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Recruiter / Company Work Email
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600 transition-colors"
                  placeholder="recruiter@company.com"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600 transition-colors"
                  placeholder="••••••••"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full mt-2 inline-flex items-center justify-center gap-2 py-2.5 px-4 border border-transparent rounded-lg shadow-xs text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-hidden focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all cursor-pointer"
            >
              <span>Sign In to Recruiter Workspace</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </form>

          {/* Links */}
          <div className="mt-6 pt-5 border-t border-slate-100 flex flex-col space-y-3 text-center text-xs">
            <div>
              New hiring partner?{' '}
              <Link to="/company/register" className="font-semibold text-indigo-600 hover:text-indigo-800">
                Register company profile
              </Link>
            </div>
            <div className="pt-2 border-t border-dashed border-slate-200">
              <Link
                to="/login"
                className="inline-flex items-center gap-1.5 font-medium text-slate-500 hover:text-blue-600 transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5 text-blue-500" />
                <span>Are you a student? Switch to Student Login</span>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
