import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  MessageSquareCode,
  Sparkles,
  HelpCircle,
  CheckCircle2,
  RefreshCw,
  Send,
  Sliders,
  ChevronDown,
  Award,
  Layers,
  ArrowRight,
  ShieldCheck,
  Camera,
  Play
} from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';
import { InterviewSetupScreen } from '../../components/interview/InterviewSetupScreen.tsx';
import { LiveInterviewScreen } from '../../components/interview/LiveInterviewScreen.tsx';
import { InterviewResultsScreen } from '../../components/interview/InterviewResultsScreen.tsx';
import { InterviewHistoryModal } from '../../components/interview/InterviewHistoryModal.tsx';
import {
  InterviewSessionConfig,
  QuestionSubmission,
  IntegrityViolationEvent,
  InterviewFinalReport,
  interviewService
} from '../../services/interviewService.ts';

export const InterviewPrepPage: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, interviewHistory, recordInterviewAttempt } = useCareer();

  // Mode: 'setup' | 'live' | 'results'
  const [viewMode, setViewMode] = useState<'setup' | 'live' | 'results'>('setup');
  const [sessionConfig, setSessionConfig] = useState<InterviewSessionConfig | null>(null);
  const [activeMediaStream, setActiveMediaStream] = useState<MediaStream | null>(null);
  const [finalReport, setFinalReport] = useState<InterviewFinalReport | null>(null);
  const [showHistoryModal, setShowHistoryModal] = useState<boolean>(() => {
    return location.pathname.includes('history');
  });

  // Check if routed specifically to /interview-history
  useEffect(() => {
    if (location.pathname.includes('history')) {
      setShowHistoryModal(true);
    }
  }, [location.pathname]);

  // Handler: Start Live Interview from Setup Screen
  const handleStartInterview = (config: InterviewSessionConfig, mediaStream: MediaStream | null) => {
    setSessionConfig(config);
    setActiveMediaStream(mediaStream);
    setViewMode('live');
  };

  // Handler: Complete Live Interview
  const handleFinishInterview = (
    submissions: QuestionSubmission[],
    timeTakenSeconds: number,
    integrityEvents: IntegrityViolationEvent[]
  ) => {
    if (!sessionConfig) return;

    // Generate comprehensive final report
    const report = interviewService.generateFinalReport({
      config: sessionConfig,
      submissions,
      timeTakenSeconds,
      integrityEvents
    });

    setFinalReport(report);

    // Save to CareerContext Interview History
    recordInterviewAttempt({
      date: report.date,
      interviewType: report.interviewType,
      role: user.targetRole || 'Software Engineer',
      score: report.overallScore,
      durationMinutes: Math.round(timeTakenSeconds / 60) || 1,
      status: report.overallScore >= 80 ? 'Exceptional' : report.overallScore >= 65 ? 'Passed' : 'Review Needed',
      feedback: `Completed ${report.interviewType} proctored session with ${report.questionsAnswered} questions answered. Strengths: ${report.strengths.slice(0, 2).join(', ')}.`,
      categoryBreakdown: {
        technical: report.technicalScore,
        communication: report.communicationScore,
        confidence: report.confidenceScore,
        completeness: report.problemSolvingScore,
        coding: report.codingScore,
        problemSolving: report.problemSolvingScore
      },
      codingScore: report.codingScore,
      integrityWarnings: report.integrityWarnings,
      questionsCount: report.questionsAnswered,
      difficulty: report.difficulty,
      detailedReport: report
    });

    setViewMode('results');
  };

  // Handler: Terminate Live Interview Due to Proctoring Violations
  const handleTerminateInterview = (data: {
    reason: string;
    warningCount: number;
    integrityEvents: IntegrityViolationEvent[];
  }) => {
    if (!sessionConfig) return;

    recordInterviewAttempt({
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      interviewType: sessionConfig.type,
      role: user.targetRole || 'Software Engineer',
      score: 0,
      durationMinutes: 1,
      status: 'Terminated',
      feedback: `Session was terminated due to repeated proctoring violations (${data.warningCount}/3 warnings). Reason: ${data.reason}`,
      categoryBreakdown: {
        technical: 0,
        communication: 0,
        confidence: 0,
        completeness: 0
      },
      integrityWarnings: data.warningCount,
      questionsCount: 0,
      difficulty: sessionConfig.difficulty,
      proctoringStatus: 'Terminated',
      terminationReason: data.reason
    });
  };

  // Stop all media tracks if InterviewPrepPage unmounts
  useEffect(() => {
    return () => {
      if (activeMediaStream) {
        activeMediaStream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [activeMediaStream]);

  // Handler: Cancel / Reset
  const handleCancelLive = () => {
    if (activeMediaStream) {
      activeMediaStream.getTracks().forEach((track) => track.stop());
      setActiveMediaStream(null);
    }
    setViewMode('setup');
    setSessionConfig(null);
  };

  const handleRestart = () => {
    if (activeMediaStream) {
      activeMediaStream.getTracks().forEach((track) => track.stop());
      setActiveMediaStream(null);
    }
    setViewMode('setup');
    setFinalReport(null);
    setSessionConfig(null);
  };

  return (
    <div className="space-y-6">
      {viewMode === 'setup' && (
        <div className="flex items-center justify-between">
          <BackButton fallback="/dashboard" />
        </div>
      )}

      {viewMode === 'setup' && (
        <InterviewSetupScreen
          onStartInterview={handleStartInterview}
          onViewHistory={() => setShowHistoryModal(true)}
          defaultRole={user.targetRole}
        />
      )}

      {viewMode === 'live' && sessionConfig && (
        <LiveInterviewScreen
          config={sessionConfig}
          initialMediaStream={activeMediaStream}
          onFinishInterview={handleFinishInterview}
          onCancelInterview={handleCancelLive}
          onTerminateInterview={handleTerminateInterview}
        />
      )}

      {viewMode === 'results' && finalReport && (
        <InterviewResultsScreen
          report={finalReport}
          onRestart={handleRestart}
          onViewHistory={() => setShowHistoryModal(true)}
        />
      )}

      {/* History Modal */}
      {showHistoryModal && (
        <InterviewHistoryModal
          history={interviewHistory}
          onClose={() => setShowHistoryModal(false)}
          onStartNew={() => {
            setShowHistoryModal(false);
            setViewMode('setup');
          }}
        />
      )}
    </div>
  );
};
