import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Bookmark,
  Building2,
  MapPin,
  Trash2,
  ExternalLink,
  ArrowRight,
  Briefcase,
  CheckCircle2,
  AlertCircle,
  Sparkles
} from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';
import { Modal } from '../../components/common/Modal.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';
import { JobItem } from '../../types.ts';

export const SavedJobsPage: React.FC = () => {
  const navigate = useNavigate();
  const { savedJobs, toggleSaveJob, addApplication } = useCareer();
  const [selectedJob, setSelectedJob] = useState<JobItem | null>(null);
  const [applyModalJob, setApplyModalJob] = useState<JobItem | null>(null);
  const [appliedSuccess, setAppliedSuccess] = useState(false);

  const handleApply = (job: JobItem) => {
    if (!job.applicationUrl) return;

    addApplication({
      company: job.company,
      role: job.title,
      location: job.location,
      appliedDate: 'Today',
      status: 'Application Started',
      salary: job.salary,
      notes: `External application started from saved jobs via ${job.company} portal. Match: ${job.matchScore}%.`,
      nextStep: 'Complete application on the employer website.',
    });

    try {
      window.open(job.applicationUrl, '_blank', 'noopener,noreferrer');
    } catch (e) {
      console.error('Failed to open external application url:', e);
    }

    setAppliedSuccess(true);
    setTimeout(() => {
      setAppliedSuccess(false);
      setApplyModalJob(null);
    }, 1800);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/app/jobs" />
      </div>

      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-600 flex items-center gap-1">
              <Bookmark className="w-3.5 h-3.5" />
              Bookmarked Opportunities
            </span>
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            Saved Jobs ({savedJobs.length})
          </h2>
          <p className="text-xs text-slate-500">
            Review and track positions you have shortlisted for upcoming campus intake drives.
          </p>
        </div>

        <button
          onClick={() => navigate('/app/jobs')}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors cursor-pointer"
        >
          <Briefcase className="w-3.5 h-3.5" />
          <span>Discover More Jobs</span>
        </button>
      </div>

      {/* Saved Jobs List */}
      {savedJobs.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200/90 p-12 text-center space-y-4 shadow-xs">
          <div className="w-14 h-14 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
            <Bookmark className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-bold text-slate-900">No Saved Jobs Yet</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed">
              Explore recommended roles matching your profile and bookmark them to prepare targeted applications.
            </p>
          </div>
          <button
            onClick={() => navigate('/app/jobs')}
            className="inline-flex items-center gap-2 px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
          >
            <span>Browse Job Recommendations</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {savedJobs.map((job) => (
            <div
              key={job.id}
              className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs hover:border-slate-300 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-slate-900">{job.title}</h3>
                  <span className="text-3xs font-semibold px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200">
                    {job.matchScore}% Match
                  </span>
                </div>

                <div className="flex items-center gap-3 text-xs text-slate-600">
                  <span className="font-semibold text-slate-800">{job.company}</span>
                  <span>·</span>
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-slate-400" />
                    {job.location} ({job.workplace})
                  </span>
                  <span>·</span>
                  <span className="font-mono text-slate-700 font-medium">{job.salary}</span>
                </div>

                <div className="flex flex-wrap gap-1 pt-1">
                  {job.requiredSkills.map((sk) => (
                    <span
                      key={sk}
                      className="text-2xs px-2 py-0.5 rounded bg-slate-100 text-slate-700"
                    >
                      {sk}
                    </span>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 pt-3 sm:pt-0 border-t sm:border-t-0 border-slate-100 shrink-0">
                <button
                  onClick={() => setSelectedJob(job)}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                >
                  View
                </button>

                <button
                  onClick={() => setApplyModalJob(job)}
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors cursor-pointer"
                >
                  Apply
                </button>

                <button
                  onClick={() => toggleSaveJob(job.id)}
                  className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                  title="Remove from saved"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* View Job Modal */}
      {selectedJob && (
        <Modal
          isOpen={true}
          onClose={() => setSelectedJob(null)}
          title={selectedJob.title}
          subtitle={`${selectedJob.company} · ${selectedJob.location}`}
          maxWidth="2xl"
        >
          <div className="space-y-4 text-xs text-slate-700">
            <p className="leading-relaxed">{selectedJob.description}</p>
            <div>
              <h5 className="font-bold text-slate-900 mb-1">Key Responsibilities</h5>
              <ul className="list-disc pl-4 space-y-1">
                {selectedJob.responsibilities.map((r, i) => (
                  <li key={i}>{r}</li>
                ))}
              </ul>
            </div>
            <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
              <button
                onClick={() => setSelectedJob(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 rounded-lg"
              >
                Close
              </button>
              <button
                onClick={() => {
                  setApplyModalJob(selectedJob);
                  setSelectedJob(null);
                }}
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg"
              >
                Apply Now
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Apply Modal */}
      {applyModalJob && (
        <Modal
          isOpen={true}
          onClose={() => setApplyModalJob(null)}
          title={applyModalJob.applicationUrl ? `Apply to ${applyModalJob.company}` : 'Application Link Unavailable'}
          subtitle={`Position: ${applyModalJob.title}`}
          maxWidth="md"
        >
          <div className="space-y-4 text-xs text-slate-700">
            {!applyModalJob.applicationUrl ? (
              <div className="space-y-4">
                <div className="p-4 bg-amber-50 rounded-xl border border-amber-200 text-amber-900 space-y-2">
                  <div className="flex items-center gap-2 font-bold text-sm text-amber-950">
                    <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>Application link unavailable</span>
                  </div>
                  <p className="text-xs text-amber-800 leading-relaxed">
                    This job does not currently provide an external application link.
                  </p>
                </div>
                <div className="flex justify-end pt-2 border-t border-slate-100">
                  <button
                    onClick={() => setApplyModalJob(null)}
                    className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 rounded-lg cursor-pointer"
                  >
                    Close
                  </button>
                </div>
              </div>
            ) : appliedSuccess ? (
              <div className="p-4 text-center space-y-2">
                <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
                <h4 className="text-sm font-bold text-slate-900">Application Started!</h4>
                <p className="text-xs text-slate-600">Opening employer portal in a new tab. Recorded in your Application Tracker.</p>
              </div>
            ) : (
              <>
                <p className="leading-relaxed">
                  Review this job application before continuing to the employer&apos;s application page. You will complete and submit your application directly on their website.
                </p>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
                  <div className="flex justify-between font-medium">
                    <span className="text-slate-500">Your ATS Resume Profile:</span>
                    <span className="font-semibold text-slate-900">Snehal_Kale_Resume_DataAnalyst.pdf</span>
                  </div>
                  <div className="flex justify-between font-medium">
                    <span className="text-slate-500">ATS Readiness Score:</span>
                    <span className="font-mono text-emerald-600 font-bold">84/100</span>
                  </div>
                  <div className="p-2 bg-blue-50/80 rounded border border-blue-100 text-3xs text-blue-900 leading-normal">
                    <strong>Note:</strong> Your resume is not automatically submitted or uploaded to the employer. You must complete the application and upload your resume directly on the employer&apos;s website.
                  </div>
                </div>
                <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                  <button
                    onClick={() => setApplyModalJob(null)}
                    className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900 bg-slate-100 rounded-lg cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => handleApply(applyModalJob)}
                    className="inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs cursor-pointer"
                  >
                    <span>Continue to Employer</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </button>
                </div>
              </>
            )}
          </div>
        </Modal>
      )}
    </div>
  );
};
