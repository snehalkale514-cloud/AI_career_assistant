import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Briefcase,
  Search,
  MapPin,
  Bookmark,
  CheckCircle2,
  AlertCircle,
  Filter,
  Sparkles,
  ArrowRight,
  SlidersHorizontal,
  Building2,
  DollarSign
} from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';
import { useCompany } from '../../context/CompanyContext.tsx';
import { Modal } from '../../components/common/Modal.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';
import { JobItem, CompanyApplicantRecord } from '../../types.ts';
import { liveJobsService, LiveJobFetchResult } from '../../services/liveJobsService.ts';
import { DataTransparencyBadge } from '../../components/common/DataTransparencyBadge.tsx';
import { Radio, RefreshCw, ExternalLink } from 'lucide-react';

export const JobRecommendationsPage: React.FC = () => {
  const navigate = useNavigate();
  const {
    jobs,
    liveJobState,
    isLoadingJobs,
    refreshLiveJobs,
    toggleSaveJob,
    addApplication,
    user,
    skills,
    resumeAnalysis,
    isStudentAuthenticated,
    applications,
  } = useCareer();

  const { allPostings, allApplicants, submitStudentApplication } = useCompany();

  // Combine published company postings with live jobs
  const combinedJobs: JobItem[] = useMemo(() => {
    const publishedPostings = (allPostings || []).filter((p) => p.status === 'Published');
    const studentSkillInputs = skills.map((s) => ({
      name: s.name,
      currentLevel: s.currentLevel,
    }));

    const companyJobItems: JobItem[] = publishedPostings.map((p) => {
      const gap = liveJobsService.calculateSkillGaps(
        studentSkillInputs,
        p.requiredSkills,
        p.title,
        p.workplace === 'Remote',
        user.targetRole,
        user.workPreference
      );
      return {
        id: p.id,
        companyId: p.companyId,
        title: p.title,
        company: p.companyName,
        location: p.location,
        type: p.type,
        workplace: p.workplace,
        experience: p.experience,
        salary: p.salary,
        matchScore: gap.matchScore,
        requiredSkills: p.requiredSkills,
        matchedSkills: gap.matched,
        missingSkills: gap.missing,
        description: p.description,
        responsibilities: p.responsibilities,
        requirements: p.requirements,
        postedDaysAgo: 1,
        isSaved: jobs.find((j) => j.id === p.id)?.isSaved || false,
        isLive: false,
        isCompanyPartner: true,
        status: p.status,
        applicantsCount: p.applicantsCount || 0,
      };
    });

    const otherJobs = jobs.filter(
      (j) => !companyJobItems.some((cj) => cj.id === j.id)
    );
    return [...companyJobItems, ...otherJobs];
  }, [allPostings, skills, user.targetRole, user.workPreference, jobs]);

  // Filters state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedWorkplace, setSelectedWorkplace] = useState<string>('All');
  const [selectedLocation, setSelectedLocation] = useState<string>('All');
  const [minMatch, setMinMatch] = useState<number>(0);

  // Available locations derived dynamically from combined jobs dataset
  const availableLocations = useMemo(() => {
    const locSet = new Set<string>();
    combinedJobs.forEach((j) => {
      if (j.location && j.location !== 'Not provided' && j.location.toLowerCase() !== 'remote') {
        locSet.add(j.location);
      }
    });
    return Array.from(locSet).sort().slice(0, 20);
  }, [combinedJobs]);

  // Selected job for detail view modal
  const [selectedJob, setSelectedJob] = useState<JobItem | null>(null);
  const [applyModalJob, setApplyModalJob] = useState<JobItem | null>(null);
  const [appliedSuccess, setAppliedSuccess] = useState(false);
  const [applyError, setApplyError] = useState<string | null>(null);
  const [applySuccessMessage, setApplySuccessMessage] = useState<string | null>(null);

  const filteredJobs = useMemo(() => {
    return combinedJobs.filter((job) => {
      const q = searchQuery.trim().toLowerCase();
      const matchesSearch =
        !q ||
        job.title.toLowerCase().includes(q) ||
        job.company.toLowerCase().includes(q) ||
        job.requiredSkills.some((s) => s.toLowerCase().includes(q));

      const matchesWorkplace =
        selectedWorkplace === 'All' || job.workplace === selectedWorkplace;

      const matchesLocation =
        selectedLocation === 'All' ||
        (selectedLocation === 'Remote'
          ? (job.workplace === 'Remote' || job.location.toLowerCase().includes('remote'))
          : job.location.toLowerCase().includes(selectedLocation.toLowerCase()));

      const matchesScore = minMatch === 0 || job.matchScore >= minMatch;

      return matchesSearch && matchesWorkplace && matchesLocation && matchesScore;
    });
  }, [combinedJobs, searchQuery, selectedWorkplace, selectedLocation, minMatch]);

  const handleApply = (job: JobItem) => {
    if (!job.applicationUrl) return;

    addApplication({
      company: job.company,
      role: job.title,
      location: job.location,
      appliedDate: 'Today',
      status: 'Application Started',
      salary: job.salary,
      notes: `External application started via ${job.company} portal. Match: ${job.matchScore}%.`,
      nextStep: 'Complete application on the employer website.',
    });

    try {
      window.open(job.applicationUrl, '_blank', 'noopener,noreferrer');
    } catch (e) {
      console.error('Failed to open external application url:', e);
    }

    setAppliedSuccess(true);
    setTimeout(() => {
      setAppliedSuccess(false);
      setApplyModalJob(null);
      setSelectedJob(null);
    }, 1800);
  };

  const handleDirectCompanyApply = (job: JobItem) => {
    setApplyError(null);
    if (!isStudentAuthenticated) {
      setApplyError('Please sign in as a student to submit your application.');
      return;
    }

    // Check duplicate
    const alreadyApplied = applications.some((a) => a.jobId === job.id) ||
      allApplicants.some(
        (a: CompanyApplicantRecord) =>
          a.jobId === job.id &&
          (a.studentId === (user.id || 'std_snehal_kale') ||
            a.candidateEmail.toLowerCase() === user.email.toLowerCase())
      );

    if (alreadyApplied) {
      setApplyError('You have already submitted an application for this position.');
      return;
    }

    if (job.status && job.status !== 'Published') {
      setApplyError('This position is currently closed to new applications.');
      return;
    }

    const res = submitStudentApplication({
      jobId: job.id,
      studentId: user.id || 'std_snehal_kale',
      candidateName: user.name,
      candidateEmail: user.email,
      candidateCollege: user.college,
      candidateDegree: user.degree,
      candidateBranch: user.branch || 'AI & Data Science',
      candidateGraduationYear: user.graduationYear,
      verifiedSkills: skills.map((s) => s.name),
      matchScore: job.matchScore,
      resumeFileName: resumeAnalysis.analyzedFileName || 'Snehal_Kale_Resume_DataAnalyst.pdf',
      atsScore: resumeAnalysis.atsScore || 84,
      notes: `Direct campus drive application. ATS Score: ${resumeAnalysis.atsScore || 84}/100.`,
    });

    if (!res.success) {
      setApplyError(res.error || 'Failed to submit application.');
      return;
    }

    addApplication({
      id: res.applicant?.id,
      jobId: job.id,
      companyId: job.companyId,
      studentId: user.id || 'std_snehal_kale',
      company: job.company,
      role: job.title,
      location: job.location,
      appliedDate: 'Today',
      status: 'Applied',
      salary: job.salary,
      notes: `Direct application submitted to ${job.company}. Match score: ${job.matchScore}%.`,
      nextStep: 'Application under review by recruiter.',
      resumeFileName: resumeAnalysis.analyzedFileName || 'Snehal_Kale_Resume_DataAnalyst.pdf',
      atsScore: resumeAnalysis.atsScore || 84,
    });

    setApplySuccessMessage(`Application successfully submitted directly to ${job.company}!`);
    setTimeout(() => {
      setApplySuccessMessage(null);
      setApplyModalJob(null);
      setSelectedJob(null);
    }, 2000);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/dashboard" />
      </div>

      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-600 flex items-center gap-1">
              <Briefcase className="w-3.5 h-3.5" />
              Recruitment Feed
            </span>
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            Job &amp; Internship Recommendations
          </h2>
          <p className="text-xs text-slate-500">
            Curated openings ranked by verified technical skill overlap and graduation cohort.
          </p>
        </div>

        <button
          onClick={() => navigate('/app/saved-jobs')}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-2xs transition-colors cursor-pointer"
        >
          <Bookmark className="w-3.5 h-3.5 text-blue-600" />
          <span>View Saved Jobs</span>
        </button>
      </div>

      {/* 3-Tier Architecture Transparency Badge */}
      <DataTransparencyBadge activeScope="jobs" />

      {/* Live Job Stream Status Banner */}
      <div className={`p-4 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
        liveJobState?.isLive
          ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
          : 'bg-amber-50/70 border-amber-200 text-amber-950'
      }`}>
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center">
            <Radio className={`w-5 h-5 ${liveJobState?.isLive ? 'text-emerald-600 animate-pulse' : 'text-amber-600'}`} />
          </div>
          <div className="space-y-0.5">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider">
                {liveJobState?.isLive ? 'Live Job Data' : 'Curated Verified Benchmark Data'}
              </span>
              <span className="text-3xs font-mono px-2 py-0.5 rounded bg-white/80 border border-slate-200 text-slate-700">
                Source: {liveJobState?.source || 'Public Feed'}
              </span>
            </div>
            <p className="text-xs text-slate-600">
              {liveJobState?.statusMessage || 'Retrieving current live tech openings and matching requirements against your verified skills.'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <span className="text-2xs font-mono text-slate-500">
            Last updated: <strong>{liveJobState?.lastUpdated || 'Current session'}</strong>
          </span>
          <button
            onClick={refreshLiveJobs}
            disabled={isLoadingJobs}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-2xs text-slate-700 transition-colors cursor-pointer disabled:opacity-60"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoadingJobs ? 'animate-spin text-blue-600' : 'text-slate-500'}`} />
            <span>Refresh Live Feed</span>
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-xs space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Keyword Search */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search title, company, skill..."
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:outline-hidden focus:bg-white focus:border-blue-600"
            />
          </div>

          {/* Workplace Filter */}
          <div>
            <select
              value={selectedWorkplace}
              onChange={(e) => setSelectedWorkplace(e.target.value)}
              className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-hidden focus:bg-white focus:border-blue-600"
            >
              <option value="All">All Workplaces (Remote &amp; Onsite)</option>
              <option value="Remote">Remote Only</option>
              <option value="Hybrid">Hybrid</option>
              <option value="On-site">On-site Only</option>
            </select>
          </div>

          {/* Location Filter */}
          <div>
            <select
              value={selectedLocation}
              onChange={(e) => setSelectedLocation(e.target.value)}
              className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-hidden focus:bg-white focus:border-blue-600"
            >
              <option value="All">All Locations</option>
              <option value="Remote">Remote</option>
              {availableLocations.map((loc) => (
                <option key={loc} value={loc}>
                  {loc}
                </option>
              ))}
            </select>
          </div>

          {/* Min Match Slider */}
          <div className="flex items-center justify-between gap-2 px-2 text-xs">
            <span className="text-slate-500 whitespace-nowrap">Min Match:</span>
            <input
              type="range"
              min="0"
              max="95"
              step="5"
              value={minMatch}
              onChange={(e) => setMinMatch(Number(e.target.value))}
              className="w-full accent-blue-600 cursor-pointer"
            />
            <span className="font-mono font-bold text-blue-700 tabular-nums">
              {minMatch === 0 ? 'All' : `${minMatch}%`}
            </span>
          </div>
        </div>

        <div className="flex items-center justify-between pt-1 text-2xs text-slate-500 border-t border-slate-100">
          <span>Showing <strong>{filteredJobs.length}</strong> matching positions</span>
          {(searchQuery || selectedWorkplace !== 'All' || selectedLocation !== 'All' || minMatch > 0) && (
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedWorkplace('All');
                setSelectedLocation('All');
                setMinMatch(0);
              }}
              className="text-blue-600 hover:underline font-semibold cursor-pointer"
            >
              Reset filters
            </button>
          )}
        </div>
      </div>

      {/* Jobs Grid / Loading State / Empty State */}
      {isLoadingJobs && jobs.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200/90 p-12 text-center space-y-3 shadow-xs">
          <RefreshCw className="w-8 h-8 text-blue-600 animate-spin mx-auto" />
          <h3 className="text-base font-bold text-slate-900">Loading Live Opportunities</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Retrieving current job openings from Arbeitnow Live Public API and evaluating skill matches for your profile...
          </p>
        </div>
      ) : filteredJobs.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200/90 p-12 text-center space-y-4 shadow-xs">
          <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-500">
            <Briefcase className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-bold text-slate-900">
              {jobs.length === 0 ? 'No current jobs available' : 'No matching positions found'}
            </h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              {jobs.length === 0
                ? 'Live job data is temporarily unavailable from the configured public API feed. Click "Refresh Live Feed" to re-check for active listings.'
                : 'No positions matched your selected search or filter criteria. Try adjusting or resetting your filters to see available opportunities.'}
            </p>
          </div>
          {jobs.length === 0 ? (
            <button
              onClick={refreshLiveJobs}
              disabled={isLoadingJobs}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors cursor-pointer shadow-xs disabled:opacity-50 mx-auto"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoadingJobs ? 'animate-spin' : ''}`} />
              <span>Retry Fetching Live Feed</span>
            </button>
          ) : (
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedWorkplace('All');
                setSelectedLocation('All');
                setMinMatch(0);
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors cursor-pointer mx-auto"
            >
              <span>Reset All Filters</span>
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {filteredJobs.map((job) => (
          <div
            key={job.id}
            className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs hover:border-slate-300 hover:shadow-sm transition-all space-y-4 flex flex-col justify-between"
          >
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2.5 flex-wrap">
                  <h3 className="text-base font-bold text-slate-900 tracking-tight">
                    {job.title}
                  </h3>
                  {job.isCompanyPartner && (
                    <span className="text-3xs font-extrabold px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200 flex items-center gap-1">
                      <Building2 className="w-3 h-3" />
                      Campus Partner
                    </span>
                  )}
                  <span className="text-3xs font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                    {job.type}
                  </span>
                  <span className="text-3xs font-semibold px-2 py-0.5 rounded bg-blue-50 text-blue-700">
                    {job.workplace}
                  </span>
                </div>

                <p className="text-xs text-slate-600">
                  <span className="font-semibold text-slate-800">{job.company}</span> · {job.location} · {job.experience}
                </p>

                <p className="text-xs text-slate-500 mt-2 line-clamp-2 leading-relaxed">
                  {job.description}
                </p>
              </div>

              {/* Match Score Badge */}
              <div className="text-left sm:text-right shrink-0">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 font-mono text-xs font-bold">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{job.matchScore}% Match</span>
                </div>
                <span className="block font-mono text-xs font-bold text-slate-800 mt-1">
                  {job.salary}
                </span>
              </div>
            </div>

            {/* Skills & Real Skill-Gap Matching */}
            <div className="space-y-2 pt-1">
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="text-2xs text-slate-500 font-bold uppercase tracking-wider mr-1">Required:</span>
                {job.requiredSkills.map((sk) => {
                  const isMatched = job.matchedSkills.includes(sk);
                  return (
                    <span
                      key={sk}
                      className={`text-2xs px-2.5 py-0.5 rounded-md font-medium ${
                        isMatched
                          ? 'bg-blue-50 text-blue-800 border border-blue-200'
                          : 'bg-slate-100 text-slate-700 border border-slate-200'
                      }`}
                    >
                      {isMatched ? '✓ ' : ''}{sk}
                    </span>
                  );
                })}
              </div>

              {/* Explicit Skill Gap Row */}
              {job.missingSkills && job.missingSkills.length > 0 ? (
                <div className="flex flex-wrap items-center gap-1.5 text-2xs p-2.5 rounded-lg bg-amber-50/80 border border-amber-200/90 text-amber-900">
                  <span className="font-bold flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                    Missing skills →
                  </span>
                  {job.missingSkills.map((missingSkill) => (
                    <span
                      key={missingSkill}
                      className="px-2 py-0.5 rounded bg-white font-bold text-amber-900 border border-amber-300 shadow-2xs"
                    >
                      {missingSkill}
                    </span>
                  ))}
                  <span className="text-amber-700 text-3xs ml-1">
                    (Compare against current student profile)
                  </span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 text-2xs p-2 rounded-lg bg-emerald-50/70 border border-emerald-200 text-emerald-900">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="font-semibold">Complete Skill Alignment!</span>
                  <span className="text-emerald-700 text-3xs">Student profile satisfies all listed requirements.</span>
                </div>
              )}
            </div>

            {/* Bottom Actions */}
            <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <span className="text-2xs text-slate-400 font-mono">
                {job.dateFetched ? `Fetched: ${job.dateFetched}` : `Listed ${job.postedDaysAgo} days ago`} · {job.isLive ? 'Live Open Opportunity' : 'Verified Partner Opportunity'}
              </span>

              <div className="flex items-center gap-2">
                {job.applicationUrl && (
                  <a
                    href={job.applicationUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-lg border border-slate-200 text-slate-500 hover:text-blue-600 hover:bg-slate-50 transition-colors"
                    title="External Application Link"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                )}

                <button
                  onClick={() => toggleSaveJob(job.id)}
                  className={`p-2 rounded-lg border transition-colors cursor-pointer ${
                    job.isSaved
                      ? 'bg-blue-50 text-blue-600 border-blue-200'
                      : 'bg-white text-slate-400 border-slate-200 hover:text-slate-700'
                  }`}
                  title={job.isSaved ? 'Saved' : 'Save Job'}
                >
                  <Bookmark className="w-4 h-4" />
                </button>

                <button
                  onClick={() => setSelectedJob(job)}
                  className="px-3.5 py-1.5 font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                >
                  View Job
                </button>

                {applications.some((a) => a.jobId === job.id) ||
                allApplicants.some(
                  (a: CompanyApplicantRecord) =>
                    a.jobId === job.id &&
                    (a.studentId === (user.id || 'std_snehal_kale') ||
                      a.candidateEmail.toLowerCase() === user.email.toLowerCase())
                ) ? (
                  <span className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Applied
                  </span>
                ) : (
                  <button
                    onClick={() => {
                      setApplyError(null);
                      setApplySuccessMessage(null);
                      setApplyModalJob(job);
                    }}
                    className="px-4 py-1.5 font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors cursor-pointer"
                  >
                    Apply
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
      )}

      {/* 18. Detailed Job Modal */}
      {selectedJob && (
        <Modal
          isOpen={true}
          onClose={() => setSelectedJob(null)}
          title={selectedJob.title}
          subtitle={`${selectedJob.company} · ${selectedJob.location} · ${selectedJob.salary}`}
          maxWidth="2xl"
        >
          <div className="space-y-5 text-xs text-slate-700">
            {/* Match Overview Banner */}
            <div className="p-4 rounded-xl bg-blue-50/60 border border-blue-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-blue-900 text-sm">
                  Your Profile Match: {selectedJob.matchScore}%
                </span>
                <span className="text-2xs font-mono text-slate-500">
                  {selectedJob.experience}
                </span>
              </div>
              <p className="text-slate-700 leading-relaxed">
                <strong>Why this job matches you:</strong>{' '}
                {selectedJob.matchedSkills.length > 0
                  ? `Matches your verified skills in ${selectedJob.matchedSkills.join(', ')} for ${selectedJob.title}.`
                  : `Limited technical skill overlap detected for this role. Developing ${selectedJob.missingSkills.slice(0, 3).join(', ')} will strengthen your candidate profile.`}
              </p>
            </div>

            {/* Matched vs Missing */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200">
                <span className="font-bold text-emerald-800 block mb-1">
                  ✓ Matched Skills ({selectedJob.matchedSkills.length})
                </span>
                <p className="text-slate-700">{selectedJob.matchedSkills.join(', ')}</p>
              </div>

              <div className="p-3 bg-amber-50 rounded-lg border border-amber-200">
                <span className="font-bold text-amber-800 block mb-1">
                  ! Skills to Strengthen ({selectedJob.missingSkills.length})
                </span>
                <p className="text-slate-700">{selectedJob.missingSkills.join(', ')}</p>
              </div>
            </div>

            {/* Description */}
            <div>
              <h4 className="font-bold text-slate-900 mb-1">Job Description</h4>
              <p className="leading-relaxed">{selectedJob.description}</p>
            </div>

            {/* Responsibilities */}
            <div>
              <h4 className="font-bold text-slate-900 mb-1.5">Responsibilities</h4>
              <ul className="list-disc pl-5 space-y-1">
                {selectedJob.responsibilities.map((r, i) => (
                  <li key={i}>{r}</li>
                ))}
              </ul>
            </div>

            {/* Requirements */}
            <div>
              <h4 className="font-bold text-slate-900 mb-1.5">Requirements &amp; Eligibility</h4>
              <ul className="list-disc pl-5 space-y-1">
                {selectedJob.requirements.map((req, i) => (
                  <li key={i}>{req}</li>
                ))}
              </ul>
            </div>

            {/* Actions */}
            <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
              <button
                onClick={() => toggleSaveJob(selectedJob.id)}
                className="px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-lg flex items-center gap-1.5"
              >
                <Bookmark className="w-3.5 h-3.5" />
                <span>{selectedJob.isSaved ? 'Saved to Bookmarks' : 'Save Job'}</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setSelectedJob(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 rounded-lg"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    setApplyModalJob(selectedJob);
                    setSelectedJob(null);
                  }}
                  className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
                >
                  Apply Now
                </button>
              </div>
            </div>
          </div>
        </Modal>
      )}

      {/* Apply Modal */}
      {applyModalJob && (
        <Modal
          isOpen={true}
          onClose={() => {
            setApplyModalJob(null);
            setApplyError(null);
            setApplySuccessMessage(null);
          }}
          title={
            applySuccessMessage
              ? 'Application Submitted'
              : applyModalJob.isCompanyPartner
              ? `Apply to ${applyModalJob.company}`
              : applyModalJob.applicationUrl
              ? `Apply to ${applyModalJob.company}`
              : 'Application Link Unavailable'
          }
          subtitle={`Role: ${applyModalJob.title} ${applyModalJob.isCompanyPartner ? '· Campus Recruitment Drive' : ''}`}
          maxWidth="md"
        >
          <div className="space-y-4 text-xs text-slate-700">
            {applyModalJob.isCompanyPartner ? (
              // Direct Campus Partner Application Flow
              applySuccessMessage ? (
                <div className="p-6 text-center space-y-3">
                  <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
                  <h4 className="text-base font-bold text-slate-900">Application Submitted!</h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {applySuccessMessage}
                  </p>
                  <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-900 text-2xs space-y-1 text-left">
                    <div className="font-bold">Application Details:</div>
                    <div>Position: {applyModalJob.title} at {applyModalJob.company}</div>
                    <div>Candidate: {user.name} ({user.email})</div>
                    <div>College: {user.college} &bull; {user.degree} ({user.graduationYear})</div>
                    <div>Status: Applied (Direct Campus Drive)</div>
                  </div>
                </div>
              ) : !isStudentAuthenticated ? (
                <div className="p-4 bg-amber-50 rounded-xl border border-amber-200 text-amber-900 space-y-3">
                  <div className="flex items-center gap-2 font-bold text-sm text-amber-950">
                    <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>Student Sign-In Required</span>
                  </div>
                  <p className="text-xs text-amber-800 leading-relaxed">
                    You need to be signed in to your student account to submit an application to {applyModalJob.company}.
                  </p>
                  <div className="pt-2 flex items-center justify-end gap-2 border-t border-amber-200/60">
                    <button
                      onClick={() => setApplyModalJob(null)}
                      className="px-3.5 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-white border border-slate-200 rounded-lg cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => {
                        setApplyModalJob(null);
                        navigate('/login');
                      }}
                      className="px-4 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs cursor-pointer"
                    >
                      Sign In as Student &rarr;
                    </button>
                  </div>
                </div>
              ) : applications.some((a) => a.jobId === applyModalJob.id) ||
                allApplicants.some(
                  (a: CompanyApplicantRecord) =>
                    a.jobId === applyModalJob.id &&
                    (a.studentId === (user.id || 'std_snehal_kale') ||
                      a.candidateEmail.toLowerCase() === user.email.toLowerCase())
                ) ? (
                <div className="space-y-4">
                  <div className="p-4 bg-blue-50 rounded-xl border border-blue-200 text-blue-900 space-y-2">
                    <div className="flex items-center gap-2 font-bold text-sm text-blue-950">
                      <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                      <span>Already Applied</span>
                    </div>
                    <p className="text-xs text-blue-800 leading-relaxed">
                      You have already submitted an application for this position at {applyModalJob.company}. Recruiter feedback, screening notes, and interview invitations can be viewed in your Application Tracker.
                    </p>
                  </div>
                  <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
                    <button
                      onClick={() => setApplyModalJob(null)}
                      className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 rounded-lg cursor-pointer"
                    >
                      Close
                    </button>
                    <button
                      onClick={() => {
                        setApplyModalJob(null);
                        navigate('/applications');
                      }}
                      className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs cursor-pointer"
                    >
                      View in Application Tracker &rarr;
                    </button>
                  </div>
                </div>
              ) : applyModalJob.status && applyModalJob.status !== 'Published' ? (
                <div className="space-y-4">
                  <div className="p-4 bg-rose-50 rounded-xl border border-rose-200 text-rose-900 space-y-2">
                    <div className="flex items-center gap-2 font-bold text-sm text-rose-950">
                      <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                      <span>Position Closed</span>
                    </div>
                    <p className="text-xs text-rose-800 leading-relaxed">
                      This opening has been closed by {applyModalJob.company} and is no longer accepting new applications.
                    </p>
                  </div>
                  <div className="pt-2 flex justify-end">
                    <button
                      onClick={() => setApplyModalJob(null)}
                      className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-lg cursor-pointer"
                    >
                      Close
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {applyError && (
                    <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-xl flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                      <span>{applyError}</span>
                    </div>
                  )}

                  <p className="leading-relaxed">
                    You are submitting a verified candidate application to <strong>{applyModalJob.company}</strong>. Your student profile, technical skill match, and ATS resume will be delivered directly to the company recruiter pipeline.
                  </p>

                  <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2.5">
                    <div className="flex justify-between font-medium">
                      <span className="text-slate-500">Applicant:</span>
                      <span className="font-semibold text-slate-900">{user.name} ({user.email})</span>
                    </div>
                    <div className="flex justify-between font-medium">
                      <span className="text-slate-500">College &amp; Degree:</span>
                      <span className="text-slate-800 font-semibold">{user.college} &bull; {user.degree} ({user.graduationYear})</span>
                    </div>
                    <div className="flex justify-between font-medium">
                      <span className="text-slate-500">Role Match:</span>
                      <span className="font-mono text-emerald-600 font-bold">{applyModalJob.matchScore}% Match</span>
                    </div>
                    <div className="flex justify-between font-medium">
                      <span className="text-slate-500">ATS Resume Profile:</span>
                      <span className="font-semibold text-slate-900">{resumeAnalysis.analyzedFileName || 'Snehal_Kale_Resume_DataAnalyst.pdf'}</span>
                    </div>
                    <div className="flex justify-between font-medium">
                      <span className="text-slate-500">ATS Readiness Score:</span>
                      <span className="font-mono text-blue-600 font-bold">{resumeAnalysis.atsScore || 84}/100</span>
                    </div>
                    <div className="p-2 bg-indigo-50/80 rounded-lg border border-indigo-100 text-3xs text-indigo-950 leading-relaxed">
                      <strong>Campus Partner Drive:</strong> Submitting this application shares your verified skills, ATS resume, and contact details with {applyModalJob.company} for recruitment screening.
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                    <button
                      onClick={() => {
                        setApplyError(null);
                        setApplyModalJob(null);
                      }}
                      className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 rounded-lg cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => handleDirectCompanyApply(applyModalJob)}
                      className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs cursor-pointer"
                    >
                      <span>Submit Application Directly</span>
                      <CheckCircle2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )
            ) : (
              // External Employer Flow (Live API Jobs)
              !applyModalJob.applicationUrl ? (
                <div className="space-y-4">
                  <div className="p-4 bg-amber-50 rounded-xl border border-amber-200 text-amber-900 space-y-2">
                    <div className="flex items-center gap-2 font-bold text-sm text-amber-950">
                      <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                      <span>Application link unavailable</span>
                    </div>
                    <p className="text-xs text-amber-800 leading-relaxed">
                      This job does not currently provide an external application link. You can bookmark this job using Save to track it for updates.
                    </p>
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                    <button
                      onClick={() => setApplyModalJob(null)}
                      className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 rounded-lg cursor-pointer"
                    >
                      Close
                    </button>
                    <button
                      onClick={() => {
                        toggleSaveJob(applyModalJob.id);
                        setApplyModalJob(null);
                      }}
                      className="px-4 py-2 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition-colors cursor-pointer"
                    >
                      {applyModalJob.isSaved ? 'Saved in Bookmarks' : 'Save to Bookmarks'}
                    </button>
                  </div>
                </div>
              ) : appliedSuccess ? (
                <div className="p-6 text-center space-y-2">
                  <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
                  <h4 className="text-base font-bold text-slate-900">Application Started!</h4>
                  <p className="text-xs text-slate-600">
                    Opening employer portal in a new tab. Recorded in your Application Tracker so you can track your progress.
                  </p>
                </div>
              ) : (
                <>
                  <p className="leading-relaxed">
                    Review this job application before continuing to the employer&apos;s application page. You will complete and submit your application directly on their website.
                  </p>

                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
                    <div className="flex justify-between font-medium">
                      <span className="text-slate-500">Your ATS Resume Profile:</span>
                      <span className="font-semibold text-slate-900">Snehal_Kale_Resume_DataAnalyst.pdf</span>
                    </div>
                    <div className="flex justify-between font-medium">
                      <span className="text-slate-500">ATS Readiness Score:</span>
                      <span className="font-mono text-emerald-600 font-bold">84/100</span>
                    </div>
                    <div className="flex justify-between font-medium">
                      <span className="text-slate-500">Role Match:</span>
                      <span className="font-mono text-blue-600 font-bold">{applyModalJob.matchScore}%</span>
                    </div>
                    <div className="p-2 bg-blue-50/80 rounded border border-blue-100 text-3xs text-blue-900 leading-normal">
                      <strong>Note:</strong> Your resume is not automatically submitted or uploaded to the employer. You must complete the application and upload your resume directly on the employer&apos;s website.
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                    <button
                      onClick={() => setApplyModalJob(null)}
                      className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 rounded-lg cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => handleApply(applyModalJob)}
                      className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs cursor-pointer"
                    >
                      <span>Continue to Employer</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </>
              )
            )}
          </div>
        </Modal>
      )}
    </div>
  );
};
