import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Compass,
  CheckCircle2,
  ArrowRight,
  BookOpen,
  Check,
  ExternalLink,
  Code,
  ChevronRight,
  Target,
  Info,
  ChevronDown,
  Layers,
  HelpCircle,
  Sparkles,
  ShieldCheck,
  AlertTriangle,
  TrendingUp,
  History
} from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';
import { ProgressBar } from '../../components/common/ProgressBar.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';
import { Modal } from '../../components/common/Modal.tsx';
import { RoadmapStage } from '../../types.ts';
import { SkillAssessmentModal } from '../../components/assessment/SkillAssessmentModal.tsx';
import { DataTransparencyBadge } from '../../components/common/DataTransparencyBadge.tsx';
import {
  areSkillsMatching,
  canonicalizeSkill,
  getRoleBenchmarkSkills,
  isJobRelevantForCandidate
} from '../../services/liveJobsService.ts';
import {
  getVerifiedResourcesForSkill,
  groupRoadmapIntoStages,
  getPlainEnglishExplanations
} from '../../services/careerRoadmapService.ts';

const AVAILABLE_ROLE_TRACKS = [
  'Data Analyst',
  'Frontend Developer',
  'Backend Developer',
  'Full Stack Developer',
  'AI Engineer',
  'ML Engineer',
  'Data Scientist',
  'DevOps Engineer'
];

export const CareerRoadmapPage: React.FC = () => {
  const navigate = useNavigate();
  const {
    roadmapStages,
    toggleRoadmapStageComplete,
    validateRoadmapStage,
    calibrateRoadmapForRole,
    user,
    updateUser,
    skills,
    assessmentHistory,
    assessmentScores,
    jobs
  } = useCareer();

  const [selectedStage, setSelectedStage] = useState<RoadmapStage | null>(null);
  const [validatingStage, setValidatingStage] = useState<RoadmapStage | null>(null);
  const [openStageId, setOpenStageId] = useState<string | null>(null);
  const [trackSwitchNotice, setTrackSwitchNotice] = useState<string | null>(null);

  // Authoritative target role: always derived directly from user.targetRole
  const activeTargetRole = user.targetRole || 'Data Analyst';


  // Group real tasks into 5 beginner-friendly stages for the active target role
  const groupedStages = groupRoadmapIntoStages(roadmapStages, activeTargetRole);

  const completedCount = roadmapStages.filter((s) => s.status === 'Completed').length;
  const progressPercentage = roadmapStages.length > 0
    ? Math.round((completedCount / roadmapStages.length) * 100)
    : 0;

  const completedStagesCount = groupedStages.filter((g) => g.status === 'Completed').length;

  // Derive live market skill gaps for the authoritative target role
  const relevantJobs = (jobs || []).filter((j) => isJobRelevantForCandidate(j, user));
  const roleBenchmarks = getRoleBenchmarkSkills(activeTargetRole, skills, relevantJobs);
  const benchmarkSkills = roleBenchmarks.map((b) => b.name);

  const roleRequiredSkills = (relevantJobs.length > 0
    ? Array.from(new Set(relevantJobs.flatMap((j) => j.requiredSkills || [])))
    : benchmarkSkills
  )
    .map((s) => canonicalizeSkill(s))
    .filter(Boolean);

  const liveMarketGaps = roleRequiredSkills
    .filter((req) => !skills.some((s) => areSkillsMatching(s.name, req)))
    .slice(0, 4);

  // Recommend EXACTLY ONE next step in sequential order:
  // First in-progress step, or first incomplete step, or the first step
  const nextRecommendedStep =
    roadmapStages.find((s) => s.status === 'In Progress') ||
    roadmapStages.find((s) => s.status !== 'Completed') ||
    roadmapStages[0];

  // Resolve top resource for the current next step card
  const topResource = nextRecommendedStep
    ? (nextRecommendedStep.learningResources && nextRecommendedStep.learningResources.length > 0
        ? nextRecommendedStep.learningResources[0]
        : getVerifiedResourcesForSkill(nextRecommendedStep.skillName)[0])
    : null;

  useEffect(() => {
    console.log('[Roadmap Diagnostics]', {
      runtimeTargetRole: activeTargetRole,
      totalStages: roadmapStages.length,
      completedCount: roadmapStages.filter((s) => s.status === 'Completed').length,
      nextRecommendedStep: nextRecommendedStep
        ? { id: nextRecommendedStep.id, title: nextRecommendedStep.title, status: nextRecommendedStep.status }
        : null,
      stages: roadmapStages.map((s) => ({
        id: s.id,
        step: s.stepNumber,
        title: s.title,
        skill: s.skillName,
        status: s.status,
      })),
    });
  }, [activeTargetRole, roadmapStages, nextRecommendedStep]);

  const handleToggleComplete = (stageId: string) => {
    toggleRoadmapStageComplete(stageId);
    if (selectedStage && selectedStage.id === stageId) {
      setSelectedStage((prev) =>
        prev
          ? {
              ...prev,
              status: prev.status === 'Completed' ? 'In Progress' : 'Completed',
            }
          : null
      );
    }
  };

  const handleTrackChange = (newTrack: string) => {
    updateUser({ targetRole: newTrack });
    if (calibrateRoadmapForRole) {
      calibrateRoadmapForRole(newTrack);
    }
    setTrackSwitchNotice(`Learning plan updated for ${newTrack}. Completed general milestones are preserved.`);
    setTimeout(() => setTrackSwitchNotice(null), 3500);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-12">
      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/dashboard" />
        <div className="flex items-center gap-2">
          <button
            onClick={() => navigate('/assessment')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-lg shadow-2xs transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
            <span>Baseline Diagnostic Test</span>
          </button>
          <button
            onClick={() => navigate('/assessment-history')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-2xs transition-colors cursor-pointer"
          >
            <History className="w-3.5 h-3.5 text-blue-600" />
            <span>Before vs. After History</span>
          </button>
        </div>
      </div>

      {/* Before-vs-After Learning Validation Summary Banner */}
      <div className="bg-gradient-to-r from-indigo-950 via-slate-900 to-indigo-900 rounded-2xl p-6 text-white shadow-sm space-y-4 border border-indigo-800/40">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-indigo-800/60 pb-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-md bg-indigo-500/30 text-indigo-200 text-3xs font-bold uppercase tracking-wider border border-indigo-400/30">
                Objective Validation Engine
              </span>
              <span className="text-indigo-200 text-xs">
                {activeTargetRole} Personalized Sequence
              </span>
            </div>
            <h2 className="text-lg font-bold tracking-tight">
              Before vs. After Progress Tracking
            </h2>
            <p className="text-xs text-indigo-200/90 leading-relaxed max-w-xl">
              Roadmap stages adapt according to your initial diagnostic baseline. Take targeted validation tests after completing milestones to objectively prove skill improvements.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => navigate('/assessment')}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white text-indigo-950 font-bold text-xs hover:bg-indigo-50 transition-colors shadow-2xs cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
              <span>Diagnostic Test</span>
            </button>
            <button
              onClick={() => navigate('/assessment-history')}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-800/80 hover:bg-indigo-700 text-white font-semibold text-xs border border-indigo-600/60 transition-colors cursor-pointer"
            >
              <History className="w-3.5 h-3.5 text-indigo-300" />
              <span>Progress Delts</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
          <div className="p-3 bg-white/5 border border-white/10 rounded-xl">
            <span className="text-3xs uppercase tracking-wider text-indigo-300 block">
              Initial Baseline
            </span>
            <span className="font-mono text-xl sm:text-2xl font-bold text-white block mt-0.5">
              {assessmentHistory.find(h => h.isBaseline)?.overallScore ?? assessmentScores?.overallScore ?? 62}%
            </span>
            <span className="text-3xs text-indigo-300">Diagnostic Score</span>
          </div>

          <div className="p-3 bg-white/5 border border-white/10 rounded-xl">
            <span className="text-3xs uppercase tracking-wider text-indigo-300 block">
              Validated Milestones
            </span>
            <span className="font-mono text-xl sm:text-2xl font-bold text-emerald-400 block mt-0.5">
              {roadmapStages.filter((s) => s.validationStatus === 'passed').length} / {roadmapStages.length}
            </span>
            <span className="text-3xs text-emerald-300">Stages Tested &amp; Passed</span>
          </div>

          <div className="p-3 bg-white/5 border border-white/10 rounded-xl">
            <span className="text-3xs uppercase tracking-wider text-indigo-300 block">
              Placement Readiness
            </span>
            <span className="font-mono text-xl sm:text-2xl font-bold text-indigo-300 block mt-0.5">
              {user.careerReadiness}%
            </span>
            <span className="text-3xs text-indigo-300">Verified Preparedness</span>
          </div>

          <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl">
            <span className="text-3xs uppercase tracking-wider text-emerald-300 block">
              Skills Upgraded
            </span>
            <span className="font-mono text-xl sm:text-2xl font-bold text-emerald-300 block mt-0.5">
              +{skills.filter((s) => s.improvementPct && s.improvementPct > 0).length} Skills
            </span>
            <span className="text-3xs text-emerald-300">Transitioned Toward Strong</span>
          </div>
        </div>
      </div>

      {/* 1. Top Section: Student-Friendly Overview */}
      <header className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
          <div className="space-y-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Your Personalized Learning Plan
            </h1>
            <p className="text-sm text-slate-600 max-w-xl leading-relaxed">
              Step-by-step guidance showing exactly what to learn next to prepare for your target career.
            </p>

            {/* Target Role Selector */}
            <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
              <span className="font-semibold text-slate-700">Target Career:</span>
              <select
                aria-label="Target Role"
                value={activeTargetRole}
                onChange={(e) => handleTrackChange(e.target.value)}
                className="bg-indigo-50/70 hover:bg-indigo-100 border border-indigo-200 text-indigo-900 font-bold px-3 py-1.5 rounded-lg text-xs cursor-pointer focus:outline-hidden focus:ring-2 focus:ring-indigo-500 transition-colors"
              >
                {AVAILABLE_ROLE_TRACKS.map((track) => (
                  <option key={track} value={track}>
                    {track}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Simple Overall Progress */}
          <div className="bg-slate-50 border border-slate-200/90 rounded-xl p-4 shrink-0 min-w-[240px] space-y-2">
            <span className="text-2xs font-bold uppercase tracking-wider text-slate-500 block">
              Overall Progress
            </span>
            <div className="text-lg font-bold text-slate-900">
              <span className="text-indigo-700 font-mono text-xl">{completedCount} of {roadmapStages.length}</span> steps completed
            </div>
            <p className="text-2xs text-slate-500 font-medium">
              {completedStagesCount} of 5 main stages finished ({progressPercentage}%)
            </p>
            <ProgressBar value={progressPercentage} color="blue" size="sm" showValueText={false} />
          </div>
        </div>

        {trackSwitchNotice && (
          <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2 animate-in fade-in duration-200">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{trackSwitchNotice}</span>
          </div>
        )}

        {/* 2. Highlighted "Your Next Step" Card answering the 4 core questions */}
        {nextRecommendedStep && (
          <div className="p-6 sm:p-7 rounded-2xl bg-gradient-to-br from-indigo-50/90 via-blue-50/60 to-purple-50/40 border-2 border-indigo-200/90 shadow-xs space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-indigo-100/90">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="bg-indigo-600 text-white text-2xs font-bold px-2.5 py-1 rounded-md uppercase tracking-wider shadow-2xs">
                  Your Next Step
                </span>
                <span className="text-xs font-semibold text-indigo-950">
                  Step {nextRecommendedStep.stepNumber} of {roadmapStages.length}
                </span>

                <span className={`text-3xs font-bold uppercase px-2 py-0.5 rounded border ${
                  nextRecommendedStep.difficulty === 'Easy'
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                    : nextRecommendedStep.difficulty === 'Hard'
                    ? 'bg-purple-50 text-purple-800 border-purple-200'
                    : 'bg-blue-50 text-blue-800 border-blue-200'
                }`}>
                  {nextRecommendedStep.difficulty || 'Moderate'} Difficulty
                </span>

                {nextRecommendedStep.validationStatus === 'passed' ? (
                  <span className="text-3xs font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    Validated: {nextRecommendedStep.validatedScore}%
                  </span>
                ) : nextRecommendedStep.validationStatus === 'review_needed' ? (
                  <span className="text-3xs font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300 flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3 text-amber-600" />
                    Needs Review: {nextRecommendedStep.validatedScore}%
                  </span>
                ) : (
                  <span className="text-3xs font-medium px-2 py-0.5 rounded bg-white text-slate-600 border border-slate-200">
                    {nextRecommendedStep.baselineScore ? `Baseline: ${nextRecommendedStep.baselineScore}%` : 'Validation Pending'}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setValidatingStage(nextRecommendedStep)}
                  className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 bg-white hover:bg-slate-50 text-indigo-900 font-bold text-xs rounded-xl border border-indigo-300 transition-colors shadow-2xs shrink-0 cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4 text-indigo-600" />
                  <span>Validate Learning</span>
                </button>
                <button
                  onClick={() => setSelectedStage(nextRecommendedStep)}
                  className="inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl transition-colors shadow-sm shrink-0 cursor-pointer"
                >
                  <span>Start Learning</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* The 4 core answers for beginners */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              {/* Question 1: What should I learn? */}
              <div className="p-4 rounded-xl bg-white border border-indigo-100/80 shadow-2xs space-y-1.5">
                <div className="flex items-center gap-1.5 text-indigo-900 font-bold text-xs uppercase tracking-wider">
                  <BookOpen className="w-3.5 h-3.5 text-indigo-600" />
                  <span>What should I learn?</span>
                </div>
                <h2 className="font-bold text-slate-900 text-sm">
                  {nextRecommendedStep.skillName}
                  {nextRecommendedStep.title !== nextRecommendedStep.skillName && (
                    <span className="font-medium text-slate-600 text-xs"> — {nextRecommendedStep.title}</span>
                  )}
                </h2>
                <p className="text-slate-600 leading-relaxed text-xs">
                  {nextRecommendedStep.goal}
                </p>
              </div>

              {/* Question 2: Why do I need it? */}
              <div className="p-4 rounded-xl bg-white border border-indigo-100/80 shadow-2xs space-y-1.5">
                <div className="flex items-center gap-1.5 text-indigo-900 font-bold text-xs uppercase tracking-wider">
                  <Target className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Why do I need it?</span>
                </div>
                <p className="text-slate-700 leading-relaxed text-xs">
                  {nextRecommendedStep.whyItMatters}
                </p>
              </div>

              {/* Question 3: Where can I learn it? */}
              <div className="p-4 rounded-xl bg-white border border-indigo-100/80 shadow-2xs space-y-1.5">
                <div className="flex items-center gap-1.5 text-indigo-900 font-bold text-xs uppercase tracking-wider">
                  <Compass className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Where can I learn it?</span>
                </div>
                {topResource ? (
                  <div>
                    <div className="font-semibold text-slate-900 text-xs flex items-center gap-1.5 flex-wrap">
                      <span>{topResource.title}</span>
                      <span className="text-3xs px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                        {topResource.cost}
                      </span>
                    </div>
                    <p className="text-2xs text-slate-500 pt-0.5">
                      Provided by: <strong className="text-slate-700">{topResource.provider}</strong> (Verified Resource)
                    </p>
                  </div>
                ) : (
                  <p className="text-slate-600 text-xs">Official documentation and interactive guides</p>
                )}
              </div>

              {/* Question 4: What should I practise? */}
              <div className="p-4 rounded-xl bg-white border border-indigo-100/80 shadow-2xs space-y-1.5">
                <div className="flex items-center gap-1.5 text-indigo-900 font-bold text-xs uppercase tracking-wider">
                  <Code className="w-3.5 h-3.5 text-indigo-600" />
                  <span>What should I practise?</span>
                </div>
                <p className="font-semibold text-slate-900 text-xs">
                  {nextRecommendedStep.practicalExercise?.title || 'Hands-on practice task'}
                </p>
                <p className="text-slate-600 leading-relaxed text-xs line-clamp-2">
                  {nextRecommendedStep.practicalExercise?.task || nextRecommendedStep.goal}
                </p>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* 3. Five Easy-to-Understand Stage Cards on the Main Page */}
      <section className="space-y-5" aria-label="Learning Stages">
        <div className="px-1 flex flex-col sm:flex-row sm:items-center justify-between gap-1">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              Your 5 Learning Stages
            </h2>
            <p className="text-xs text-slate-500">
              Simple learning journey for {activeTargetRole}. Click any stage to view its steps.
            </p>
          </div>
          <span className="text-xs font-semibold text-slate-600">
            {completedStagesCount} of 5 stages completed
          </span>
        </div>

        <div className="space-y-3.5">
          {groupedStages.map((stageGroup) => {
            const isExpanded = openStageId === stageGroup.id;
            const isCompleted = stageGroup.status === 'Completed';
            const isInProgress = stageGroup.status === 'In Progress';

            return (
              <div
                key={stageGroup.id}
                className={`rounded-2xl border transition-all ${
                  isInProgress
                    ? 'bg-white border-indigo-300 ring-1 ring-indigo-200 shadow-xs'
                    : isCompleted
                    ? 'bg-slate-50/70 border-slate-200'
                    : 'bg-white border-slate-200 hover:border-slate-300'
                }`}
              >
                {/* Main Stage Header Card (Clickable to open/toggle stage) */}
                <div
                  onClick={() => setOpenStageId(isExpanded ? null : stageGroup.id)}
                  className="p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer select-none"
                >
                  <div className="flex items-start gap-4">
                    {/* Stage Number Badge */}
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm shrink-0 ${
                        isCompleted
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                          : isInProgress
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-600 border border-slate-200'
                      }`}
                    >
                      {isCompleted ? <Check className="w-5 h-5 text-emerald-700" /> : stageGroup.stageNumber}
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center gap-2.5 flex-wrap">
                        <h3 className="text-base font-bold text-slate-900">
                          Stage {stageGroup.stageNumber}: {stageGroup.title}
                        </h3>

                        {/* Simple status: Completed, In Progress, or Not Started */}
                        <span
                          className={`text-2xs font-bold px-2.5 py-0.5 rounded-full ${
                            isCompleted
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : isInProgress
                              ? 'bg-indigo-100 text-indigo-800 border border-indigo-200'
                              : 'bg-slate-100 text-slate-600 border border-slate-200'
                          }`}
                        >
                          {stageGroup.status}
                        </span>
                      </div>

                      {/* Short description of each stage */}
                      <p className="text-xs text-slate-600 leading-relaxed max-w-2xl">
                        {stageGroup.shortDescription}
                      </p>

                      <div className="text-2xs text-slate-400 font-medium pt-0.5">
                        {stageGroup.completedCount} of {stageGroup.totalCount} steps completed
                      </div>
                    </div>
                  </div>

                  {/* Open / Close indicator */}
                  <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                    <span className="text-xs font-semibold text-indigo-600 hover:text-indigo-700">
                      {isExpanded ? 'Hide Steps' : 'View Steps'}
                    </span>
                    <ChevronDown
                      className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${
                        isExpanded ? 'rotate-180 text-indigo-600' : ''
                      }`}
                    />
                  </div>
                </div>

                {/* When a student opens a stage: show detailed tasks */}
                {isExpanded && (
                  <div className="px-5 pb-6 pt-2 border-t border-slate-100 space-y-3 bg-slate-50/40 rounded-b-2xl">
                    <div className="text-2xs font-bold uppercase tracking-wider text-slate-400 px-1">
                      Learning Steps in Stage {stageGroup.stageNumber} ({stageGroup.tasks.length} total)
                    </div>

                    <div className="space-y-2.5">
                      {stageGroup.tasks.map((task) => {
                        const taskCompleted = task.status === 'Completed';
                        const taskInProgress = task.status === 'In Progress';
                        const isNext = nextRecommendedStep?.id === task.id;

                        const taskStatusLabel = taskCompleted
                          ? 'Completed'
                          : taskInProgress
                          ? 'Learning Now'
                          : 'Not Started';

                        const actionLabel = taskCompleted
                          ? 'Review'
                          : taskInProgress
                          ? 'Continue Learning'
                          : 'Start Learning';

                        return (
                          <div
                            key={task.id}
                            onClick={() => setSelectedStage(task)}
                            className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-3 ${
                              isNext && !taskCompleted
                                ? 'bg-indigo-50/70 border-indigo-300 shadow-2xs ring-1 ring-indigo-200'
                                : taskCompleted
                                ? 'bg-white border-slate-200 hover:border-slate-300'
                                : 'bg-white border-slate-200 hover:border-indigo-200'
                            }`}
                          >
                            <div className="flex items-start gap-3">
                              <div
                                className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 ${
                                  taskCompleted
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : isNext
                                    ? 'bg-indigo-600 text-white'
                                    : 'bg-slate-100 text-slate-600'
                                }`}
                              >
                                {taskCompleted ? <Check className="w-3.5 h-3.5 text-emerald-700" /> : task.stepNumber}
                              </div>

                              <div className="space-y-1">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="text-xs font-bold text-slate-900">
                                    Step {task.stepNumber}: {task.skillName}
                                    {task.title !== task.skillName && (
                                      <span className="font-normal text-slate-600"> — {task.title}</span>
                                    )}
                                  </span>

                                  <span
                                    className={`text-3xs font-semibold px-2 py-0.5 rounded ${
                                      taskCompleted
                                        ? 'bg-emerald-50 text-emerald-700'
                                        : taskInProgress
                                        ? 'bg-indigo-100 text-indigo-800'
                                        : 'bg-slate-100 text-slate-600'
                                    }`}
                                  >
                                    {taskStatusLabel}
                                  </span>

                                  <span
                                    className={`text-3xs font-bold uppercase px-2 py-0.5 rounded border ${
                                      task.difficulty === 'Easy'
                                        ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                        : task.difficulty === 'Hard'
                                        ? 'bg-purple-50 text-purple-800 border-purple-200'
                                        : 'bg-blue-50 text-blue-800 border-blue-200'
                                    }`}
                                  >
                                    {task.difficulty || 'Moderate'}
                                  </span>

                                  {task.validationStatus === 'passed' ? (
                                    <span className="text-3xs font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center gap-1">
                                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                      <span>Validated: {task.validatedScore}%</span>
                                    </span>
                                  ) : task.validationStatus === 'review_needed' ? (
                                    <span className="text-3xs font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300 flex items-center gap-1">
                                      <AlertTriangle className="w-3 h-3 text-amber-600" />
                                      <span>Needs Review: {task.validatedScore}%</span>
                                    </span>
                                  ) : (
                                    <span className="text-3xs text-slate-500 font-medium bg-white px-1.5 py-0.5 rounded border border-slate-200">
                                      {task.baselineScore ? `Baseline: ${task.baselineScore}%` : 'Unvalidated'}
                                    </span>
                                  )}
                                </div>

                                <p className="text-xs text-slate-600 leading-relaxed">
                                  {task.goal}
                                </p>
                              </div>
                            </div>

                            <div className="flex items-center gap-2 justify-end shrink-0 pt-1 md:pt-0">
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setValidatingStage(task);
                                }}
                                className="px-2.5 py-1.5 rounded-lg text-3xs font-bold bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 cursor-pointer flex items-center gap-1 transition-colors"
                                title="Take Objective Validation Test for this Stage"
                              >
                                <ShieldCheck className="w-3 h-3 text-indigo-600" />
                                <span>Validate</span>
                              </button>

                              <span
                                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors ${
                                  isNext && !taskCompleted
                                    ? 'bg-indigo-600 text-white'
                                    : taskCompleted
                                    ? 'bg-slate-100 text-slate-700'
                                    : 'bg-indigo-50 text-indigo-700'
                                }`}
                              >
                                <span>{actionLabel}</span>
                                <ChevronRight className="w-3 h-3" />
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* 4. Collapsed Technical Details Section (Kept for evaluators, hidden by default) */}
      <details className="border border-slate-200 rounded-xl bg-slate-50/60 overflow-hidden text-xs">
        <summary className="px-4 py-3 font-medium text-slate-600 hover:text-slate-900 cursor-pointer flex items-center justify-between select-none transition-colors">
          <span className="flex items-center gap-2 text-2xs uppercase tracking-wider font-semibold text-slate-500">
            <Info className="w-3.5 h-3.5 text-indigo-600" />
            Technical Architecture &amp; Data Sources (Reference Details)
          </span>
          <span className="text-3xs text-slate-400 font-mono">Click to view</span>
        </summary>
        <div className="p-4 pt-2 border-t border-slate-200/70 space-y-4">
          <p className="text-xs text-slate-500">
            This technical summary provides transparency on dataset benchmarks, student profile scoring, and live job-gap analysis algorithms for platform evaluators and faculty.
          </p>

          <DataTransparencyBadge activeScope="roadmap" />

          {/* Adaptive Roadmap Generation Architecture panel */}
          <div className="p-3.5 rounded-xl border border-indigo-200 bg-indigo-50/40 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-2xs font-bold uppercase tracking-wider text-indigo-900 flex items-center gap-1.5">
                <Target className="w-3.5 h-3.5 text-indigo-600" />
                Synthesis Architecture Status
              </span>
              <span className="text-3xs font-mono bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded font-semibold">
                Role Track: {activeTargetRole}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
              <div className="p-2 rounded-lg bg-white border border-indigo-100">
                <span className="text-3xs font-bold uppercase tracking-wider text-slate-400 block">
                  1. Current Skills
                </span>
                <span className="font-semibold text-slate-800 text-xs truncate block">
                  {skills.slice(0, 3).map(s => s.name).join(', ')} (+{skills.length - 3} more)
                </span>
              </div>

              <div className="p-2 rounded-lg bg-white border border-indigo-100">
                <span className="text-3xs font-bold uppercase tracking-wider text-slate-400 block">
                  2. Diagnostic History
                </span>
                <span className="font-semibold text-slate-800 text-xs truncate block">
                  {assessmentHistory && assessmentHistory.length > 0
                    ? `${assessmentHistory[0].skillName || 'Diagnostic'} (${assessmentHistory[0].overallScore}%)`
                    : 'Diagnostic Complete'}
                </span>
              </div>

              <div className="p-2 rounded-lg bg-white border border-indigo-100">
                <span className="text-3xs font-bold uppercase tracking-wider text-amber-800 block">
                  3. Live Market Gaps
                </span>
                <span className="font-semibold text-amber-900 text-xs truncate block">
                  {liveMarketGaps.join(', ') || 'Core role skills mastered'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </details>

      {/* 5. Milestone Drill-Down Detail Modal: Simple 5-Step Learning Sequence */}
      {selectedStage && (() => {
        const resources = selectedStage.learningResources && selectedStage.learningResources.length > 0
          ? selectedStage.learningResources
          : getVerifiedResourcesForSkill(selectedStage.skillName);

        const isCompleted = selectedStage.status === 'Completed';
        const displayStatus = isCompleted
          ? 'Completed'
          : selectedStage.status === 'In Progress'
          ? 'Learning Now'
          : 'Not Started';

        // Detect any jargon/technical terms in this task and get plain-English explanations
        const combinedText = `${selectedStage.skillName} ${selectedStage.title} ${selectedStage.goal} ${(selectedStage.conceptsToLearn || []).join(' ')}`;
        const plainEnglishExplanations = getPlainEnglishExplanations(combinedText);

        return (
          <Modal
            isOpen={true}
            onClose={() => setSelectedStage(null)}
            title={`Step ${selectedStage.stepNumber}: ${selectedStage.skillName}`}
            subtitle={`Target Career: ${activeTargetRole}`}
            maxWidth="2xl"
          >
            <div className="space-y-6 text-xs text-slate-700 max-h-[75vh] overflow-y-auto pr-1">
              {/* Status Header Badge */}
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <span className="text-slate-500 font-medium">Step Status:</span>
                  <span
                    className={`text-2xs font-bold px-2.5 py-1 rounded-full ${
                      isCompleted
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                        : displayStatus === 'Learning Now'
                        ? 'bg-indigo-100 text-indigo-800 border border-indigo-200'
                        : 'bg-slate-100 text-slate-700 border border-slate-200'
                    }`}
                  >
                    {displayStatus}
                  </span>
                </div>

                <div className="flex items-center gap-1.5 text-2xs">
                  <span className="text-slate-400">Skill Assessment:</span>
                  {selectedStage.isAssessed && selectedStage.assessmentScore !== null ? (
                    <span className="font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      Assessed ({selectedStage.assessmentScore}%)
                    </span>
                  ) : (
                    <span className="font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                      Not Assessed
                    </span>
                  )}
                </div>
              </div>

              {/* Learning Sequence Step 1: Learn the Concept */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold shrink-0">
                    1
                  </span>
                  <h4 className="font-bold text-slate-900 text-sm">
                    Learn the Concept
                  </h4>
                </div>

                <div className="pl-8 space-y-3">
                  <p className="text-slate-700 leading-relaxed text-xs">
                    {selectedStage.goal}
                  </p>

                  {/* Plain English Definitions for any technical words */}
                  {plainEnglishExplanations.length > 0 && (
                    <div className="p-3.5 rounded-xl bg-purple-50/60 border border-purple-200 space-y-1.5">
                      <div className="flex items-center gap-1.5 text-purple-900 font-bold text-2xs uppercase tracking-wider">
                        <HelpCircle className="w-3.5 h-3.5 text-purple-600" />
                        <span>Plain English Meaning</span>
                      </div>
                      <div className="space-y-1 text-2xs text-purple-950">
                        {plainEnglishExplanations.map((exp, idx) => (
                          <p key={idx}>
                            <strong>{exp.term}:</strong> {exp.plainEnglish}
                          </p>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Concepts list */}
                  {selectedStage.conceptsToLearn && selectedStage.conceptsToLearn.length > 0 && (
                    <div className="space-y-1 pt-1">
                      <span className="font-bold text-slate-800 text-2xs uppercase tracking-wider block">
                        Key Concepts to Learn:
                      </span>
                      <ul className="space-y-1">
                        {selectedStage.conceptsToLearn.map((concept, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-slate-700">
                            <span className="text-indigo-600 font-bold mt-0.5">•</span>
                            <span>{concept}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Why it matters */}
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1">
                    <span className="font-bold text-slate-700 text-2xs uppercase tracking-wider block">
                      Why you need this skill:
                    </span>
                    <p className="text-slate-600 text-xs leading-relaxed">
                      {selectedStage.whyItMatters}
                    </p>
                  </div>
                </div>
              </div>

              {/* Learning Sequence Step 2: Follow a Relevant Learning Resource */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold shrink-0">
                    2
                  </span>
                  <h4 className="font-bold text-slate-900 text-sm">
                    Follow a Relevant Learning Resource
                  </h4>
                </div>

                <div className="pl-8 space-y-2">
                  {resources.length > 0 ? (
                    resources.map((res, i) => (
                      <div
                        key={i}
                        className="p-3.5 rounded-xl bg-white border border-slate-200 shadow-2xs hover:border-indigo-300 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-bold text-slate-900 text-xs">{res.title}</span>
                            <span className="text-3xs font-semibold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                              {res.cost}
                            </span>
                            {res.isVerified && (
                              <span className="text-3xs text-emerald-700 font-medium flex items-center gap-0.5">
                                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                Verified
                              </span>
                            )}
                          </div>
                          <div className="text-2xs text-slate-500">
                            Provided by: <strong className="text-slate-700">{res.provider}</strong>
                            {res.type && ` · ${res.type}`}
                          </div>
                        </div>

                        <a
                          href={res.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-lg transition-colors shrink-0 shadow-2xs cursor-pointer"
                        >
                          <span>Open Resource</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    ))
                  ) : (
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200 text-2xs text-amber-800">
                      No verified external tutorial link is currently cataloged for this topic. Reference official vendor documentation.
                    </div>
                  )}
                </div>
              </div>

              {/* Learning Sequence Step 3: Try a Practical Exercise */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold shrink-0">
                    3
                  </span>
                  <h4 className="font-bold text-slate-900 text-sm">
                    Try a Practical Exercise
                  </h4>
                </div>

                <div className="pl-8">
                  {selectedStage.practicalExercise ? (
                    <div className="p-4 rounded-xl bg-indigo-50/50 border border-indigo-200 space-y-2">
                      <h5 className="font-bold text-slate-900 text-xs">
                        {selectedStage.practicalExercise.title}
                      </h5>
                      <p className="text-xs text-slate-700 leading-relaxed">
                        {selectedStage.practicalExercise.task}
                      </p>
                    </div>
                  ) : (
                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600">
                      Practice by following along with the tutorial examples and implementing the concepts in a local test file.
                    </div>
                  )}
                </div>
              </div>

              {/* Learning Sequence Step 4: Check Whether the Task is Complete */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold shrink-0">
                    4
                  </span>
                  <h4 className="font-bold text-slate-900 text-sm">
                    Check Whether the Task is Complete
                  </h4>
                </div>

                <div className="pl-8">
                  <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200 text-xs text-emerald-900 leading-relaxed">
                    <span className="font-bold block pb-1">Ready to move on when:</span>
                    {selectedStage.completionCriteria ||
                      selectedStage.practicalExercise?.completionCriteria ||
                      'You have reviewed the concept, tried the practical exercise, and understand the core workflow.'}
                  </div>
                </div>
              </div>

              {/* Learning Sequence Step 5: Learning Validation Assessment */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold shrink-0">
                    5
                  </span>
                  <h4 className="font-bold text-slate-900 text-sm">
                    Validate Your Learning (Knowledge Benchmark)
                  </h4>
                </div>

                <div className="pl-8">
                  <div className="p-4 rounded-xl bg-gradient-to-r from-indigo-50/90 via-blue-50/60 to-purple-50/40 border border-indigo-200/90 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-bold text-slate-900">
                          {selectedStage.skillName} Milestone Validation Test
                        </span>
                        <span className="text-3xs font-semibold px-2 py-0.5 rounded bg-indigo-100 text-indigo-800 border border-indigo-200">
                          {selectedStage.difficulty || 'Moderate'}
                        </span>
                        {selectedStage.validationStatus === 'passed' ? (
                          <span className="text-3xs font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            <span>Validated: {selectedStage.validatedScore}%</span>
                          </span>
                        ) : selectedStage.validationStatus === 'review_needed' ? (
                          <span className="text-3xs font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300 flex items-center gap-1">
                            <AlertTriangle className="w-3 h-3 text-amber-600" />
                            <span>Review Needed: {selectedStage.validatedScore}%</span>
                          </span>
                        ) : null}
                      </div>
                      <p className="text-3xs text-slate-600 leading-relaxed">
                        Score <strong>≥75%</strong> to objectively validate this milestone, update your skill level in your profile, and unlock subsequent roadmap milestones.
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        const stageToValidate = selectedStage;
                        setSelectedStage(null);
                        setValidatingStage(stageToValidate);
                      }}
                      className="inline-flex items-center justify-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-lg transition-colors shrink-0 shadow-2xs cursor-pointer"
                    >
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Take Validation Test</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Learning Sequence Step 6: Mark It Complete */}
              <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
                <button
                  onClick={() => setSelectedStage(null)}
                  className="w-full sm:w-auto px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 rounded-lg cursor-pointer transition-colors"
                >
                  Close
                </button>

                <button
                  onClick={() => handleToggleComplete(selectedStage.id)}
                  className={`w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer shadow-xs ${
                    isCompleted
                      ? 'bg-amber-50 text-amber-800 border border-amber-300 hover:bg-amber-100'
                      : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    {isCompleted ? 'Mark as In Progress' : 'Mark Step as Complete'}
                  </span>
                </button>
              </div>
            </div>
          </Modal>
        );
      })()}

      {/* 6. Objective Skill Assessment Modal for Validating Roadmap Stages */}
      {validatingStage && (
        <SkillAssessmentModal
          skillName={validatingStage.skillName}
          baselineScore={validatingStage.baselineScore ?? undefined}
          previousScore={validatingStage.validatedScore ?? undefined}
          initialDifficulty={validatingStage.difficulty || 'Moderate'}
          mode="validation"
          stageId={validatingStage.id}
          stageTitle={validatingStage.title}
          onClose={() => setValidatingStage(null)}
          onSaveResult={(res) => {
            validateRoadmapStage({
              stageId: validatingStage.id,
              skillName: validatingStage.skillName,
              score: res.calculatedScore,
              difficulty: res.difficulty || 'Moderate',
              correctCount: res.correctCount,
              totalQuestions: res.totalQuestions,
              strongTopics: res.strongAreas,
              weakTopics: res.needsImprovement,
              recommendedPractice: res.recommendedPractice,
            });
            if (selectedStage && selectedStage.id === validatingStage.id) {
              setSelectedStage((prev) =>
                prev
                  ? {
                      ...prev,
                      validatedScore: res.calculatedScore,
                      validationStatus: res.calculatedScore >= 75 ? 'passed' : 'review_needed',
                      status: res.calculatedScore >= 75 ? 'Completed' : prev.status,
                    }
                  : null
              );
            }
          }}
        />
      )}
    </div>
  );
};

