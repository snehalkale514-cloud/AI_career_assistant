import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Sparkles,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  User,
  GraduationCap,
  Code,
  Briefcase,
  Target,
  Trophy
} from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';

const availableSkillTags = [
  'Python',
  'SQL',
  'C++',
  'Java',
  'JavaScript',
  'React',
  'Machine Learning',
  'Data Analysis',
  'Power BI',
  'Excel',
  'Statistics',
  'Communication',
  'DSA',
  'Tableau',
  'Git & GitHub',
  'FastAPI'
];

const targetRoles = [
  'Data Analyst',
  'Data Scientist',
  'ML Engineer',
  'Software Developer',
  'Web Developer',
  'AI Engineer',
  'Business Analyst'
];

export const OnboardingPage: React.FC = () => {
  const navigate = useNavigate();
  const { user, updateUser, addSkill } = useCareer();
  const [currentStep, setCurrentStep] = useState(1);

  // Form states
  const [personal, setPersonal] = useState({
    name: user.name,
    email: user.email,
    phone: user.phone || '+91 98234 56789',
    location: user.location || 'Pune, Maharashtra',
  });

  const [education, setEducation] = useState({
    degree: user.degree,
    branch: user.branch,
    college: user.college,
    graduationYear: user.graduationYear,
    currentSemester: user.currentSemester || 'Semester 4',
  });

  const [selectedSkills, setSelectedSkills] = useState<string[]>([
    'Python',
    'SQL',
    'Machine Learning',
    'Power BI',
    'Statistics',
    'Excel',
    'Communication'
  ]);
  const [customSkillInput, setCustomSkillInput] = useState('');
  const [skillFeedback, setSkillFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const [targetRole, setTargetRole] = useState(user.targetRole || 'Data Analyst');
  const [experienceLevel, setExperienceLevel] = useState<'Beginner' | 'Intermediate' | 'Advanced'>('Intermediate');
  const [careerGoal, setCareerGoal] = useState(
    'Secure a high-impact Data Analyst internship and placement at a leading analytics firm.'
  );

  const toggleSkill = (skill: string) => {
    if (selectedSkills.includes(skill)) {
      setSelectedSkills(selectedSkills.filter((s) => s !== skill));
    } else {
      setSelectedSkills([...selectedSkills, skill]);
    }
  };

  const handleAddCustomSkill = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const clean = customSkillInput.trim();
    if (!clean) {
      setSkillFeedback({ type: 'error', message: 'Please enter a skill name before clicking Add Skill.' });
      setTimeout(() => setSkillFeedback(null), 3000);
      return;
    }
    if (selectedSkills.some((s) => s.toLowerCase() === clean.toLowerCase())) {
      setSkillFeedback({ type: 'error', message: `"${clean}" is already added.` });
      setTimeout(() => setSkillFeedback(null), 3000);
      return;
    }
    setSelectedSkills([...selectedSkills, clean]);
    addSkill(clean);
    setCustomSkillInput('');
    setSkillFeedback({ type: 'success', message: `Added "${clean}"!` });
    setTimeout(() => setSkillFeedback(null), 3000);
  };

  const handleFinish = () => {
    updateUser({
      name: personal.name,
      email: personal.email,
      phone: personal.phone,
      location: personal.location,
      degree: education.degree,
      branch: education.branch,
      college: education.college,
      graduationYear: education.graduationYear,
      currentSemester: education.currentSemester,
      targetRole,
      experienceLevel,
      careerGoal,
      skillsMatched: 12,
      careerReadiness: 72,
    });
    navigate('/app/dashboard');
  };

  const stepsMeta = [
    { num: 1, title: 'Personal Info', icon: User },
    { num: 2, title: 'Education', icon: GraduationCap },
    { num: 3, title: 'Skills', icon: Code },
    { num: 4, title: 'Career Role', icon: Briefcase },
    { num: 5, title: 'Experience', icon: Target },
    { num: 6, title: 'Goal & Summary', icon: Trophy },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center py-10 px-4 sm:px-6 lg:px-8 relative">
      <div className="absolute top-4 left-4 sm:top-6 sm:left-6">
        <BackButton fallback="/signup" />
      </div>

      {/* Top Header */}
      <div className="max-w-2xl mx-auto w-full text-center mb-8">
        <div className="inline-flex items-center gap-2 mb-3">
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-xs">
            <Sparkles className="w-4 h-4" />
          </div>
          <span className="text-lg font-bold text-slate-900 tracking-tight">
            AI Career Assistant Setup
          </span>
        </div>
        <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
          Personalize Your Campus Career Engine
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Step {currentStep} of 6 — Tailoring benchmark criteria for recruitment drives
        </p>

        {/* Step Indicator Bar */}
        <div className="mt-6 grid grid-cols-6 gap-2">
          {stepsMeta.map((s) => (
            <div key={s.num} className="space-y-1">
              <div
                className={`h-1.5 rounded-full transition-colors ${
                  s.num <= currentStep ? 'bg-blue-600' : 'bg-slate-200'
                }`}
              />
              <span
                className={`hidden sm:block text-3xs font-medium truncate ${
                  s.num === currentStep
                    ? 'text-blue-600 font-bold'
                    : s.num < currentStep
                    ? 'text-slate-700'
                    : 'text-slate-400'
                }`}
              >
                {s.title}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Main Card Container */}
      <div className="max-w-2xl mx-auto w-full bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8">
        {/* Step 1: Personal Info */}
        {currentStep === 1 && (
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Personal Information</h2>
              <p className="text-xs text-slate-500">Provide official details used on job applications and recruiter contact forms.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name</label>
                <input
                  type="text"
                  value={personal.name}
                  onChange={(e) => setPersonal({ ...personal, name: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Email Address</label>
                <input
                  type="email"
                  value={personal.email}
                  onChange={(e) => setPersonal({ ...personal, email: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Phone Number</label>
                <input
                  type="text"
                  value={personal.phone}
                  onChange={(e) => setPersonal({ ...personal, phone: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Location / City</label>
                <input
                  type="text"
                  value={personal.location}
                  onChange={(e) => setPersonal({ ...personal, location: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                />
              </div>
            </div>
          </div>
        )}

        {/* Step 2: Education */}
        {currentStep === 2 && (
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Education Details</h2>
              <p className="text-xs text-slate-500">Recruiter placement portals prioritize batch, branch, and semester standing.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Degree</label>
                <select
                  value={education.degree}
                  onChange={(e) => setEducation({ ...education, degree: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                >
                  <option value="BTech">BTech (Bachelor of Technology)</option>
                  <option value="BE">BE (Bachelor of Engineering)</option>
                  <option value="BCA">BCA (Computer Applications)</option>
                  <option value="MCA">MCA (Master of Computer Applications)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Branch / Specialization</label>
                <input
                  type="text"
                  value={education.branch}
                  onChange={(e) => setEducation({ ...education, branch: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">College / Institute Name</label>
                <input
                  type="text"
                  value={education.college}
                  onChange={(e) => setEducation({ ...education, college: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Graduation Year</label>
                <select
                  value={education.graduationYear}
                  onChange={(e) => setEducation({ ...education, graduationYear: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                >
                  <option value="2025">2025</option>
                  <option value="2026">2026</option>
                  <option value="2027">2027</option>
                  <option value="2028">2028 (Demo Cohort)</option>
                  <option value="2029">2029</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Current Standing</label>
                <select
                  value={education.currentSemester}
                  onChange={(e) => setEducation({ ...education, currentSemester: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                >
                  <option value="Semester 3">Semester 3</option>
                  <option value="Semester 4">Semester 4 (2nd Year)</option>
                  <option value="Semester 5">Semester 5 (3rd Year)</option>
                  <option value="Semester 6">Semester 6</option>
                  <option value="Semester 7">Semester 7 (Final Year)</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* Step 3: Skills */}
        {currentStep === 3 && (
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Your Current Technical Skills</h2>
              <p className="text-xs text-slate-500">Select skills you have worked with or studied in your college coursework.</p>
            </div>

            <div className="flex flex-wrap gap-2 pt-2">
              {availableSkillTags.map((skill) => {
                const isSelected = selectedSkills.includes(skill);
                return (
                  <button
                    key={skill}
                    type="button"
                    onClick={() => toggleSkill(skill)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {isSelected && '✓ '}
                    {skill}
                  </button>
                );
              })}
            </div>

            <form onSubmit={handleAddCustomSkill} className="pt-2 flex gap-2">
              <input
                type="text"
                value={customSkillInput}
                onChange={(e) => setCustomSkillInput(e.target.value)}
                placeholder="Add other skill (e.g. Docker, MongoDB)..."
                className="flex-1 px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
              />
              <button
                type="submit"
                onClick={handleAddCustomSkill}
                className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
              >
                Add Skill
              </button>
            </form>
            {skillFeedback && (
              <div
                className={`mt-1.5 p-2 rounded-lg text-2xs font-medium ${
                  skillFeedback.type === 'success'
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                    : 'bg-rose-50 text-rose-800 border border-rose-200'
                }`}
              >
                {skillFeedback.message}
              </div>
            )}
          </div>
        )}

        {/* Step 4: Career Preferences */}
        {currentStep === 4 && (
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Primary Target Career Role</h2>
              <p className="text-xs text-slate-500">Your roadmap and job recommendations will be calibrated against this target.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              {targetRoles.map((role) => {
                const isSelected = targetRole === role;
                return (
                  <div
                    key={role}
                    onClick={() => setTargetRole(role)}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'border-blue-600 bg-blue-50/60 shadow-xs'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">{role}</h4>
                      <p className="text-2xs text-slate-500 mt-0.5">High campus hiring demand</p>
                    </div>
                    {isSelected && <CheckCircle2 className="w-4 h-4 text-blue-600" />}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 5: Experience Level */}
        {currentStep === 5 && (
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Current Experience Level</h2>
              <p className="text-xs text-slate-500">Helps calibrate the initial difficulty of assessment tests and project tasks.</p>
            </div>

            <div className="space-y-3 pt-2">
              {[
                {
                  level: 'Beginner' as const,
                  title: 'Beginner (0–6 Months)',
                  desc: 'Learning syntax, coursework basics, solved small academic lab exercises.',
                },
                {
                  level: 'Intermediate' as const,
                  title: 'Intermediate (6–18 Months)',
                  desc: 'Built independent projects, familiar with Pandas, SQL queries, and basic Git.',
                },
                {
                  level: 'Advanced' as const,
                  title: 'Advanced (18+ Months / Prior Internship)',
                  desc: 'Completed production pipelines, contributed to hackathons, prior internship experience.',
                },
              ].map((item) => {
                const isSelected = experienceLevel === item.level;
                return (
                  <div
                    key={item.level}
                    onClick={() => setExperienceLevel(item.level)}
                    className={`p-4 rounded-xl border transition-all cursor-pointer flex items-start justify-between ${
                      isSelected
                        ? 'border-blue-600 bg-blue-50/60 shadow-xs'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="space-y-1">
                      <h4 className="text-sm font-bold text-slate-900">{item.title}</h4>
                      <p className="text-xs text-slate-600 leading-relaxed">{item.desc}</p>
                    </div>
                    {isSelected && <CheckCircle2 className="w-5 h-5 text-blue-600 shrink-0 ml-3" />}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 6: Goal & Completion Summary */}
        {currentStep === 6 && (
          <div className="space-y-5">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Career Goal &amp; Setup Summary</h2>
              <p className="text-xs text-slate-500">Review your configured profile before generating your personalized workspace.</p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Your Primary Career Aspiration
              </label>
              <textarea
                rows={2}
                value={careerGoal}
                onChange={(e) => setCareerGoal(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
              />
            </div>

            {/* Summary review box */}
            <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-3 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-200">
                <span className="text-slate-500">Student Name</span>
                <span className="font-semibold text-slate-900">{personal.name}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200">
                <span className="text-slate-500">Target Role</span>
                <span className="font-semibold text-blue-700">{targetRole}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200">
                <span className="text-slate-500">Institution &amp; Batch</span>
                <span className="font-semibold text-slate-900">VPKBIET · Class of {education.graduationYear}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200">
                <span className="text-slate-500">Skills Selected</span>
                <span className="font-semibold text-slate-900">{selectedSkills.length} Verified Skills</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500">Initial Placement Readiness</span>
                <span className="font-mono font-bold text-emerald-600">72% (Cohort Standard)</span>
              </div>
            </div>
          </div>
        )}

        {/* Navigation buttons */}
        <div className="mt-8 pt-4 border-t border-slate-100 flex items-center justify-between">
          {currentStep > 1 ? (
            <button
              type="button"
              onClick={() => setCurrentStep(currentStep - 1)}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back</span>
            </button>
          ) : (
            <div />
          )}

          {currentStep < 6 ? (
            <button
              type="button"
              onClick={() => setCurrentStep(currentStep + 1)}
              className="inline-flex items-center gap-1.5 px-5 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              <span>Continue</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              type="button"
              onClick={handleFinish}
              className="inline-flex items-center gap-1.5 px-6 py-2.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              <span>Launch Career Dashboard</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
