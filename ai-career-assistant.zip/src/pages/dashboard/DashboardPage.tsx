import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  TrendingUp,
  Award,
  FileCheck2,
  ListTodo,
  Briefcase,
  Compass,
  ArrowRight,
  CheckCircle2,
  Bookmark,
  Sparkles,
  GitBranch,
  Share2,
  MessageSquareCode,
  Globe,
  ChevronRight,
  Target
} from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';
import { StatCard } from '../../components/common/StatCard.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';
import { ProgressBar } from '../../components/common/ProgressBar.tsx';
import { AIInsight } from '../../components/common/AIInsight.tsx';
import { Modal } from '../../components/common/Modal.tsx';
import { JobItem } from '../../types.ts';
import { calculatePlacementReadiness } from '../../services/placementReadinessService.ts';
import { getRoleBenchmarkSkills, areSkillsMatching } from '../../services/liveJobsService.ts';

export const DashboardPage: React.FC = () => {
  const navigate = useNavigate();
  const {
    user,
    skills,
    projects,
    resumeAnalysis,
    interviewHistory,
    jobs,
    toggleSaveJob,
    roadmapStages,
    applications,
    achievements,
    githubProjects,
    linkedinPosts
  } = useCareer();

  const [selectedJobForModal, setSelectedJobForModal] = useState<JobItem | null>(null);

  // Authoritative dynamic placement readiness evaluation
  const readiness = useMemo(() => {
    return calculatePlacementReadiness(user, skills, projects, resumeAnalysis, interviewHistory, user.targetRole);
  }, [user, skills, projects, resumeAnalysis, interviewHistory]);

  // Current target role benchmarks
  const roleBenchmarks = useMemo(() => {
    return getRoleBenchmarkSkills(user.targetRole);
  }, [user.targetRole]);

  // Verified benchmark competencies
  const matchedBenchmarkSkills = useMemo(() => {
    return roleBenchmarks.filter((b) =>
      skills.some(
        (s) =>
          areSkillsMatching(s.name, b.name) &&
          (s.currentLevel >= 60 || s.status === 'Strong' || s.status === 'Good' || (s as any).verified === true)
      )
    );
  }, [roleBenchmarks, skills]);

  const skillsMatchedCount = matchedBenchmarkSkills.length;
  const totalRoleSkillsCount = Math.max(1, roleBenchmarks.length);
  const skillGapsCount = Math.max(0, totalRoleSkillsCount - skillsMatchedCount);

  // Dynamic role-aware skill comparison for the current student
  const displaySkills = useMemo(() => {
    return roleBenchmarks.slice(0, 5).map((b) => {
      const userSkill = skills.find((s) => areSkillsMatching(s.name, b.name));
      const level = userSkill ? userSkill.currentLevel : 0;
      let status: 'Strong' | 'Good' | 'Needs Improvement' | 'Priority Gap' = 'Priority Gap';
      if (level >= 80) status = 'Strong';
      else if (level >= 60) status = 'Good';
      else if (level >= 45) status = 'Needs Improvement';

      return {
        name: b.name,
        level,
        status
      };
    });
  }, [roleBenchmarks, skills]);

  // Calculate roadmap progress
  const completedStages = roadmapStages.filter((s) => s.status === 'Completed').length;
  const roadmapPct = Math.round((completedStages / roadmapStages.length) * 100);

  // Recommended jobs
  const topJobs = jobs.slice(0, 2);

  return (
    <div className="space-y-7 max-w-7xl mx-auto">
      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/" />
      </div>

      {/* Welcome Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-2 border-b border-slate-200/60">
        <div>
          <span className="text-2xs font-bold uppercase tracking-wider text-blue-600 flex items-center gap-1.5 mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            AI Placement Mentor Active
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Welcome back, {user?.name ? user.name.split(' ')[0] : 'Student'}
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Class of {user.graduationYear} · {user.degree} in {user.branch} · Target: <span className="font-semibold text-blue-700">{user.targetRole}</span>
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => navigate('/portfolio')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-2xs transition-colors cursor-pointer"
          >
            <Globe className="w-3.5 h-3.5 text-blue-600" />
            <span>View Portfolio</span>
          </button>
          <button
            onClick={() => navigate('/career-hub')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Open Career Hub</span>
          </button>
        </div>
      </div>

      {/* 1. Top Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Career Readiness"
          value={`${readiness.overallScore}%`}
          subtext={`Target ${user.targetRole} benchmarks`}
          icon={TrendingUp}
          trend={{ value: readiness.status, isPositive: readiness.overallScore >= 60 }}
          onClick={() => navigate('/placement-readiness')}
        />
        <StatCard
          title="Resume Score"
          value={readiness.componentMetadata.ats.status === 'completed' ? `${readiness.atsScore}%` : 'Not Attempted'}
          subtext={readiness.componentMetadata.ats.status === 'completed' ? 'ATS pass rate & keywords' : 'Upload resume to scan'}
          icon={FileCheck2}
          trend={readiness.componentMetadata.ats.status === 'completed' ? { value: readiness.atsScore >= 75 ? 'ATS Verified' : 'Review Recommended', isPositive: readiness.atsScore >= 75 } : undefined}
          onClick={() => navigate('/resume-analyzer')}
        />
        <StatCard
          title="Skills Matched"
          value={`${skillsMatchedCount}/${totalRoleSkillsCount}`}
          subtext={`Target ${user.targetRole} requirements`}
          icon={Award}
          trend={{ value: `${skillGapsCount} gap${skillGapsCount !== 1 ? 's' : ''} identified`, isPositive: skillGapsCount === 0 }}
          onClick={() => navigate('/skill-analytics')}
        />
        <StatCard
          title="Applications"
          value={applications.length}
          subtext="Active recruitment drives"
          icon={ListTodo}
          trend={{ value: '1 offer received', isPositive: true }}
          onClick={() => navigate('/applications')}
        />
      </div>

      {/* 2. AI Career Insight Banner */}
      <AIInsight
        type="AI INSIGHT"
        title="Placement Strategy"
        actionLabel="View My Roadmap"
        onAction={() => navigate('/roadmap')}
      >
        <p className="font-semibold text-slate-900 text-sm">
          {matchedBenchmarkSkills.length > 0
            ? `Your verified competencies in ${matchedBenchmarkSkills.slice(0, 2).map((s) => s.name).join(' and ')} are key strengths for your ${user.targetRole} pathway.`
            : `Focus on foundational technical competencies to build momentum for ${user.targetRole} placement drives.`}
        </p>
        <p className="text-slate-600 text-xs mt-1">
          {skillGapsCount > 0
            ? `Target ${user.targetRole} opportunities in the job market. Complete priority roadmap milestones to bridge ${skillGapsCount} identified skill gap${skillGapsCount !== 1 ? 's' : ''}.`
            : `Your verified profile aligns strongly with current ${user.targetRole} requisitions in the live job market.`}
        </p>
      </AIInsight>

      {/* 3. Continue Your Career Journey */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
          <div className="flex items-center gap-2">
            <Compass className="w-4 h-4 text-blue-600" />
            <h3 className="text-sm font-bold text-slate-900 tracking-tight">Continue Your Career Journey</h3>
          </div>
          <span className="text-2xs font-mono text-slate-400">4 Core Focus Areas</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div
            onClick={() => navigate('/roadmap')}
            className="p-3.5 rounded-xl border border-slate-200 hover:border-blue-300 hover:bg-blue-50/30 transition-all cursor-pointer flex flex-col justify-between space-y-2 group"
          >
            <div className="flex items-center justify-between">
              <span className="text-3xs font-bold uppercase tracking-wider text-blue-600">Roadmap</span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-blue-600 group-hover:translate-x-0.5 transition-all" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900">Continue Roadmap</h4>
              <p className="text-3xs text-slate-500 mt-0.5">Active Milestone for {user.targetRole}</p>
            </div>
            <div className="text-2xs font-mono text-blue-700 font-semibold">{roadmapPct}% Complete</div>
          </div>

          <div
            onClick={() => navigate('/interview-prep')}
            className="p-3.5 rounded-xl border border-slate-200 hover:border-indigo-300 hover:bg-indigo-50/30 transition-all cursor-pointer flex flex-col justify-between space-y-2 group"
          >
            <div className="flex items-center justify-between">
              <span className="text-3xs font-bold uppercase tracking-wider text-indigo-600">Interview</span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-0.5 transition-all" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900">Practice Interview</h4>
              <p className="text-3xs text-slate-500 mt-0.5">Technical &amp; Role-Specific Scenarios</p>
            </div>
            <div
              className={`text-2xs font-mono font-semibold ${
                readiness.componentMetadata.interview.status === 'completed' ? 'text-indigo-700' : 'text-slate-500'
              }`}
            >
              {readiness.componentMetadata.interview.status === 'completed'
                ? `${readiness.interviewScore}% Score`
                : 'Not Yet Attempted'}
            </div>
          </div>

          <div
            onClick={() => navigate('/resume-analyzer')}
            className="p-3.5 rounded-xl border border-slate-200 hover:border-emerald-300 hover:bg-emerald-50/30 transition-all cursor-pointer flex flex-col justify-between space-y-2 group"
          >
            <div className="flex items-center justify-between">
              <span className="text-3xs font-bold uppercase tracking-wider text-emerald-600">Resume</span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-emerald-600 group-hover:translate-x-0.5 transition-all" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900">Analyze Resume</h4>
              <p className="text-3xs text-slate-500 mt-0.5">Review ATS &amp; X-Y-Z bullet rewrites</p>
            </div>
            <div
              className={`text-2xs font-mono font-semibold ${
                readiness.componentMetadata.ats.status === 'completed' ? 'text-emerald-700' : 'text-slate-500'
              }`}
            >
              {readiness.componentMetadata.ats.status === 'completed'
                ? `${readiness.atsScore}% ATS Score`
                : 'Not Yet Attempted'}
            </div>
          </div>

          <div
            onClick={() => navigate('/jobs')}
            className="p-3.5 rounded-xl border border-slate-200 hover:border-purple-300 hover:bg-purple-50/30 transition-all cursor-pointer flex flex-col justify-between space-y-2 group"
          >
            <div className="flex items-center justify-between">
              <span className="text-3xs font-bold uppercase tracking-wider text-purple-600">Jobs</span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-purple-600 group-hover:translate-x-0.5 transition-all" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900">Recommended Jobs</h4>
              <p className="text-3xs text-slate-500 mt-0.5">Explore openings matching your skills</p>
            </div>
            <div className="text-2xs font-mono text-purple-700 font-semibold">
              {jobs.length > 0 && jobs[0].matchScore > 0 ? `${jobs[0].matchScore}% Top Match` : 'Active Market Feed'}
            </div>
          </div>
        </div>
      </div>

      {/* 4. Two-Column Core: My Skills & Career Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: My Skills */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 tracking-tight">My Skills</h3>
                <p className="text-xs text-slate-500">Benchmark comparison for {user.targetRole}</p>
              </div>
              <button
                onClick={() => navigate('/skill-analytics')}
                className="text-xs font-semibold text-blue-600 hover:text-blue-800 transition-colors cursor-pointer"
              >
                Skill Gap Matrix →
              </button>
            </div>

            <div className="space-y-3.5">
              {displaySkills.map((sk) => {
                const color =
                  sk.level >= 80 ? 'blue' : sk.level < 50 ? 'amber' : 'indigo';
                return (
                  <div key={sk.name} className="space-y-1">
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-semibold text-slate-800">{sk.name}</span>
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-3xs px-1.5 py-0.5 rounded font-medium ${
                            sk.status === 'Strong'
                              ? 'bg-blue-50 text-blue-700'
                              : sk.status === 'Priority Gap'
                              ? 'bg-amber-50 text-amber-700 font-semibold'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {sk.status}
                        </span>
                        <span className="font-mono font-bold text-slate-900 tabular-nums">
                          {sk.level}%
                        </span>
                      </div>
                    </div>
                    <ProgressBar
                      value={sk.level}
                      color={color}
                      size="md"
                      showValueText={false}
                    />
                  </div>
                );
              })}
            </div>
          </div>

          <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Next recommended milestone:</span>
            <span
              onClick={() => navigate('/roadmap')}
              className="font-semibold text-blue-600 cursor-pointer hover:underline"
            >
              {readiness.recommendedActions[0]?.title || `Master ${user.targetRole} Core Competencies`} →
            </span>
          </div>
        </div>

        {/* Right Column: Career Activity Section */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 tracking-tight">Career Activity</h3>
                <p className="text-xs text-slate-500">Live synced professional identity assets</p>
              </div>
              <button
                onClick={() => navigate('/career-hub')}
                className="text-xs font-semibold text-blue-600 hover:text-blue-800 transition-colors cursor-pointer"
              >
                Career Hub →
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div
                onClick={() => navigate('/achievements')}
                className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/70 hover:bg-slate-100/70 transition-colors cursor-pointer space-y-1"
              >
                <div className="flex items-center justify-between">
                  <span className="text-2xs font-semibold text-slate-500">Achievements</span>
                  <Award className="w-3.5 h-3.5 text-blue-600" />
                </div>
                <div className="font-mono text-2xl font-bold text-slate-900 tabular-nums">
                  {achievements.length}
                </div>
                <span className="text-3xs text-slate-400 block truncate">Latest: Verified Certificate</span>
              </div>

              <div
                onClick={() => navigate('/github')}
                className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/70 hover:bg-slate-100/70 transition-colors cursor-pointer space-y-1"
              >
                <div className="flex items-center justify-between">
                  <span className="text-2xs font-semibold text-slate-500">GitHub Repos</span>
                  <GitBranch className="w-3.5 h-3.5 text-slate-700" />
                </div>
                <div className="font-mono text-2xl font-bold text-slate-900 tabular-nums">
                  {githubProjects.length}
                </div>
                <span className="text-3xs text-slate-400 block truncate">Synced Repositories</span>
              </div>

              <div
                onClick={() => navigate('/linkedin')}
                className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/70 hover:bg-slate-100/70 transition-colors cursor-pointer space-y-1"
              >
                <div className="flex items-center justify-between">
                  <span className="text-2xs font-semibold text-slate-500">LinkedIn Posts</span>
                  <Share2 className="w-3.5 h-3.5 text-blue-600" />
                </div>
                <div className="font-mono text-2xl font-bold text-slate-900 tabular-nums">
                  {linkedinPosts.length}
                </div>
                <span className="text-3xs text-slate-400 block truncate">Drafted &amp; Published</span>
              </div>

              <div
                onClick={() => navigate('/applications')}
                className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/70 hover:bg-slate-100/70 transition-colors cursor-pointer space-y-1"
              >
                <div className="flex items-center justify-between">
                  <span className="text-2xs font-semibold text-slate-500">Applications</span>
                  <ListTodo className="w-3.5 h-3.5 text-emerald-600" />
                </div>
                <div className="font-mono text-2xl font-bold text-slate-900 tabular-nums">
                  {applications.length}
                </div>
                <span className="text-3xs text-emerald-600 font-semibold block truncate">Recruitment Drives</span>
              </div>
            </div>
          </div>

          <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-500">Shared profile synchronized</span>
            <button
              onClick={() => navigate('/portfolio')}
              className="text-xs font-semibold text-blue-600 hover:underline cursor-pointer"
            >
              Public Portfolio Page →
            </button>
          </div>
        </div>
      </div>

      {/* 5. AI Recommended Jobs */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h3 className="text-base font-bold text-slate-900 tracking-tight">AI Recommended Jobs</h3>
            <p className="text-xs text-slate-500">
              Personalized matching against your verified skill profile
            </p>
          </div>
          <button
            onClick={() => navigate('/jobs')}
            className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1 cursor-pointer"
          >
            <span>View All Jobs</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {topJobs.length === 0 ? (
          <div className="p-8 text-center bg-slate-50/60 rounded-xl border border-dashed border-slate-200">
            <p className="text-xs text-slate-500">Live job data is updating from Arbeitnow API. Click below to explore all openings.</p>
            <button
              onClick={() => navigate('/jobs')}
              className="mt-2 text-xs font-semibold text-blue-600 hover:text-blue-800 cursor-pointer"
            >
              Explore Job Board
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {topJobs.map((job) => (
              <div
                key={job.id}
                className="p-5 rounded-xl border border-slate-200 hover:border-slate-300 hover:shadow-xs transition-all flex flex-col justify-between bg-slate-50/40"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h4 className="text-sm font-bold text-slate-900 leading-snug">{job.title}</h4>
                      <p className="text-xs text-slate-600 mt-0.5">
                        {job.company} · {job.location}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <span className="inline-block px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 font-mono text-xs font-bold border border-emerald-200">
                        {job.matchScore}% Match
                      </span>
                      <span className="block text-3xs text-slate-400 mt-0.5">{job.salary}</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {job.requiredSkills.map((sk) => {
                      const isMatched = job.matchedSkills.includes(sk);
                      return (
                        <span
                          key={sk}
                          className={`text-2xs px-2 py-0.5 rounded ${
                            isMatched
                              ? 'bg-blue-50 text-blue-700 font-medium'
                              : 'bg-amber-50 text-amber-800'
                          }`}
                        >
                          {isMatched ? '✓ ' : '+ '}
                          {sk}
                        </span>
                      );
                    })}
                  </div>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-200/80 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setSelectedJobForModal(job)}
                      className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg transition-colors cursor-pointer"
                    >
                      View Job
                    </button>
                    <button
                      onClick={() => toggleSaveJob(job.id)}
                      className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                        job.isSaved
                          ? 'bg-blue-50 text-blue-600 border-blue-200'
                          : 'bg-white text-slate-400 border-slate-200 hover:text-slate-700'
                      }`}
                      title={job.isSaved ? 'Saved' : 'Save Job'}
                    >
                      <Bookmark className="w-4 h-4" />
                    </button>
                  </div>

                  <button
                    onClick={() => {
                      setSelectedJobForModal(job);
                    }}
                    className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors cursor-pointer"
                  >
                    Apply Now
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Job Details Modal */}
      {selectedJobForModal && (
        <Modal
          isOpen={true}
          onClose={() => setSelectedJobForModal(null)}
          title={selectedJobForModal.title}
          subtitle={`${selectedJobForModal.company} · ${selectedJobForModal.location} · ${selectedJobForModal.salary}`}
          maxWidth="2xl"
        >
          <div className="space-y-4 text-xs text-slate-700">
            <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50/60 border border-blue-100">
              <span className="font-semibold text-blue-900">
                Your Profile Match: {selectedJobForModal.matchScore}%
              </span>
              <span className="font-mono text-2xs text-slate-500">
                Posted {selectedJobForModal.postedDaysAgo} days ago
              </span>
            </div>

            <div>
              <h5 className="font-bold text-slate-900 mb-1">About the Role</h5>
              <p className="leading-relaxed">{selectedJobForModal.description}</p>
            </div>

            <div>
              <h5 className="font-bold text-slate-900 mb-1">Key Responsibilities</h5>
              <ul className="list-disc pl-4 space-y-1 leading-relaxed">
                {selectedJobForModal.responsibilities.map((r, i) => (
                  <li key={i}>{r}</li>
                ))}
              </ul>
            </div>

            <div>
              <h5 className="font-bold text-slate-900 mb-1">Required Skills &amp; Match</h5>
              <div className="flex flex-wrap gap-1.5 pt-1">
                {selectedJobForModal.requiredSkills.map((sk) => {
                  const hasSkill = selectedJobForModal.matchedSkills.includes(sk);
                  return (
                    <span
                      key={sk}
                      className={`px-2.5 py-1 rounded text-2xs font-medium ${
                        hasSkill
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                          : 'bg-amber-50 text-amber-800 border border-amber-200'
                      }`}
                    >
                      {hasSkill ? '✓ Matched: ' : '! Missing: '}
                      {sk}
                    </span>
                  );
                })}
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
              <button
                onClick={() => setSelectedJobForModal(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 rounded-lg"
              >
                Close
              </button>
              <button
                onClick={() => {
                  setSelectedJobForModal(null);
                  navigate('/applications');
                }}
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg"
              >
                Submit Application
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};

export default DashboardPage;
