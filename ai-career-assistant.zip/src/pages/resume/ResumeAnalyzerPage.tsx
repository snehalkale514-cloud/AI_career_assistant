import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  UploadCloud,
  FileCheck2,
  FileText,
  AlertCircle,
  CheckCircle2,
  ArrowRight,
  Download,
  Sparkles,
  Layers,
  RefreshCw,
  Sliders,
  Check
} from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';
import { ProgressBar } from '../../components/common/ProgressBar.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';
import { extractTextFromFile, analyzeResumeContent } from '../../services/resumeAnalyzerService.ts';

export const ResumeAnalyzerPage: React.FC = () => {
  const navigate = useNavigate();
  const { resumeAnalysis, updateResumeAnalysis, user } = useCareer();
  const [analyzing, setAnalyzing] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const hasUploadedResume = Boolean(resumeAnalysis?.hasUploadedResume);
  const [fileName, setFileName] = useState(hasUploadedResume ? (resumeAnalysis?.analyzedFileName || '') : '');
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [reportNotice, setReportNotice] = useState<string | null>(null);

  React.useEffect(() => {
    if (hasUploadedResume && resumeAnalysis?.analyzedFileName) {
      setFileName(resumeAnalysis.analyzedFileName);
    } else if (!hasUploadedResume) {
      setFileName('');
    }
  }, [hasUploadedResume, resumeAnalysis?.analyzedFileName]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setFileName(file.name);
      runAnalysis(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      setFileName(file.name);
      runAnalysis(file);
    }
  };

  const runAnalysis = async (file: File) => {
    setAnalyzing(true);
    try {
      const extractedText = await extractTextFromFile(file);
      const result = analyzeResumeContent(extractedText, file.name, user.targetRole);
      updateResumeAnalysis({
        ...result,
        hasUploadedResume: true
      });
    } catch (err) {
      console.error('Error analyzing resume:', err);
      updateResumeAnalysis({
        atsScore: 5,
        atsCompatibility: 5,
        keywordMatch: 0,
        formattingScore: 10,
        skillsMatch: 0,
        experienceMatch: 0,
        strengths: [],
        missingSkills: [],
        keywordSuggestions: [],
        improvements: [],
        analyzedFileName: file.name,
        hasUploadedResume: true,
        warningMessage: 'Failed to extract text from the uploaded file. Please ensure it is an uncorrupted document with selectable text.'
      });
    } finally {
      setAnalyzing(false);
    }
  };

  const handleCopyBullet = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/dashboard" />
      </div>

      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-600 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" />
              ATS Diagnostic Engine
            </span>
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            Resume Analyzer &amp; Optimization
          </h2>
          <p className="text-xs text-slate-500">
            Audit your resume against live ATS screening algorithms used by campus hiring partners.
          </p>
        </div>

        <button
          onClick={() => navigate('/app/resume-builder')}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors cursor-pointer"
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Build ATS Resume</span>
        </button>
      </div>

      {/* Upload Drop Area */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        className={`relative rounded-2xl border-2 border-dashed p-8 text-center transition-all bg-white ${
          dragOver
            ? 'border-blue-500 bg-blue-50/40'
            : 'border-slate-300 hover:border-slate-400'
        }`}
      >
        <input
          type="file"
          id="resume-upload"
          accept=".pdf,.docx,.doc"
          onChange={handleFileUpload}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
        />

        <div className="space-y-3">
          <div className="w-12 h-12 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center mx-auto border border-blue-100">
            <UploadCloud className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Drop your resume here, or <span className="text-blue-600 underline">Choose File</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Supports standard PDF and DOCX format (Max 10MB)
            </p>
          </div>
          {hasUploadedResume && (fileName || resumeAnalysis?.analyzedFileName) ? (
            <div className="inline-flex items-center gap-2 text-2xs text-slate-600 bg-slate-50 px-3 py-1 rounded-md border border-slate-200">
              <FileCheck2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>Currently Analyzed: <strong>{fileName || resumeAnalysis?.analyzedFileName}</strong></span>
            </div>
          ) : (
            <div className="inline-flex items-center gap-2 text-2xs text-slate-500 bg-slate-50 px-3 py-1 rounded-md border border-slate-200">
              <FileText className="w-3.5 h-3.5 text-slate-400" />
              <span>No resume uploaded yet</span>
            </div>
          )}
        </div>
      </div>

      {/* Document Warning Notice if any */}
      {hasUploadedResume && resumeAnalysis?.warningMessage && (
        <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 flex items-start gap-2.5">
          <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold block">Document Notice</span>
            <span>{resumeAnalysis.warningMessage}</span>
          </div>
        </div>
      )}

      {/* Loading state indicator */}
      {analyzing && (
        <div className="p-8 bg-white rounded-2xl border border-blue-200 text-center space-y-3 shadow-xs">
          <RefreshCw className="w-8 h-8 text-blue-600 animate-spin mx-auto" />
          <h4 className="text-sm font-bold text-slate-900">Parsing Resume Structure &amp; Keywords...</h4>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Extracting text tokens, analyzing X-Y-Z metric formulations, and matching against {user.targetRole} screening criteria.
          </p>
        </div>
      )}

      {/* Analysis Results View vs Initial Unattempted State */}
      {!analyzing && (
        hasUploadedResume ? (
          <div className="space-y-8">
            {/* Main Scorecard Overview */}
          <div className="bg-white rounded-2xl border border-slate-200/90 p-6 sm:p-8 shadow-xs">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center pb-6 border-b border-slate-100">
              {/* Left Score Circle */}
              <div className="md:col-span-4 text-center border-b md:border-b-0 md:border-r border-slate-100 pb-6 md:pb-0 md:pr-6 space-y-3">
                <span className="text-2xs font-bold uppercase tracking-wider text-slate-400">
                  Overall ATS Score
                </span>
                <div className="relative w-32 h-32 mx-auto flex items-center justify-center">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                    <path
                      className="text-slate-100"
                      strokeWidth="3.5"
                      stroke="currentColor"
                      fill="none"
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    />
                    <path
                      className={
                        resumeAnalysis.atsScore >= 75
                          ? 'text-blue-600'
                          : resumeAnalysis.atsScore >= 45
                          ? 'text-amber-500'
                          : 'text-rose-500'
                      }
                      strokeDasharray={`${resumeAnalysis.atsScore}, 100`}
                      strokeWidth="3.5"
                      strokeLinecap="round"
                      stroke="currentColor"
                      fill="none"
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-3xl font-mono font-extrabold text-slate-900 tabular-nums">
                      {resumeAnalysis.atsScore}
                    </span>
                    <span className="text-3xs text-slate-400 font-semibold uppercase">out of 100</span>
                  </div>
                </div>
                <div
                  className={`text-2xs font-semibold px-2 py-1 rounded inline-block ${
                    resumeAnalysis.atsScore >= 75
                      ? 'text-emerald-700 bg-emerald-50'
                      : resumeAnalysis.atsScore >= 45
                      ? 'text-amber-700 bg-amber-50'
                      : 'text-rose-700 bg-rose-50'
                  }`}
                >
                  {resumeAnalysis.atsScore >= 75
                    ? 'High Interview Pass Rate'
                    : resumeAnalysis.atsScore >= 45
                    ? 'Moderate Screening Pass Rate'
                    : 'Low Screening Pass Rate (Needs Optimization)'}
                </div>
              </div>

              {/* Right Pillar Breakdown */}
              <div className="md:col-span-8 space-y-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                  ATS Evaluation Pillars
                </h3>
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-xs font-semibold mb-1">
                      <span className="text-slate-700">ATS Compatibility (Parsability &amp; Structure)</span>
                      <span className="font-mono text-slate-900">{resumeAnalysis.atsCompatibility}%</span>
                    </div>
                    <ProgressBar value={resumeAnalysis.atsCompatibility} size="sm" showValueText={false} color="blue" />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-semibold mb-1">
                      <span className="text-slate-700">Keyword Match ({user.targetRole} Density)</span>
                      <span className="font-mono text-slate-900">{resumeAnalysis.keywordMatch}%</span>
                    </div>
                    <ProgressBar value={resumeAnalysis.keywordMatch} size="sm" showValueText={false} color="indigo" />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-semibold mb-1">
                      <span className="text-slate-700">Formatting &amp; Hierarchy (Font &amp; Standard Headings)</span>
                      <span className="font-mono text-slate-900">{resumeAnalysis.formattingScore}%</span>
                    </div>
                    <ProgressBar value={resumeAnalysis.formattingScore} size="sm" showValueText={false} color="emerald" />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-semibold mb-1">
                      <span className="text-slate-700">Skills Match (Verified Technical Competencies)</span>
                      <span className="font-mono text-slate-900">{resumeAnalysis.skillsMatch}%</span>
                    </div>
                    <ProgressBar value={resumeAnalysis.skillsMatch} size="sm" showValueText={false} color="blue" />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-semibold mb-1">
                      <span className="text-slate-700">Experience &amp; Project Depth</span>
                      <span className="font-mono text-slate-900">{resumeAnalysis.experienceMatch}%</span>
                    </div>
                    <ProgressBar value={resumeAnalysis.experienceMatch} size="sm" showValueText={false} color="amber" />
                  </div>
                </div>
              </div>
            </div>

            {/* Strengths & Missing Skills */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-6">
              {/* Strengths */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-700">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Resume Strengths</span>
                </div>
                <ul className="space-y-2 text-xs text-slate-700">
                  {resumeAnalysis.strengths.length > 0 ? (
                    resumeAnalysis.strengths.map((str, i) => (
                      <li key={i} className="flex items-start gap-2 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                        <span className="text-emerald-600 font-bold shrink-0">✓</span>
                        <span>{str}</span>
                      </li>
                    ))
                  ) : (
                    <li className="p-3 text-slate-400 bg-slate-50 rounded-lg text-center text-xs">
                      No verified strengths detected. Upload an uncorrupted document with selectable text and standard headings.
                    </li>
                  )}
                </ul>
              </div>

              {/* Missing Skills */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-700">
                  <AlertCircle className="w-4 h-4" />
                  <span>Missing Skills in Resume ({user.targetRole})</span>
                </div>
                <ul className="space-y-2 text-xs text-slate-700">
                  {resumeAnalysis.missingSkills.length > 0 ? (
                    resumeAnalysis.missingSkills.map((sk, i) => (
                      <li key={i} className="flex items-start gap-2 bg-amber-50/50 p-2.5 rounded-lg border border-amber-200/80">
                        <span className="text-amber-700 font-bold shrink-0">!</span>
                        <span>{sk}</span>
                      </li>
                    ))
                  ) : (
                    <li className="p-3 text-emerald-700 bg-emerald-50 rounded-lg text-center font-medium text-xs">
                      All primary benchmark skills for {user.targetRole} detected in resume!
                    </li>
                  )}
                </ul>
              </div>
            </div>

            {/* Keyword Suggestions */}
            <div className="pt-6 mt-6 border-t border-slate-100 space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Recommended ATS Keywords to Add ({user.targetRole}):
              </h4>
              <div className="flex flex-wrap gap-2">
                {resumeAnalysis.keywordSuggestions.length > 0 ? (
                  resumeAnalysis.keywordSuggestions.map((kw) => (
                    <span
                      key={kw}
                      className="text-xs px-3 py-1 rounded-md bg-blue-50 text-blue-700 border border-blue-200 font-medium"
                    >
                      + {kw}
                    </span>
                  ))
                ) : (
                  <span className="text-xs text-slate-400">All key role keywords detected in resume text.</span>
                )}
              </div>
            </div>
          </div>

          {/* Before & After Bullet Point Improvement Examples */}
          <div className="bg-white rounded-2xl border border-slate-200/90 p-6 sm:p-8 shadow-xs space-y-6">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  AI Impact Rewriting Engine
                </span>
              </div>
              <h3 className="text-base font-bold text-slate-900">
                Action-Oriented Bullet Improvements (Google X-Y-Z Formula)
              </h3>
              <p className="text-xs text-slate-500">
                &quot;Accomplished [X] as measured by [Y], by doing [Z]&quot; — Transforms passive descriptions into quantified accomplishments.
              </p>
            </div>

            <div className="space-y-4">
              {resumeAnalysis.improvements.map((imp, idx) => (
                <div key={idx} className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-3">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Before */}
                    <div className="p-3 rounded-lg bg-rose-50/50 border border-rose-200/70 space-y-1">
                      <span className="text-2xs font-bold uppercase tracking-wider text-rose-700 block">
                        Current / Weak Phrasing
                      </span>
                      <p className="text-xs text-rose-950 font-normal leading-relaxed line-through opacity-85">
                        &quot;{imp.original}&quot;
                      </p>
                    </div>

                    {/* After */}
                    <div className="p-3 rounded-lg bg-emerald-50/50 border border-emerald-200/70 space-y-1 relative">
                      <div className="flex items-center justify-between">
                        <span className="text-2xs font-bold uppercase tracking-wider text-emerald-700 block">
                          AI Recommended X-Y-Z Phrasing
                        </span>
                        <button
                          onClick={() => handleCopyBullet(imp.suggested, idx)}
                          className="text-2xs font-semibold text-emerald-700 hover:text-emerald-900 flex items-center gap-1 cursor-pointer"
                        >
                          {copiedIndex === idx ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-600" />
                              <span>Copied!</span>
                            </>
                          ) : (
                            <span>Copy Bullet</span>
                          )}
                        </button>
                      </div>
                      <p className="text-xs text-emerald-950 font-medium leading-relaxed">
                        &quot;{imp.suggested}&quot;
                      </p>
                    </div>
                  </div>
                  <p className="text-2xs text-slate-500 italic pl-1">
                    <strong>Why this works:</strong> {imp.reason}
                  </p>
                </div>
              ))}
            </div>

            {/* Report Notice Banner */}
            {reportNotice && (
              <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{reportNotice}</span>
              </div>
            )}

            {/* Bottom Actions */}
            <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3">
              <button
                onClick={() => {
                  setReportNotice('ATS Diagnostic PDF Report generated and ready.');
                  setTimeout(() => setReportNotice(null), 3500);
                }}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Report</span>
              </button>

              <div className="flex items-center gap-3 w-full sm:w-auto">
                <button
                  onClick={() => navigate('/app/resume-builder')}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm transition-all cursor-pointer"
                >
                  <span>Build ATS Resume with Live Preview</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Initial State Card when no resume has been uploaded yet */
        <div className="bg-white rounded-2xl border border-slate-200/90 p-8 sm:p-12 text-center space-y-6 shadow-xs">
          <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto border border-blue-100 shadow-2xs">
            <FileText className="w-8 h-8" />
          </div>

          <div className="space-y-2 max-w-lg mx-auto">
            <h3 className="text-xl font-bold text-slate-900 tracking-tight">
              Ready to Analyze Your Resume?
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Upload your resume to calculate your ATS score and receive personalized feedback.
            </p>
          </div>

          {/* Feature highlights of the analysis engine */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 max-w-2xl mx-auto pt-2 text-left">
            <div className="p-3.5 rounded-xl border border-slate-200/80 bg-slate-50/50 space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
                <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                <span>5-Pillar ATS Scoring</span>
              </div>
              <p className="text-3xs text-slate-500 leading-normal">
                Parsability, formatting, keyword density, technical competencies, and impact.
              </p>
            </div>

            <div className="p-3.5 rounded-xl border border-slate-200/80 bg-slate-50/50 space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Role Benchmark Matching</span>
              </div>
              <p className="text-3xs text-slate-500 leading-normal">
                Detects required tools, frameworks, and skills for {user.targetRole}.
              </p>
            </div>

            <div className="p-3.5 rounded-xl border border-slate-200/80 bg-slate-50/50 space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
                <Sliders className="w-3.5 h-3.5 text-indigo-600" />
                <span>Google X-Y-Z Feedback</span>
              </div>
              <p className="text-3xs text-slate-500 leading-normal">
                Actionable metric-driven suggestions to optimize your bullet points.
              </p>
            </div>
          </div>

          <div className="pt-2">
            <label
              htmlFor="resume-upload"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
            >
              <UploadCloud className="w-4 h-4" />
              <span>Select Resume to Begin</span>
            </label>
          </div>
        </div>
      ))}
    </div>
  );
};
