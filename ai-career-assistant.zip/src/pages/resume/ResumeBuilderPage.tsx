import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  FileText,
  Save,
  Download,
  FileCheck2,
  Plus,
  Trash2,
  Sparkles,
  ExternalLink,
  CheckCircle2,
  Mail,
  Phone,
  MapPin,
  Linkedin,
  Github
} from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';

export const ResumeBuilderPage: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useCareer();
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Resume builder state initialized with Snehal Kale's profile
  const [resumeData, setResumeData] = useState({
    fullName: user.name,
    targetRole: user.targetRole,
    email: user.email,
    phone: user.phone,
    location: user.location,
    linkedin: 'linkedin.com/in/snehalkale',
    github: 'github.com/snehalkale',
    summary:
      'Disciplined BTech candidate in AI & Data Science (VPKBIET, Class of 2028) with hands-on proficiency in Python, PostgreSQL, and analytical data pipelines. Proven experience analyzing transactional datasets, engineering machine learning classifiers, and developing executive reporting dashboards.',
    education: [
      {
        id: 'edu_1',
        degree: 'Bachelor of Technology in Artificial Intelligence & Data Science',
        institution: "Vidya Pratishthan's Kamalnayan Bajaj Institute of Engineering & Technology",
        period: '2024 – 2028',
        grade: 'CGPA: 8.84 / 10.0',
        coursework: 'Database Management Systems, Data Structures & Algorithms, Applied Statistics, Machine Learning, Python for Data Science',
      },
    ],
    skills: {
      languages: 'Python, SQL (PostgreSQL, MySQL), C++',
      toolsAndFrameworks: 'Pandas, NumPy, Scikit-Learn, Power BI, Advanced Excel, Git, FastAPI',
      analyticalConcepts: 'Exploratory Data Analysis (EDA), Hypothesis Testing, A/B Testing, Time Series, Data Cleansing',
    },
    projects: [
      {
        id: 'proj_1',
        title: 'Sales & Inventory Intelligence Dashboard',
        role: 'Lead Data Analyst',
        period: 'Jan 2026 – Present',
        bullets: [
          'Engineered an automated data extraction and transformation pipeline in Python (Pandas) processing 100,000+ retail order transactions.',
          'Modeled star schemas in PostgreSQL with foreign-key cardinalities and optimized window functions to compute customer retention cohorts.',
          'Built 4 interactive Power BI executive reports displaying margin metrics, identifying 14% inventory savings opportunities.'
        ],
      },
      {
        id: 'proj_2',
        title: 'Customer Churn Prediction & Retention System',
        role: 'ML Developer',
        period: 'Oct 2025 – Dec 2025',
        bullets: [
          'Trained and evaluated XGBoost and Random Forest classification models on 7,000+ telecom subscription records, achieving 86% ROC-AUC.',
          'Engineered 18 behavioral features from raw usage logs and utilized SHAP value analysis to interpret top churn drivers for business stakeholders.',
          'Containerized model inference script using Python with 98% test coverage and modular documentation.'
        ],
      },
    ],
    experience: [
      {
        id: 'exp_1',
        title: 'Student Analyst Trainee',
        company: 'VPKBIET Data & Innovation Lab',
        location: 'Baramati / Pune, India',
        period: 'Aug 2025 – Dec 2025',
        bullets: [
          'Assisted departmental faculty in structuring relational SQL schemas for 1,200+ student academic records.',
          'Created automated Python report scripts reducing semester mark consolidation turnaround time from 3 days to 45 minutes.'
        ],
      },
    ],
    certifications: [
      'Google Data Analytics Professional Certificate — Coursera (2025)',
      'PostgreSQL for Data Engineers & Analysts — VPKBIET Placement Wing (2025)',
      'Microsoft Power BI Data Analyst Associate (PL-300 in prep)'
    ],
    achievements: [
      'Top 5% rank in Second Year BTech Engineering Cohort (VPKBIET, 2025)',
      '1st Place in Intra-College Python Data Hackathon (48 teams participating)',
      'Lead Technical Organizer, AI & Data Science Student Chapter'
    ],
  });

  const handleSave = () => {
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const handlePrint = () => {
    window.print();
  };

  const addProjectBullet = (projId: string) => {
    setResumeData((prev) => ({
      ...prev,
      projects: prev.projects.map((p) =>
        p.id === projId ? { ...p, bullets: [...p.bullets, 'Accomplished [X] measured by [Y] by doing [Z]'] } : p
      ),
    }));
  };

  return (
    <div className="space-y-6">
      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/resume-analyzer" />
      </div>

      {/* Top Action Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-slate-200">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600" />
            <span>ATS Resume Builder</span>
          </h2>
          <p className="text-xs text-slate-500">
            Clean, single-column reverse-chronological format optimized for recruiter applicant tracking systems.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => navigate('/app/resume-analyzer')}
            className="px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <FileCheck2 className="w-3.5 h-3.5 text-blue-600" />
            <span>Analyze Resume</span>
          </button>
          <button
            onClick={handleSave}
            className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save Draft</span>
          </button>
          <button
            onClick={handlePrint}
            className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download / Print PDF</span>
          </button>
        </div>
      </div>

      {saveSuccess && (
        <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>Resume draft saved successfully. Changes are ready for ATS submission.</span>
        </div>
      )}

      {/* Two Column Layout: Editor on Left, Live Clean Preview on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Form Section Controls */}
        <div className="lg:col-span-5 space-y-5">
          {/* Section 1: Personal Details */}
          <div className="bg-white rounded-xl border border-slate-200/90 p-5 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              1. Personal Details
            </h3>
            <div className="space-y-2 text-xs">
              <div>
                <label className="block text-slate-600 mb-0.5">Full Name</label>
                <input
                  type="text"
                  value={resumeData.fullName}
                  onChange={(e) => setResumeData({ ...resumeData, fullName: e.target.value })}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md text-slate-900"
                />
              </div>
              <div>
                <label className="block text-slate-600 mb-0.5">Target Job Title</label>
                <input
                  type="text"
                  value={resumeData.targetRole}
                  onChange={(e) => setResumeData({ ...resumeData, targetRole: e.target.value })}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md text-slate-900"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-600 mb-0.5">Email</label>
                  <input
                    type="email"
                    value={resumeData.email}
                    onChange={(e) => setResumeData({ ...resumeData, email: e.target.value })}
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 mb-0.5">Phone</label>
                  <input
                    type="text"
                    value={resumeData.phone}
                    onChange={(e) => setResumeData({ ...resumeData, phone: e.target.value })}
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md text-slate-900"
                  />
                </div>
              </div>
              <div>
                <label className="block text-slate-600 mb-0.5">Professional Summary</label>
                <textarea
                  rows={3}
                  value={resumeData.summary}
                  onChange={(e) => setResumeData({ ...resumeData, summary: e.target.value })}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md text-slate-900"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Technical Skills */}
          <div className="bg-white rounded-xl border border-slate-200/90 p-5 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              2. Technical Skills Matrix
            </h3>
            <div className="space-y-2 text-xs">
              <div>
                <label className="block text-slate-600 mb-0.5">Languages</label>
                <input
                  type="text"
                  value={resumeData.skills.languages}
                  onChange={(e) =>
                    setResumeData({
                      ...resumeData,
                      skills: { ...resumeData.skills, languages: e.target.value },
                    })
                  }
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md text-slate-900"
                />
              </div>
              <div>
                <label className="block text-slate-600 mb-0.5">Tools &amp; Frameworks</label>
                <input
                  type="text"
                  value={resumeData.skills.toolsAndFrameworks}
                  onChange={(e) =>
                    setResumeData({
                      ...resumeData,
                      skills: { ...resumeData.skills, toolsAndFrameworks: e.target.value },
                    })
                  }
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md text-slate-900"
                />
              </div>
              <div>
                <label className="block text-slate-600 mb-0.5">Analytical Concepts</label>
                <input
                  type="text"
                  value={resumeData.skills.analyticalConcepts}
                  onChange={(e) =>
                    setResumeData({
                      ...resumeData,
                      skills: { ...resumeData.skills, analyticalConcepts: e.target.value },
                    })
                  }
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md text-slate-900"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Project Bullets */}
          <div className="bg-white rounded-xl border border-slate-200/90 p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                3. Key Projects
              </h3>
            </div>
            <div className="space-y-4 text-xs">
              {resumeData.projects.map((proj) => (
                <div key={proj.id} className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
                  <span className="font-bold text-slate-900 block">{proj.title}</span>
                  <div className="space-y-1.5">
                    {proj.bullets.map((b, bIdx) => (
                      <textarea
                        key={bIdx}
                        rows={2}
                        value={b}
                        onChange={(e) => {
                          const newBullets = [...proj.bullets];
                          newBullets[bIdx] = e.target.value;
                          setResumeData({
                            ...resumeData,
                            projects: resumeData.projects.map((p) =>
                              p.id === proj.id ? { ...p, bullets: newBullets } : p
                            ),
                          });
                        }}
                        className="w-full px-2 py-1 bg-white border border-slate-200 rounded text-slate-800 text-xs"
                      />
                    ))}
                  </div>
                  <button
                    onClick={() => addProjectBullet(proj.id)}
                    className="text-2xs text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3 h-3" />
                    <span>Add Project Bullet</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Live ATS-Friendly Printable Document Preview */}
        <div className="lg:col-span-7">
          <div className="bg-white rounded-2xl border border-slate-300 p-8 sm:p-10 shadow-md text-slate-900 space-y-5 print:p-0 print:border-none print:shadow-none min-h-[840px]">
            {/* Document Header */}
            <div className="text-center border-b border-slate-800 pb-3 space-y-1">
              <h1 className="text-xl sm:text-2xl font-bold uppercase tracking-wide text-slate-950">
                {resumeData.fullName}
              </h1>
              <p className="text-xs font-semibold text-slate-700 tracking-wide uppercase">
                {resumeData.targetRole}
              </p>
              <div className="text-2xs text-slate-600 flex flex-wrap items-center justify-center gap-2 pt-1">
                <span>{resumeData.location}</span>
                <span>•</span>
                <span>{resumeData.email}</span>
                <span>•</span>
                <span>{resumeData.phone}</span>
                <span>•</span>
                <span>{resumeData.linkedin}</span>
                <span>•</span>
                <span>{resumeData.github}</span>
              </div>
            </div>

            {/* Summary */}
            <div className="space-y-1">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5">
                Professional Summary
              </h2>
              <p className="text-2xs sm:text-xs text-slate-700 leading-relaxed text-justify">
                {resumeData.summary}
              </p>
            </div>

            {/* Education */}
            <div className="space-y-1.5">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5">
                Education
              </h2>
              {resumeData.education.map((edu) => (
                <div key={edu.id} className="space-y-0.5 text-2xs sm:text-xs">
                  <div className="flex justify-between font-bold text-slate-900">
                    <span>{edu.institution}</span>
                    <span className="font-mono text-slate-600">{edu.period}</span>
                  </div>
                  <div className="flex justify-between text-slate-700 italic">
                    <span>{edu.degree}</span>
                    <span className="font-semibold not-italic">{edu.grade}</span>
                  </div>
                  <p className="text-3xs sm:text-2xs text-slate-600">
                    <span className="font-semibold text-slate-800">Relevant Coursework:</span>{' '}
                    {edu.coursework}
                  </p>
                </div>
              ))}
            </div>

            {/* Technical Skills */}
            <div className="space-y-1">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5">
                Technical Skills
              </h2>
              <div className="text-2xs sm:text-xs space-y-0.5 text-slate-800">
                <p>
                  <span className="font-bold">Languages:</span> {resumeData.skills.languages}
                </p>
                <p>
                  <span className="font-bold">Frameworks &amp; Tools:</span>{' '}
                  {resumeData.skills.toolsAndFrameworks}
                </p>
                <p>
                  <span className="font-bold">Analytical Concepts:</span>{' '}
                  {resumeData.skills.analyticalConcepts}
                </p>
              </div>
            </div>

            {/* Key Technical Projects */}
            <div className="space-y-2">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5">
                Technical Projects
              </h2>
              {resumeData.projects.map((proj) => (
                <div key={proj.id} className="space-y-1 text-2xs sm:text-xs">
                  <div className="flex justify-between font-bold text-slate-900">
                    <span>{proj.title}</span>
                    <span className="font-mono text-slate-600">{proj.period}</span>
                  </div>
                  <ul className="list-disc pl-4 space-y-1 text-slate-700 leading-relaxed text-justify">
                    {proj.bullets.map((b, i) => (
                      <li key={i}>{b}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            {/* Experience */}
            <div className="space-y-2">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5">
                Work Experience &amp; Academic Training
              </h2>
              {resumeData.experience.map((exp) => (
                <div key={exp.id} className="space-y-1 text-2xs sm:text-xs">
                  <div className="flex justify-between font-bold text-slate-900">
                    <span>
                      {exp.company} — <span className="italic font-normal">{exp.title}</span>
                    </span>
                    <span className="font-mono text-slate-600">{exp.period}</span>
                  </div>
                  <ul className="list-disc pl-4 space-y-1 text-slate-700 leading-relaxed text-justify">
                    {exp.bullets.map((b, i) => (
                      <li key={i}>{b}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            {/* Certifications & Achievements */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
              <div className="space-y-1">
                <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5">
                  Certifications
                </h2>
                <ul className="list-disc pl-4 space-y-0.5 text-3xs sm:text-2xs text-slate-700">
                  {resumeData.certifications.map((c, i) => (
                    <li key={i}>{c}</li>
                  ))}
                </ul>
              </div>

              <div className="space-y-1">
                <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5">
                  Honors &amp; Achievements
                </h2>
                <ul className="list-disc pl-4 space-y-0.5 text-3xs sm:text-2xs text-slate-700">
                  {resumeData.achievements.map((a, i) => (
                    <li key={i}>{a}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
