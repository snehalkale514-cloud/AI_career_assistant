import React, { useState } from 'react';
import {
  FolderGit2,
  Clock,
  Bookmark,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  ExternalLink,
  Code2,
  Layers
} from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';
import { Modal } from '../../components/common/Modal.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';
import { ProjectItem } from '../../types.ts';

export const ProjectsPage: React.FC = () => {
  const { projects, toggleSaveProject, updateProjectStatus, user } = useCareer();
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);
  const [activeFilter, setActiveFilter] = useState<'All' | 'Intermediate' | 'Advanced'>('All');

  const filteredProjects = projects.filter((p) => {
    if (activeFilter === 'All') return true;
    return p.difficulty === activeFilter;
  });

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/dashboard" />
      </div>

      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-600 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" />
              Portfolio Accelerators
            </span>
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            AI Recommended Projects
          </h2>
          <p className="text-xs text-slate-500">
            Engineered to bridge verified skill gaps for <strong>{user.targetRole}</strong> recruitment rounds.
          </p>
        </div>

        {/* Filter buttons */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs">
          {(['All', 'Intermediate', 'Advanced'] as const).map((filter) => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                activeFilter === filter
                  ? 'bg-white text-slate-900 font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredProjects.map((proj) => (
          <div
            key={proj.id}
            className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs hover:border-slate-300 hover:shadow-sm transition-all flex flex-col justify-between space-y-5"
          >
            <div className="space-y-3">
              {/* Header tags */}
              <div className="flex items-start justify-between gap-2">
                <span className="text-3xs font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200">
                  {proj.difficulty} Level
                </span>

                <button
                  onClick={() => toggleSaveProject(proj.id)}
                  className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                    proj.isSaved
                      ? 'bg-blue-50 text-blue-600 border-blue-200'
                      : 'bg-white text-slate-400 border-slate-200 hover:text-slate-600'
                  }`}
                  title={proj.isSaved ? 'Saved to bookmarks' : 'Save project'}
                >
                  <Bookmark className="w-4 h-4" />
                </button>
              </div>

              <h3 className="text-base font-bold text-slate-900 leading-snug">{proj.title}</h3>

              <p className="text-xs text-slate-600 leading-relaxed">{proj.description}</p>

              {/* Why recommended highlight */}
              <div className="p-3 rounded-xl bg-blue-50/50 border border-blue-100 text-xs text-blue-900 space-y-0.5">
                <span className="text-3xs font-bold uppercase tracking-wider text-blue-700 block">
                  Why AI Recommended:
                </span>
                <p className="italic text-slate-700">{proj.whyRecommended}</p>
              </div>

              {/* Skills required */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {proj.skills.map((sk) => (
                  <span
                    key={sk}
                    className="text-2xs px-2.5 py-0.5 rounded bg-slate-100 text-slate-700 font-medium"
                  >
                    {sk}
                  </span>
                ))}
              </div>
            </div>

            {/* Actions footer */}
            <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-2xs font-mono text-slate-400 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                {proj.estimatedHours}
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setSelectedProject(proj)}
                  className="px-3 py-1.5 font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                >
                  View Project
                </button>

                <button
                  onClick={() => {
                    updateProjectStatus(
                      proj.id,
                      proj.status === 'In Progress' ? 'Completed' : 'In Progress'
                    );
                  }}
                  className={`px-3.5 py-1.5 font-semibold rounded-lg transition-colors cursor-pointer ${
                    proj.status === 'In Progress'
                      ? 'bg-amber-50 text-amber-800 border border-amber-300'
                      : proj.status === 'Completed'
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                      : 'bg-blue-600 text-white hover:bg-blue-700 shadow-xs'
                  }`}
                >
                  {proj.status === 'In Progress'
                    ? 'In Progress'
                    : proj.status === 'Completed'
                    ? 'Completed'
                    : 'Start Project'}
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Detailed Project Modal */}
      {selectedProject && (
        <Modal
          isOpen={true}
          onClose={() => setSelectedProject(null)}
          title={selectedProject.title}
          subtitle={`Difficulty: ${selectedProject.difficulty} · Estimated Time: ${selectedProject.estimatedHours}`}
          maxWidth="2xl"
        >
          <div className="space-y-5 text-xs text-slate-700">
            <div>
              <h4 className="font-bold text-slate-900 mb-1">Project Synopsis</h4>
              <p className="leading-relaxed">{selectedProject.description}</p>
            </div>

            <div className="p-3.5 rounded-xl bg-blue-50/60 border border-blue-200 space-y-1">
              <span className="font-bold text-blue-900 block">Placement Alignment</span>
              <p className="text-slate-700 leading-relaxed">{selectedProject.whyRecommended}</p>
            </div>

            <div>
              <h4 className="font-bold text-slate-900 mb-1.5">Required Deliverables &amp; Code Artifacts</h4>
              <ul className="list-disc pl-5 space-y-1.5 text-slate-700">
                {selectedProject.deliverables.map((d, i) => (
                  <li key={i}>{d}</li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-slate-900 mb-1.5">Technologies Handled</h4>
              <div className="flex flex-wrap gap-2">
                {selectedProject.skills.map((sk) => (
                  <span
                    key={sk}
                    className="px-3 py-1 bg-slate-100 text-slate-800 font-semibold rounded-md border border-slate-200"
                  >
                    {sk}
                  </span>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
              <button
                onClick={() => setSelectedProject(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 rounded-lg cursor-pointer"
              >
                Close
              </button>

              <button
                onClick={() => {
                  updateProjectStatus(selectedProject.id, 'In Progress');
                  setSelectedProject(null);
                }}
                className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs cursor-pointer"
              >
                Accept &amp; Start Project
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
