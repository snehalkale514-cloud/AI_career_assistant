import React, { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  TrendingUp,
  FileCheck2,
  Code2,
  MessageSquareCode,
  FolderGit2,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  ShieldCheck,
  Target
} from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';
import { ProgressBar } from '../../components/common/ProgressBar.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';
import { MLPlacementReadinessSection } from '../../components/readiness/MLPlacementReadinessSection.tsx';
import { calculatePlacementReadiness } from '../../services/placementReadinessService.ts';

export const PlacementReadinessPage: React.FC = () => {
  const navigate = useNavigate();
  const { user, skills, projects, resumeAnalysis, interviewHistory } = useCareer();

  const readiness = useMemo(() => {
    return calculatePlacementReadiness(user, skills, projects, resumeAnalysis, interviewHistory, user.targetRole);
  }, [user, skills, projects, resumeAnalysis, interviewHistory]);

  const readinessBreakdown = [
    {
      title: 'ATS Resume Quality',
      score: readiness.atsScore,
      status: readiness.componentMetadata.ats.status,
      label: readiness.componentMetadata.ats.label,
      color: (readiness.atsScore >= 75 ? 'emerald' : readiness.atsScore >= 50 ? 'blue' : 'amber') as 'emerald' | 'blue' | 'amber',
      link: '/app/resume-analyzer'
    },
    {
      title: 'Technical Skills Proficiency',
      score: readiness.technicalScore,
      status: readiness.componentMetadata.technical.status,
      label: readiness.componentMetadata.technical.label,
      color: (readiness.technicalScore >= 75 ? 'emerald' : readiness.technicalScore >= 50 ? 'blue' : 'amber') as 'emerald' | 'blue' | 'amber',
      link: '/app/skill-analytics'
    },
    {
      title: 'Applied Projects & Portfolio',
      score: readiness.projectsScore,
      status: readiness.componentMetadata.projects.status,
      label: readiness.componentMetadata.projects.label,
      color: (readiness.projectsScore >= 75 ? 'emerald' : readiness.projectsScore >= 50 ? 'indigo' : 'amber') as 'emerald' | 'indigo' | 'amber',
      link: '/app/projects'
    },
    {
      title: 'Interview & Verbal Articulation',
      score: readiness.interviewScore,
      status: readiness.componentMetadata.interview.status,
      label: readiness.componentMetadata.interview.label,
      color: (readiness.interviewScore >= 75 ? 'emerald' : readiness.interviewScore >= 50 ? 'blue' : 'amber') as 'emerald' | 'blue' | 'amber',
      link: '/app/interview-prep'
    }
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/dashboard" />
      </div>

      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-600 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              Recruitment Preparedness
            </span>
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            Placement Readiness Evaluation
          </h2>
          <p className="text-xs text-slate-500">
            A weighted single-score metric integrating resume quality, test scores, mock interviews, and project artifacts.
          </p>
        </div>

        <span className="text-2xs font-mono font-medium text-slate-500 bg-white border border-slate-200 px-3 py-1.5 rounded-lg">
          Target: <strong>{user.targetRole} (80%+ Goal)</strong>
        </span>
      </div>

      {/* Main Readiness Gauge Hero Banner */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-6 sm:p-8 shadow-xs">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          {/* Big Score Gauge */}
          <div className="md:col-span-4 text-center border-b md:border-b-0 md:border-r border-slate-100 pb-6 md:pb-0 md:pr-6 space-y-3">
            <span className="text-2xs font-bold uppercase tracking-wider text-slate-400">
              Overall Readiness
            </span>
            <div className="relative w-36 h-36 mx-auto flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                <path
                  className="text-slate-100"
                  strokeWidth="3.5"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
                <path
                  className={readiness.overallScore >= 75 ? 'text-emerald-600' : readiness.overallScore >= 50 ? 'text-blue-600' : 'text-amber-500'}
                  strokeDasharray={`${readiness.overallScore}, 100`}
                  strokeWidth="3.5"
                  strokeLinecap="round"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-4xl font-mono font-extrabold text-slate-900 tabular-nums">
                  {readiness.overallScore}%
                </span>
                <span className={`text-3xs font-bold uppercase ${
                  readiness.status === 'Placement Ready' ? 'text-emerald-600' :
                  readiness.status === 'Competitive' ? 'text-blue-600' :
                  readiness.status === 'Developing' ? 'text-indigo-600' : 'text-amber-600'
                }`}>
                  {readiness.status}
                </span>
              </div>
            </div>
            <p className="text-2xs text-slate-500 max-w-xs mx-auto">
              Based on your verified profile evidence across technical benchmarks, projects, resume, and interviews.
            </p>
          </div>

          {/* Breakdown Pillars */}
          <div className="md:col-span-8 space-y-3.5">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Multi-Dimensional Score Breakdown
            </h3>
            {readinessBreakdown.map((item) => (
              <div
                key={item.title}
                onClick={() => navigate(item.link)}
                className="space-y-1 cursor-pointer group"
              >
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-slate-800 group-hover:text-blue-600 transition-colors">
                    {item.title}
                  </span>
                  <div className="flex items-center gap-2">
                    {item.status === 'not_attempted' ? (
                      <span className="text-3xs font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-500 border border-slate-200">
                        Not Yet Attempted
                      </span>
                    ) : (
                      <span className="font-mono font-bold text-slate-900">{item.score}%</span>
                    )}
                  </div>
                </div>
                <ProgressBar
                  value={item.status === 'not_attempted' ? 0 : item.score}
                  size="sm"
                  color={item.color}
                  showValueText={false}
                />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ML-Based Placement Readiness & Verification Panel */}
      <MLPlacementReadinessSection />

      {/* Strengths & Improvement Areas */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-emerald-700 font-bold text-xs">
            <CheckCircle2 className="w-4 h-4" />
            <span>Strong Competencies (Ready for Technical Rounds)</span>
          </div>
          {readiness.strengths.length > 0 ? (
            <ul className="text-xs text-slate-700 space-y-2">
              {readiness.strengths.map((s, idx) => (
                <li key={idx} className="flex items-center justify-between p-2.5 rounded-lg bg-emerald-50/50 border border-emerald-100">
                  <span className="font-semibold">{s.title}</span>
                  {typeof s.score === 'number' && (
                    <span className="font-mono text-emerald-800 font-bold">{s.score}%</span>
                  )}
                </li>
              ))}
            </ul>
          ) : (
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-500">
              No verified competencies recorded yet. Complete skill tests, upload a resume, or complete mock interviews to establish verified strengths.
            </div>
          )}
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-amber-700 font-bold text-xs">
            <AlertCircle className="w-4 h-4" />
            <span>Improvement Areas (Prioritize Before Final Drives)</span>
          </div>
          {readiness.improvementAreas.length > 0 ? (
            <ul className="text-xs text-slate-700 space-y-2">
              {readiness.improvementAreas.map((area, idx) => (
                <li key={idx} className="flex items-center justify-between p-2.5 rounded-lg bg-amber-50/50 border border-amber-200/60">
                  <div className="overflow-hidden pr-2">
                    <span className="font-semibold block truncate">{area.title}</span>
                    <span className="text-3xs text-slate-500 block truncate">{area.description}</span>
                  </div>
                  <span className="text-3xs font-bold uppercase text-amber-800 bg-amber-100/70 px-2 py-0.5 rounded shrink-0">
                    {area.priority || 'Priority'}
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-500">
              All core benchmark requirements verified for {user.targetRole}.
            </div>
          )}
        </div>
      </div>

      {/* Recommended Next Actions */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-6 sm:p-8 shadow-xs space-y-5">
        <div>
          <h3 className="text-base font-bold text-slate-900 tracking-tight">
            Recommended Next Actions to Hit 80%+ Readiness
          </h3>
          <p className="text-xs text-slate-500">
            Completing these actions will bridge key gaps and maximize your shortlist conversion rates.
          </p>
        </div>

        <div className="space-y-3">
          {readiness.recommendedActions.map((action, idx) => (
            <div
              key={idx}
              onClick={() => navigate(action.link)}
              className="p-4 rounded-xl border border-slate-200 hover:border-blue-300 hover:bg-slate-50/70 transition-all cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3"
            >
              <div className="space-y-0.5">
                <span className="text-3xs font-bold uppercase tracking-wider text-slate-400">
                  {action.category}
                </span>
                <h4 className="text-xs sm:text-sm font-bold text-slate-900">{action.title}</h4>
              </div>

              <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0">
                <span className="text-2xs font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  {action.impact}
                </span>
                <span className="text-xs font-semibold text-blue-600 flex items-center gap-1">
                  <span>Start Action</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
