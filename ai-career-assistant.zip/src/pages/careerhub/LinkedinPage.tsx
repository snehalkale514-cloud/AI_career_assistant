import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Share2,
  Sparkles,
  Copy,
  Check,
  Send,
  ExternalLink,
  ThumbsUp,
  MessageSquare,
  Award,
  Layers,
  RefreshCw,
  ShieldCheck,
  ShieldAlert,
  Settings,
  Clock,
  History,
  CheckCircle2,
  AlertCircle,
  FileCheck,
  TrendingUp,
  BrainCircuit,
  GitBranch,
  BookOpen,
  Trash2,
  Edit2,
  Eye,
  Sliders,
  Lock
} from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';
import { Badge } from '../../components/common/Badge.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';
import { StatCard } from '../../components/common/StatCard.tsx';
import { linkedinService } from '../../services/linkedin.ts';
import { CareerProgressEvent, LinkedInPostItem } from '../../types.ts';

export const LinkedinPage: React.FC = () => {
  const navigate = useNavigate();
  const {
    user,
    linkedinPosts,
    linkedInSettings,
    updateLinkedInSettings,
    connectLinkedInAccount,
    disconnectLinkedInAccount,
    progressEvents,
    certificates,
    createLinkedInDraftFromProgress,
    createLinkedInDraftFromCertificate,
    publishLinkedInPost,
    publishLinkedInPostById,
    updateLinkedInPost,
    deleteLinkedInPost
  } = useCareer();

  // Active Main Tab
  const [activeTab, setActiveTab] = useState<'studio' | 'milestones' | 'history' | 'settings'>('studio');

  // Generator & Studio States
  const [activePostId, setActivePostId] = useState<string | null>(null);
  const [currentTone, setCurrentTone] = useState<'Professional' | 'Enthusiastic' | 'Learning journey' | 'Concise'>(
    linkedInSettings.defaultTone || 'Professional'
  );
  const [includeHashtags, setIncludeHashtags] = useState<boolean>(linkedInSettings.includeHashtags ?? true);
  const [includeMetrics, setIncludeMetrics] = useState<boolean>(linkedInSettings.includeMetricsByDefault ?? true);
  const [includeCredentialUrl, setIncludeCredentialUrl] = useState<boolean>(linkedInSettings.includeCredentialUrls ?? true);

  const [postDraftText, setPostDraftText] = useState<string>(() => {
    return linkedinPosts[0]?.content ||
      `🚀 Excited to share my latest placement preparation progress at VPKBIET!\n\nDeepened technical mastery across Python problem sets, advanced SQL relational query design, and business dashboard architecture.\n\n#DataAnalytics #ContinuousLearning #VPKBIET`;
  });
  const [postDraftTitle, setPostDraftTitle] = useState<string>(() => linkedinPosts[0]?.title || 'Placement Preparation Progress');
  const [copied, setCopied] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);
  const [publishSuccessNotice, setPublishSuccessNotice] = useState<string | null>(null);

  // Filter progress events
  const meaningfulEvents = progressEvents.filter((e) => e.isMeaningful);

  // Switch to drafting a specific progress milestone
  const handleDraftFromEvent = (event: CareerProgressEvent) => {
    setActiveTab('studio');
    setPublishSuccessNotice(null);
    const draft = createLinkedInDraftFromProgress(event.id);
    setActivePostId(draft.id);
    setPostDraftTitle(draft.title);
    setPostDraftText(draft.content);
    setCurrentTone(draft.tone || linkedInSettings.defaultTone || 'Professional');
  };

  // Switch to drafting a specific certificate
  const handleDraftFromCert = (certId: string) => {
    setActiveTab('studio');
    setPublishSuccessNotice(null);
    const draft = createLinkedInDraftFromCertificate(certId);
    setActivePostId(draft.id);
    setPostDraftTitle(draft.title);
    setPostDraftText(draft.content);
    setCurrentTone(draft.tone || linkedInSettings.defaultTone || 'Professional');
  };

  // Regenerate post using current tone & settings
  const handleRegeneratePost = (toneToUse = currentTone) => {
    setCurrentTone(toneToUse);
    setPublishSuccessNotice(null);

    // If linked to active post or event
    const activePost = linkedinPosts.find((p) => p.id === activePostId);
    if (activePost?.certificateId) {
      const cert = certificates.find((c) => c.id === activePost.certificateId);
      if (cert) {
        const gen = linkedinService.generatePostFromCertificate(cert, {
          tone: toneToUse,
          includeHashtags,
          includeCredentialUrl
        });
        setPostDraftTitle(gen.title);
        setPostDraftText(gen.content);
        return;
      }
    }

    if (activePost?.progressEventId) {
      const ev = progressEvents.find((e) => e.id === activePost.progressEventId);
      if (ev) {
        const gen = linkedinService.generatePostFromProgress(ev, {
          tone: toneToUse,
          includeHashtags,
          includeMetrics
        });
        setPostDraftTitle(gen.title);
        setPostDraftText(gen.content);
        return;
      }
    }

    // Default template regeneration based on tone
    let title = postDraftTitle;
    let hook = '';
    let body = '';

    if (toneToUse === 'Enthusiastic') {
      hook = `🌟 Thrilled to share my latest placement preparation journey at VPKBIET! 🚀`;
      body = `Every single technical sprint brings new insights. Over the past month, I have strengthened my core engineering skills in Python, SQL window functions, and interactive dashboarding.\n\nEager to apply these skills in upcoming real-world data and software engineering internships!`;
    } else if (toneToUse === 'Learning journey') {
      hook = `🌱 Reflecting on steady engineering growth and placement milestones:`;
      body = `One of the most rewarding aspects of engineering is seeing deliberate practice convert into verified competence. By diagnosing weak areas through benchmark testing and building hands-on projects, I am continuing to build depth across data analytics and machine learning.`;
    } else if (toneToUse === 'Concise') {
      hook = `Technical Progress Update: Data Analytics & Placement Readiness.`;
      body = `Key Focus Areas:\n• Python container algorithms & OOP design\n• Relational query optimization & star schemas\n• Real-world portfolio architecture`;
    } else {
      hook = `📈 Delighted to share an update on my technical learning and career preparation:`;
      body = `As a BTech AI & Data Science candidate at VPKBIET, I am systematically preparing for campus drives and summer internships. Consistent hands-on problem solving, verified assessments, and portfolio projects continue to anchor my career readiness.`;
    }

    const tags = includeHashtags ? '\n\n#DataAnalytics #CareerGrowth #LearningInPublic #VPKBIET' : '';
    setPostDraftText(`${hook}\n\n${body}${tags}`);
  };

  // Copy post text
  const handleCopyPost = () => {
    navigator.clipboard?.writeText(postDraftText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Save current draft
  const handleSaveDraft = () => {
    if (activePostId) {
      updateLinkedInPost(activePostId, {
        title: postDraftTitle,
        content: postDraftText,
        tone: currentTone,
        status: 'Draft'
      });
    } else {
      const newDraft = publishLinkedInPost({
        title: postDraftTitle,
        hook: postDraftText.split('\n')[0] || postDraftTitle,
        content: postDraftText,
        hashtags: postDraftText.match(/#[a-zA-Z0-9_]+/g) || ['#CareerGrowth'],
        postType: 'General',
        status: 'Draft',
        tone: currentTone
      });
      setActivePostId(newDraft.id);
    }
    setPublishSuccessNotice('Post draft saved successfully in your LinkedIn Post History.');
  };

  // Publish to LinkedIn
  const handlePublish = async () => {
    setIsPublishing(true);
    setPublishSuccessNotice(null);

    setTimeout(() => {
      let publishedPost: LinkedInPostItem;
      if (activePostId) {
        publishLinkedInPostById(activePostId);
        updateLinkedInPost(activePostId, {
          title: postDraftTitle,
          content: postDraftText,
          status: 'Published',
          publishedUrl: `https://www.linkedin.com/feed/update/urn:li:activity:${Date.now()}/`
        });
      } else {
        publishedPost = publishLinkedInPost({
          title: postDraftTitle,
          hook: postDraftText.split('\n')[0] || postDraftTitle,
          content: postDraftText,
          hashtags: postDraftText.match(/#[a-zA-Z0-9_]+/g) || ['#CareerGrowth'],
          postType: 'General',
          status: 'Published',
          publishedUrl: `https://www.linkedin.com/feed/update/urn:li:activity:${Date.now()}/`,
          tone: currentTone
        });
        setActivePostId(publishedPost.id);
      }

      setIsPublishing(false);
      setPublishSuccessNotice('Post published to LinkedIn! Live feed activity created and verified in post history.');
    }, 600);
  };

  const totalLikes = linkedinPosts.reduce((acc, p) => acc + (p.likes || 0), 0);
  const totalComments = linkedinPosts.reduce((acc, p) => acc + (p.comments || 0), 0);
  const publishedPosts = linkedinPosts.filter((p) => p.status === 'Published');
  const draftPosts = linkedinPosts.filter((p) => p.status === 'Draft');

  return (
    <div className="space-y-7 max-w-7xl mx-auto">
      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/career-hub" />
      </div>

      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200/60 mb-2">
            <Share2 className="w-3.5 h-3.5 text-blue-600" />
            <span>Verifiable Social Proof &amp; Recruiter Presence</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            LinkedIn Career Progress Studio
          </h1>
          <p className="text-sm text-slate-600 mt-1 max-w-2xl">
            Turn verified assessment score jumps, milestone completions, certifications, and GitHub repositories into authentic, professional LinkedIn updates without exaggeration.
          </p>
        </div>

        {/* OAuth Connection Status Chip */}
        <div className="flex items-center gap-3">
          <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-semibold ${
            linkedInSettings.isConnected
              ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
              : 'bg-amber-50 text-amber-800 border-amber-200'
          }`}>
            <span className={`w-2 h-2 rounded-full ${linkedInSettings.isConnected ? 'bg-emerald-500' : 'bg-amber-500'}`} />
            <span>{linkedInSettings.isConnected ? `Connected: ${user.name}` : 'Not Connected'}</span>
          </div>

          <button
            onClick={() => setActiveTab('settings')}
            className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl border border-slate-200 transition-colors cursor-pointer"
            title="LinkedIn Integration Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Detected Milestones"
          value={meaningfulEvents.length}
          subtext={`${meaningfulEvents.filter((e) => e.linkedInStatus === 'Draft Ready').length} ready for review`}
          icon={TrendingUp}
          trend={{ value: 'Real student events', isPositive: true }}
          onClick={() => setActiveTab('milestones')}
        />
        <StatCard
          title="Published Posts"
          value={publishedPosts.length}
          subtext={`${draftPosts.length} drafts saved`}
          icon={Share2}
          trend={{ value: '+1 this week', isPositive: true }}
          onClick={() => setActiveTab('history')}
        />
        <StatCard
          title="Total Engagements"
          value={`${totalLikes} Likes`}
          subtext={`${totalComments} peer & recruiter comments`}
          icon={ThumbsUp}
          trend={{ value: 'Top 5% student voice', isPositive: true }}
        />
        <StatCard
          title="Auto-Post Security"
          value={linkedInSettings.autoPublishApprovedProgress ? 'Auto-Publish' : 'Ask Before Post'}
          subtext={linkedInSettings.autoPublishApprovedProgress ? 'Approved progress auto-shares' : 'Explicit user consent required'}
          icon={ShieldCheck}
          trend={{ value: 'Zero fake claims', isPositive: true }}
          onClick={() => setActiveTab('settings')}
        />
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('studio')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
            activeTab === 'studio'
              ? 'bg-blue-600 text-white shadow-2xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Post Studio &amp; Generator</span>
        </button>

        <button
          onClick={() => setActiveTab('milestones')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
            activeTab === 'milestones'
              ? 'bg-blue-600 text-white shadow-2xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>Detected Progress Events</span>
          {meaningfulEvents.filter((e) => e.linkedInStatus === 'Draft Ready').length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full text-3xs font-mono bg-blue-100 text-blue-800">
              {meaningfulEvents.filter((e) => e.linkedInStatus === 'Draft Ready').length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('history')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
            activeTab === 'history'
              ? 'bg-blue-600 text-white shadow-2xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <History className="w-4 h-4" />
          <span>Post History ({linkedinPosts.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
            activeTab === 'settings'
              ? 'bg-blue-600 text-white shadow-2xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Sliders className="w-4 h-4" />
          <span>Account &amp; Security Settings</span>
        </button>
      </div>

      {/* Success Notification Banner */}
      {publishSuccessNotice && (
        <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 flex items-center justify-between text-xs text-emerald-900">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{publishSuccessNotice}</span>
          </div>
          <button
            onClick={() => setPublishSuccessNotice(null)}
            className="text-emerald-700 hover:text-emerald-900 font-bold p-1 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* TAB 1: STUDIO & GENERATOR */}
      {activeTab === 'studio' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-7">
          {/* Left Column: Post Composer (7 cols) */}
          <div className="lg:col-span-7 space-y-5">
            {/* Tone Selector */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3 shadow-2xs">
              <div className="flex items-center justify-between">
                <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  1. Post Tone
                </h2>
                <span className="text-2xs text-slate-500">Adapts style &amp; professional reflections</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {(['Professional', 'Enthusiastic', 'Learning journey', 'Concise'] as const).map((tone) => (
                  <button
                    key={tone}
                    type="button"
                    onClick={() => handleRegeneratePost(tone)}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                      currentTone === tone
                        ? 'border-blue-600 bg-blue-50/50 text-blue-900 font-bold shadow-2xs'
                        : 'border-slate-200 hover:border-slate-300 bg-white text-slate-700 font-medium'
                    }`}
                  >
                    <span className="text-xs block">{tone}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Customization Controls */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-2xs">
              <div className="flex items-center justify-between">
                <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  2. Customize Post Elements
                </h2>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleRegeneratePost()}
                    className="text-xs font-semibold text-blue-600 hover:text-blue-700 inline-flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Regenerate Post</span>
                  </button>
                </div>
              </div>

              {/* Toggles */}
              <div className="flex flex-wrap items-center gap-4 text-xs pt-1 border-b border-slate-100 pb-3">
                <label className="flex items-center gap-2 cursor-pointer text-slate-700 font-medium">
                  <input
                    type="checkbox"
                    checked={includeHashtags}
                    onChange={(e) => {
                      setIncludeHashtags(e.target.checked);
                      setTimeout(() => handleRegeneratePost(), 50);
                    }}
                    className="rounded text-blue-600 focus:ring-blue-500 h-4 w-4 border-slate-300"
                  />
                  <span>Include Hashtags</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-slate-700 font-medium">
                  <input
                    type="checkbox"
                    checked={includeMetrics}
                    onChange={(e) => {
                      setIncludeMetrics(e.target.checked);
                      setTimeout(() => handleRegeneratePost(), 50);
                    }}
                    className="rounded text-blue-600 focus:ring-blue-500 h-4 w-4 border-slate-300"
                  />
                  <span>Include Exact Scores / Metrics</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-slate-700 font-medium">
                  <input
                    type="checkbox"
                    checked={includeCredentialUrl}
                    onChange={(e) => {
                      setIncludeCredentialUrl(e.target.checked);
                      setTimeout(() => handleRegeneratePost(), 50);
                    }}
                    className="rounded text-blue-600 focus:ring-blue-500 h-4 w-4 border-slate-300"
                  />
                  <span>Include Verification Link</span>
                </label>
              </div>

              {/* Post Title */}
              <div className="space-y-1">
                <label className="text-2xs font-semibold text-slate-600">Post Title / Activity Summary</label>
                <input
                  type="text"
                  value={postDraftTitle}
                  onChange={(e) => setPostDraftTitle(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-semibold text-slate-800 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* Post Content */}
              <div className="space-y-1">
                <label className="text-2xs font-semibold text-slate-600">Post Body (Full Editability)</label>
                <textarea
                  rows={9}
                  value={postDraftText}
                  onChange={(e) => setPostDraftText(e.target.value)}
                  className="w-full p-3.5 text-xs text-slate-800 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 leading-relaxed font-sans"
                />
              </div>

              {/* Character Count & Action Buttons */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-2">
                <span className="text-2xs text-slate-400">
                  {postDraftText.length} characters • Grounded in authentic records only
                </span>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={handleCopyPost}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl transition-colors cursor-pointer"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied!' : 'Copy Text'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleSaveDraft}
                    className="px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                  >
                    Save Draft
                  </button>

                  <button
                    type="button"
                    disabled={isPublishing}
                    onClick={handlePublish}
                    className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors cursor-pointer disabled:opacity-50"
                  >
                    {isPublishing ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Publishing...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-3.5 h-3.5" />
                        <span>Publish to LinkedIn</span>
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const shareUrl = linkedinService.getLinkedInShareUrl(postDraftText);
                      window.open(shareUrl, '_blank');
                    }}
                    className="p-2 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-xl border border-blue-200 transition-colors cursor-pointer"
                    title="Open directly in official LinkedIn share window"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Live Feed Simulation (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Live Feed Preview
            </h2>

            <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-md">
              {/* Author header */}
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-blue-700 to-indigo-600 flex items-center justify-center text-white text-xs font-bold shadow-xs">
                  SK
                </div>
                <div>
                  <span className="block text-xs font-bold text-slate-900 leading-tight">
                    {user.name}
                  </span>
                  <span className="block text-2xs text-slate-500 leading-tight">
                    {linkedInSettings.profileHeadline || `Aspiring ${user.targetRole} • ${user.college}`}
                  </span>
                  <span className="block text-3xs text-slate-400">Just now • 🌐</span>
                </div>
              </div>

              {/* Post text */}
              <div className="text-xs text-slate-800 whitespace-pre-line leading-relaxed max-h-96 overflow-y-auto pr-1 font-sans">
                {postDraftText}
              </div>

              {/* Simulated reactions */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-2xs text-slate-500">
                <span className="flex items-center gap-1">
                  <span className="text-blue-600">👍</span>
                  <span className="text-rose-500">❤️</span>
                  <span>You and 38 others</span>
                </span>
                <span>6 comments</span>
              </div>

              <div className="pt-2 border-t border-slate-100 grid grid-cols-3 text-center text-xs text-slate-600 font-medium">
                <div className="flex items-center justify-center gap-1.5 py-1 hover:bg-slate-50 rounded cursor-pointer">
                  <ThumbsUp className="w-3.5 h-3.5" />
                  <span>Like</span>
                </div>
                <div className="flex items-center justify-center gap-1.5 py-1 hover:bg-slate-50 rounded cursor-pointer">
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Comment</span>
                </div>
                <div className="flex items-center justify-center gap-1.5 py-1 hover:bg-slate-50 rounded cursor-pointer">
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Repost</span>
                </div>
              </div>
            </div>

            {/* Quick Tips */}
            <div className="bg-slate-50 rounded-2xl border border-slate-200 p-4 space-y-2 text-2xs text-slate-600">
              <span className="font-bold text-slate-800 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                Anti-Slop &amp; Truthfulness Guarantee
              </span>
              <p>
                Every generated sentence strictly derives from your verified assessment history, course completions, and git commits. No unverified job titles, artificial claims, or exaggerated credentials will ever be generated.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: DETECTED CAREER PROGRESS EVENTS */}
      {activeTab === 'milestones' && (
        <div className="space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                Automatic Career Progress Detection
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                System monitors meaningful events (score improvements &ge; +5%, new verified skills, roadmap stages completed, certificates added). Tiny actions are filtered out.
              </p>
            </div>

            <button
              onClick={() => navigate('/certificates')}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors cursor-pointer shrink-0"
            >
              <FileCheck className="w-4 h-4 text-blue-600" />
              <span>Manage Certificates</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {meaningfulEvents.map((event) => {
              const isPublished = event.linkedInStatus === 'Published';
              return (
                <div
                  key={event.id}
                  className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3.5 shadow-2xs hover:border-slate-300 transition-all flex flex-col justify-between"
                >
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="text-3xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 border border-blue-100">
                          {event.eventType}
                        </span>
                        <span className="text-3xs text-slate-400">{event.date}</span>
                      </div>

                      <Badge
                        variant={isPublished ? 'success' : event.linkedInStatus === 'Draft Ready' ? 'primary' : 'outline'}
                        size="sm"
                      >
                        {event.linkedInStatus}
                      </Badge>
                    </div>

                    <div>
                      <h3 className="text-sm font-bold text-slate-900">{event.title}</h3>
                      <p className="text-xs text-slate-600 mt-1 leading-relaxed">{event.description}</p>
                    </div>

                    {/* Value Badge if available */}
                    {event.delta && (
                      <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 text-2xs font-semibold border border-emerald-200">
                        <span>Score: {event.previousValue} → {event.newValue}</span>
                        <span className="font-bold">({event.delta})</span>
                      </div>
                    )}
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-2xs text-slate-400">
                      {event.relatedSkill ? `Skill: ${event.relatedSkill}` : 'General Milestone'}
                    </span>

                    <button
                      type="button"
                      onClick={() => handleDraftFromEvent(event)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-2xs transition-colors cursor-pointer"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>{isPublished ? 'View Post' : 'Create LinkedIn Post'}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: POST HISTORY */}
      {activeTab === 'history' && (
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900">LinkedIn Post History</h2>
              <p className="text-xs text-slate-500">
                Track all published career updates, review metrics, or resume editing saved drafts.
              </p>
            </div>
            <button
              onClick={() => {
                setActivePostId(null);
                setActiveTab('studio');
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors cursor-pointer shrink-0"
            >
              <Sparkles className="w-4 h-4" />
              <span>Draft New Update</span>
            </button>
          </div>

          <div className="space-y-3">
            {linkedinPosts.map((post) => (
              <div
                key={post.id}
                className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3 shadow-2xs hover:border-slate-300 transition-all"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900">{post.title}</span>
                    <Badge variant={post.status === 'Published' ? 'success' : 'outline'} size="sm">
                      {post.status}
                    </Badge>
                    <span className="text-3xs text-slate-400">• {post.date}</span>
                  </div>

                  <div className="flex items-center gap-3 text-2xs text-slate-500">
                    {post.status === 'Published' && (
                      <>
                        <span>❤️ {post.likes} likes</span>
                        <span>💬 {post.comments} comments</span>
                      </>
                    )}
                    <span className="font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md">
                      {post.postType}
                    </span>
                  </div>
                </div>

                <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed whitespace-pre-line bg-slate-50 p-3 rounded-xl border border-slate-100">
                  {post.content}
                </p>

                <div className="flex items-center justify-between pt-1 text-xs">
                  <div className="flex items-center gap-1 text-2xs text-slate-400">
                    {post.publishedUrl && (
                      <a
                        href={post.publishedUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 text-blue-600 hover:text-blue-800 font-semibold"
                      >
                        <span>View Live on LinkedIn</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setActivePostId(post.id);
                        setPostDraftTitle(post.title);
                        setPostDraftText(post.content);
                        setCurrentTone(post.tone || 'Professional');
                        setActiveTab('studio');
                      }}
                      className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl transition-colors cursor-pointer"
                    >
                      <Edit2 className="w-3 h-3 text-slate-500" />
                      <span>Edit in Studio</span>
                    </button>

                    {post.status === 'Draft' && (
                      <button
                        type="button"
                        onClick={() => {
                          publishLinkedInPostById(post.id);
                        }}
                        className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-2xs transition-colors cursor-pointer"
                      >
                        <Send className="w-3 h-3" />
                        <span>Publish</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => deleteLinkedInPost(post.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                      title="Delete post from history"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: ACCOUNT & SECURITY SETTINGS */}
      {activeTab === 'settings' && (
        <div className="max-w-3xl space-y-6">
          {/* Connection Box */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 shadow-2xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center">
                  <Share2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">LinkedIn Account Connection</h3>
                  <p className="text-2xs text-slate-500">
                    Verified authorization state for recruiter discovery
                  </p>
                </div>
              </div>

              {linkedInSettings.isConnected ? (
                <button
                  type="button"
                  onClick={disconnectLinkedInAccount}
                  className="px-3 py-1.5 text-xs font-semibold text-rose-600 hover:bg-rose-50 border border-rose-200 rounded-xl transition-colors cursor-pointer"
                >
                  Disconnect Profile
                </button>
              ) : (
                <button
                  type="button"
                  onClick={connectLinkedInAccount}
                  className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  Connect LinkedIn
                </button>
              )}
            </div>

            {linkedInSettings.isConnected && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="space-y-1">
                  <span className="text-2xs text-slate-400 font-semibold block">PROFILE NAME</span>
                  <span className="font-bold text-slate-800">{user.name}</span>
                </div>
                <div className="space-y-1">
                  <span className="text-2xs text-slate-400 font-semibold block">PROFILE HEADLINE</span>
                  <span className="text-slate-600">{linkedInSettings.profileHeadline || `Aspiring ${user.targetRole} • ${user.college}`}</span>
                </div>
                <div className="space-y-1">
                  <span className="text-2xs text-slate-400 font-semibold block">LINKEDIN URL</span>
                  <a
                    href={linkedInSettings.profileUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="text-blue-600 hover:underline inline-flex items-center gap-1 font-medium"
                  >
                    <span>{linkedInSettings.profileUrl}</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
                <div className="space-y-1">
                  <span className="text-2xs text-slate-400 font-semibold block">STATUS</span>
                  <span className="text-emerald-700 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Authorized for Social Proof
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Privacy & Auto-Publish Guardrails */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 shadow-2xs">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-blue-600" />
                Posting Authorization Mode
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Per career assistant protocol, no post is published automatically without your explicit consent unless you activate auto-post mode.
              </p>
            </div>

            <div className="space-y-3">
              <label
                onClick={() => updateLinkedInSettings({ autoPublishApprovedProgress: false, postingPreference: 'ask_before_post' })}
                className={`p-4 rounded-xl border flex items-start gap-3 cursor-pointer transition-all ${
                  !linkedInSettings.autoPublishApprovedProgress
                    ? 'border-blue-600 bg-blue-50/40 text-blue-900'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <input
                  type="radio"
                  name="autoPostMode"
                  checked={!linkedInSettings.autoPublishApprovedProgress}
                  onChange={() => updateLinkedInSettings({ autoPublishApprovedProgress: false, postingPreference: 'ask_before_post' })}
                  className="mt-0.5 text-blue-600"
                />
                <div className="space-y-1">
                  <span className="text-xs font-bold block">
                    Ask me before every post (Recommended &amp; Default)
                  </span>
                  <p className="text-2xs text-slate-500">
                    When meaningful progress is detected, a post draft will be saved in your Post Studio. You can preview, edit, change tone, and approve publication manually.
                  </p>
                </div>
              </label>

              <label
                onClick={() => updateLinkedInSettings({ autoPublishApprovedProgress: true, postingPreference: 'auto_publish_approved' })}
                className={`p-4 rounded-xl border flex items-start gap-3 cursor-pointer transition-all ${
                  linkedInSettings.autoPublishApprovedProgress
                    ? 'border-blue-600 bg-blue-50/40 text-blue-900'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <input
                  type="radio"
                  name="autoPostMode"
                  checked={linkedInSettings.autoPublishApprovedProgress}
                  onChange={() => updateLinkedInSettings({ autoPublishApprovedProgress: true, postingPreference: 'auto_publish_approved' })}
                  className="mt-0.5 text-blue-600"
                />
                <div className="space-y-1">
                  <span className="text-xs font-bold block">
                    Auto-post approved progress
                  </span>
                  <p className="text-2xs text-slate-500">
                    Automatically publishes verified certificate uploads and major assessment milestones to your LinkedIn feed without asking each time.
                  </p>
                </div>
              </label>
            </div>
          </div>

          {/* Progress Events to Monitor */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 shadow-2xs">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Career Milestones to Monitor
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Select which internal activities qualify as candidate milestones for post draft generation:
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              {[
                { type: 'Certificate' as const, label: 'New Certificate Uploaded (Course / Hackathon / Internship)' },
                { type: 'Assessment' as const, label: 'Assessment Score Improvement (e.g. 62% → 78%)' },
                { type: 'Skill' as const, label: 'Skill Successfully Verified (Diagnostic passed)' },
                { type: 'Roadmap' as const, label: 'Roadmap Milestone Completed (e.g. Python OOP)' },
                { type: 'Project' as const, label: 'Completed Portfolio Project' },
                { type: 'Interview' as const, label: 'Mock Interview Scored &ge; 75%' },
                { type: 'Achievement' as const, label: 'Hackathon & College Achievements' },
                { type: 'GitHub' as const, label: 'GitHub Repository Synced' },
              ].map(({ type, label }) => {
                const isChecked = linkedInSettings.monitoredEventTypes.includes(type);
                return (
                  <label key={type} className="flex items-start gap-2.5 p-2 rounded-lg hover:bg-slate-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={(e) => {
                        const updated = e.target.checked
                          ? [...linkedInSettings.monitoredEventTypes, type]
                          : linkedInSettings.monitoredEventTypes.filter((t) => t !== type);
                        updateLinkedInSettings({ monitoredEventTypes: updated });
                      }}
                      className="mt-0.5 rounded text-blue-600 focus:ring-blue-500 h-4 w-4 border-slate-300"
                    />
                    <span className="text-xs text-slate-700 font-medium leading-tight">{label}</span>
                  </label>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
