import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Sparkles,
  Award,
  GitBranch,
  Share2,
  Globe,
  ArrowRight,
  CheckCircle2,
  ExternalLink,
  Code2,
  Star,
  Eye,
  FileCheck
} from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';
import { StatCard } from '../../components/common/StatCard.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';
import { Badge } from '../../components/common/Badge.tsx';

export const CareerHubPage: React.FC = () => {
  const navigate = useNavigate();
  const { user, achievements, githubProjects, linkedinPosts, certificates } = useCareer();

  const publicAchievements = achievements.filter((a) => a.visibility === 'Public');
  const totalStars = githubProjects.reduce((acc, p) => acc + p.stars, 0);
  const totalLikes = linkedinPosts.reduce((acc, p) => acc + (p.likes || 0), 0);

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/dashboard" />
      </div>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200/60 mb-2">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            <span>Digital Presence &amp; Verification Hub</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Career Hub
          </h1>
          <p className="text-sm text-slate-600 mt-1 max-w-2xl">
            Unify your verified certifications, GitHub repositories, LinkedIn social proof, and public recruiter portfolio in one command center.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate('/certificates')}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl transition-colors cursor-pointer"
          >
            <FileCheck className="w-4 h-4 text-blue-600" />
            <span>Certificates Vault</span>
          </button>

          <button
            onClick={() => navigate('/portfolio')}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <Globe className="w-4 h-4" />
            <span>View Public Portfolio</span>
          </button>
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Verified Certificates"
          value={certificates.length}
          subtext="Course, intern & hackathons"
          icon={FileCheck}
          trend={{ value: '100% verified', isPositive: true }}
          onClick={() => navigate('/certificates')}
        />
        <StatCard
          title="GitHub Repositories"
          value={githubProjects.length}
          subtext={`${totalStars} total repository stars`}
          icon={GitBranch}
          trend={{ value: 'Synced with @snehalkale', isPositive: true }}
          onClick={() => navigate('/github')}
        />
        <StatCard
          title="LinkedIn Reach"
          value={`${totalLikes} Engagements`}
          subtext={`${linkedinPosts.length} posts generated`}
          icon={Share2}
          trend={{ value: 'Top 5% student voice', isPositive: true }}
          onClick={() => navigate('/linkedin')}
        />
        <StatCard
          title="Verified Achievements"
          value={achievements.length}
          subtext={`${publicAchievements.length} visible to recruiters`}
          icon={Award}
          trend={{ value: 'Portfolio synced', isPositive: true }}
          onClick={() => navigate('/achievements')}
        />
      </div>

      {/* Feature Pillar Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Certificate Manager Card */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-5 hover:border-slate-300 transition-colors shadow-2xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-200/60 flex items-center justify-center text-blue-700">
                <FileCheck className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-900">Certificate Manager</h2>
                <p className="text-xs text-slate-500">Store, preview &amp; draft verified LinkedIn posts</p>
              </div>
            </div>
            <button
              onClick={() => navigate('/certificates')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700 inline-flex items-center gap-1 cursor-pointer"
            >
              <span>Manage all</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {certificates.slice(0, 3).map((cert) => (
              <div
                key={cert.id}
                className="p-3.5 rounded-xl border border-slate-100 bg-slate-50/60 flex items-center justify-between"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900 line-clamp-1">{cert.title}</span>
                    <Badge variant="primary" size="sm">
                      {cert.certificateType}
                    </Badge>
                  </div>
                  <p className="text-2xs text-slate-500">{cert.organization} • {cert.issueDate}</p>
                </div>
                <button
                  type="button"
                  onClick={() => navigate('/certificates')}
                  className="inline-flex items-center gap-1 text-3xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 px-2.5 py-1 rounded-md border border-blue-200 transition-colors cursor-pointer"
                >
                  <Share2 className="w-3 h-3" />
                  <span>Post</span>
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Achievements Section */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-5 hover:border-slate-300 transition-colors shadow-2xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-50 border border-amber-200/60 flex items-center justify-center text-amber-700">
                <Award className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-900">Achievements &amp; Honors</h2>
                <p className="text-xs text-slate-500">Document verifiable proof for placement drives</p>
              </div>
            </div>
            <button
              onClick={() => navigate('/achievements')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700 inline-flex items-center gap-1 cursor-pointer"
            >
              <span>Manage all</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {achievements.slice(0, 3).map((ach) => (
              <div
                key={ach.id}
                className="p-3.5 rounded-xl border border-slate-100 bg-slate-50/60 flex items-center justify-between"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900">{ach.title}</span>
                    <Badge variant="success" size="sm">
                      {ach.category}
                    </Badge>
                  </div>
                  <p className="text-2xs text-slate-500">{ach.organization} • {ach.date}</p>
                </div>
                {ach.inResume && (
                  <span className="inline-flex items-center gap-1 text-3xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                    <FileCheck className="w-3 h-3" />
                    On Resume
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* GitHub Workflows Section */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-5 hover:border-slate-300 transition-colors shadow-2xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-white">
                <GitBranch className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-900">GitHub Repositories</h2>
                <p className="text-xs text-slate-500">Live code commits, README audits &amp; stars</p>
              </div>
            </div>
            <button
              onClick={() => navigate('/github')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700 inline-flex items-center gap-1 cursor-pointer"
            >
              <span>Explore repos</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {githubProjects.slice(0, 3).map((repo) => (
              <div
                key={repo.id}
                className="p-3.5 rounded-xl border border-slate-100 bg-slate-50/60 flex items-center justify-between"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900 font-mono">{repo.repoName}</span>
                    <span className="flex items-center gap-1 text-2xs text-amber-600 font-medium">
                      <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                      {repo.stars}
                    </span>
                  </div>
                  <p className="text-2xs text-slate-500 truncate max-w-xs">{repo.description}</p>
                </div>
                <Badge variant="outline" size="sm">
                  {repo.projectType}
                </Badge>
              </div>
            ))}
          </div>
        </div>

        {/* LinkedIn Growth Section */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-5 hover:border-slate-300 transition-colors shadow-2xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-200/60 flex items-center justify-center text-blue-700">
                <Share2 className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-900">LinkedIn Post Studio</h2>
                <p className="text-xs text-slate-500">Turn student achievements into high-engagement career updates</p>
              </div>
            </div>
            <button
              onClick={() => navigate('/linkedin')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700 inline-flex items-center gap-1 cursor-pointer"
            >
              <span>Draft post</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="p-4 rounded-xl bg-gradient-to-br from-blue-50/60 to-indigo-50/40 border border-blue-100 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-blue-900">Latest Viral Post</span>
              <Badge variant="primary" size="sm">Published</Badge>
            </div>
            <p className="text-xs text-slate-700 italic">
              "{linkedinPosts[0]?.hook || 'Delighted to share my latest data analytics project!'}"
            </p>
            <div className="flex items-center gap-4 text-2xs text-slate-500 pt-1">
              <span>❤️ {linkedinPosts[0]?.likes || 64} likes</span>
              <span>💬 {linkedinPosts[0]?.comments || 12} comments</span>
              <span>📅 {linkedinPosts[0]?.date || 'Recent'}</span>
            </div>
          </div>
        </div>

        {/* Public Portfolio Preview Card */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-5 hover:border-slate-300 transition-colors shadow-2xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200/60 flex items-center justify-center text-emerald-700">
                <Globe className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-900">Public Portfolio Link</h2>
                <p className="text-xs text-slate-500">Shareable recruiter landing page with your profile and projects</p>
              </div>
            </div>
            <button
              onClick={() => navigate('/portfolio')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700 inline-flex items-center gap-1 cursor-pointer"
            >
              <span>Open live</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-slate-700 font-semibold truncate">
                career.ai/{user.name.toLowerCase().replace(/\s+/g, '')}
              </span>
              <button
                onClick={() => {
                  navigator.clipboard?.writeText(window.location.origin + '/portfolio');
                }}
                className="text-2xs font-semibold text-blue-600 hover:text-blue-700 cursor-pointer"
              >
                Copy Link
              </button>
            </div>
            <p className="text-xs text-slate-600">
              Includes {user.name}’s academic credentials at {user.college}, resume score ({user.resumeScore}%), top technical skills, and featured repositories.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
