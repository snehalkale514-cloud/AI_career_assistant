import React, { useState } from 'react';
import {
  Globe,
  Mail,
  Phone,
  MapPin,
  ExternalLink,
  GitBranch,
  Star,
  Award,
  Sparkles,
  FileCheck2,
  Share2,
  Copy,
  Check,
  CheckCircle2
} from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';
import { Badge } from '../../components/common/Badge.tsx';

export const PortfolioPage: React.FC = () => {
  const { user, skills, achievements, githubProjects, projects } = useCareer();
  const [copied, setCopied] = useState(false);

  const portfolioAchievements = achievements.filter((a) => a.inPortfolio);
  const portfolioRepos = githubProjects.filter((p) => p.inPortfolio);

  const handleCopyLink = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/career-hub" />
      </div>

      {/* Top Banner Action */}
      <div className="bg-blue-50 border border-blue-200/80 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 text-xs text-blue-900 font-medium">
          <Globe className="w-4 h-4 text-blue-600 shrink-0" />
          <span>This is your live recruiter portfolio preview. Anyone with the link can view your credentials.</span>
        </div>
        <button
          onClick={handleCopyLink}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-700 bg-white border border-blue-200 rounded-lg shadow-2xs hover:bg-blue-50 transition-colors cursor-pointer shrink-0"
        >
          {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
          <span>{copied ? 'Link Copied!' : 'Copy Shareable Link'}</span>
        </button>
      </div>

      {/* Main Portfolio Presentation Card */}
      <div className="bg-white rounded-3xl border border-slate-200 p-8 sm:p-10 shadow-sm space-y-10">
        {/* Profile Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 pb-8 border-b border-slate-100">
          <div className="flex items-center gap-5">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-blue-700 to-indigo-600 flex items-center justify-center text-white text-2xl font-extrabold shadow-md">
              SK
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                  {user.name}
                </h1>
                <span className="inline-flex items-center gap-1 text-2xs font-semibold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                  <CheckCircle2 className="w-3 h-3" />
                  Available for Placements
                </span>
              </div>
              <p className="text-sm font-semibold text-blue-600">
                {user.targetRole} • {user.branch}
              </p>
              <p className="text-xs text-slate-500">
                {user.college} ({user.graduationYear})
              </p>
            </div>
          </div>

          <div className="flex flex-wrap sm:flex-col items-start sm:items-end gap-2 text-xs text-slate-600">
            <span className="flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-slate-400" />
              {user.email}
            </span>
            <span className="flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-slate-400" />
              {user.location}
            </span>
          </div>
        </div>

        {/* Bio / Career Statement */}
        <div className="space-y-2">
          <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Professional Overview
          </h2>
          <p className="text-sm text-slate-700 leading-relaxed max-w-3xl">
            {user.careerGoal || 'BTech AI & Data Science undergraduate passionate about building scalable analytics pipelines, relational data models, and interactive executive reporting dashboards. Committed to data-driven decision making and rapid software engineering cycles.'}
          </p>
        </div>

        {/* Verified Technical Skills */}
        <div className="space-y-3">
          <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Verified Competencies
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {skills.slice(0, 8).map((sk) => (
              <div
                key={sk.id}
                className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between"
              >
                <div>
                  <span className="block text-xs font-bold text-slate-900">{sk.name}</span>
                  <span className="block text-3xs text-slate-500">{sk.category}</span>
                </div>
                <span className="font-mono text-xs font-bold text-blue-600">
                  {sk.currentLevel}%
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Featured Code Projects */}
        <div className="space-y-4">
          <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Featured GitHub Repositories
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {portfolioRepos.map((repo) => (
              <div
                key={repo.id}
                className="p-4 rounded-xl border border-slate-200 hover:border-blue-400 transition-colors bg-white flex flex-col justify-between space-y-3 shadow-2xs"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold font-mono text-slate-900">{repo.repoName}</span>
                    <span className="flex items-center gap-1 text-2xs text-amber-600">
                      <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                      {repo.stars}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1.5 leading-relaxed line-clamp-2">
                    {repo.description}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-2xs">
                  <div className="flex gap-1">
                    {repo.technologies.slice(0, 3).map((t) => (
                      <span key={t} className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 text-3xs font-mono">
                        {t}
                      </span>
                    ))}
                  </div>
                  <a
                    href={repo.url || `https://github.com/snehalkale/${repo.repoName}`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-blue-600 font-semibold hover:underline inline-flex items-center gap-1"
                  >
                    <span>View Code</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Verified Honors & Credentials */}
        <div className="space-y-4">
          <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Certifications &amp; Placement Honors
          </h2>
          <div className="space-y-2.5">
            {portfolioAchievements.map((item) => (
              <div
                key={item.id}
                className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900">{item.title}</span>
                    <Badge variant="success" size="sm">
                      {item.category}
                    </Badge>
                  </div>
                  <p className="text-2xs text-slate-500 mt-0.5">{item.organization} • {item.date}</p>
                </div>
                <span className="inline-flex items-center gap-1 text-2xs text-slate-600 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  Verified Credential
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
