import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Award,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  FileCheck,
  Globe,
  Share2,
  Trash2,
  Sparkles,
  ExternalLink,
  Calendar,
  Building
} from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';
import { Badge } from '../../components/common/Badge.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';
import { Modal } from '../../components/common/Modal.tsx';
import { AchievementItem } from '../../types.ts';

export const AchievementsPage: React.FC = () => {
  const navigate = useNavigate();
  const {
    achievements,
    addAchievement,
    deleteAchievement,
    toggleAchievementInResume,
    toggleAchievementInPortfolio,
  } = useCareer();

  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // New Achievement form state
  const [newTitle, setNewTitle] = useState('');
  const [newOrg, setNewOrg] = useState('');
  const [newCategory, setNewCategory] = useState<AchievementItem['category']>('Certification');
  const [newDate, setNewDate] = useState('October 2026');
  const [newDesc, setNewDesc] = useState('');
  const [newSkills, setNewSkills] = useState('');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const categories = [
    'All',
    'Certification',
    'Internship',
    'Hackathon',
    'Award',
    'Course',
    'College Achievement',
  ];

  const filteredAchievements = achievements.filter((ach) => {
    const matchesSearch =
      ach.title.toLowerCase().includes(search.toLowerCase()) ||
      ach.organization.toLowerCase().includes(search.toLowerCase()) ||
      ach.skillsRelated.some((s) => s.toLowerCase().includes(search.toLowerCase()));
    const matchesCategory = selectedCategory === 'All' || ach.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newOrg.trim()) return;

    addAchievement({
      title: newTitle.trim(),
      organization: newOrg.trim(),
      category: newCategory,
      date: newDate.trim(),
      description: newDesc.trim() || 'Successfully verified placement achievement credential.',
      skillsRelated: newSkills.split(',').map((s) => s.trim()).filter(Boolean),
      visibility: 'Public',
      status: 'Verified',
      inResume: true,
      inPortfolio: true,
      linkedinPosted: false,
    });

    setStatusMessage(`Achievement "${newTitle.trim()}" added to your verified profile!`);
    setTimeout(() => setStatusMessage(null), 3500);

    setIsModalOpen(false);
    setNewTitle('');
    setNewOrg('');
    setNewDesc('');
    setNewSkills('');
  };

  return (
    <div className="space-y-7 max-w-7xl mx-auto">
      {statusMessage && (
        <div className="p-3 text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{statusMessage}</span>
          </div>
          <button onClick={() => setStatusMessage(null)} className="text-emerald-700 cursor-pointer">
            &times;
          </button>
        </div>
      )}

      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/career-hub" />
      </div>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-200/60 mb-2">
            <Award className="w-3.5 h-3.5 text-amber-600" />
            <span>Placement Portfolio Vault</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Achievements &amp; Certifications
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Store your verifiable academic honors, NPTEL scores, hackathon podiums, and virtual internships.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add Achievement</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row gap-3 items-center justify-between bg-white p-3.5 rounded-2xl border border-slate-200 shadow-2xs">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search by title, organization or skill..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto pb-1 md:pb-0">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-blue-600 text-white font-semibold'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Achievements Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredAchievements.map((item) => (
          <div
            key={item.id}
            className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 hover:border-slate-300 transition-all flex flex-col justify-between shadow-2xs group"
          >
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-2">
                <span className="inline-flex items-center gap-1 text-2xs font-semibold px-2 py-0.5 rounded-md bg-amber-50 text-amber-700 border border-amber-200">
                  <Award className="w-3 h-3" />
                  {item.category}
                </span>
                <span className="inline-flex items-center gap-1 text-2xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                  <CheckCircle2 className="w-3 h-3" />
                  Verified
                </span>
              </div>

              <div>
                <h3 className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors leading-snug">
                  {item.title}
                </h3>
                <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                  <span className="font-medium text-slate-700">{item.organization}</span>
                  <span>•</span>
                  <span>{item.date}</span>
                </div>
              </div>

              <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                {item.description}
              </p>

              {item.skillsRelated.length > 0 && (
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {item.skillsRelated.map((skill) => (
                    <span
                      key={skill}
                      className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-3xs font-mono"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Toggles & Controls */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-2xs">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => toggleAchievementInResume(item.id)}
                  className={`inline-flex items-center gap-1 font-semibold px-2 py-1 rounded-md transition-colors cursor-pointer ${
                    item.inResume
                      ? 'bg-blue-50 text-blue-700 border border-blue-200'
                      : 'text-slate-400 hover:text-slate-700'
                  }`}
                  title="Toggle inclusion in ATS Resume"
                >
                  <FileCheck className="w-3.5 h-3.5" />
                  <span>Resume</span>
                </button>

                <button
                  onClick={() => toggleAchievementInPortfolio(item.id)}
                  className={`inline-flex items-center gap-1 font-semibold px-2 py-1 rounded-md transition-colors cursor-pointer ${
                    item.inPortfolio
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      : 'text-slate-400 hover:text-slate-700'
                  }`}
                  title="Toggle inclusion on Public Portfolio"
                >
                  <Globe className="w-3.5 h-3.5" />
                  <span>Portfolio</span>
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => navigate('/linkedin')}
                  className="p-1.5 text-slate-400 hover:text-blue-600 rounded-md hover:bg-slate-100 transition-colors cursor-pointer"
                  title="Generate LinkedIn post from this"
                >
                  <Share2 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => deleteAchievement(item.id)}
                  className="p-1.5 text-slate-400 hover:text-rose-600 rounded-md hover:bg-slate-100 transition-colors cursor-pointer"
                  title="Delete record"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Achievement Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Add Verified Achievement"
        subtitle="Record your certification or competitive placement milestone"
      >
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Achievement / Certification Title *
            </label>
            <input
              type="text"
              required
              placeholder="e.g. NPTEL Python for Data Science (Elite + Gold)"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Issuing Organization *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. IIT Madras / SWAYAM"
                value={newOrg}
                onChange={(e) => setNewOrg(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Category
              </label>
              <select
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value as any)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
              >
                <option value="Certification">Certification</option>
                <option value="Internship">Internship</option>
                <option value="Hackathon">Hackathon</option>
                <option value="Award">Award</option>
                <option value="Course">Course</option>
                <option value="College Achievement">College Achievement</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Issue Date / Period
            </label>
            <input
              type="text"
              placeholder="e.g. September 2026"
              value={newDate}
              onChange={(e) => setNewDate(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Related Skills (comma separated)
            </label>
            <input
              type="text"
              placeholder="e.g. Python, Pandas, Regression, Statistics"
              value={newSkills}
              onChange={(e) => setNewSkills(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Description / Impact
            </label>
            <textarea
              rows={3}
              placeholder="Brief details about your rank, score, or project delivered..."
              value={newDesc}
              onChange={(e) => setNewDesc(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors cursor-pointer"
            >
              Save Achievement
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
