import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  GitBranch,
  Star,
  GitFork,
  ExternalLink,
  Code2,
  RefreshCw,
  Plus,
  Search,
  CheckCircle2,
  Globe,
  Sliders
} from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';
import { Badge } from '../../components/common/Badge.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';

export const GithubPage: React.FC = () => {
  const navigate = useNavigate();
  const { user, githubProjects, updateGitHubProject } = useCareer();
  const [syncing, setSyncing] = useState(false);
  const [search, setSearch] = useState('');

  const handleSync = () => {
    setSyncing(true);
    setTimeout(() => {
      setSyncing(false);
    }, 900);
  };

  const filtered = githubProjects.filter(
    (p) =>
      p.repoName.toLowerCase().includes(search.toLowerCase()) ||
      p.description.toLowerCase().includes(search.toLowerCase()) ||
      p.technologies.some((t) => t.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="space-y-7 max-w-7xl mx-auto">
      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/career-hub" />
      </div>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-800 border border-slate-200 mb-2">
            <GitBranch className="w-3.5 h-3.5 text-slate-700" />
            <span>Developer Code Portfolio</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            GitHub Repositories
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Connected account: <span className="font-mono text-blue-600 font-semibold">@{user.githubUsername || 'snehalkale'}</span>. Repositories showcased to recruiters.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleSync}
            disabled={syncing}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl shadow-2xs transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${syncing ? 'animate-spin text-blue-600' : ''}`} />
            <span>{syncing ? 'Syncing...' : 'Sync GitHub'}</span>
          </button>
        </div>
      </div>

      {/* GitHub Account Stats Banner */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-blue-950 rounded-2xl p-6 text-white flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-md">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center text-white text-xl font-bold font-mono">
            {user.githubUsername?.slice(0, 2).toUpperCase() || 'SK'}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold">{user.name}</h2>
              <span className="text-2xs font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                Connected
              </span>
            </div>
            <p className="text-xs text-slate-300">
              github.com/{user.githubUsername || 'snehalkale'} • BTech AI &amp; Data Science
            </p>
          </div>
        </div>

        <div className="flex items-center gap-6 border-t md:border-t-0 md:border-l border-white/10 pt-4 md:pt-0 md:pl-6 text-xs">
          <div>
            <span className="block text-2xl font-bold font-mono text-white">{githubProjects.length}</span>
            <span className="text-slate-400 text-2xs">Showcased Repos</span>
          </div>
          <div>
            <span className="block text-2xl font-bold font-mono text-amber-400">
              {githubProjects.reduce((a, b) => a + b.stars, 0)}
            </span>
            <span className="text-slate-400 text-2xs">Total Stars</span>
          </div>
          <div>
            <span className="block text-2xl font-bold font-mono text-blue-400">
              {githubProjects.reduce((a, b) => a + b.forks, 0)}
            </span>
            <span className="text-slate-400 text-2xs">Forks</span>
          </div>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative max-w-md">
        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          placeholder="Filter repositories by title, tech stack..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
        />
      </div>

      {/* Repositories Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filtered.map((repo) => (
          <div
            key={repo.id}
            className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 hover:border-slate-300 transition-all shadow-2xs flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <GitBranch className="w-4 h-4 text-slate-700" />
                  <a
                    href={repo.url || `https://github.com/snehalkale/${repo.repoName}`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-sm font-bold text-blue-600 hover:underline font-mono truncate"
                  >
                    {repo.repoName}
                  </a>
                </div>
                <Badge variant="outline" size="sm">
                  {repo.visibility}
                </Badge>
              </div>

              <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                {repo.description}
              </p>

              {/* Technologies */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {repo.technologies.map((t) => (
                  <span
                    key={t}
                    className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-3xs font-mono"
                  >
                    {t}
                  </span>
                ))}
              </div>
            </div>

            {/* Bottom Meta & Portfolio Toggle */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-2xs text-slate-500">
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1 font-mono text-slate-700">
                  <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-400" />
                  {repo.stars}
                </span>
                <span className="flex items-center gap-1 font-mono text-slate-700">
                  <GitFork className="w-3.5 h-3.5 text-slate-400" />
                  {repo.forks}
                </span>
                <span>Updated {repo.lastUpdated}</span>
              </div>

              <button
                onClick={() =>
                  updateGitHubProject(repo.id, { inPortfolio: !repo.inPortfolio })
                }
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-3xs font-semibold transition-colors cursor-pointer ${
                  repo.inPortfolio
                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                <Globe className="w-3 h-3" />
                <span>{repo.inPortfolio ? 'In Portfolio' : 'Add to Portfolio'}</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
