import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  FileCheck,
  Upload,
  Plus,
  Search,
  ExternalLink,
  Award,
  Sparkles,
  Share2,
  Trash2,
  Edit2,
  Eye,
  CheckCircle2,
  Clock,
  Copy,
  Check,
  RefreshCw,
  Send,
  Building,
  Calendar,
  Tag,
  ShieldCheck,
  FileText,
  AlertCircle
} from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';
import { CertificateItem } from '../../types.ts';
import { Badge } from '../../components/common/Badge.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';
import { StatCard } from '../../components/common/StatCard.tsx';
import { linkedinService } from '../../services/linkedin.ts';

export const CertificatesPage: React.FC = () => {
  const navigate = useNavigate();
  const {
    certificates,
    addCertificate,
    updateCertificate,
    deleteCertificate,
    createLinkedInDraftFromCertificate,
    publishLinkedInPost,
    linkedInSettings,
    user
  } = useCareer();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('All');

  // Modal states
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [editingCert, setEditingCert] = useState<CertificateItem | null>(null);
  const [previewingCert, setPreviewingCert] = useState<CertificateItem | null>(null);
  const [postComposerCert, setPostComposerCert] = useState<CertificateItem | null>(null);

  // Upload Form State
  const [formTitle, setFormTitle] = useState('');
  const [formOrg, setFormOrg] = useState('');
  const [formDate, setFormDate] = useState('');
  const [formType, setFormType] = useState<CertificateItem['certificateType']>('Course');
  const [formSkill, setFormSkill] = useState('Python');
  const [formSkillsGained, setFormSkillsGained] = useState('');
  const [formCredentialId, setFormCredentialId] = useState('');
  const [formCredentialUrl, setFormCredentialUrl] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [uploadedFileName, setUploadedFileName] = useState('');
  const [autoDraftPost, setAutoDraftPost] = useState(true);
  const [isExtracting, setIsExtracting] = useState(false);
  const [extractedNotice, setExtractedNotice] = useState<string | null>(null);

  // LinkedIn Composer State
  const [composerTone, setComposerTone] = useState<'Professional' | 'Enthusiastic' | 'Learning journey' | 'Concise'>('Professional');
  const [includeHashtags, setIncludeHashtags] = useState(true);
  const [includeCredentialUrl, setIncludeCredentialUrl] = useState(true);
  const [composerText, setComposerText] = useState('');
  const [composerTitle, setComposerTitle] = useState('');
  const [composerCopied, setComposerCopied] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);
  const [publishSuccessUrl, setPublishSuccessUrl] = useState<string | null>(null);

  // Filtered certificates
  const filteredCertificates = certificates.filter((cert) => {
    const matchesSearch =
      cert.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      cert.organization.toLowerCase().includes(searchQuery.toLowerCase()) ||
      cert.relatedSkill.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedType === 'All' || cert.certificateType === selectedType;
    return matchesSearch && matchesType;
  });

  const certificateTypes: CertificateItem['certificateType'][] = [
    'Course',
    'Internship',
    'Workshop',
    'Hackathon',
    'Training',
    'Professional'
  ];

  // Open Upload modal with defaults
  const handleOpenUpload = () => {
    setEditingCert(null);
    setFormTitle('');
    setFormOrg('');
    setFormDate(new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }));
    setFormType('Course');
    setFormSkill('Python');
    setFormSkillsGained('');
    setFormCredentialId('');
    setFormCredentialUrl('');
    setFormDescription('');
    setUploadedFileName('');
    setExtractedNotice(null);
    setIsUploadModalOpen(true);
  };

  // Open Edit modal
  const handleOpenEdit = (cert: CertificateItem) => {
    setEditingCert(cert);
    setFormTitle(cert.title);
    setFormOrg(cert.organization);
    setFormDate(cert.issueDate);
    setFormType(cert.certificateType);
    setFormSkill(cert.relatedSkill);
    setFormSkillsGained(cert.skillsGained ? cert.skillsGained.join(', ') : '');
    setFormCredentialId(cert.credentialId || '');
    setFormCredentialUrl(cert.credentialUrl || '');
    setFormDescription(cert.description || '');
    setUploadedFileName(cert.certificateFileName || '');
    setExtractedNotice(null);
    setIsUploadModalOpen(true);
  };

  // Simulate file upload and intelligent document extraction
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadedFileName(file.name);
    setIsExtracting(true);

    setTimeout(() => {
      const extracted = linkedinService.extractCertificateDetails(file.name);
      if (extracted.title) setFormTitle(extracted.title);
      if (extracted.organization) setFormOrg(extracted.organization);
      if (extracted.certificateType) setFormType(extracted.certificateType);
      if (extracted.relatedSkill) setFormSkill(extracted.relatedSkill);
      if (extracted.credentialId) setFormCredentialId(extracted.credentialId);
      if (extracted.skillsGained) setFormSkillsGained(extracted.skillsGained.join(', '));
      if (extracted.issueDate) setFormDate(extracted.issueDate);

      setIsExtracting(false);
      setExtractedNotice(`Extracted metadata from "${file.name}": detected ${extracted.organization} ${extracted.certificateType} in ${extracted.relatedSkill}.`);
    }, 450);
  };

  // Save certificate
  const handleSaveCertificate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formOrg.trim()) return;

    const skillsArray = formSkillsGained
      .split(',')
      .map((s) => s.trim())
      .filter((s) => s.length > 0);

    if (editingCert) {
      updateCertificate(editingCert.id, {
        title: formTitle.trim(),
        organization: formOrg.trim(),
        issueDate: formDate.trim() || 'Recent',
        certificateType: formType,
        relatedSkill: formSkill.trim(),
        skillsGained: skillsArray,
        credentialId: formCredentialId.trim() || undefined,
        credentialUrl: formCredentialUrl.trim() || undefined,
        description: formDescription.trim() || undefined,
        certificateFileName: uploadedFileName || editingCert.certificateFileName
      });
      setIsUploadModalOpen(false);
    } else {
      const created = addCertificate({
        title: formTitle.trim(),
        organization: formOrg.trim(),
        issueDate: formDate.trim() || new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
        certificateType: formType,
        relatedSkill: formSkill.trim(),
        skillsGained: skillsArray,
        credentialId: formCredentialId.trim() || undefined,
        credentialUrl: formCredentialUrl.trim() || undefined,
        description: formDescription.trim() || undefined,
        certificateFileName: uploadedFileName || `${formTitle.replace(/\s+/g, '_')}_Certificate.pdf`,
        verificationStatus: 'Verified',
        linkedInPostGenerated: false
      });

      setIsUploadModalOpen(false);

      if (autoDraftPost) {
        handleOpenLinkedInComposer(created);
      }
    }
  };

  // Open LinkedIn Composer for a certificate
  const handleOpenLinkedInComposer = (cert: CertificateItem) => {
    setPostComposerCert(cert);
    setComposerTone(linkedInSettings.defaultTone || 'Professional');
    setIncludeHashtags(linkedInSettings.includeHashtags ?? true);
    setIncludeCredentialUrl(linkedInSettings.includeCredentialUrls ?? true);
    setPublishSuccessUrl(null);

    const generated = linkedinService.generatePostFromCertificate(cert, {
      tone: linkedInSettings.defaultTone || 'Professional',
      includeHashtags: linkedInSettings.includeHashtags ?? true,
      includeCredentialUrl: linkedInSettings.includeCredentialUrls ?? true
    });

    setComposerTitle(generated.title);
    setComposerText(generated.content);
  };

  // Regenerate post in composer with current tone/options
  const handleRegeneratePost = (toneToUse = composerTone) => {
    if (!postComposerCert) return;
    setComposerTone(toneToUse);
    const generated = linkedinService.generatePostFromCertificate(postComposerCert, {
      tone: toneToUse,
      includeHashtags,
      includeCredentialUrl
    });
    setComposerTitle(generated.title);
    setComposerText(generated.content);
  };

  // Copy Composer text
  const handleCopyComposerText = () => {
    navigator.clipboard?.writeText(composerText);
    setComposerCopied(true);
    setTimeout(() => setComposerCopied(false), 2000);
  };

  // Save as Draft
  const handleSaveDraft = () => {
    if (!postComposerCert) return;
    createLinkedInDraftFromCertificate(postComposerCert.id);
    setPostComposerCert(null);
  };

  // Publish to LinkedIn
  const handlePublishToLinkedIn = () => {
    if (!postComposerCert) return;
    setIsPublishing(true);

    setTimeout(() => {
      const publicUrl = `https://www.linkedin.com/feed/update/urn:li:activity:${Date.now()}/`;
      publishLinkedInPost({
        title: composerTitle || `Completed ${postComposerCert.title} Certification`,
        hook: composerText.split('\n')[0] || `Completed ${postComposerCert.title}`,
        content: composerText,
        hashtags: composerText.match(/#[a-zA-Z0-9_]+/g) || ['#ContinuousLearning', '#CareerGrowth'],
        postType: 'Certificate',
        certificateId: postComposerCert.id,
        status: 'Published',
        publishedUrl: publicUrl,
        tone: composerTone,
        includeCredentialUrl,
        includeMetrics: true
      });

      setIsPublishing(false);
      setPublishSuccessUrl(publicUrl);
    }, 600);
  };

  // Distinct skills count
  const distinctSkills = Array.from(new Set(certificates.map((c) => c.relatedSkill)));
  const verifiedCount = certificates.filter((c) => c.verificationStatus === 'Verified').length;
  const postedCount = certificates.filter((c) => c.linkedInPostGenerated).length;

  return (
    <div className="space-y-7 max-w-7xl mx-auto">
      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/career-hub" />
      </div>

      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200/60 mb-2">
            <FileCheck className="w-3.5 h-3.5 text-blue-600" />
            <span>Career Hub Credential Vault</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Certificate Manager
          </h1>
          <p className="text-sm text-slate-600 mt-1 max-w-2xl">
            Store, preview, and authenticate course certifications, internship completions, and hackathon awards. Generate verified LinkedIn posts directly from your credentials.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate('/linkedin')}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl transition-colors cursor-pointer"
          >
            <Share2 className="w-3.5 h-3.5 text-blue-600" />
            <span>LinkedIn Studio</span>
          </button>

          <button
            onClick={handleOpenUpload}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Upload Certificate</span>
          </button>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Certificates"
          value={certificates.length}
          subtext="Course, intern & hackathons"
          icon={FileCheck}
          trend={{ value: '+1 this month', isPositive: true }}
        />
        <StatCard
          title="Verified Credentials"
          value={verifiedCount}
          subtext="Authentic credential IDs"
          icon={ShieldCheck}
          trend={{ value: '100% verified', isPositive: true }}
        />
        <StatCard
          title="Skills Validated"
          value={distinctSkills.length}
          subtext={distinctSkills.slice(0, 3).join(', ')}
          icon={Award}
          trend={{ value: 'Linked to Profile', isPositive: true }}
        />
        <StatCard
          title="LinkedIn Social Proof"
          value={postedCount}
          subtext={`${certificates.length - postedCount} pending social drafts`}
          icon={Share2}
          trend={{ value: `${Math.round((postedCount / (certificates.length || 1)) * 100)}% shared`, isPositive: true }}
          onClick={() => navigate('/linkedin')}
        />
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 space-y-3 shadow-2xs">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search by title, organization, skill..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs text-slate-800 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
            {['All', ...certificateTypes].map((type) => (
              <button
                key={type}
                onClick={() => setSelectedType(type)}
                className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                  selectedType === type
                    ? 'bg-blue-600 text-white shadow-2xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200/80 hover:text-slate-900'
                }`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Certificate Grid */}
      {filteredCertificates.length === 0 ? (
        <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-12 text-center space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto">
            <FileCheck className="w-6 h-6" />
          </div>
          <div className="max-w-md mx-auto space-y-1">
            <h3 className="text-sm font-bold text-slate-900">No certificates found</h3>
            <p className="text-xs text-slate-500">
              {searchQuery || selectedType !== 'All'
                ? 'Try adjusting your search query or filter category.'
                : 'Upload your verified certificates from NPTEL, Coursera, Microsoft, or internships to build social proof.'}
            </p>
          </div>
          <button
            onClick={handleOpenUpload}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Upload Certificate</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredCertificates.map((cert) => (
            <div
              key={cert.id}
              className="bg-white rounded-2xl border border-slate-200 hover:border-slate-300 p-5 space-y-4 shadow-2xs transition-all hover:shadow-xs flex flex-col justify-between"
            >
              <div className="space-y-3">
                {/* Header tag & status */}
                <div className="flex items-center justify-between gap-2">
                  <Badge variant="primary" size="sm">
                    {cert.certificateType}
                  </Badge>
                  <span className="inline-flex items-center gap-1 text-3xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                    <CheckCircle2 className="w-3 h-3" />
                    Verified
                  </span>
                </div>

                {/* Title & Organization */}
                <div>
                  <h3 className="text-sm font-bold text-slate-900 leading-snug line-clamp-2">
                    {cert.title}
                  </h3>
                  <div className="flex items-center gap-1.5 text-xs text-slate-600 font-medium mt-1">
                    <Building className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{cert.organization}</span>
                  </div>
                </div>

                {/* Date & Related Skill */}
                <div className="flex items-center justify-between text-2xs text-slate-500 pt-1 border-t border-slate-100">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-slate-400" />
                    {cert.issueDate}
                  </span>
                  <span className="font-semibold text-blue-700 bg-blue-50/80 px-2 py-0.5 rounded-md border border-blue-100">
                    {cert.relatedSkill}
                  </span>
                </div>

                {/* Skills Gained Tags */}
                {cert.skillsGained && cert.skillsGained.length > 0 && (
                  <div className="flex flex-wrap gap-1 pt-1">
                    {cert.skillsGained.slice(0, 3).map((sk, idx) => (
                      <span
                        key={idx}
                        className="text-3xs font-medium px-2 py-0.5 rounded bg-slate-50 text-slate-600 border border-slate-100 truncate max-w-[130px]"
                      >
                        • {sk}
                      </span>
                    ))}
                    {cert.skillsGained.length > 3 && (
                      <span className="text-3xs font-medium px-1.5 py-0.5 rounded bg-slate-50 text-slate-400">
                        +{cert.skillsGained.length - 3}
                      </span>
                    )}
                  </div>
                )}

                {/* Credential ID / Verification Link */}
                {cert.credentialId && (
                  <div className="text-3xs font-mono text-slate-500 bg-slate-50 p-2 rounded-lg border border-slate-100 truncate">
                    <span className="font-bold text-slate-700">ID:</span> {cert.credentialId}
                  </div>
                )}
              </div>

              {/* Bottom Actions */}
              <div className="pt-3 border-t border-slate-100 space-y-2">
                <button
                  type="button"
                  onClick={() => handleOpenLinkedInComposer(cert)}
                  className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Create LinkedIn Post</span>
                </button>

                <div className="flex items-center justify-between text-2xs">
                  <button
                    type="button"
                    onClick={() => setPreviewingCert(cert)}
                    className="inline-flex items-center gap-1 text-slate-600 hover:text-slate-900 font-medium py-1 px-1.5 rounded hover:bg-slate-50 cursor-pointer"
                  >
                    <Eye className="w-3 h-3 text-slate-500" />
                    <span>Preview</span>
                  </button>

                  {cert.credentialUrl && (
                    <a
                      href={cert.credentialUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1 text-blue-600 hover:text-blue-700 font-medium py-1 px-1.5 rounded hover:bg-blue-50/50"
                    >
                      <span>Verify Link</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => handleOpenEdit(cert)}
                      className="p-1.5 text-slate-400 hover:text-slate-700 rounded hover:bg-slate-50 cursor-pointer"
                      title="Edit certificate details"
                    >
                      <Edit2 className="w-3 h-3" />
                    </button>
                    <button
                      type="button"
                      onClick={() => deleteCertificate(cert.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50 cursor-pointer"
                      title="Delete certificate"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Upload / Edit Certificate Modal */}
      {isUploadModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl border border-slate-200 max-w-xl w-full p-6 sm:p-7 shadow-xl space-y-5 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                  <Upload className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-slate-900">
                    {editingCert ? 'Edit Certificate Details' : 'Upload Verified Certificate'}
                  </h2>
                  <p className="text-2xs text-slate-500">
                    Supports course completions, internship letters, hackathons, and workshops
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsUploadModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-lg font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Simulated OCR File Dropzone */}
            {!editingCert && (
              <div className="border-2 border-dashed border-blue-200 bg-blue-50/40 rounded-2xl p-4 text-center space-y-2">
                <label className="cursor-pointer block space-y-1.5">
                  <Upload className="w-5 h-5 text-blue-600 mx-auto" />
                  <span className="block text-xs font-bold text-blue-900">
                    {uploadedFileName ? `File: ${uploadedFileName}` : 'Choose Certificate PDF or Image'}
                  </span>
                  <span className="block text-3xs text-slate-500">
                    Automatic detail extraction pre-fills course name, issuing org, and credential ID without inventing facts
                  </span>
                  <input
                    type="file"
                    accept=".pdf,.jpg,.jpeg,.png"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
                {isExtracting && (
                  <div className="flex items-center justify-center gap-2 text-2xs text-blue-700 font-semibold pt-1">
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Analyzing certificate document...</span>
                  </div>
                )}
                {extractedNotice && (
                  <div className="p-2.5 bg-emerald-50 rounded-xl border border-emerald-200 text-2xs text-emerald-800 text-left flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{extractedNotice}</span>
                  </div>
                )}
              </div>
            )}

            <form onSubmit={handleSaveCertificate} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1 sm:col-span-2">
                  <label className="font-semibold text-slate-700">Certificate Title *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Python for Data Science & Machine Learning"
                    value={formTitle}
                    onChange={(e) => setFormTitle(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-700">Issuing Organization *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. NPTEL (IIT Madras), Microsoft, Deloitte"
                    value={formOrg}
                    onChange={(e) => setFormOrg(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-700">Completion Date *</label>
                  <input
                    type="text"
                    placeholder="e.g. Sep 15, 2026"
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-700">Certificate Type</label>
                  <select
                    value={formType}
                    onChange={(e) => setFormType(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-blue-500"
                  >
                    {certificateTypes.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-700">Related Profile Skill *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Python, SQL, Power BI, Machine Learning"
                    value={formSkill}
                    onChange={(e) => setFormSkill(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div className="space-y-1 sm:col-span-2">
                  <label className="font-semibold text-slate-700">Skills Gained (comma-separated)</label>
                  <input
                    type="text"
                    placeholder="e.g. Pandas & NumPy, Object-Oriented Programming, Computational Statistics"
                    value={formSkillsGained}
                    onChange={(e) => setFormSkillsGained(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-700">Credential ID (Optional)</label>
                  <input
                    type="text"
                    placeholder="e.g. NPTEL26CS92817291"
                    value={formCredentialId}
                    onChange={(e) => setFormCredentialId(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-blue-500 font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-700">Credential / Verify URL (Optional)</label>
                  <input
                    type="url"
                    placeholder="https://nptel.ac.in/noc/Ecertificate/..."
                    value={formCredentialUrl}
                    onChange={(e) => setFormCredentialUrl(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div className="space-y-1 sm:col-span-2">
                  <label className="font-semibold text-slate-700">Description / Key Learnings (Optional)</label>
                  <textarea
                    rows={2}
                    placeholder="Brief 1-2 sentence overview of the syllabus or practical tasks completed..."
                    value={formDescription}
                    onChange={(e) => setFormDescription(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              {!editingCert && (
                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="checkbox"
                    id="autoDraftPost"
                    checked={autoDraftPost}
                    onChange={(e) => setAutoDraftPost(e.target.checked)}
                    className="rounded text-blue-600 focus:ring-blue-500 h-4 w-4 border-slate-300"
                  />
                  <label htmlFor="autoDraftPost" className="text-xs text-slate-700 cursor-pointer">
                    Open LinkedIn Post Creator immediately after saving
                  </label>
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsUploadModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  {editingCert ? 'Save Changes' : 'Add to Vault'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Preview Certificate Modal */}
      {previewingCert && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl border border-slate-200 max-w-2xl w-full p-6 sm:p-8 shadow-2xl space-y-6 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-600" />
                <h3 className="text-base font-bold text-slate-900">Certificate Credential Preview</h3>
              </div>
              <button
                type="button"
                onClick={() => setPreviewingCert(null)}
                className="text-slate-400 hover:text-slate-600 font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Document visual mockup */}
            <div className="border-4 border-double border-slate-300 bg-gradient-to-br from-amber-50/20 via-white to-blue-50/20 p-8 sm:p-10 rounded-2xl text-center space-y-5 shadow-inner">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-amber-100 text-amber-700 mx-auto">
                <Award className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <span className="text-3xs uppercase tracking-widest text-slate-400 font-bold block">
                  Certificate of Completion &amp; Achievement
                </span>
                <p className="text-xs text-slate-500 italic">This verifiable document certifies that</p>
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                  {user.name}
                </h2>
                <p className="text-xs text-slate-600 font-medium">
                  Candidate at {user.college}
                </p>
              </div>

              <div className="py-2 border-y border-slate-200/80 max-w-md mx-auto space-y-1">
                <p className="text-xs text-slate-500">has successfully completed all requirements for</p>
                <h3 className="text-base font-bold text-blue-900">{previewingCert.title}</h3>
                <p className="text-xs text-slate-600 font-medium">Issued by {previewingCert.organization}</p>
              </div>

              <div className="grid grid-cols-2 gap-4 text-left max-w-md mx-auto text-2xs text-slate-600 pt-2">
                <div>
                  <span className="text-3xs text-slate-400 block font-semibold">ISSUE DATE</span>
                  <span className="font-semibold text-slate-800">{previewingCert.issueDate}</span>
                </div>
                <div>
                  <span className="text-3xs text-slate-400 block font-semibold">VERIFIED SKILL</span>
                  <span className="font-semibold text-blue-700">{previewingCert.relatedSkill}</span>
                </div>
                {previewingCert.credentialId && (
                  <div className="col-span-2">
                    <span className="text-3xs text-slate-400 block font-semibold">CREDENTIAL ID</span>
                    <span className="font-mono text-slate-800 text-3xs">{previewingCert.credentialId}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
              <div className="text-2xs text-slate-500">
                Verified against application profile records
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={() => setPreviewingCert(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 rounded-xl cursor-pointer"
                >
                  Close
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const c = previewingCert;
                    setPreviewingCert(null);
                    handleOpenLinkedInComposer(c);
                  }}
                  className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Create LinkedIn Post</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* LinkedIn Post Composer Modal */}
      {postComposerCert && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl border border-slate-200 max-w-4xl w-full p-6 sm:p-7 shadow-2xl space-y-5 my-8">
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
                  <Share2 className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-slate-900">
                    LinkedIn Post Creator
                  </h2>
                  <p className="text-2xs text-slate-500">
                    Generated strictly from verified certificate: <span className="font-semibold text-slate-700">{postComposerCert.title}</span>
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPostComposerCert(null)}
                className="text-slate-400 hover:text-slate-600 text-lg font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Success Banner if published */}
            {publishSuccessUrl && (
              <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 space-y-2">
                <div className="flex items-center gap-2 text-emerald-900 font-bold text-xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Post Published to LinkedIn!</span>
                </div>
                <p className="text-2xs text-emerald-800">
                  Your certificate post has been recorded in your LinkedIn Post History and published with verified credentials.
                </p>
                <div className="flex items-center gap-2 pt-1">
                  <a
                    href={publishSuccessUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-800 bg-white border border-emerald-300 rounded-lg hover:bg-emerald-50 transition-colors"
                  >
                    <span>View Live Feed Activity</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                  <button
                    type="button"
                    onClick={() => {
                      const shareUrl = linkedinService.getLinkedInShareUrl(composerText, postComposerCert.credentialUrl);
                      window.open(shareUrl, '_blank');
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-2xs transition-colors cursor-pointer"
                  >
                    <span>Open in LinkedIn Web</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left Column: Post Controls & Editor */}
              <div className="lg:col-span-7 space-y-4">
                {/* Tone Selector */}
                <div className="space-y-1.5">
                  <label className="text-2xs font-bold text-slate-700 uppercase tracking-wider block">
                    Select Post Tone
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {(['Professional', 'Enthusiastic', 'Learning journey', 'Concise'] as const).map((tone) => (
                      <button
                        key={tone}
                        type="button"
                        onClick={() => handleRegeneratePost(tone)}
                        className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold border transition-all text-center cursor-pointer ${
                          composerTone === tone
                            ? 'bg-blue-50 text-blue-700 border-blue-300 shadow-2xs'
                            : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100 hover:text-slate-900'
                        }`}
                      >
                        {tone}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Toggles */}
                <div className="flex flex-wrap items-center gap-4 text-xs pt-1">
                  <label className="flex items-center gap-2 cursor-pointer text-slate-700 font-medium">
                    <input
                      type="checkbox"
                      checked={includeHashtags}
                      onChange={(e) => {
                        setIncludeHashtags(e.target.checked);
                        setTimeout(() => handleRegeneratePost(), 50);
                      }}
                      className="rounded text-blue-600 focus:ring-blue-500 h-3.5 w-3.5 border-slate-300"
                    />
                    <span>Include Relevant Hashtags</span>
                  </label>

                  {postComposerCert.credentialUrl && (
                    <label className="flex items-center gap-2 cursor-pointer text-slate-700 font-medium">
                      <input
                        type="checkbox"
                        checked={includeCredentialUrl}
                        onChange={(e) => {
                          setIncludeCredentialUrl(e.target.checked);
                          setTimeout(() => handleRegeneratePost(), 50);
                        }}
                        className="rounded text-blue-600 focus:ring-blue-500 h-3.5 w-3.5 border-slate-300"
                      />
                      <span>Include Credential Link</span>
                    </label>
                  )}
                </div>

                {/* Editable Text Area */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-2xs font-bold text-slate-700 uppercase tracking-wider">
                      Editable Post Copy
                    </label>
                    <button
                      type="button"
                      onClick={() => handleRegeneratePost()}
                      className="text-2xs font-semibold text-blue-600 hover:text-blue-700 inline-flex items-center gap-1 cursor-pointer"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>Regenerate Draft</span>
                    </button>
                  </div>
                  <textarea
                    rows={10}
                    value={composerText}
                    onChange={(e) => setComposerText(e.target.value)}
                    className="w-full p-3.5 text-xs text-slate-800 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:border-blue-500 leading-relaxed font-sans"
                  />
                  <div className="flex items-center justify-between text-3xs text-slate-400">
                    <span>{composerText.length} characters</span>
                    <span>Contains authentic course data only</span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={handleCopyComposerText}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl transition-colors cursor-pointer"
                  >
                    {composerCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{composerCopied ? 'Copied to Clipboard' : 'Copy Text'}</span>
                  </button>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleSaveDraft}
                      className="px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                    >
                      Save as Draft
                    </button>

                    <button
                      type="button"
                      disabled={isPublishing}
                      onClick={handlePublishToLinkedIn}
                      className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors cursor-pointer disabled:opacity-50"
                    >
                      {isPublishing ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          <span>Publishing...</span>
                        </>
                      ) : (
                        <>
                          <Send className="w-3.5 h-3.5" />
                          <span>Publish to LinkedIn</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>

              {/* Right Column: Live Feed Simulation */}
              <div className="lg:col-span-5 space-y-3">
                <span className="text-2xs font-bold text-slate-700 uppercase tracking-wider block">
                  Live LinkedIn Feed Preview
                </span>

                <div className="bg-white rounded-2xl border border-slate-200 p-4 space-y-3 shadow-md text-xs">
                  {/* Author Header */}
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-blue-700 to-indigo-600 flex items-center justify-center text-white text-xs font-bold shadow-xs">
                      SK
                    </div>
                    <div>
                      <div className="font-bold text-slate-900 leading-tight">
                        {user.name}
                      </div>
                      <div className="text-3xs text-slate-500 leading-tight">
                        {linkedInSettings.profileHeadline || `Aspiring ${user.targetRole} • ${user.college}`}
                      </div>
                      <div className="text-3xs text-slate-400">Just now • 🌐</div>
                    </div>
                  </div>

                  {/* Post Content */}
                  <div className="text-xs text-slate-800 whitespace-pre-line leading-relaxed max-h-72 overflow-y-auto pr-1">
                    {composerText}
                  </div>

                  {/* Certificate Credential Snippet Card */}
                  <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-2xs">
                    <div className="flex items-center gap-2 truncate">
                      <Award className="w-4 h-4 text-amber-600 shrink-0" />
                      <div className="truncate">
                        <span className="font-bold text-slate-800 block truncate">{postComposerCert.title}</span>
                        <span className="text-slate-500 text-3xs">{postComposerCert.organization}</span>
                      </div>
                    </div>
                    <Badge variant="outline" size="sm">Verified</Badge>
                  </div>

                  {/* Simulated Reactions */}
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-3xs text-slate-400">
                    <span className="flex items-center gap-1">
                      <span>👍</span>
                      <span>💡</span>
                      <span>You and 14 others</span>
                    </span>
                    <span>3 comments</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
