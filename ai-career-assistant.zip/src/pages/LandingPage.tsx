import React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  Sparkles,
  GraduationCap,
  Building2,
  ArrowRight,
  CheckCircle2,
  Compass,
  FileCheck2,
  Target,
  MessageSquareCode,
  Briefcase,
  Users2,
  UserCheck,
  Send,
  FolderGit2
} from 'lucide-react';

export const LandingPage: React.FC = () => {
  const navigate = useNavigate();

  const studentFeatures = [
    { text: 'Personalized AI Career Roadmap', icon: Compass },
    { text: 'Resume & ATS Analysis', icon: FileCheck2 },
    { text: 'Skill Gap Analysis', icon: Target },
    { text: 'Interview Preparation', icon: MessageSquareCode },
    { text: 'Internship & Job Applications', icon: Briefcase },
  ];

  const companyFeatures = [
    { text: 'Post Jobs & Internships', icon: Briefcase },
    { text: 'Review Student Applications', icon: UserCheck },
    { text: 'Shortlist Candidates', icon: CheckCircle2 },
    { text: 'Manage Recruitment', icon: Users2 },
    { text: 'Review Shared Student Projects', icon: FolderGit2 },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between selection:bg-blue-100 selection:text-blue-900">
      {/* Top Header / Branding */}
      <header className="w-full border-b border-slate-200/80 bg-white/80 backdrop-blur-md sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Link
            to="/"
            className="flex items-center gap-3 group focus:outline-hidden focus-visible:ring-2 focus-visible:ring-blue-600 rounded-lg p-1"
            aria-label="AI Career Assistant Home"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-purple-600 flex items-center justify-center text-white shadow-xs group-hover:scale-105 transition-transform duration-200">
              <Sparkles className="w-5 h-5" />
            </div>
            <div className="flex flex-col">
              <span className="text-base sm:text-lg font-bold tracking-tight text-slate-900 group-hover:text-blue-600 transition-colors">
                AI Career Assistant
              </span>
              <span className="text-2xs font-medium text-slate-500 hidden sm:block -mt-1">
                Career Guidance &amp; Hiring Platform
              </span>
            </div>
          </Link>

          {/* Clean minimal top right shortcut */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => navigate('/login')}
              className="text-xs font-semibold text-slate-700 hover:text-blue-600 px-3 py-1.5 rounded-lg hover:bg-slate-100 transition-colors"
            >
              Sign In
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col py-8 sm:py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-5xl mx-auto w-full my-auto space-y-8 sm:space-y-10">
          {/* Header & Tagline */}
          <div className="text-center space-y-3 sm:space-y-4 max-w-2xl mx-auto">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-200/60 text-blue-700 text-xs font-medium">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              <span>Smart Placement Ecosystem</span>
            </div>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight">
              Welcome to AI Career Assistant
            </h1>
            <p className="text-base sm:text-lg text-slate-600 font-normal leading-relaxed">
              One platform. Two portals. Better career opportunities.
            </p>
          </div>

          {/* Two Portal Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8 items-stretch pt-2">
            {/* 1. STUDENT PORTAL CARD */}
            <div className="flex flex-col justify-between bg-white border border-slate-200/90 rounded-2xl sm:rounded-3xl p-6 sm:p-8 shadow-sm hover:shadow-xl hover:border-blue-300 transition-all duration-200 group">
              <div className="space-y-5 sm:space-y-6">
                {/* Icon & Heading */}
                <div className="flex items-start gap-4">
                  <div className="w-13 h-13 sm:w-14 sm:h-14 rounded-2xl bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-600 group-hover:scale-105 group-hover:bg-blue-600 group-hover:text-white transition-all duration-200 shadow-xs shrink-0">
                    <GraduationCap className="w-6 h-6 sm:w-7 sm:h-7" />
                  </div>
                  <div className="space-y-0.5 pt-0.5">
                    <span className="text-xs font-semibold text-blue-600 uppercase tracking-wider">
                      For Job Seekers
                    </span>
                    <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
                      Student Portal
                    </h2>
                  </div>
                </div>

                {/* Description */}
                <p className="text-sm text-slate-600 leading-relaxed">
                  Build your skills, create an ATS-friendly resume, prepare for interviews, explore opportunities, and track your career growth.
                </p>

                {/* Feature Highlights */}
                <div className="space-y-3 pt-2 border-t border-slate-100">
                  <h3 className="text-xs font-semibold text-slate-800 uppercase tracking-wider">
                    Portal Features
                  </h3>
                  <ul className="space-y-2.5">
                    {studentFeatures.map((item) => {
                      const Icon = item.icon;
                      return (
                        <li key={item.text} className="flex items-center gap-3 text-sm text-slate-700">
                          <span className="w-5 h-5 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                          </span>
                          <span className="font-medium text-slate-800">{item.text}</span>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              </div>

              {/* Action Button & Sublinks */}
              <div className="pt-6 sm:pt-8 space-y-3">
                <button
                  type="button"
                  onClick={() => navigate('/login')}
                  className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-semibold text-sm shadow-sm hover:shadow-md transition-all duration-200 cursor-pointer focus:outline-hidden focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2"
                  aria-label="Continue as Student - Go to student login"
                >
                  <span>Continue as Student</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                </button>
                <div className="text-center text-xs text-slate-500">
                  <span>New student? </span>
                  <Link
                    to="/signup"
                    className="font-semibold text-blue-600 hover:text-blue-800 transition-colors underline-offset-2 hover:underline"
                  >
                    Create an account
                  </Link>
                </div>
              </div>
            </div>

            {/* 2. COMPANY PORTAL CARD */}
            <div className="flex flex-col justify-between bg-white border border-slate-200/90 rounded-2xl sm:rounded-3xl p-6 sm:p-8 shadow-sm hover:shadow-xl hover:border-purple-300 transition-all duration-200 group">
              <div className="space-y-5 sm:space-y-6">
                {/* Icon & Heading */}
                <div className="flex items-start gap-4">
                  <div className="w-13 h-13 sm:w-14 sm:h-14 rounded-2xl bg-purple-50 border border-purple-100 flex items-center justify-center text-purple-600 group-hover:scale-105 group-hover:bg-purple-600 group-hover:text-white transition-all duration-200 shadow-xs shrink-0">
                    <Building2 className="w-6 h-6 sm:w-7 sm:h-7" />
                  </div>
                  <div className="space-y-0.5 pt-0.5">
                    <span className="text-xs font-semibold text-purple-600 uppercase tracking-wider">
                      For Employers &amp; Recruiters
                    </span>
                    <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
                      Company Portal
                    </h2>
                  </div>
                </div>

                {/* Description */}
                <p className="text-sm text-slate-600 leading-relaxed">
                  Discover talented students, publish internships and job openings, review applications, and connect with potential candidates.
                </p>

                {/* Feature Highlights */}
                <div className="space-y-3 pt-2 border-t border-slate-100">
                  <h3 className="text-xs font-semibold text-slate-800 uppercase tracking-wider">
                    Portal Features
                  </h3>
                  <ul className="space-y-2.5">
                    {companyFeatures.map((item) => {
                      const Icon = item.icon;
                      return (
                        <li key={item.text} className="flex items-center gap-3 text-sm text-slate-700">
                          <span className="w-5 h-5 rounded-full bg-purple-50 text-purple-600 flex items-center justify-center shrink-0">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                          </span>
                          <span className="font-medium text-slate-800">{item.text}</span>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              </div>

              {/* Action Button & Sublinks */}
              <div className="pt-6 sm:pt-8 space-y-3">
                <button
                  type="button"
                  onClick={() => navigate('/company/login')}
                  className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-purple-600 hover:bg-purple-700 active:bg-purple-800 text-white font-semibold text-sm shadow-sm hover:shadow-md transition-all duration-200 cursor-pointer focus:outline-hidden focus-visible:ring-2 focus-visible:ring-purple-600 focus-visible:ring-offset-2"
                  aria-label="Continue as Company - Go to company login"
                >
                  <span>Continue as Company</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                </button>
                <div className="text-center text-xs text-slate-500">
                  <span>New employer? </span>
                  <Link
                    to="/company/register"
                    className="font-semibold text-purple-600 hover:text-purple-800 transition-colors underline-offset-2 hover:underline"
                  >
                    Register company
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Clean, minimalist footer */}
      <footer className="w-full border-t border-slate-200/80 bg-white/60 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>© {new Date().getFullYear()} AI Career Assistant. All rights reserved.</p>
          <div className="flex items-center gap-5 text-slate-500">
            <span>Student Career Development</span>
            <span aria-hidden="true">·</span>
            <span>Campus &amp; Corporate Recruitment</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
