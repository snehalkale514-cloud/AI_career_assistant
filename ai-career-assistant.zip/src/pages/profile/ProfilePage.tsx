import React, { useState } from 'react';
import {
  User,
  Mail,
  Phone,
  MapPin,
  GraduationCap,
  Building,
  Calendar,
  Target,
  Code2,
  CheckCircle2,
  Edit3,
  Save,
  Plus,
  Briefcase,
  Layers,
  ArrowRight,
  BrainCircuit,
  TrendingUp,
  AlertTriangle,
  History,
  Clock,
  Award,
  Sparkles,
  BookOpen
} from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';
import { Badge } from '../../components/common/Badge.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';
import { SkillAssessmentModal } from '../../components/assessment/SkillAssessmentModal.tsx';
import { SkillItem } from '../../types.ts';

export const ProfilePage: React.FC = () => {
  const { user, updateUser, skills, addSkill, submitSkillAssessmentResult, assessmentHistory } = useCareer();
  const [isEditing, setIsEditing] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [testingSkill, setTestingSkill] = useState<SkillItem | null>(null);

  // Edit buffer
  const [formData, setFormData] = useState({
    name: user.name,
    email: user.email,
    phone: user.phone,
    location: user.location,
    college: user.college,
    degree: user.degree,
    branch: user.branch,
    graduationYear: user.graduationYear,
    targetRole: user.targetRole,
    careerGoal: user.careerGoal,
    preferredLocation: user.preferredLocation || 'Pune / Mumbai / Remote',
    workPreference: user.workPreference || 'Hybrid',
  });

  const [newSkillName, setNewSkillName] = useState('');
  const [skillMessage, setSkillMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleSave = () => {
    updateUser(formData);
    setIsEditing(false);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const handleAddNewSkill = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const clean = newSkillName.trim();
    if (!clean) {
      setSkillMessage({ type: 'error', text: 'Please enter a skill name before clicking Add Skill.' });
      setTimeout(() => setSkillMessage(null), 3500);
      return;
    }
    if (skills.some((s) => s.name.toLowerCase() === clean.toLowerCase())) {
      setSkillMessage({ type: 'error', text: `"${clean}" is already present in your technical profile.` });
      setTimeout(() => setSkillMessage(null), 3500);
      return;
    }
    const res = addSkill(clean);
    setNewSkillName('');
    if (res && !res.success) {
      setSkillMessage({ type: 'error', text: res.error || 'Failed to add skill.' });
      setTimeout(() => setSkillMessage(null), 3500);
    } else {
      setSkillMessage({
        type: 'success',
        text: `"${clean}" successfully added to your profile! You can now verify it below.`
      });
      setTimeout(() => setSkillMessage(null), 4000);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Back Button */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/dashboard" />
        <span className="text-2xs font-mono text-slate-400">Student ID: std_vpkbiet_2028_sk</span>
      </div>

      {/* Top Banner / Hero Profile Card */}
      <div className="bg-white rounded-2xl border border-slate-200/90 overflow-hidden shadow-xs">
        <div className="h-32 bg-gradient-to-r from-blue-700 via-indigo-700 to-slate-900 px-6 flex items-end">
          <div className="translate-y-1/2 flex items-end gap-5">
            <div className="w-24 h-24 rounded-2xl bg-white p-1 shadow-md border border-slate-200">
              <div className="w-full h-full rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white text-2xl font-bold shadow-inner">
                SK
              </div>
            </div>
          </div>
        </div>

        <div className="pt-16 pb-6 px-6 sm:px-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">{user.name}</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {user.degree} in {user.branch} · Class of {user.graduationYear} · {user.college}
            </p>
            <div className="flex items-center gap-2 mt-2">
              <Badge variant="primary">Target: {user.targetRole}</Badge>
              <Badge variant="success">Placement Readiness: {user.careerReadiness}%</Badge>
              <Badge variant="neutral">Resume: {user.resumeScore}% ATS</Badge>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isEditing ? (
              <button
                onClick={handleSave}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-xs transition-colors cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Save Changes</span>
              </button>
            ) : (
              <button
                onClick={() => setIsEditing(true)}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-2xs transition-colors cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5 text-slate-500" />
                <span>Edit Profile</span>
              </button>
            )}
          </div>
        </div>

        {saveSuccess && (
          <div className="mx-6 sm:mx-8 mb-6 p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Profile successfully updated! Your career roadmap &amp; portfolio are synchronized.</span>
          </div>
        )}
      </div>

      {/* Main Details Sections */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Personal Information */}
        <div className="bg-white rounded-xl border border-slate-200/90 p-6 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <User className="w-4 h-4 text-blue-600" />
            <h3 className="text-sm font-bold text-slate-900">Personal Information</h3>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <span className="text-slate-400 block mb-0.5">Full Name</span>
              {isEditing ? (
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md text-slate-900 font-medium"
                />
              ) : (
                <span className="font-semibold text-slate-800">{user.name}</span>
              )}
            </div>

            <div>
              <span className="text-slate-400 block mb-0.5">Email Address</span>
              {isEditing ? (
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md text-slate-900 font-medium"
                />
              ) : (
                <div className="flex items-center gap-1.5 text-slate-800 font-medium">
                  <Mail className="w-3.5 h-3.5 text-slate-400" />
                  <span>{user.email}</span>
                </div>
              )}
            </div>

            <div>
              <span className="text-slate-400 block mb-0.5">Phone Number</span>
              {isEditing ? (
                <input
                  type="text"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md text-slate-900 font-medium"
                />
              ) : (
                <div className="flex items-center gap-1.5 text-slate-800 font-medium">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  <span>{user.phone}</span>
                </div>
              )}
            </div>

            <div>
              <span className="text-slate-400 block mb-0.5">Current Location</span>
              {isEditing ? (
                <input
                  type="text"
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md text-slate-900 font-medium"
                />
              ) : (
                <div className="flex items-center gap-1.5 text-slate-800 font-medium">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  <span>{user.location}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Academic Details */}
        <div className="bg-white rounded-xl border border-slate-200/90 p-6 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <GraduationCap className="w-4 h-4 text-blue-600" />
            <h3 className="text-sm font-bold text-slate-900">Education Details</h3>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <span className="text-slate-400 block mb-0.5">Degree &amp; Branch</span>
              {isEditing ? (
                <input
                  type="text"
                  value={`${formData.degree} — ${formData.branch}`}
                  onChange={(e) => {
                    const parts = e.target.value.split('—');
                    setFormData({
                      ...formData,
                      degree: parts[0]?.trim() || formData.degree,
                      branch: parts[1]?.trim() || formData.branch,
                    });
                  }}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md text-slate-900 font-medium"
                />
              ) : (
                <span className="font-semibold text-slate-800">
                  {user.degree} — {user.branch}
                </span>
              )}
            </div>

            <div>
              <span className="text-slate-400 block mb-0.5">College / Institution</span>
              {isEditing ? (
                <input
                  type="text"
                  value={formData.college}
                  onChange={(e) => setFormData({ ...formData, college: e.target.value })}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md text-slate-900 font-medium"
                />
              ) : (
                <div className="flex items-center gap-1.5 text-slate-800 font-medium">
                  <Building className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="leading-snug">{user.college}</span>
                </div>
              )}
            </div>

            <div>
              <span className="text-slate-400 block mb-0.5">Graduation Cohort</span>
              {isEditing ? (
                <input
                  type="text"
                  value={formData.graduationYear}
                  onChange={(e) => setFormData({ ...formData, graduationYear: e.target.value })}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md text-slate-900 font-medium"
                />
              ) : (
                <div className="flex items-center gap-1.5 text-slate-800 font-medium">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <span>2024–{user.graduationYear} (Semester 4 · Class of 2028)</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Career Preferences Section (Section 6 Requirements) */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-6 shadow-xs space-y-4">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
          <Briefcase className="w-4 h-4 text-blue-600" />
          <h3 className="text-sm font-bold text-slate-900">Career Preferences</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div>
            <span className="text-slate-400 block mb-0.5">Target Role</span>
            {isEditing ? (
              <input
                type="text"
                value={formData.targetRole}
                onChange={(e) => setFormData({ ...formData, targetRole: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md text-slate-900 font-semibold"
              />
            ) : (
              <span className="font-bold text-blue-700">{user.targetRole}</span>
            )}
          </div>

          <div>
            <span className="text-slate-400 block mb-0.5">Preferred Locations</span>
            {isEditing ? (
              <input
                type="text"
                value={formData.preferredLocation}
                onChange={(e) => setFormData({ ...formData, preferredLocation: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md text-slate-900 font-medium"
              />
            ) : (
              <span className="font-semibold text-slate-800">{user.preferredLocation || 'Pune / Mumbai / Remote'}</span>
            )}
          </div>

          <div>
            <span className="text-slate-400 block mb-0.5">Work Preference</span>
            {isEditing ? (
              <select
                value={formData.workPreference}
                onChange={(e) => setFormData({ ...formData, workPreference: e.target.value as any })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md text-slate-900 font-medium"
              >
                <option value="Hybrid">Hybrid</option>
                <option value="Remote">Remote</option>
                <option value="On-site">On-site</option>
                <option value="Flexible">Flexible</option>
              </select>
            ) : (
              <span className="font-semibold text-slate-800">{user.workPreference || 'Hybrid'}</span>
            )}
          </div>
        </div>

        <div className="pt-2 text-xs">
          <span className="text-slate-400 block mb-1">Target Companies Mapped:</span>
          <div className="flex flex-wrap gap-1.5">
            {['TechNova Solutions', 'Tata Consultancy Services', 'Deloitte USI', 'ZS Associates', 'AnalyticsHub', 'Barclays'].map((comp) => (
              <span key={comp} className="px-2.5 py-1 rounded-md bg-slate-100 text-slate-700 font-medium">
                {comp}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Verified Skills */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-6 shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-100 gap-2">
          <div>
            <div className="flex items-center gap-2">
              <Code2 className="w-4 h-4 text-blue-600" />
              <h3 className="text-sm font-bold text-slate-900">Verified Technical Skills</h3>
            </div>
            <p className="text-3xs text-slate-500 mt-0.5">
              Proficiency scores calculated strictly from standardized topic assessments. No assumed or artificial ratings.
            </p>
          </div>
          <span className="text-2xs text-slate-500 font-mono bg-slate-50 px-2 py-1 rounded border border-slate-200 self-start sm:self-auto">
            {skills.length} skills tracked
          </span>
        </div>

        {/* Skill Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {skills.map((sk) => {
            const hasHistory = sk.previousLevel !== undefined || sk.lastTestedDate;
            return (
              <div
                key={sk.id}
                className="p-3.5 rounded-xl border border-slate-200/90 bg-slate-50/40 hover:bg-white hover:border-blue-300 transition-all shadow-2xs flex flex-col justify-between gap-3 group"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="text-xs font-bold text-slate-900 group-hover:text-blue-700 transition-colors">
                        {sk.name}
                      </h4>
                      <span className="text-3xs text-slate-400 font-medium">{sk.category}</span>
                    </div>
                    <span className={`font-mono text-xs font-bold px-2 py-0.5 rounded border ${
                      sk.currentLevel >= 80
                        ? 'text-emerald-700 bg-emerald-50 border-emerald-200'
                        : sk.currentLevel >= 60
                        ? 'text-blue-700 bg-blue-50 border-blue-200'
                        : 'text-amber-700 bg-amber-50 border-amber-200'
                    }`}>
                      {sk.currentLevel}%
                    </span>
                  </div>

                  {/* Assessment History & Previous Attempt Comparison */}
                  <div className="mt-2.5 pt-2 border-t border-slate-200/60 text-3xs space-y-1">
                    {hasHistory ? (
                      <div className="space-y-0.5">
                        <div className="flex items-center justify-between text-slate-600 font-medium">
                          <span>
                            Previous: <strong className="text-slate-800">{sk.previousLevel ?? sk.currentLevel}%</strong>
                          </span>
                          <span className="text-slate-300">→</span>
                          <span>
                            Current: <strong className="text-slate-900">{sk.currentLevel}%</strong>
                          </span>
                          {sk.improvementPct !== undefined && (
                            <span className={`font-mono font-bold px-1.5 py-0.5 rounded text-3xs ${
                              sk.improvementPct >= 0
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : 'bg-rose-50 text-rose-700 border border-rose-200'
                            }`}>
                              {sk.improvementPct >= 0 ? `+${sk.improvementPct}%` : `${sk.improvementPct}%`}
                            </span>
                          )}
                        </div>
                        {sk.lastTestedDate && (
                          <div className="flex items-center gap-1 text-slate-400 pt-0.5">
                            <Clock className="w-2.5 h-2.5" />
                            <span>Tested: {sk.lastTestedDate}</span>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="text-slate-400 italic flex items-center gap-1">
                        <span>Awaiting formal verification</span>
                      </div>
                    )}

                    {/* Weak topics / Needs improvement preview */}
                    {sk.weakTopics && sk.weakTopics.length > 0 && (
                      <div className="pt-1 text-3xs text-amber-700 flex items-start gap-1 font-medium">
                        <span className="shrink-0">• Gap:</span>
                        <span className="truncate">{sk.weakTopics.slice(0, 2).join(', ')}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Take Assessment Button */}
                <button
                  type="button"
                  onClick={() => setTestingSkill(sk)}
                  className="w-full py-1.5 px-3 rounded-lg text-2xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-600 hover:text-white border border-blue-200 transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                >
                  <BrainCircuit className="w-3.5 h-3.5" />
                  <span>{hasHistory ? 'Retest Skill' : 'Test Your Skill'}</span>
                </button>
              </div>
            );
          })}
        </div>

        {/* Add Skill Form */}
        <div className="pt-2 border-t border-slate-100 space-y-2">
          {skillMessage && (
            <div
              className={`p-2.5 rounded-lg text-xs font-medium flex items-center gap-2 ${
                skillMessage.type === 'success'
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                  : 'bg-rose-50 text-rose-800 border border-rose-200'
              }`}
            >
              {skillMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              )}
              <span>{skillMessage.text}</span>
            </div>
          )}

          <form onSubmit={handleAddNewSkill} className="flex gap-2">
            <input
              type="text"
              value={newSkillName}
              onChange={(e) => setNewSkillName(e.target.value)}
              placeholder="Add skill to profile (e.g. C++, Scikit-Learn, Docker, React)..."
              className="flex-1 px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
            />
            <button
              type="submit"
              onClick={handleAddNewSkill}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors cursor-pointer shrink-0 shadow-2xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Skill</span>
            </button>
          </form>
          <span className="text-3xs text-slate-400 mt-1 block">
            Added skills appear in your technical profile and can be tested immediately to establish verified proficiency.
          </span>
        </div>
      </div>

      {/* Assessment History Section */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-blue-600" />
            <h3 className="text-sm font-bold text-slate-900">Verified Assessment History</h3>
          </div>
          <span className="text-2xs text-slate-500 font-mono">
            {assessmentHistory.length} recorded evaluations
          </span>
        </div>

        <div className="space-y-3">
          {assessmentHistory.slice(0, 5).map((item) => {
            const skillItem = skills.find(s => s.name.toLowerCase() === (item.skillName || '').toLowerCase());
            return (
              <div
                key={item.id}
                className="p-3.5 rounded-xl border border-slate-200/80 bg-slate-50/50 hover:bg-slate-50 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-slate-900">
                      {item.skillName ? `${item.skillName} Knowledge Assessment` : `${item.targetRole} Diagnostic`}
                    </span>
                    <span className="text-3xs text-slate-400 font-mono">
                      {item.date}
                    </span>
                    {item.knowledgeLevel && (
                      <span className="text-3xs font-semibold px-2 py-0.2 bg-blue-50 text-blue-700 rounded border border-blue-200">
                        {item.knowledgeLevel}
                      </span>
                    )}
                  </div>

                  {/* Previous vs Current score */}
                  <div className="flex items-center gap-3 text-2xs text-slate-600">
                    {item.previousScore !== undefined && (
                      <span>
                        Previous: <strong className="text-slate-700">{item.previousScore}%</strong>
                      </span>
                    )}
                    <span>
                      Score: <strong className="text-blue-700 font-mono font-bold">{item.overallScore}%</strong>
                    </span>
                    {item.improvementPct !== undefined && item.improvementPct !== 0 && (
                      <span className={`font-mono font-bold px-1.5 py-0.2 rounded text-3xs ${
                        item.improvementPct > 0
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : 'bg-rose-50 text-rose-700 border border-rose-200'
                      }`}>
                        {item.improvementPct > 0 ? `+${item.improvementPct}%` : `${item.improvementPct}%`} Improvement
                      </span>
                    )}
                  </div>

                  {/* Strong & Weak Areas */}
                  {(item.strongTopics || item.weakTopics) && (
                    <div className="flex flex-wrap gap-x-4 gap-y-1 text-3xs pt-0.5">
                      {item.strongTopics && item.strongTopics.length > 0 && (
                        <div className="text-emerald-700 flex items-center gap-1">
                          <CheckCircle2 className="w-2.5 h-2.5 shrink-0" />
                          <span>Strong: {item.strongTopics.slice(0, 2).join(', ')}</span>
                        </div>
                      )}
                      {item.weakTopics && item.weakTopics.length > 0 && (
                        <div className="text-amber-700 flex items-center gap-1">
                          <AlertTriangle className="w-2.5 h-2.5 shrink-0" />
                          <span>Needs practice: {item.weakTopics.slice(0, 2).join(', ')}</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {item.skillName && (
                    <button
                      type="button"
                      onClick={() => {
                        const targetSkill = skillItem || {
                          id: `skill_${Date.now()}`,
                          name: item.skillName!,
                          category: 'Technical' as const,
                          currentLevel: item.overallScore,
                          requiredLevel: 75,
                          status: 'Good' as const
                        };
                        setTestingSkill(targetSkill);
                      }}
                      className="px-3 py-1.5 rounded-lg text-2xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 transition-colors cursor-pointer"
                    >
                      Retest
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Skill Assessment Modal */}
      {testingSkill && (
        <SkillAssessmentModal
          skillName={testingSkill.name}
          previousScore={testingSkill.currentLevel > 0 ? testingSkill.currentLevel : undefined}
          onClose={() => setTestingSkill(null)}
          onSaveResult={(result) => {
            submitSkillAssessmentResult(result);
            setTestingSkill(null);
          }}
        />
      )}
    </div>
  );
};

export default ProfilePage;
