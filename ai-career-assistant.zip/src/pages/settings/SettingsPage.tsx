import React, { useState } from 'react';
import {
  Settings,
  Bell,
  User,
  Shield,
  Briefcase,
  CheckCircle2,
  Building2,
  Save,
  Mail,
  ToggleLeft,
  ToggleRight
} from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';
import { BackButton } from '../../components/common/BackButton.tsx';

export const SettingsPage: React.FC = () => {
  const { user, updateUser, jobAlerts, updateJobAlerts } = useCareer();
  const [activeTab, setActiveTab] = useState<'Notifications' | 'Career Preferences' | 'Account' | 'Privacy'>('Career Preferences');
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Settings buffers
  const [alertsState, setAlertsState] = useState(jobAlerts);
  const [targetCompany, setTargetCompany] = useState(jobAlerts.company || 'TechNova / TCS / Deloitte');
  const [targetRole, setTargetRole] = useState(jobAlerts.role || 'Data Analyst');

  const handleSave = () => {
    updateJobAlerts({
      ...alertsState,
      company: targetCompany,
      role: targetRole,
    });
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/dashboard" />
      </div>

      {/* Top Header */}
      <div>
        <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
          <Settings className="w-6 h-6 text-blue-600" />
          <span>Platform Settings &amp; Preferences</span>
        </h2>
        <p className="text-xs text-slate-500 mt-0.5">
          Configure real-time job opening alerts, notification channels, and career targets.
        </p>
      </div>

      {saveSuccess && (
        <div className="p-3.5 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Settings and recruitment alert preferences saved successfully!</span>
        </div>
      )}

      {/* Settings Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 overflow-x-auto text-xs font-semibold">
        {(['Career Preferences', 'Notifications', 'Account', 'Privacy'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`pb-3 px-3 transition-colors cursor-pointer border-b-2 whitespace-nowrap ${
              activeTab === tab
                ? 'border-blue-600 text-blue-700 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Tab 1: Career Preferences & Job Opening Alerts */}
      {activeTab === 'Career Preferences' && (
        <div className="bg-white rounded-2xl border border-slate-200/90 p-6 sm:p-8 shadow-xs space-y-6">
          <div>
            <h3 className="text-base font-bold text-slate-900 tracking-tight">
              Recruitment &amp; Job Alert Targets
            </h3>
            <p className="text-xs text-slate-500">
              Receive immediate notifications whenever campus drives or verified fresher requisitions match your criteria.
            </p>
          </div>

          <div className="space-y-4 text-xs">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                Target Placement Companies
              </label>
              <input
                type="text"
                value={targetCompany}
                onChange={(e) => setTargetCompany(e.target.value)}
                placeholder="e.g. TCS, TechNova, Deloitte, Barclays, Cognizant"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
              />
              <span className="text-3xs text-slate-400 mt-1 block">
                Separate multiple companies with commas or slashes
              </span>
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                Target Role Preference
              </label>
              <input
                type="text"
                value={targetRole}
                onChange={(e) => setTargetRole(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
              />
            </div>

            <div className="pt-2 space-y-3">
              <span className="font-bold text-slate-900 block">Notification Channels:</span>

              <label className="flex items-center justify-between p-3 rounded-xl border border-slate-200 cursor-pointer hover:bg-slate-50">
                <div>
                  <h4 className="font-semibold text-slate-900">Job Opening Alerts</h4>
                  <p className="text-3xs text-slate-500">Notify me immediately about new matching openings (85%+ match).</p>
                </div>
                <input
                  type="checkbox"
                  checked={alertsState.jobAlerts}
                  onChange={(e) => setAlertsState({ ...alertsState, jobAlerts: e.target.checked })}
                  className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4 cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl border border-slate-200 cursor-pointer hover:bg-slate-50">
                <div>
                  <h4 className="font-semibold text-slate-900">Internship &amp; PPO Alerts</h4>
                  <p className="text-3xs text-slate-500">Alert for pre-final year internship openings and campus shortlist notices.</p>
                </div>
                <input
                  type="checkbox"
                  checked={alertsState.emailAlerts}
                  onChange={(e) => setAlertsState({ ...alertsState, emailAlerts: e.target.checked })}
                  className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4 cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl border border-slate-200 cursor-pointer hover:bg-slate-50">
                <div>
                  <h4 className="font-semibold text-slate-900">Roadmap Milestone Reminders</h4>
                  <p className="text-3xs text-slate-500">Weekly progress checkpoints for Power BI and Statistics modules.</p>
                </div>
                <input
                  type="checkbox"
                  checked={alertsState.roadmapReminders}
                  onChange={(e) => setAlertsState({ ...alertsState, roadmapReminders: e.target.checked })}
                  className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4 cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl border border-slate-200 cursor-pointer hover:bg-slate-50">
                <div>
                  <h4 className="font-semibold text-slate-900">Interview Preparation Reminders</h4>
                  <p className="text-3xs text-slate-500">Daily quick technical diagnostic questions before scheduled drive dates.</p>
                </div>
                <input
                  type="checkbox"
                  checked={alertsState.interviewReminders}
                  onChange={(e) => setAlertsState({ ...alertsState, interviewReminders: e.target.checked })}
                  className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4 cursor-pointer"
                />
              </label>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex justify-end">
            <button
              onClick={handleSave}
              className="inline-flex items-center gap-1.5 px-5 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Career Preferences</span>
            </button>
          </div>
        </div>
      )}

      {/* Tab 2: Notifications */}
      {activeTab === 'Notifications' && (
        <div className="bg-white rounded-2xl border border-slate-200/90 p-6 sm:p-8 shadow-xs space-y-4 text-xs">
          <h3 className="text-base font-bold text-slate-900">Email &amp; System Notifications</h3>
          <p className="text-slate-500">Primary delivery address: <strong>{user.email}</strong></p>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
            <div className="flex justify-between items-center">
              <span>Recruiter screening invites</span>
              <span className="font-semibold text-emerald-700">Enabled</span>
            </div>
            <div className="flex justify-between items-center">
              <span>Weekly skill progress summary</span>
              <span className="font-semibold text-emerald-700">Enabled</span>
            </div>
            <div className="flex justify-between items-center">
              <span>Campus drive deadline reminders</span>
              <span className="font-semibold text-emerald-700">Enabled</span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Account */}
      {activeTab === 'Account' && (
        <div className="bg-white rounded-2xl border border-slate-200/90 p-6 sm:p-8 shadow-xs space-y-4 text-xs">
          <h3 className="text-base font-bold text-slate-900">Student Account</h3>
          <div className="space-y-3 max-w-md">
            <div>
              <span className="text-slate-500 block mb-0.5">Account ID</span>
              <span className="font-mono font-semibold text-slate-900">std_vpkbiet_2028_sk</span>
            </div>
            <div>
              <span className="text-slate-500 block mb-0.5">College Affiliation</span>
              <span className="font-semibold text-slate-900">{user.college}</span>
            </div>
            <div>
              <span className="text-slate-500 block mb-0.5">Cohort Standing</span>
              <span className="font-semibold text-slate-900">{user.degree} {user.branch} (2024–{user.graduationYear})</span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Privacy */}
      {activeTab === 'Privacy' && (
        <div className="bg-white rounded-2xl border border-slate-200/90 p-6 sm:p-8 shadow-xs space-y-4 text-xs">
          <h3 className="text-base font-bold text-slate-900">Privacy &amp; Resume Visibility</h3>
          <p className="text-slate-600 leading-relaxed">
            Your resume and diagnostic metrics are shared strictly with verified campus recruiters participating in institutional placement drives.
          </p>
          <div className="p-4 bg-blue-50/60 rounded-xl border border-blue-200 text-blue-900 space-y-1">
            <span className="font-bold block">Placement Officer Verification</span>
            <p>Your academic profile is linked to VPKBIET Training &amp; Placement Cell records.</p>
          </div>
        </div>
      )}
    </div>
  );
};
