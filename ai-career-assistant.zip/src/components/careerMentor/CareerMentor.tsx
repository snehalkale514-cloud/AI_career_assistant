import React, { useState, useCallback } from 'react';
import { useLocation } from 'react-router-dom';
import { useCareer } from '../../context/CareerContext.tsx';
import { sendCareerCompanionMessage } from '../../services/careerCompanionService.ts';
import { ChatMessage } from './CareerMentorMessage.tsx';
import { CareerMentorDrawer } from './CareerMentorDrawer.tsx';
import { CareerMentorButton } from './CareerMentorButton.tsx';

export const CareerMentor: React.FC = () => {
  const location = useLocation();
  const {
    user,
    skills,
    roadmapStages,
    resumeAnalysis,
    interviewHistory,
    projects,
    applications
  } = useCareer();

  // Hide student floating mentor on public landing page and inside company portal
  if (location.pathname === '/' || location.pathname.startsWith('/company')) {
    return null;
  }

  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastFailedMessage, setLastFailedMessage] = useState<string | null>(null);

  const handleSendMessage = useCallback(
    async (text: string) => {
      const trimmed = text.trim();
      if (!trimmed || loading) return;

      const userMsgId = `user_${Date.now()}`;
      const userMsg: ChatMessage = {
        id: userMsgId,
        sender: 'user',
        text: trimmed
      };

      setMessages((prev) => [...prev, userMsg]);
      setLoading(true);
      setError(null);
      setLastFailedMessage(null);

      try {
        // Deterministically build current CareerCompanionSnapshot at message-send time
        const reply = await sendCareerCompanionMessage(trimmed, {
          user,
          skills,
          roadmapStages,
          resumeAnalysis,
          interviewHistory,
          projects,
          applications,
          targetRoleOverride: user?.targetRole
        });

        const mentorMsg: ChatMessage = {
          id: `mentor_${Date.now()}`,
          sender: 'mentor',
          text: reply || 'I received your question, but was unable to produce a response. Please try again.'
        };

        setMessages((prev) => [...prev, mentorMsg]);
      } catch (err: any) {
        console.error('Failed to send message to Career Mentor:', err);
        setError(err.message || 'The career assistant is temporarily unavailable. Please try again.');
        setLastFailedMessage(trimmed);
      } finally {
        setLoading(false);
      }
    },
    [user, skills, roadmapStages, resumeAnalysis, interviewHistory, projects, applications, loading]
  );

  const handleRetry = useCallback(() => {
    if (lastFailedMessage) {
      handleSendMessage(lastFailedMessage);
    }
  }, [lastFailedMessage, handleSendMessage]);

  const handleClearHistory = useCallback(() => {
    setMessages([]);
    setError(null);
    setLastFailedMessage(null);
  }, []);

  return (
    <>
      <CareerMentorButton
        isOpen={isOpen}
        onClick={() => setIsOpen((prev) => !prev)}
      />

      <CareerMentorDrawer
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        messages={messages}
        loading={loading}
        error={error}
        onSendMessage={handleSendMessage}
        onRetry={lastFailedMessage ? handleRetry : undefined}
        onClearHistory={messages.length > 0 ? handleClearHistory : undefined}
      />
    </>
  );
};
