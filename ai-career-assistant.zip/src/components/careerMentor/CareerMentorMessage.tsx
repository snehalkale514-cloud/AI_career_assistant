import React from 'react';
import { Bot, User } from 'lucide-react';

export interface ChatMessage {
  id: string;
  sender: 'user' | 'mentor';
  text: string;
  timestamp?: string;
}

interface CareerMentorMessageProps {
  message: ChatMessage;
}

/**
 * Lightweight, safe renderer for bold text, inline code, and emphasis
 * without external heavyweight markdown dependencies.
 */
function renderFormattedInlineText(text: string): React.ReactNode {
  const parts: React.ReactNode[] = [];
  const regex = /(`[^`]+`|\*\*(?:[^*]+)\*\*|\*(?:[^*\s][^*]*?)\*)/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = regex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      parts.push(text.substring(lastIndex, match.index));
    }
    const token = match[0];
    if (token.startsWith('`') && token.endsWith('`')) {
      parts.push(
        <code key={match.index} className="px-1.5 py-0.5 bg-blue-50 text-blue-700 border border-blue-100 rounded font-mono text-2xs font-medium">
          {token.slice(1, -1)}
        </code>
      );
    } else if (token.startsWith('**') && token.endsWith('**')) {
      parts.push(
        <strong key={match.index} className="font-semibold text-slate-900">
          {token.slice(2, -2)}
        </strong>
      );
    } else if (token.startsWith('*') && token.endsWith('*')) {
      parts.push(
        <em key={match.index} className="italic text-slate-700">
          {token.slice(1, -1)}
        </em>
      );
    }
    lastIndex = regex.lastIndex;
  }

  if (lastIndex < text.length) {
    parts.push(text.substring(lastIndex));
  }

  return parts.length > 0 ? parts : text;
}

/**
 * Renders paragraphs, bullet lists, and numbered lists cleanly.
 */
function renderMessageContent(content: string): React.ReactNode {
  const lines = content.split('\n');
  const elements: React.ReactNode[] = [];
  let currentList: { type: 'ul' | 'ol'; items: string[] } | null = null;
  let currentParagraph: string[] = [];

  const flushParagraph = (key: string | number) => {
    if (currentParagraph.length > 0) {
      elements.push(
        <p key={`p-${key}`} className="text-sm leading-relaxed text-slate-800 my-1.5">
          {currentParagraph.map((line, idx) => (
            <React.Fragment key={idx}>
              {renderFormattedInlineText(line)}
              {idx < currentParagraph.length - 1 && <br />}
            </React.Fragment>
          ))}
        </p>
      );
      currentParagraph = [];
    }
  };

  const flushList = (key: string | number) => {
    if (currentList) {
      if (currentList.type === 'ul') {
        elements.push(
          <ul key={`ul-${key}`} className="space-y-1.5 my-2 pl-4 list-disc list-outside text-slate-700 text-sm">
            {currentList.items.map((item, idx) => (
              <li key={idx} className="leading-relaxed">
                {renderFormattedInlineText(item)}
              </li>
            ))}
          </ul>
        );
      } else {
        elements.push(
          <ol key={`ol-${key}`} className="space-y-1.5 my-2 pl-4 list-decimal list-outside text-slate-700 text-sm">
            {currentList.items.map((item, idx) => (
              <li key={idx} className="leading-relaxed">
                {renderFormattedInlineText(item)}
              </li>
            ))}
          </ol>
        );
      }
      currentList = null;
    }
  };

  lines.forEach((line, idx) => {
    const trimmed = line.trim();
    if (!trimmed) {
      flushParagraph(idx);
      flushList(idx);
      return;
    }

    if (trimmed.startsWith('* ') || trimmed.startsWith('- ')) {
      flushParagraph(idx);
      const itemText = trimmed.replace(/^[*\-]\s+/, '');
      if (currentList && currentList.type === 'ul') {
        currentList.items.push(itemText);
      } else {
        flushList(idx);
        currentList = { type: 'ul', items: [itemText] };
      }
    } else if (/^\d+\.\s+/.test(trimmed)) {
      flushParagraph(idx);
      const itemText = trimmed.replace(/^\d+\.\s+/, '');
      if (currentList && currentList.type === 'ol') {
        currentList.items.push(itemText);
      } else {
        flushList(idx);
        currentList = { type: 'ol', items: [itemText] };
      }
    } else {
      flushList(idx);
      currentParagraph.push(trimmed);
    }
  });

  flushParagraph('final');
  flushList('final');

  return elements;
}

export const CareerMentorMessage: React.FC<CareerMentorMessageProps> = ({ message }) => {
  const isUser = message.sender === 'user';

  if (isUser) {
    return (
      <div className="flex justify-end items-end gap-2 my-2">
        <div className="max-w-[85%] bg-blue-600 text-white px-4 py-2.5 rounded-2xl rounded-br-xs shadow-sm">
          <p className="text-sm leading-relaxed whitespace-pre-wrap select-text">{message.text}</p>
        </div>
        <div className="w-7 h-7 rounded-full bg-blue-100 border border-blue-200 flex items-center justify-center text-blue-700 shrink-0">
          <User className="w-3.5 h-3.5" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex justify-start items-start gap-2.5 my-2">
      <div className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center text-white shrink-0 mt-0.5 shadow-xs">
        <Bot className="w-4 h-4" />
      </div>
      <div className="max-w-[88%] bg-white border border-slate-200/80 rounded-2xl rounded-tl-xs p-3.5 shadow-xs text-slate-800 select-text">
        <div className="text-xs font-semibold text-blue-700 mb-1 flex items-center gap-1.5">
          <span>AI Career Mentor</span>
        </div>
        <div className="text-slate-800 space-y-1">
          {renderMessageContent(message.text)}
        </div>
      </div>
    </div>
  );
};
