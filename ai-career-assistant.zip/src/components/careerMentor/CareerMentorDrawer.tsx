import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Send,
  Sparkles,
  Bot,
  RotateCcw,
  AlertCircle,
  HelpCircle,
  Briefcase,
  Target
} from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';
import { CareerMentorMessage, ChatMessage } from './CareerMentorMessage.tsx';

interface CareerMentorDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  messages: ChatMessage[];
  loading: boolean;
  error: string | null;
  onSendMessage: (message: string) => void;
  onRetry?: () => void;
  onClearHistory?: () => void;
}

const SUGGESTED_PROMPTS = [
  'What should I learn next?',
  'What am I missing for my target role?',
  'How can I improve my placement readiness?',
  'Help me plan my next steps'
];

export const CareerMentorDrawer: React.FC<CareerMentorDrawerProps> = ({
  isOpen,
  onClose,
  messages,
  loading,
  error,
  onSendMessage,
  onRetry,
  onClearHistory
}) => {
  const { user, skills } = useCareer();
  const [inputValue, setInputValue] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Auto-scroll on new message or loading change
  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, loading, isOpen]);

  // Focus input when opened
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  }, [isOpen]);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = inputValue.trim();
    if (!trimmed || loading) return;

    onSendMessage(trimmed);
    setInputValue('');
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleSuggestionClick = (prompt: string) => {
    if (loading) return;
    onSendMessage(prompt);
  };

  if (!isOpen) return null;

  const firstName = user?.name ? user.name.split(' ')[0] : 'there';
  const targetRole = user?.targetRole || 'Software Engineer';
  const verifiedCount = skills?.length || 0;

  return (
    <div className="fixed inset-0 z-[60] overflow-hidden flex justify-end" role="dialog" aria-modal="true" aria-label="AI Career Mentor Chat">
      {/* Semi-transparent backdrop on small screens */}
      <div
        className="fixed inset-0 bg-slate-900/30 backdrop-blur-xs transition-opacity sm:bg-slate-900/20"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Drawer Panel */}
      <div className="relative w-full sm:w-[440px] md:w-[480px] bg-slate-50 h-full shadow-2xl border-l border-slate-200 z-10 flex flex-col transition-transform duration-300">
        
        {/* Header */}
        <div className="px-5 py-3.5 bg-white border-b border-slate-200 flex items-center justify-between shrink-0 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-700 to-sky-500 text-white flex items-center justify-center shadow-xs">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm sm:text-base font-bold text-slate-900 leading-tight">
                  AI Career Mentor
                </h2>
                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-2xs font-semibold border border-emerald-200">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  Live
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Your personal career companion
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {messages.length > 0 && onClearHistory && (
              <button
                type="button"
                onClick={onClearHistory}
                title="Reset conversation"
                aria-label="Reset conversation"
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              title="Close chat"
              aria-label="Close AI Career Mentor drawer"
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors focus:ring-2 focus:ring-blue-400"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Live Context Banner */}
        <div className="px-5 py-2 bg-blue-50/80 border-b border-blue-100 flex items-center justify-between text-2xs text-blue-900 shrink-0">
          <div className="flex items-center gap-1.5 truncate">
            <Target className="w-3.5 h-3.5 text-blue-600 shrink-0" />
            <span className="font-medium text-slate-600">Target Role:</span>
            <span className="font-semibold text-blue-800 truncate">{targetRole}</span>
          </div>
          <div className="flex items-center gap-1 text-slate-600 shrink-0">
            <Briefcase className="w-3.5 h-3.5 text-slate-500" />
            <span>{verifiedCount} verified skill{verifiedCount === 1 ? '' : 's'}</span>
          </div>
        </div>

        {/* Messages Body */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
          
          {/* Welcome State (Zero Messages) */}
          {messages.length === 0 && (
            <div className="space-y-4 my-2">
              <div className="bg-white border border-blue-100 rounded-2xl p-4 shadow-xs">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs">
                    <Bot className="w-3.5 h-3.5" />
                  </div>
                  <span className="text-xs font-semibold text-blue-800">Mentor Greeting</span>
                </div>
                <p className="text-sm text-slate-800 leading-relaxed">
                  Hi {firstName}! I&apos;m your AI Career Mentor. I can help you understand your career progress, decide what to learn next, improve your resume, prepare for interviews, and stay consistent with your roadmap.
                </p>
                <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center gap-1.5 text-2xs text-slate-500">
                  <HelpCircle className="w-3.5 h-3.5 text-blue-500" />
                  <span>Grounded in your real profile, verified skills, and interview activity.</span>
                </div>
              </div>

              {/* Suggested Prompts */}
              <div>
                <p className="text-2xs font-semibold uppercase tracking-wider text-slate-500 mb-2 px-1">
                  Suggested Questions
                </p>
                <div className="flex flex-col gap-2">
                  {SUGGESTED_PROMPTS.map((prompt) => (
                    <button
                      key={prompt}
                      type="button"
                      onClick={() => handleSuggestionClick(prompt)}
                      className="text-left text-xs text-slate-700 bg-white hover:bg-blue-50/70 border border-slate-200 hover:border-blue-300 rounded-xl px-3.5 py-2.5 transition-all shadow-2xs hover:shadow-xs flex items-center justify-between group cursor-pointer"
                    >
                      <span className="font-medium group-hover:text-blue-900">{prompt}</span>
                      <Send className="w-3 h-3 text-slate-400 group-hover:text-blue-600 transition-colors shrink-0 ml-2" />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Render Conversation */}
          {messages.map((m) => (
            <CareerMentorMessage key={m.id} message={m} />
          ))}

          {/* Loading / Thinking Indicator */}
          {loading && (
            <div className="flex justify-start items-start gap-2.5 my-2">
              <div className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center text-white shrink-0 shadow-xs">
                <Bot className="w-4 h-4" />
              </div>
              <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-xs px-4 py-3 shadow-xs">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-600 font-medium">Mentor is thinking</span>
                  <div className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-bounce [animation-delay:-0.3s]" />
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-bounce [animation-delay:-0.15s]" />
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-bounce" />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Friendly Error State */}
          {error && (
            <div className="bg-rose-50 border border-rose-200 rounded-xl p-3.5 text-xs text-rose-800 flex items-start justify-between gap-2 shadow-xs">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium">{error}</p>
                  <p className="text-2xs text-rose-600 mt-0.5">Please check your connection or try again.</p>
                </div>
              </div>
              {onRetry && (
                <button
                  type="button"
                  onClick={onRetry}
                  className="px-2.5 py-1 bg-white border border-rose-300 hover:bg-rose-100/60 rounded-md font-medium text-rose-700 text-2xs shrink-0 cursor-pointer transition-colors"
                >
                  Retry
                </button>
              )}
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggested chips footer (when conversation has started) */}
        {messages.length > 0 && !loading && (
          <div className="px-4 py-1.5 bg-slate-100/70 border-t border-slate-200 flex items-center gap-1.5 overflow-x-auto text-2xs scrollbar-none shrink-0">
            <span className="text-slate-400 font-medium shrink-0">Quick ask:</span>
            {SUGGESTED_PROMPTS.slice(0, 3).map((prompt) => (
              <button
                key={prompt}
                type="button"
                onClick={() => handleSuggestionClick(prompt)}
                className="whitespace-nowrap px-2.5 py-1 bg-white hover:bg-blue-50 text-slate-600 hover:text-blue-700 border border-slate-200 hover:border-blue-300 rounded-full transition-colors cursor-pointer"
              >
                {prompt}
              </button>
            ))}
          </div>
        )}

        {/* Input Form */}
        <form onSubmit={handleSubmit} className="p-3.5 bg-white border-t border-slate-200 shrink-0">
          <div className="flex items-end gap-2 bg-slate-50 border border-slate-300 rounded-2xl p-1.5 focus-within:border-blue-500 focus-within:ring-2 focus-within:ring-blue-200 transition-all">
            <textarea
              ref={inputRef}
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask about skills, roadmap, resume, or interview prep..."
              rows={1}
              disabled={loading}
              className="w-full resize-none bg-transparent px-2.5 py-1 text-sm text-slate-800 placeholder-slate-400 focus:outline-none max-h-24 disabled:opacity-60"
            />
            <button
              type="submit"
              disabled={!inputValue.trim() || loading}
              aria-label="Send message"
              className="w-8 h-8 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 text-white disabled:text-slate-400 flex items-center justify-center shrink-0 transition-colors shadow-xs cursor-pointer disabled:cursor-not-allowed"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
          <div className="flex items-center justify-between mt-1.5 px-2 text-3xs text-slate-400">
            <span>Press Enter to send, Shift+Enter for new line</span>
            <span>Advisory AI Mentor</span>
          </div>
        </form>

      </div>
    </div>
  );
};
