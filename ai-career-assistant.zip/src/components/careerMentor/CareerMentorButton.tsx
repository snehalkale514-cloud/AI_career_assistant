import React from 'react';
import { Sparkles, MessageSquare } from 'lucide-react';

interface CareerMentorButtonProps {
  isOpen: boolean;
  onClick: () => void;
  unreadCount?: number;
}

export const CareerMentorButton: React.FC<CareerMentorButtonProps> = ({
  isOpen,
  onClick
}) => {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={isOpen ? 'Close AI Career Mentor' : 'Open AI Career Mentor'}
      className="fixed bottom-6 right-6 z-50 group flex items-center gap-2.5 bg-gradient-to-r from-blue-600 to-sky-600 hover:from-blue-700 hover:to-sky-700 text-white pl-3.5 pr-4 py-3 rounded-full shadow-lg hover:shadow-xl hover:scale-105 active:scale-95 transition-all duration-200 focus:outline-none focus:ring-4 focus:ring-blue-200 cursor-pointer border border-blue-400/30"
    >
      <div className="relative">
        <Sparkles className="w-5 h-5 text-blue-100 group-hover:rotate-12 transition-transform duration-300" />
        <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2 border-blue-600 animate-pulse" />
      </div>
      <span className="text-xs sm:text-sm font-semibold tracking-wide text-white">
        Career Mentor
      </span>
    </button>
  );
};
