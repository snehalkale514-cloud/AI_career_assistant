import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Camera,
  Mic,
  ShieldCheck,
  AlertTriangle,
  Play,
  Maximize2,
  CheckCircle2,
  Settings,
  HelpCircle,
  VideoOff,
  MicOff,
  Building2,
  Sparkles,
  Info,
  RefreshCw
} from 'lucide-react';
import {
  InterviewSessionConfig,
  InterviewType,
  InterviewDifficulty,
  interviewService
} from '../../services/interviewService.ts';
import { useCareer } from '../../context/CareerContext.tsx';
import { BackButton } from '../common/BackButton.tsx';

interface InterviewSetupScreenProps {
  onStartInterview: (config: InterviewSessionConfig, mediaStream: MediaStream | null) => void;
  onViewHistory: () => void;
  defaultRole?: string;
}

export const InterviewSetupScreen: React.FC<InterviewSetupScreenProps> = ({
  onStartInterview,
  onViewHistory,
  defaultRole = 'Software Engineer / Data Analyst'
}) => {
  const { user, skills, assessmentHistory, interviewHistory } = useCareer();
  const assessmentWeakTopics = useMemo(() => {
    const fromSkills = skills.flatMap((s) => s.weakTopics || []);
    const fromHistory = assessmentHistory.flatMap((h) => h.weakTopics || h.weakSkills || []);
    const fromInterview = interviewService
      .getInterviewPracticeWeaknesses(interviewHistory, user.targetRole)
      .filter((w) => !w.isResolved)
      .map((w) => w.topic);
    return Array.from(new Set([...fromSkills, ...fromHistory, ...fromInterview])).slice(0, 4);
  }, [skills, assessmentHistory, interviewHistory, user.targetRole]);

  // Session Configuration
  const [interviewType, setInterviewType] = useState<InterviewType>('Technical');
  const [difficulty, setDifficulty] = useState<InterviewDifficulty>('Medium');
  const [questionsCount, setQuestionsCount] = useState<number>(3);
  const [timeLimitMinutes, setTimeLimitMinutes] = useState<number>(15);
  const [targetCompany, setTargetCompany] = useState<string>('TCS');

  // Media Permissions & Live Preview
  const [cameraStatus, setCameraStatus] = useState<'prompt' | 'granted' | 'denied' | 'unavailable'>('prompt');
  const [micStatus, setMicStatus] = useState<'prompt' | 'granted' | 'denied' | 'unavailable'>('prompt');
  const [mediaStream, setMediaStream] = useState<MediaStream | null>(null);
  const [micLevel, setMicLevel] = useState<number>(0);
  const [permissionError, setPermissionError] = useState<string | null>(null);
  const [bypassHardwareForTesting, setBypassHardwareForTesting] = useState<boolean>(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const isNavigatingToLiveRef = useRef<boolean>(false);
  const isRequestingRef = useRef<boolean>(false);

  // Request permissions and start live preview
  const requestMediaPermissions = async () => {
    if (isRequestingRef.current) return;
    isRequestingRef.current = true;
    setPermissionError(null);

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraStatus('unavailable');
        setMicStatus('unavailable');
        setPermissionError('Camera access is not supported in this browser or environment.');
        return;
      }

      // Stop any existing stream tracks before requesting a fresh stream
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      }

      let stream: MediaStream | null = null;

      // Attempt standard combined video + audio request
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: 'user' },
          audio: true
        });
        setCameraStatus('granted');
        setMicStatus('granted');
      } catch (combinedErr: any) {
        console.warn('Combined media request threw, falling back to separate queries:', combinedErr);
        // Try getting video alone so candidate webcam can still display
        try {
          stream = await navigator.mediaDevices.getUserMedia({
            video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: 'user' }
          });
          setCameraStatus('granted');

          // Attempt audio separately without failing camera
          try {
            const audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
            const audioTrack = audioStream.getAudioTracks()[0];
            if (audioTrack && stream) {
              stream.addTrack(audioTrack);
              setMicStatus('granted');
            }
          } catch {
            setMicStatus('denied');
          }
        } catch (videoErr: any) {
          // If video also failed, re-throw videoErr so we accurately classify the camera issue
          throw videoErr;
        }
      }

      if (stream) {
        streamRef.current = stream;
        setMediaStream(stream);

        // Bind directly to video element if already mounted
        if (videoRef.current) {
          if (videoRef.current.srcObject !== stream) {
            videoRef.current.srcObject = stream;
          }
          videoRef.current.play().catch(() => {});
        }

        // Audio level visualizer
        const audioTracks = stream.getAudioTracks();
        if (audioTracks.length > 0) {
          try {
            const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
            if (AudioContextClass) {
              if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
                audioContextRef.current.close().catch(() => {});
              }
              const audioCtx = new AudioContextClass();
              audioContextRef.current = audioCtx;
              const source = audioCtx.createMediaStreamSource(stream);
              const analyser = audioCtx.createAnalyser();
              analyser.fftSize = 64;
              source.connect(analyser);

              const dataArray = new Uint8Array(analyser.frequencyBinCount);
              const updateAudioLevel = () => {
                analyser.getByteFrequencyData(dataArray);
                let sum = 0;
                for (let i = 0; i < dataArray.length; i++) sum += dataArray[i];
                const avg = sum / dataArray.length;
                setMicLevel(Math.min(100, Math.round((avg / 128) * 100)));
                animFrameRef.current = requestAnimationFrame(updateAudioLevel);
              };
              updateAudioLevel();
            }
          } catch (audioErr) {
            console.warn('AudioContext visualization not available:', audioErr);
          }
        }
      }
    } catch (err: any) {
      console.warn('Media permission issue:', err);
      const isIframe = window.self !== window.top;
      const errMsg = (err?.message || '').toLowerCase();

      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError' || err.name === 'SecurityError') {
        setCameraStatus('denied');
        setMicStatus('denied');
        if (isIframe && (errMsg.includes('permissions policy') || errMsg.includes('disallowed') || err.name === 'SecurityError')) {
          setPermissionError('Camera access is blocked by the Preview frame permissions policy. Open the app in a new browser window or allow camera access.');
        } else {
          setPermissionError('Camera access is blocked. Please allow camera permission in your browser settings and try again.');
        }
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        setCameraStatus('unavailable');
        setMicStatus('unavailable');
        setPermissionError('No camera was detected on this device.');
      } else if (err.name === 'NotReadableError' || err.name === 'TrackStartError') {
        setCameraStatus('unavailable');
        setMicStatus('unavailable');
        setPermissionError('Camera is currently in use by another application or unavailable.');
      } else if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraStatus('unavailable');
        setMicStatus('unavailable');
        setPermissionError('Camera access is not supported in this browser or environment.');
      } else {
        setCameraStatus('denied');
        setMicStatus('denied');
        setPermissionError(err.message || 'Camera access is blocked. Please allow camera permission in your browser settings and try again.');
      }
    } finally {
      isRequestingRef.current = false;
    }
  };

  // Video Ref Callback: immediately attaches stream when video element mounts
  const setVideoRef = (el: HTMLVideoElement | null) => {
    videoRef.current = el;
    if (el && mediaStream && cameraStatus === 'granted') {
      if (el.srcObject !== mediaStream) {
        el.srcObject = mediaStream;
      }
      el.play().catch(() => {});
    }
  };

  // Ensure stream stays bound whenever cameraStatus or mediaStream updates
  useEffect(() => {
    if (videoRef.current && mediaStream && cameraStatus === 'granted') {
      const el = videoRef.current;
      if (el.srcObject !== mediaStream) {
        el.srcObject = mediaStream;
      }
      el.play().catch(() => {});
    }
  }, [cameraStatus, mediaStream]);

  useEffect(() => {
    // Initial permission check attempt
    requestMediaPermissions();

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close().catch(() => {});
      }
      // If unmounting and not progressing to the live interview session, stop all tracks
      if (!isNavigatingToLiveRef.current && streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      }
    };
  }, []);

  const isReadyToStart = (cameraStatus === 'granted' && micStatus === 'granted') || bypassHardwareForTesting;

  const handleStart = () => {
    isNavigatingToLiveRef.current = true;
    onStartInterview(
      {
        type: interviewType,
        difficulty,
        questionsCount,
        timeLimitMinutes,
        targetCompany: interviewType === 'Company Specific' ? targetCompany : undefined,
        targetRole: user.targetRole,
        weakTopics: assessmentWeakTopics
      },
      mediaStream
    );
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Top Header Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-600 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5" />
              Proctored Technical Simulator
            </span>
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            Real-Time AI Technical Interview
          </h2>
          <p className="text-xs text-slate-500 max-w-xl">
            Experience a realistic recruiter technical assessment with live camera monitoring, voice speech recognition, anti-cheat tracking, and integrated coding compilers.
          </p>
        </div>

        <button
          onClick={onViewHistory}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-2xs transition-colors cursor-pointer"
        >
          <span>Past Interview Results</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Media Check & Hardware Verification */}
        <div className="lg:col-span-6 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Camera className="w-4 h-4 text-blue-600" />
              <h3 className="text-sm font-bold text-slate-900">Hardware &amp; System Verification</h3>
            </div>
            <span className="text-3xs font-mono font-medium px-2 py-0.5 rounded bg-slate-100 text-slate-600">
              Required Before Start
            </span>
          </div>

          {/* Camera Viewport Preview */}
          <div className="relative w-full aspect-video bg-slate-900 rounded-xl overflow-hidden border border-slate-800 shadow-inner flex items-center justify-center">
            {cameraStatus === 'granted' ? (
              <video
                ref={setVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover transform -scale-x-100"
              />
            ) : (
              <div className="p-6 text-center text-slate-300 space-y-3 max-w-sm">
                <VideoOff className="w-10 h-10 mx-auto text-slate-400" />
                <div className="space-y-1">
                  <p className="text-xs font-bold text-white">
                    {cameraStatus === 'denied'
                      ? 'Camera Access Blocked'
                      : permissionError?.includes('No camera')
                      ? 'No Camera Detected'
                      : cameraStatus === 'unavailable'
                      ? 'Camera Unavailable'
                      : 'Camera Initializing'}
                  </p>
                  <p className="text-3xs text-slate-300 leading-relaxed">
                    {permissionError || 'Requesting camera access to verify candidate presence for the interview session.'}
                  </p>
                </div>
                <div className="pt-1">
                  <button
                    type="button"
                    onClick={requestMediaPermissions}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Retry Camera</span>
                  </button>
                </div>
              </div>
            )}

            {/* Live Indicator Overlay */}
            {cameraStatus === 'granted' && (
              <div className="absolute top-3 left-3 flex items-center gap-2 bg-slate-900/80 backdrop-blur-xs px-2.5 py-1 rounded-full text-3xs font-mono text-emerald-400 border border-emerald-500/30">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>CAMERA ACTIVE</span>
              </div>
            )}
          </div>

          {/* Device Status Badges */}
          <div className="grid grid-cols-2 gap-3 text-xs">
            {/* Camera Status */}
            <div className={`p-3 rounded-xl border flex items-center gap-2.5 ${
              cameraStatus === 'granted'
                ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
                : 'bg-amber-50/70 border-amber-200 text-amber-900'
            }`}>
              <Camera className="w-4 h-4 shrink-0 text-current" />
              <div className="overflow-hidden">
                <span className="font-bold block truncate">Webcam Status</span>
                <span className="text-3xs block capitalize">
                  {cameraStatus === 'granted' ? 'Connected & Verified' : 'Action Required'}
                </span>
              </div>
            </div>

            {/* Microphone Status */}
            <div className={`p-3 rounded-xl border flex items-center gap-2.5 ${
              micStatus === 'granted'
                ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
                : 'bg-amber-50/70 border-amber-200 text-amber-900'
            }`}>
              <Mic className="w-4 h-4 shrink-0 text-current" />
              <div className="overflow-hidden">
                <span className="font-bold block truncate">Microphone Status</span>
                <span className="text-3xs block capitalize">
                  {micStatus === 'granted' ? 'Audio Stream Ready' : 'Action Required'}
                </span>
              </div>
            </div>
          </div>

          {/* Microphone Live Audio Level Bar */}
          {micStatus === 'granted' && (
            <div className="space-y-1.5 p-3 rounded-xl bg-slate-50 border border-slate-200">
              <div className="flex justify-between items-center text-xs">
                <span className="text-2xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <Mic className="w-3.5 h-3.5 text-blue-600" />
                  Live Audio Input Level (Say something to test)
                </span>
                <span className="font-mono text-3xs font-bold text-slate-600">{micLevel}%</span>
              </div>
              <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-emerald-500 h-full rounded-full transition-all duration-75"
                  style={{ width: `${Math.max(5, micLevel)}%` }}
                />
              </div>
            </div>
          )}

          {/* Error Message if Denied */}
          {permissionError && (
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-semibold">{permissionError}</p>
                <button
                  type="button"
                  onClick={requestMediaPermissions}
                  className="text-2xs font-bold text-blue-700 underline hover:text-blue-900 cursor-pointer"
                >
                  Retry Requesting Permissions
                </button>
              </div>
            </div>
          )}

          {/* Hardware Bypass for devices without physical webcam */}
          <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-2xs text-slate-500">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={bypassHardwareForTesting}
                onChange={(e) => setBypassHardwareForTesting(e.target.checked)}
                className="rounded text-blue-600"
              />
              <span>Allow simulator testing mode (if physical webcam is unavailable)</span>
            </label>
          </div>
        </div>

        {/* Right Column: Interview Session Configuration */}
        <div className="lg:col-span-6 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Settings className="w-4 h-4 text-blue-600" />
              <h3 className="text-sm font-bold text-slate-900">Session Setup &amp; Track Selection</h3>
            </div>
            <span className="text-3xs text-slate-400 font-medium">Config</span>
          </div>

          {/* Interview Type Selector */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-800">
              1. Select Interview Track
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {(['Technical', 'Coding', 'SQL', 'HR', 'Company Specific'] as InterviewType[]).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setInterviewType(t)}
                  className={`p-3 rounded-xl border text-xs font-semibold text-left transition-all cursor-pointer ${
                    interviewType === t
                      ? 'bg-blue-50/70 border-blue-400 text-blue-900 shadow-2xs ring-1 ring-blue-300'
                      : 'bg-slate-50/50 border-slate-200 text-slate-700 hover:border-slate-300'
                  }`}
                >
                  <span className="block">{t}</span>
                  <span className="text-3xs font-normal text-slate-500 block mt-0.5">
                    {t === 'Coding' ? 'Live IDE compiler' : t === 'SQL' ? 'Query formulation' : t === 'HR' ? 'Behavioral & STAR' : t === 'Company Specific' ? 'Target employer' : 'Core CS theory'}
                  </span>
                </button>
              ))}
            </div>

            {/* Target Assessment Weak Areas */}
            {assessmentWeakTopics.length > 0 && (
              <div className="mt-3 p-3 bg-amber-50/70 rounded-xl border border-amber-200/80 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-3xs font-bold uppercase tracking-wider text-amber-900 flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-amber-600" />
                    Target Identified Assessment Weak Areas
                  </span>
                  <span className="text-3xs text-amber-800 font-semibold bg-amber-100/90 px-1.5 py-0.5 rounded">
                    From Diagnostic
                  </span>
                </div>
                <p className="text-3xs text-amber-800">
                  Click a weak topic from your skill assessments to tailor this interview session:
                </p>
                <div className="flex flex-wrap gap-1.5 pt-0.5">
                  {assessmentWeakTopics.map((topic) => (
                    <button
                      key={topic}
                      type="button"
                      onClick={() => {
                        const low = topic.toLowerCase();
                        if (low.includes('sql')) setInterviewType('SQL');
                        else if (low.includes('problem') || low.includes('coding') || low.includes('dsa')) setInterviewType('Coding');
                        else setInterviewType('Technical');
                      }}
                      className="px-2 py-0.5 rounded-md bg-white border border-amber-300 text-amber-900 text-3xs font-medium hover:bg-amber-100 transition-colors flex items-center gap-1 cursor-pointer shadow-2xs"
                    >
                      <span>🎯 {topic}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Company Specific Target Dropdown */}
          {interviewType === 'Company Specific' && (
            <div className="p-3.5 bg-blue-50/40 rounded-xl border border-blue-200/80 space-y-2">
              <label className="block text-xs font-bold text-blue-950 flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5 text-blue-600" />
                Select Target Employer Pattern
              </label>
              <select
                value={targetCompany}
                onChange={(e) => setTargetCompany(e.target.value)}
                className="w-full text-xs bg-white border border-slate-200 rounded-lg p-2 font-medium text-slate-800"
              >
                <option value="TCS">Tata Consultancy Services (TCS Digital / NQT)</option>
                <option value="Infosys">Infosys (Specialist Programmer / DSE)</option>
                <option value="Amazon">Amazon (SDE 1 - Leadership Principles)</option>
                <option value="Google">Google (Software Engineer Core Algorithms)</option>
                <option value="Accenture">Accenture (Advanced Application Tech)</option>
                <option value="ThoughtWorks">ThoughtWorks (Consultant Developer)</option>
              </select>
              <span className="text-3xs text-blue-700 block">
                Generates questions formatted to match this employer's recruitment rounds.
              </span>
            </div>
          )}

          {/* Difficulty & Question Parameters */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Difficulty */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-800">
                2. Difficulty Level
              </label>
              <select
                value={difficulty}
                onChange={(e) => setDifficulty(e.target.value as InterviewDifficulty)}
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2 font-medium text-slate-800 focus:outline-hidden focus:border-blue-600"
              >
                <option value="Easy">Easy (Campus Entry Level)</option>
                <option value="Medium">Medium (Standard SDE 1)</option>
                <option value="Hard">Hard (Product Core / High Package)</option>
              </select>
            </div>

            {/* Time Limit */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-800">
                3. Total Time Limit
              </label>
              <select
                value={timeLimitMinutes}
                onChange={(e) => setTimeLimitMinutes(parseInt(e.target.value))}
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2 font-medium text-slate-800 focus:outline-hidden focus:border-blue-600"
              >
                <option value={10}>10 Minutes (Rapid Fire)</option>
                <option value={15}>15 Minutes (Standard Round)</option>
                <option value={30}>30 Minutes (Deep Technical)</option>
                <option value={45}>45 Minutes (Full Coding Simulation)</option>
              </select>
            </div>
          </div>

          {/* Number of Questions */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-800">4. Question Quota:</span>
              <span className="font-mono font-bold text-blue-600">{questionsCount} Questions</span>
            </div>
            <div className="flex gap-2">
              {[3, 5, 8].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => setQuestionsCount(num)}
                  className={`flex-1 py-1.5 rounded-lg border text-xs font-semibold cursor-pointer ${
                    questionsCount === num
                      ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {num} Questions
                </button>
              ))}
            </div>
          </div>

          {/* Proctored Rules Notice */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-3xs text-slate-600 space-y-2">
            <span className="font-bold text-slate-800 block text-2xs flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-blue-600" />
              Proctored Environment Rules &amp; Anti-Cheating Protocol:
            </span>
            <ul className="list-disc pl-4 space-y-1 text-slate-500">
              <li><strong>Camera &amp; Microphone:</strong> Must stay active throughout the session (streams processed locally in-browser).</li>
              <li><strong>Fullscreen Mode:</strong> Requested upon start. Exiting fullscreen mode triggers a proctoring warning.</li>
              <li><strong>Tab / Focus Monitoring:</strong> Switching tabs or leaving the interview window triggers integrity warnings.</li>
              <li><strong>Strict 3-Warning Limit:</strong> A 4th violation will immediately <strong>terminate the interview</strong> without generating a score.</li>
              <li><strong>Sequential Submission:</strong> Questions move forward sequentially; submitted answers are permanently evaluated.</li>
            </ul>
            <div className="pt-1 border-t border-slate-200 text-slate-500 text-3xs leading-relaxed italic">
              <strong>Technical Note:</strong> Proctored mode monitors browser-visible events such as leaving the interview page, exiting fullscreen, and interrupting camera/microphone access. Browser security prevents a website from completely blocking users from closing the browser or using another device.
            </div>
          </div>

          {/* Start Interview Action */}
          <div className="pt-2">
            <button
              onClick={handleStart}
              disabled={!isReadyToStart}
              className="w-full py-3.5 rounded-xl font-bold text-sm text-white bg-blue-600 hover:bg-blue-700 shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>Start Interview Session</span>
            </button>
            {!isReadyToStart && (
              <p className="text-3xs text-center text-amber-700 mt-2">
                * Please grant camera and microphone access above or enable simulator testing mode to begin.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
