import React, { useState } from 'react';
import {
  Clock,
  Award,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  X,
  Calendar,
  ChevronRight,
  Code2
} from 'lucide-react';
import { InterviewHistoryItem } from '../../types.ts';

interface InterviewHistoryModalProps {
  history: InterviewHistoryItem[];
  onClose: () => void;
  onStartNew: () => void;
}

export const InterviewHistoryModal: React.FC<InterviewHistoryModalProps> = ({
  history,
  onClose,
  onStartNew
}) => {
  const [selectedItem, setSelectedItem] = useState<InterviewHistoryItem | null>(history[0] || null);

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col shadow-2xl border border-slate-200">
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              Proctored Mock Interview History &amp; Diagnostics
            </h3>
            <p className="text-2xs text-slate-500">
              Review completed technical rounds, scores, coding test results, and integrity audits.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body: Split List & Detail */}
        <div className="flex-1 overflow-hidden grid grid-cols-1 md:grid-cols-12">
          {/* Left: History Items List */}
          <div className="md:col-span-5 border-r border-slate-100 p-4 overflow-y-auto space-y-2.5 max-h-[70vh]">
            {history.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs">
                No previous interview sessions recorded yet.
              </div>
            ) : (
              history.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setSelectedItem(item)}
                  className={`p-3.5 rounded-xl border text-xs cursor-pointer transition-all ${
                    selectedItem?.id === item.id
                      ? 'bg-blue-50/70 border-blue-300 shadow-2xs'
                      : 'bg-white border-slate-200/90 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-slate-900">{item.interviewType}</span>
                    <span className="font-mono font-bold text-blue-700">{item.score}%</span>
                  </div>
                  <div className="flex items-center justify-between text-3xs text-slate-500">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {item.date}
                    </span>
                    <span className={`font-semibold px-1.5 py-0.5 rounded ${
                      item.status === 'Terminated'
                        ? 'text-rose-700 bg-rose-50 border border-rose-200'
                        : item.status === 'Exceptional'
                        ? 'text-emerald-700 bg-emerald-50 border border-emerald-200'
                        : 'text-blue-700 bg-blue-50 border border-blue-200'
                    }`}>
                      {item.status}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Right: Selected Detail View */}
          <div className="md:col-span-7 p-6 overflow-y-auto max-h-[70vh] space-y-5">
            {selectedItem ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div>
                    <h4 className="text-base font-bold text-slate-900">{selectedItem.interviewType} Mock Assessment</h4>
                    <span className="text-2xs text-slate-500">{selectedItem.role} · {selectedItem.date}</span>
                  </div>
                  <div className="text-right">
                    <span className={`text-2xl font-mono font-extrabold ${
                      selectedItem.status === 'Terminated' ? 'text-rose-600' : 'text-blue-600'
                    }`}>
                      {selectedItem.score}%
                    </span>
                    <span className={`text-3xs block font-bold uppercase ${
                      selectedItem.status === 'Terminated' ? 'text-rose-700' : 'text-emerald-700'
                    }`}>
                      {selectedItem.status}
                    </span>
                  </div>
                </div>

                {/* Score Breakdown Pills */}
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-3xs text-slate-400 block font-bold uppercase">Technical Depth</span>
                    <span className="font-mono font-bold text-slate-900">{selectedItem.categoryBreakdown.technical}%</span>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-3xs text-slate-400 block font-bold uppercase">Communication</span>
                    <span className="font-mono font-bold text-slate-900">{selectedItem.categoryBreakdown.communication}%</span>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-3xs text-slate-400 block font-bold uppercase">Confidence</span>
                    <span className="font-mono font-bold text-slate-900">{selectedItem.categoryBreakdown.confidence}%</span>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-3xs text-slate-400 block font-bold uppercase">Completeness</span>
                    <span className="font-mono font-bold text-slate-900">{selectedItem.categoryBreakdown.completeness}%</span>
                  </div>
                </div>

                {/* Feedback note */}
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5 text-xs">
                  <span className="font-bold text-slate-900 block">Recruiter Evaluation Summary:</span>
                  <p className="text-slate-600 leading-relaxed">{selectedItem.feedback}</p>
                </div>

                {/* Integrity audit line */}
                {selectedItem.integrityWarnings !== undefined && (
                  <div className="p-3 rounded-lg bg-amber-50 border border-amber-200 text-2xs text-amber-900 flex items-center justify-between">
                    <span>Proctored Integrity Warnings:</span>
                    <span className="font-mono font-bold">{selectedItem.integrityWarnings}</span>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-8 text-center text-slate-400 text-xs">
                Select an interview record from the left to view detailed metrics.
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-600 hover:text-slate-800 cursor-pointer"
          >
            Close
          </button>
          <button
            onClick={() => {
              onClose();
              onStartNew();
            }}
            className="px-4 py-2 rounded-lg text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 shadow-xs cursor-pointer"
          >
            Start New Real Interview
          </button>
        </div>
      </div>
    </div>
  );
};
