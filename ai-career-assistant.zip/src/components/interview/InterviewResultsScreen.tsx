import React from 'react';
import {
  Award,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Code2,
  MessageSquare,
  ShieldAlert,
  ArrowRight,
  RotateCcw,
  BookOpen,
  Sparkles,
  Layers,
  ChevronDown
} from 'lucide-react';
import { InterviewFinalReport } from '../../services/interviewService.ts';
import { ProgressBar } from '../common/ProgressBar.tsx';
import { BackButton } from '../common/BackButton.tsx';

interface InterviewResultsScreenProps {
  report: InterviewFinalReport;
  onRestart: () => void;
  onViewHistory: () => void;
}

export const InterviewResultsScreen: React.FC<InterviewResultsScreenProps> = ({
  report,
  onRestart,
  onViewHistory
}) => {
  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/dashboard" />
      </div>

      {/* Top Banner Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Interview Completed &amp; Evaluated
              </span>
            </div>
            <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">
              Official Interview Performance Report
            </h2>
            <p className="text-xs text-slate-500">
              Track: <strong>{report.interviewType}</strong> · Level: <strong>{report.difficulty}</strong> · {report.date}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onRestart}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>New Mock Session</span>
            </button>
            <button
              onClick={onViewHistory}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
            >
              <span>Interview History</span>
            </button>
          </div>
        </div>

        {/* Hero Score Gauge Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          {/* Big Overall Score Ring */}
          <div className="md:col-span-4 text-center border-b md:border-b-0 md:border-r border-slate-100 pb-6 md:pb-0 md:pr-6 space-y-2">
            <span className="text-3xs font-bold uppercase tracking-wider text-slate-400">
              Overall Candidate Score
            </span>
            <div className="relative w-36 h-36 mx-auto flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                <path
                  className="text-slate-100"
                  strokeWidth="3.5"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
                <path
                  className={report.overallScore >= 75 ? 'text-emerald-600' : 'text-amber-500'}
                  strokeDasharray={`${report.overallScore}, 100`}
                  strokeWidth="3.5"
                  strokeLinecap="round"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-4xl font-mono font-extrabold text-slate-900 tabular-nums">
                  {report.overallScore}%
                </span>
                <span className={`text-3xs font-bold uppercase ${report.overallScore >= 75 ? 'text-emerald-700' : 'text-amber-700'}`}>
                  {report.overallScore >= 85 ? 'Exceptional' : report.overallScore >= 70 ? 'Passed' : 'Review Needed'}
                </span>
              </div>
            </div>
            <p className="text-2xs text-slate-500">
              Session duration: <strong>{Math.floor(report.timeTakenSeconds / 60)}m {report.timeTakenSeconds % 60}s</strong>
            </p>
          </div>

          {/* Detailed Category Bars */}
          <div className="md:col-span-8 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Multi-Dimensional Competency Breakdown
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <div className="flex justify-between text-2xs font-semibold mb-1">
                  <span className="text-slate-700">Technical Depth</span>
                  <span className="font-mono font-bold text-slate-900">{report.technicalScore}%</span>
                </div>
                <ProgressBar value={report.technicalScore} size="sm" color="blue" showValueText={false} />
              </div>

              <div>
                <div className="flex justify-between text-2xs font-semibold mb-1">
                  <span className="text-slate-700">Communication &amp; Clarity</span>
                  <span className="font-mono font-bold text-slate-900">{report.communicationScore}%</span>
                </div>
                <ProgressBar value={report.communicationScore} size="sm" color="emerald" showValueText={false} />
              </div>

              <div>
                <div className="flex justify-between text-2xs font-semibold mb-1">
                  <span className="text-slate-700">Problem Solving &amp; Logic</span>
                  <span className="font-mono font-bold text-slate-900">{report.problemSolvingScore}%</span>
                </div>
                <ProgressBar value={report.problemSolvingScore} size="sm" color="indigo" showValueText={false} />
              </div>

              <div>
                <div className="flex justify-between text-2xs font-semibold mb-1">
                  <span className="text-slate-700">Coding Execution Accuracy</span>
                  <span className="font-mono font-bold text-slate-900">{report.codingScore}%</span>
                </div>
                <ProgressBar value={report.codingScore} size="sm" color="indigo" showValueText={false} />
              </div>

              <div>
                <div className="flex justify-between text-2xs font-semibold mb-1">
                  <span className="text-slate-700">Confidence &amp; Professional Tone</span>
                  <span className="font-mono font-bold text-slate-900">{report.confidenceScore}%</span>
                </div>
                <ProgressBar value={report.confidenceScore} size="sm" color="amber" showValueText={false} />
              </div>

              <div>
                <div className="flex justify-between text-2xs font-semibold mb-1">
                  <span className="text-slate-700">Time Management</span>
                  <span className="font-mono font-bold text-slate-900">{report.timeManagementScore}%</span>
                </div>
                <ProgressBar value={report.timeManagementScore} size="sm" color="blue" showValueText={false} />
              </div>
            </div>
          </div>
        </div>

        {/* Quick Highlights Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <span className="text-3xs text-slate-400 block font-bold uppercase">Questions Answered</span>
            <span className="text-lg font-mono font-bold text-slate-900">{report.questionsAnswered}</span>
          </div>

          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <span className="text-3xs text-slate-400 block font-bold uppercase">Questions Skipped</span>
            <span className="text-lg font-mono font-bold text-slate-900">{report.questionsSkipped}</span>
          </div>

          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <span className="text-3xs text-slate-400 block font-bold uppercase">Coding Solved</span>
            <span className="text-lg font-mono font-bold text-emerald-700">{report.codingProblemsSolved}</span>
          </div>

          <div className={`p-3 rounded-xl border ${report.integrityWarnings > 0 ? 'bg-amber-50 border-amber-200' : 'bg-slate-50 border-slate-200'}`}>
            <span className="text-3xs text-slate-400 block font-bold uppercase">Integrity Warnings</span>
            <span className={`text-lg font-mono font-bold ${report.integrityWarnings > 0 ? 'text-amber-700' : 'text-slate-900'}`}>
              {report.integrityWarnings}
            </span>
          </div>
        </div>
      </div>

      {/* Integrity Audit Report if warnings occurred */}
      {report.integrityEvents.length > 0 && (
        <div className="bg-amber-50/70 border border-amber-200 p-5 rounded-2xl space-y-3 text-xs">
          <div className="flex items-center gap-2 text-amber-900 font-bold">
            <ShieldAlert className="w-4 h-4 text-amber-600" />
            <span>Interview Integrity Audit Log ({report.integrityEvents.length} recorded events)</span>
          </div>
          <p className="text-3xs text-amber-800">
            The candidate exited fullscreen, switched browser tabs, or attempted clipboard paste operations during the proctored window.
          </p>
          <div className="space-y-1.5 max-h-36 overflow-y-auto">
            {report.integrityEvents.map((evt, idx) => (
              <div key={idx} className="p-2 bg-white/80 rounded-lg border border-amber-200 text-3xs flex items-center justify-between">
                <span className="font-mono text-amber-900">[{evt.timestamp}] {evt.description}</span>
                <span className="font-semibold uppercase text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded">{evt.type}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Strengths & Improvement Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-emerald-700 font-bold text-xs">
            <CheckCircle2 className="w-4 h-4" />
            <span>Key Strengths Observed</span>
          </div>
          <ul className="text-xs text-slate-700 space-y-2">
            {report.strengths.map((str, idx) => (
              <li key={idx} className="p-2.5 rounded-lg bg-emerald-50/50 border border-emerald-100 flex items-start gap-2">
                <span className="text-emerald-600 font-bold">•</span>
                <span>{str}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-amber-700 font-bold text-xs">
            <AlertTriangle className="w-4 h-4" />
            <span>Areas to Strengthen Before Placement Drives</span>
          </div>
          <ul className="text-xs text-slate-700 space-y-2">
            {report.areasToImprove.map((gap, idx) => (
              <li key={idx} className="p-2.5 rounded-lg bg-amber-50/50 border border-amber-200/70 flex items-start gap-2">
                <span className="text-amber-600 font-bold">•</span>
                <span>{gap}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Suggested Follow-up Topics & Practice */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-blue-600" />
          Recommended Next Topics &amp; Practice Questions
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div className="space-y-2">
            <span className="text-3xs font-bold uppercase tracking-wider text-slate-400 block">
              Core Technical Topics
            </span>
            <div className="space-y-1.5">
              {report.recommendedTopics.map((topic, i) => (
                <div key={i} className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 font-semibold text-slate-800">
                  {topic}
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <span className="text-3xs font-bold uppercase tracking-wider text-slate-400 block">
              Follow-up Interview Scenarios
            </span>
            <div className="space-y-1.5">
              {report.suggestedPracticeQuestions.map((q, i) => (
                <div key={i} className="p-2.5 rounded-lg bg-blue-50/50 border border-blue-200 font-medium text-blue-950">
                  {q}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Question-by-Question Submission Log */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
          <Layers className="w-4 h-4 text-blue-600" />
          Detailed Question Submissions &amp; Recruiter Review
        </h3>

        <div className="space-y-3">
          {report.questionSubmissions.map((sub, idx) => (
            <div key={idx} className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-3 text-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-2">
                <span className="font-bold text-slate-900">
                  Q{idx + 1}: {sub.questionTitle}
                </span>
                <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-800">
                  Score: {sub.score}%
                </span>
              </div>

              {sub.type === 'Coding' && sub.codeAnswer ? (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-3xs font-mono text-slate-500">
                    <span>Language: <strong>{sub.codeAnswer.language}</strong></span>
                    <span>·</span>
                    <span>Test Cases: <strong>{sub.codeAnswer.testCasesPassed}/{sub.codeAnswer.totalTestCases} Passed</strong></span>
                  </div>
                  <pre className="p-3 bg-slate-950 text-emerald-400 rounded-lg font-mono text-3xs overflow-x-auto max-h-40">
                    {sub.codeAnswer.code}
                  </pre>
                </div>
              ) : (
                <div className="space-y-1">
                  <span className="text-3xs font-bold uppercase tracking-wider text-slate-400 block">Candidate Answer:</span>
                  <p className="p-3 bg-white rounded-lg border border-slate-200 text-slate-700 italic leading-relaxed">
                    {sub.answerText || '(No answer text recorded)'}
                  </p>
                </div>
              )}

              <p className="text-3xs text-slate-600 pt-1">
                <strong>Feedback:</strong> {sub.feedback}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
