import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Camera,
  Mic,
  MicOff,
  Video,
  VideoOff,
  Clock,
  ShieldAlert,
  Maximize2,
  Minimize2,
  Play,
  Send,
  Code2,
  Terminal,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  LogOut,
  Sparkles,
  ChevronRight,
  Radio,
  FileCode,
  RotateCcw,
  Info
} from 'lucide-react';
import {
  LiveQuestion,
  InterviewSessionConfig,
  QuestionSubmission,
  IntegrityViolationEvent,
  interviewService,
  CodeExecutionResult
} from '../../services/interviewService.ts';
import { useInterviewProctoring } from '../../hooks/useInterviewProctoring.ts';

interface LiveInterviewScreenProps {
  config: InterviewSessionConfig;
  initialMediaStream: MediaStream | null;
  onFinishInterview: (submissions: QuestionSubmission[], timeTakenSeconds: number, integrityEvents: IntegrityViolationEvent[]) => void;
  onCancelInterview: () => void;
  onTerminateInterview?: (data: { reason: string; warningCount: number; integrityEvents: IntegrityViolationEvent[] }) => void;
}

export const LiveInterviewScreen: React.FC<LiveInterviewScreenProps> = ({
  config,
  initialMediaStream,
  onFinishInterview,
  onCancelInterview,
  onTerminateInterview
}) => {
  // Questions list
  const [questions] = useState<LiveQuestion[]>(() => interviewService.getQuestionsForSession(config));
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const currentQuestion = questions[currentIndex] || questions[0];

  const videoRef = useRef<HTMLVideoElement | null>(null);

  const handleTerminateInterview = useCallback(
    (data: {
      reason: string;
      warningCount: number;
      integrityEvents: IntegrityViolationEvent[];
    }) => {
      onTerminateInterview?.(data);
    },
    [onTerminateInterview]
  );

  // Centralized Browser Proctoring Hook
  const {
    mediaStream,
    isCameraActive,
    isMicActive,
    mediaError,
    isFullscreen,
    warningCount,
    isTerminated,
    terminationReason,
    integrityEvents,
    activeWarningModal,
    latestWarningBanner,
    faceDetectorStatus,
    faceDetectorMessage,
    isFacePresent,
    requestFullscreen,
    exitFullscreen,
    retryCamera,
    acknowledgeWarning,
    terminateSession,
    recordViolation
  } = useInterviewProctoring({
    isActive: true,
    initialMediaStream,
    videoElementRef: videoRef,
    onTerminate: handleTerminateInterview
  });

  useEffect(() => {
    if (activeWarningModal) {
      console.debug('[LiveInterviewScreen] Active warning modal displayed:', activeWarningModal.type, 'Warning count:', activeWarningModal.count);
    }
  }, [activeWarningModal]);

  const [showExitConfirm, setShowExitConfirm] = useState<boolean>(false);

  // Timer State (in seconds)
  const totalSeconds = config.timeLimitMinutes * 60;
  const [secondsRemaining, setSecondsRemaining] = useState<number>(totalSeconds);
  const [timeTakenSeconds, setTimeTakenSeconds] = useState<number>(0);

  // Submissions Accumulator
  const [submissions, setSubmissions] = useState<QuestionSubmission[]>([]);
  const [showHint, setShowHint] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Verbal / Text Answer State
  const [answerText, setAnswerText] = useState<string>('');
  const [isListening, setIsListening] = useState<boolean>(false);
  const [speechStatus, setSpeechStatus] = useState<string>('Ready for voice or text response');
  const speechRecognitionRef = useRef<any>(null);

  // Coding Interview State (for Coding questions)
  const isCodingQuestion = currentQuestion?.type === 'Coding';
  const [codingLanguage, setCodingLanguage] = useState<'python' | 'javascript' | 'java' | 'cpp'>('javascript');
  const [codeContent, setCodeContent] = useState<string>(() => currentQuestion?.starterCode?.javascript || currentQuestion?.starterCode?.python || '');
  const [executionResult, setExecutionResult] = useState<CodeExecutionResult | null>(null);
  const [isExecutingCode, setIsExecutingCode] = useState<boolean>(false);
  const [activeCodeTab, setActiveCodeTab] = useState<'testcases' | 'console'>('testcases');

  // Video ref callback to immediately attach stream when video element mounts
  const setVideoRef = (el: HTMLVideoElement | null) => {
    videoRef.current = el;
    if (el && mediaStream && isCameraActive && !isTerminated) {
      if (el.srcObject !== mediaStream) {
        el.srcObject = mediaStream;
      }
      el.play().catch(() => {});
    }
  };

  // Bind video element to media stream on updates
  useEffect(() => {
    if (videoRef.current && mediaStream && isCameraActive && !isTerminated) {
      const el = videoRef.current;
      if (el.srcObject !== mediaStream) {
        el.srcObject = mediaStream;
      }
      el.play().catch(() => {});
    }
  }, [mediaStream, isCameraActive, isTerminated]);

  // Stop speech recognition when session is terminated
  useEffect(() => {
    if (isTerminated && speechRecognitionRef.current) {
      try {
        speechRecognitionRef.current.stop();
      } catch {}
      setIsListening(false);
    }
  }, [isTerminated]);

  // Web Speech API: Voice Answers
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        setIsListening(true);
        setSpeechStatus('Listening to candidate voice...');
      };

      recognition.onresult = (event: any) => {
        let finalTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcript + ' ';
          }
        }
        if (finalTranscript) {
          setAnswerText(prev => (prev ? `${prev.trim()} ${finalTranscript.trim()}` : finalTranscript.trim()));
          setSpeechStatus('Speech recognized & transcribed.');
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        setIsListening(false);
        setSpeechStatus(event.error === 'not-allowed' ? 'Microphone permission required for speech' : 'Speech input paused');
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      speechRecognitionRef.current = recognition;
    } else {
      setSpeechStatus('Voice transcription not supported in this browser. Please use text answer formulation.');
    }

    return () => {
      if (speechRecognitionRef.current) {
        speechRecognitionRef.current.stop();
      }
    };
  }, []);

  const toggleVoiceListening = () => {
    if (!speechRecognitionRef.current) return;
    if (isListening) {
      speechRecognitionRef.current.stop();
      setIsListening(false);
    } else {
      try {
        speechRecognitionRef.current.start();
      } catch (err) {
        console.warn('Error starting speech recognition:', err);
      }
    }
  };

  // Switch starter code when question or language changes
  useEffect(() => {
    if (isCodingQuestion && currentQuestion.starterCode) {
      setCodeContent(currentQuestion.starterCode[codingLanguage] || '');
      setExecutionResult(null);
    } else {
      setAnswerText('');
    }
    setShowHint(false);
  }, [currentIndex, codingLanguage, isCodingQuestion]);

  // Master Countdown Timer
  useEffect(() => {
    if (isTerminated) return;
    const interval = setInterval(() => {
      setSecondsRemaining(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          handleTimeExpired();
          return 0;
        }
        return prev - 1;
      });
      setTimeTakenSeconds(t => t + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [isTerminated]);

  const formatTimer = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleTimeExpired = () => {
    recordViolation('window_blur', 'Interview time limit expired. Auto-submitting active session.');
    finishSession();
  };

  // Run Code in Sandbox
  const handleRunCode = async () => {
    if (!isCodingQuestion) return;
    setIsExecutingCode(true);
    setActiveCodeTab('testcases');
    const res = await interviewService.executeCode({
      language: codingLanguage,
      code: codeContent,
      question: currentQuestion
    });
    setExecutionResult(res);
    setIsExecutingCode(false);
  };

  // Submit Answer & Move Forward (cannot go backward)
  const handleSubmitAnswer = async () => {
    setIsSubmitting(true);

    if (speechRecognitionRef.current && isListening) {
      speechRecognitionRef.current.stop();
    }

    let submission: QuestionSubmission;

    if (isCodingQuestion) {
      // Evaluate code test cases
      const runRes = executionResult || await interviewService.executeCode({
        language: codingLanguage,
        code: codeContent,
        question: currentQuestion
      });

      const passedRatio = runRes.totalTestCases > 0 ? runRes.testCasesPassed / runRes.totalTestCases : 1;
      const score = Math.round(passedRatio * 100);

      submission = {
        questionId: currentQuestion.id,
        questionTitle: currentQuestion.title,
        type: 'Coding',
        codeAnswer: {
          language: codingLanguage,
          code: codeContent,
          testCasesPassed: runRes.testCasesPassed,
          totalTestCases: runRes.totalTestCases,
          status: runRes.status
        },
        score,
        feedback: runRes.status === 'Accepted'
          ? (codingLanguage === 'javascript'
              ? 'Runtime execution: Solution passed all assertions with optimal time complexity!'
              : 'Static analysis: Solution demonstrated structurally consistent algorithm logic.')
          : (codingLanguage === 'javascript'
              ? `Runtime execution: Solution passed ${runRes.testCasesPassed} of ${runRes.totalTestCases} test cases.`
              : 'Static analysis: Incomplete algorithmic structure or missing loop/parameter logic detected.'),
        strengths: ['Structured code layout', 'Clean naming conventions'],
        areasToImprove: ['Address edge cases with empty or null bounds']
      };
    } else {
      // Evaluate verbal/written answer
      const evalResult = interviewService.evaluateSpokenOrTextAnswer({
        question: currentQuestion,
        answer: answerText,
        interviewType: currentQuestion.type,
        targetRole: config.targetRole
      });

      submission = {
        questionId: currentQuestion.id,
        questionTitle: currentQuestion.title,
        type: currentQuestion.type,
        answerText,
        voiceTranscribed: isListening,
        score: evalResult.score,
        conceptScore: evalResult.conceptScore,
        relevanceScore: evalResult.relevanceScore,
        structureScore: evalResult.structureScore,
        feedback: evalResult.feedback,
        strengths: evalResult.strengths,
        areasToImprove: evalResult.areasToImprove
      };
    }

    const updatedSubmissions = [...submissions, submission];
    setSubmissions(updatedSubmissions);
    setIsSubmitting(false);

    if (currentIndex + 1 < questions.length) {
      setCurrentIndex(currentIndex + 1);
    } else {
      // Completed all questions
      if (mediaStream) {
        mediaStream.getTracks().forEach((track) => track.stop());
      }
      onFinishInterview(updatedSubmissions, timeTakenSeconds, integrityEvents);
    }
  };

  const finishSession = () => {
    terminateSession('Candidate finalized and scored session early.');
    onFinishInterview(submissions, timeTakenSeconds, integrityEvents);
  };

  if (isTerminated) {
    return (
      <div className="max-w-3xl mx-auto my-8 bg-white rounded-3xl border border-rose-200 shadow-xl overflow-hidden animate-fadeIn">
        {/* Top Banner */}
        <div className="bg-rose-600 text-white p-6 sm:p-8 flex items-start gap-4">
          <div className="w-14 h-14 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center shrink-0">
            <ShieldAlert className="w-8 h-8 text-white" />
          </div>
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-700/80 text-rose-100 text-2xs font-bold uppercase tracking-wider">
              <AlertCircle className="w-3.5 h-3.5" />
              Proctored Session Discontinued
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Interview Terminated
            </h2>
            <p className="text-xs sm:text-sm text-rose-100/90 leading-relaxed">
              Your interview was ended because repeated proctoring violations were detected.
            </p>
          </div>
        </div>

        <div className="p-6 sm:p-8 space-y-6">
          {/* Reason Card */}
          <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl space-y-1 text-xs">
            <span className="font-bold text-rose-900 block text-2xs uppercase tracking-wider">
              Termination Reason:
            </span>
            <p className="text-rose-800 font-semibold leading-relaxed">
              {terminationReason || 'Interview terminated due to repeated proctoring violations.'}
            </p>
          </div>

          {/* Device & Stream Status Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-slate-200 flex items-center justify-center text-slate-600">
                <VideoOff className="w-5 h-5" />
              </div>
              <div>
                <span className="text-3xs uppercase font-bold text-slate-400 block">Camera Feed</span>
                <span className="text-xs font-bold text-slate-700">Safely Stopped</span>
              </div>
            </div>
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-slate-200 flex items-center justify-center text-slate-600">
                <MicOff className="w-5 h-5" />
              </div>
              <div>
                <span className="text-3xs uppercase font-bold text-slate-400 block">Microphone</span>
                <span className="text-xs font-bold text-slate-700">Safely Stopped</span>
              </div>
            </div>
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-rose-100 flex items-center justify-center text-rose-600">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div>
                <span className="text-3xs uppercase font-bold text-rose-500 block">Total Violations</span>
                <span className="text-xs font-black text-rose-700">4 / 3 (Limit Exceeded)</span>
              </div>
            </div>
          </div>

          {/* Incident Audit Log */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
              <Terminal className="w-4 h-4 text-slate-500" />
              Official Incident Audit Log
            </h3>
            <div className="bg-slate-900 rounded-2xl p-4 font-mono text-xs space-y-2.5 max-h-56 overflow-y-auto border border-slate-800">
              {integrityEvents.map((evt, idx) => (
                <div key={idx} className="flex items-start justify-between gap-3 text-2xs border-b border-slate-800/80 pb-2.5 last:border-0 last:pb-0">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-rose-400 font-bold">
                        {idx >= 3 ? 'Violation 4 (Final Termination)' : `Violation ${idx + 1}`}
                      </span>
                      <span className="text-slate-500">[{evt.timestamp}]</span>
                    </div>
                    <p className="text-slate-300 font-sans">{evt.description}</p>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-3xs uppercase shrink-0 font-mono">
                    {evt.type}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Browser Limitation Technical Note */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl text-xs text-slate-600 space-y-1.5">
            <span className="font-bold text-slate-800 block text-2xs flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-blue-600" />
              Browser-Based Proctoring Technical Note:
            </span>
            <p className="text-3xs text-slate-500 leading-relaxed">
              Proctored mode monitors browser-visible events such as leaving the interview page, exiting fullscreen, and interrupting camera/microphone access. Browser security prevents a website from completely blocking users from closing the browser or using another device.
            </p>
          </div>

          {/* Action Button */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-slate-100">
            <span className="text-3xs text-slate-500">
              Ensure an uninterrupted testing environment before starting another session.
            </span>
            <button
              type="button"
              onClick={onCancelInterview}
              className="w-full sm:w-auto px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl transition-colors shadow-xs cursor-pointer flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Return to Interview Setup</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[85vh] flex flex-col space-y-4">
      {/* Integrity Warning Notification Banner */}
      {latestWarningBanner && (
        <div className="bg-amber-500 text-white px-4 py-2.5 rounded-xl shadow-md flex items-center justify-between text-xs animate-bounce">
          <div className="flex items-center gap-2 font-semibold">
            <ShieldAlert className="w-4 h-4 shrink-0" />
            <span>{latestWarningBanner}</span>
          </div>
          <span className="text-3xs font-mono uppercase bg-amber-700 px-2 py-0.5 rounded">
            Integrity Alert #{integrityEvents.length}
          </span>
        </div>
      )}

      {/* Top Professional Interview Bar */}
      <div className="bg-slate-900 text-white rounded-2xl p-4 sm:p-5 shadow-lg border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        {/* Left: AI Interviewer Profile */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center font-bold text-white shadow-xs">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm text-slate-100">AI Assessment Panel</span>
              <span className="text-3xs font-mono px-2 py-0.5 rounded bg-blue-900/60 text-blue-300 border border-blue-700/50">
                {config.type} · {config.difficulty}
              </span>
            </div>
            {/* Proctored Mode Active Indicators */}
            <div className="flex flex-wrap items-center gap-1.5 mt-1 text-3xs font-mono">
              <span className="inline-flex items-center gap-1 text-emerald-400 font-semibold bg-emerald-950/40 border border-emerald-800/50 px-1.5 py-0.5 rounded">
                <span className="w-1 h-1 rounded-full bg-emerald-400 animate-pulse" />
                Proctored Mode Active
              </span>
              <span className={isCameraActive ? 'text-slate-300' : 'text-rose-400 font-bold'}>
                · Camera: {isCameraActive ? 'Active' : 'Interrupted'}
              </span>
              <span className={isMicActive ? 'text-slate-300' : 'text-rose-400 font-bold'}>
                · Mic: {isMicActive ? 'Active' : 'Interrupted'}
              </span>
              <span className={isFullscreen ? 'text-slate-300' : 'text-amber-400 font-bold'}>
                · Fullscreen: {isFullscreen ? 'Active' : 'Inactive'}
              </span>
            </div>
          </div>
        </div>

        {/* Center: Countdown Timer & Question Count */}
        <div className="flex items-center gap-4">
          <div className={`px-4 py-2 rounded-xl font-mono text-sm font-bold flex items-center gap-2 border ${
            secondsRemaining < 180
              ? 'bg-rose-950/60 text-rose-300 border-rose-700 animate-pulse'
              : secondsRemaining < 480
              ? 'bg-amber-950/60 text-amber-300 border-amber-700'
              : 'bg-slate-800 text-slate-200 border-slate-700'
          }`}>
            <Clock className="w-4 h-4 text-blue-400" />
            <span>{formatTimer(secondsRemaining)} Remaining</span>
          </div>

          <span className="text-xs font-mono font-bold text-slate-300 bg-slate-800 px-3 py-2 rounded-xl border border-slate-700">
            Q {currentIndex + 1} / {questions.length}
          </span>
        </div>

        {/* Right: Integrity & Actions */}
        <div className="flex items-center gap-2">
          {/* Integrity Counter */}
          <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-2xs ${
            warningCount >= 3 ? 'bg-rose-950/60 border-rose-800 text-rose-300' : warningCount > 0 ? 'bg-amber-950/60 border-amber-800 text-amber-300' : 'bg-slate-800 border-slate-700 text-slate-300'
          }`}>
            <ShieldAlert className={`w-3.5 h-3.5 ${warningCount >= 3 ? 'text-rose-400' : warningCount > 0 ? 'text-amber-400' : 'text-emerald-400'}`} />
            <span>Warnings: <strong className={`font-mono ${warningCount >= 3 ? 'text-rose-400 font-bold' : warningCount > 0 ? 'text-amber-300 font-bold' : 'text-white'}`}>{warningCount} / 3</strong></span>
          </div>

          {/* Fullscreen Button */}
          <button
            onClick={isFullscreen ? exitFullscreen : requestFullscreen}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 cursor-pointer transition-colors"
            title={isFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen'}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          {/* End Interview */}
          <button
            onClick={() => setShowExitConfirm(true)}
            className="px-3 py-1.5 rounded-lg bg-rose-600/90 hover:bg-rose-600 text-white font-semibold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>End Session</span>
          </button>
        </div>
      </div>

      {/* Main Split Layout: Question & Answer Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 flex-1 items-stretch select-none">
        {/* Left Pane: Question Details + Live Candidate Camera */}
        <div className={`space-y-4 flex flex-col justify-between ${isCodingQuestion ? 'lg:col-span-5' : 'lg:col-span-4'}`}>
          {/* Live Camera Preview Box */}
          <div className="bg-slate-900 rounded-2xl border border-slate-800 p-3 shadow-sm relative overflow-hidden">
            <div className="relative aspect-video w-full rounded-xl overflow-hidden bg-black flex items-center justify-center">
              {isCameraActive ? (
                <video
                  ref={setVideoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover transform -scale-x-100"
                />
              ) : (
                <div className="p-4 text-center text-rose-400 text-xs font-semibold space-y-2">
                  <VideoOff className="w-8 h-8 mx-auto mb-1 text-rose-500" />
                  <span>Camera access was interrupted. Camera must remain enabled during the interview.</span>
                  <div>
                    <button
                      type="button"
                      onClick={retryCamera}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-2xs font-bold transition-colors cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      Retry Camera
                    </button>
                  </div>
                </div>
              )}

              {/* Status Badges on Camera */}
              <div className="absolute top-2 left-2 flex items-center gap-1.5 bg-slate-900/80 px-2 py-0.5 rounded text-3xs font-mono text-emerald-400">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span>LIVE CANDIDATE</span>
              </div>

              {/* Face Presence Status Indicator */}
              {isCameraActive && (
                <div className="absolute top-2 right-2 flex items-center gap-1.5 bg-slate-900/85 px-2 py-0.5 rounded text-3xs font-mono backdrop-blur-xs">
                  {faceDetectorStatus === 'active' ? (
                    isFacePresent ? (
                      <>
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                        <span className="text-emerald-400 font-bold">FACE IN FRAME</span>
                      </>
                    ) : (
                      <>
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
                        <span className="text-amber-300 font-bold">NO FACE DETECTED</span>
                      </>
                    )
                  ) : faceDetectorStatus === 'unsupported' ? (
                    <>
                      <span className="w-1.5 h-1.5 rounded-full bg-slate-400" />
                      <span
                        className="text-slate-400"
                        title={faceDetectorMessage || 'Native FaceDetector API unavailable in this browser.'}
                      >
                        FACE DETECT: UNAVAILABLE
                      </span>
                    </>
                  ) : faceDetectorStatus === 'error' ? (
                    <>
                      <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
                      <span
                        className="text-rose-400"
                        title={faceDetectorMessage}
                      >
                        FACE DETECT: ERROR
                      </span>
                    </>
                  ) : null}
                </div>
              )}

              <div className="absolute bottom-2 right-2 flex items-center gap-1 bg-slate-900/80 px-2 py-0.5 rounded text-3xs font-mono text-slate-300">
                {isMicActive ? <Mic className="w-3 h-3 text-emerald-400" /> : <MicOff className="w-3 h-3 text-rose-400" />}
                <span>{isMicActive ? 'MIC ON' : 'MIC OFF'}</span>
              </div>
            </div>

            {mediaError && (
              <div className="mt-2 p-2 bg-rose-950/60 border border-rose-800/80 rounded-lg text-center flex items-center justify-between gap-2">
                <p className="text-3xs text-rose-400 font-medium">
                  {mediaError}
                </p>
                <button
                  type="button"
                  onClick={retryCamera}
                  className="text-3xs font-bold text-white bg-blue-600 hover:bg-blue-700 px-2 py-0.5 rounded cursor-pointer shrink-0"
                >
                  Retry
                </button>
              </div>
            )}
          </div>

          {/* Question Statement Card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex-1 flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between text-2xs">
                <span className="font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                  {currentQuestion.category || currentQuestion.type}
                </span>
                <span className="font-mono text-slate-400">
                  {currentQuestion.difficulty} Level
                </span>
              </div>

              <h3 className="text-base font-extrabold text-slate-900 leading-snug">
                {currentQuestion.title}
              </h3>

              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 leading-relaxed font-medium">
                {currentQuestion.question}
              </div>

              {/* Coding Constraints & Sample I/O */}
              {isCodingQuestion && (
                <div className="space-y-2 text-2xs">
                  {currentQuestion.codingConstraints && (
                    <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                      <span className="font-bold text-slate-700 block mb-1">Constraints:</span>
                      <ul className="list-disc pl-4 text-slate-600 space-y-0.5">
                        {currentQuestion.codingConstraints.map((c, i) => (
                          <li key={i}>{c}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {currentQuestion.sampleInputOutput && (
                    <div className="p-2.5 bg-slate-900 text-slate-200 rounded-lg font-mono text-3xs whitespace-pre-wrap">
                      {currentQuestion.sampleInputOutput}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Hint Accordion */}
            <div className="pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowHint(!showHint)}
                className="text-2xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1 cursor-pointer"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>{showHint ? 'Hide Preparation Strategy' : 'View Recruiter Hint & Strategy'}</span>
              </button>
              {showHint && (
                <p className="mt-2 p-3 bg-blue-50/70 border border-blue-200 rounded-xl text-xs text-blue-950 italic">
                  {currentQuestion.hint}
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Right Pane: Dynamic Answer Workspace */}
        <div className={`bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between space-y-4 ${isCodingQuestion ? 'lg:col-span-7' : 'lg:col-span-8'}`}>
          {isCodingQuestion ? (
            /* CODING COMPILER WORKSPACE */
            <div className="space-y-4 flex-1 flex flex-col">
              {/* Compiler Controls Bar */}
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <FileCode className="w-4 h-4 text-blue-600" />
                  <span className="text-xs font-bold text-slate-900">Language:</span>
                  <select
                    value={codingLanguage}
                    onChange={(e) => setCodingLanguage(e.target.value as any)}
                    className="text-xs font-semibold bg-slate-50 border border-slate-200 rounded-lg p-1.5 text-slate-800 focus:outline-hidden focus:border-blue-600"
                  >
                    <option value="javascript">JavaScript — Live Browser Execution</option>
                    <option value="python">Python — Structural Analysis</option>
                    <option value="java">Java — Structural Analysis</option>
                    <option value="cpp">C++ — Structural Analysis</option>
                  </select>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleRunCode}
                    disabled={isExecutingCode}
                    className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-800 flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-60"
                  >
                    <Play className="w-3.5 h-3.5 text-blue-600 fill-blue-600" />
                    <span>{isExecutingCode ? 'Evaluating...' : 'Run Code'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleSubmitAnswer}
                    disabled={isSubmitting}
                    className="px-4 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-60"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Submit &amp; Next</span>
                  </button>
                </div>
              </div>

              {/* Non-JS Honest Evaluation Notice */}
              {codingLanguage !== 'javascript' && (
                <div className="px-3 py-2 bg-amber-50/80 rounded-xl border border-amber-200/80 text-3xs text-amber-900 flex items-center gap-2">
                  <Info className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                  <span>Non-JS languages are evaluated using structural and algorithmic analysis, not live runtime execution. Use JavaScript for live test-case execution.</span>
                </div>
              )}

              {/* Code Editor Area */}
              <div className="flex-1 min-h-[300px] flex flex-col rounded-xl overflow-hidden border border-slate-800 bg-slate-950 text-slate-100 font-mono text-xs">
                <div className="bg-slate-900 px-3 py-1.5 text-3xs text-slate-400 flex items-center justify-between border-b border-slate-800">
                  <span>editor.{codingLanguage === 'python' ? 'py' : codingLanguage === 'javascript' ? 'js' : codingLanguage === 'java' ? 'java' : 'cpp'}</span>
                  <span>{codingLanguage === 'javascript' ? 'Live Browser Runtime Sandbox' : 'Structural & Algorithmic Analysis Sandbox'}</span>
                </div>
                <textarea
                  value={codeContent}
                  onChange={(e) => setCodeContent(e.target.value)}
                  className="w-full flex-1 p-3.5 bg-slate-950 text-emerald-400 focus:outline-hidden font-mono leading-relaxed resize-none"
                  spellCheck={false}
                  placeholder="// Write your solution here..."
                />
              </div>

              {/* Compiler Tabs: Test Cases & Terminal Console */}
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 space-y-2">
                <div className="flex items-center gap-3 border-b border-slate-200 pb-2 text-xs">
                  <button
                    type="button"
                    onClick={() => setActiveCodeTab('testcases')}
                    className={`font-semibold cursor-pointer pb-1 ${
                      activeCodeTab === 'testcases' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-500'
                    }`}
                  >
                    {codingLanguage === 'javascript' ? 'Test Cases' : 'Static Checks'} ({executionResult ? `${executionResult.testCasesPassed}/${executionResult.totalTestCases}` : currentQuestion.testCases?.length || 0})
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveCodeTab('console')}
                    className={`font-semibold cursor-pointer pb-1 ${
                      activeCodeTab === 'console' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-500'
                    }`}
                  >
                    {codingLanguage === 'javascript' ? 'Execution Output / Console' : 'Static Analysis Log'}
                  </button>
                </div>

                {activeCodeTab === 'testcases' ? (
                  <div className="space-y-2 max-h-36 overflow-y-auto">
                    {(executionResult?.details || currentQuestion.testCases || []).map((tc: any, i: number) => {
                      const passed = tc.passed;
                      return (
                        <div key={i} className="p-2 bg-white rounded-lg border border-slate-200 text-3xs flex items-center justify-between">
                          <div className="space-y-0.5">
                            <span className="font-bold text-slate-800">Case {i + 1}: {tc.input}</span>
                            <span className="text-slate-500 block">Expected: {tc.expected || tc.expectedOutput}</span>
                            {executionResult && (
                              <span className="text-slate-600 font-mono text-3xs block">
                                {codingLanguage === 'javascript' ? `Actual: ${tc.actual}` : `Verification: ${tc.actual}`}
                              </span>
                            )}
                          </div>
                          {executionResult && (
                            <span className={`px-2 py-0.5 rounded font-bold ${
                              passed ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                            }`}>
                              {codingLanguage === 'javascript'
                                ? (passed ? 'PASSED' : 'FAILED')
                                : (passed ? 'CONSISTENT' : 'ISSUES DETECTED')}
                            </span>
                          )}
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <pre className="p-2.5 bg-slate-900 text-slate-200 rounded-lg font-mono text-3xs overflow-x-auto whitespace-pre-wrap max-h-32">
                    {executionResult ? executionResult.output : 'Click "Run Code" to compile and execute against assertions.'}
                  </pre>
                )}
              </div>
            </div>
          ) : (
            /* VERBAL & TEXT RESPONSE WORKSPACE */
            <div className="space-y-5 flex-1 flex flex-col justify-between">
              {/* Spoken Audio & Speech-to-Text Bar */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <div className={`w-3 h-3 rounded-full ${isListening ? 'bg-rose-500 animate-ping' : 'bg-slate-300'}`} />
                    <span className="text-xs font-bold text-slate-800">
                      {isListening ? 'Microphone Active — Speak Clearly' : 'Spoken Speech Recognition'}
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={toggleVoiceListening}
                    className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 cursor-pointer transition-all ${
                      isListening
                        ? 'bg-rose-600 text-white shadow-xs hover:bg-rose-700'
                        : 'bg-blue-600 text-white shadow-xs hover:bg-blue-700'
                    }`}
                  >
                    {isListening ? (
                      <>
                        <MicOff className="w-3.5 h-3.5" />
                        <span>Stop Speaking</span>
                      </>
                    ) : (
                      <>
                        <Mic className="w-3.5 h-3.5" />
                        <span>Speak Answer (Voice Input)</span>
                      </>
                    )}
                  </button>
                </div>

                <p className="text-3xs text-slate-500 flex items-center gap-1.5">
                  <Radio className="w-3 h-3 text-blue-600" />
                  <span>Status: <strong>{speechStatus}</strong></span>
                </p>
              </div>

              {/* Text Input & Transcription Sync Area */}
              <div className="space-y-2 flex-1 flex flex-col">
                <div className="flex justify-between items-center text-xs">
                  <label className="font-bold text-slate-800">
                    Candidate Answer Formulation (Speech or Keyboard)
                  </label>
                  <span className="text-3xs text-slate-400 font-mono">
                    {answerText.length} characters
                  </span>
                </div>

                <textarea
                  value={answerText}
                  onChange={(e) => setAnswerText(e.target.value)}
                  placeholder="Speak your answer or type it here. Your speech recognition transcript will populate automatically..."
                  className="w-full flex-1 p-4 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-hidden focus:bg-white focus:border-blue-600 leading-relaxed resize-none min-h-[200px]"
                />
              </div>

              {/* Submit Controls */}
              <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3">
                <span className="text-3xs text-slate-400">
                  * Submissions are scored and recorded permanently in this interview round.
                </span>

                <button
                  type="button"
                  onClick={handleSubmitAnswer}
                  disabled={isSubmitting || answerText.trim().length === 0}
                  className="w-full sm:w-auto px-6 py-2.5 rounded-xl font-bold text-xs text-white bg-blue-600 hover:bg-blue-700 shadow-xs flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Submit &amp; Next Question</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Exit Confirmation Modal */}
      {showExitConfirm && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 space-y-4">
            <h4 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-rose-600" />
              End Interview Early?
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Are you sure you want to end this proctored session? Your answers submitted up to Question {currentIndex + 1} will be evaluated and recorded in your Interview History.
            </p>
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setShowExitConfirm(false)}
                className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 cursor-pointer"
              >
                Continue Interview
              </button>
              <button
                onClick={finishSession}
                className="px-4 py-2 rounded-lg text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 cursor-pointer"
              >
                Yes, Finalize &amp; Score
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Active Proctoring Warning Modal (Violation 1, 2, or 3) */}
      {activeWarningModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className={`bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border ${
            activeWarningModal.count === 3 ? 'border-rose-400 ring-4 ring-rose-500/20' : 'border-amber-400 ring-4 ring-amber-500/10'
          } space-y-4`}>
            <div className="flex items-center gap-3">
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                activeWarningModal.count === 3 ? 'bg-rose-100 text-rose-600' : 'bg-amber-100 text-amber-600'
              }`}>
                <ShieldAlert className="w-6 h-6" />
              </div>
              <div>
                <span className={`text-3xs font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                  activeWarningModal.count === 3 ? 'bg-rose-100 text-rose-700' : 'bg-amber-100 text-amber-800'
                }`}>
                  ⚠ Interview Proctoring Warning
                </span>
                <h4 className="text-lg font-black text-slate-900">
                  {activeWarningModal.title}
                </h4>
              </div>
            </div>

            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1">
              <span className="text-3xs font-bold uppercase tracking-wider text-slate-400 block">
                Detected Incident ({activeWarningModal.timestamp}):
              </span>
              <p className="text-slate-800 font-semibold leading-relaxed">
                {activeWarningModal.description}
              </p>
            </div>

            {/* Proctoring Status & Warnings Counter */}
            <div className="flex items-center justify-between text-2xs p-2.5 rounded-xl bg-slate-50 border border-slate-200 font-mono">
              <span className="text-slate-500">Proctoring Status: <strong className="text-emerald-600">Active</strong></span>
              <span className="text-slate-500">Warnings: <strong className={activeWarningModal.count >= 3 ? 'text-rose-600' : 'text-amber-600'}>{activeWarningModal.count} / 3</strong></span>
            </div>

            {activeWarningModal.count === 3 ? (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 font-bold flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <span>
                  One more proctoring violation will terminate this interview.
                </span>
              </div>
            ) : (
              <p className="text-xs text-slate-600 leading-relaxed">
                Please return to the interview screen. You have{' '}
                <strong className="text-slate-900">{3 - activeWarningModal.count} warning{3 - activeWarningModal.count > 1 ? 's' : ''} remaining</strong>{' '}
                before automatic session termination.
              </p>
            )}

            <div className="pt-2 flex flex-col gap-2">
              {activeWarningModal.type === 'fullscreen_exit' && (
                <button
                  type="button"
                  onClick={async () => {
                    await requestFullscreen();
                    acknowledgeWarning();
                  }}
                  className="w-full py-2.5 px-4 rounded-xl font-bold text-xs text-white bg-blue-600 hover:bg-blue-700 shadow-xs transition-colors cursor-pointer flex items-center justify-center gap-2"
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                  <span>Return to Fullscreen &amp; Continue</span>
                </button>
              )}

              {activeWarningModal.type === 'camera_interruption' && (
                <button
                  type="button"
                  onClick={async () => {
                    await retryCamera();
                    acknowledgeWarning();
                  }}
                  className="w-full py-2.5 px-4 rounded-xl font-bold text-xs text-white bg-blue-600 hover:bg-blue-700 shadow-xs transition-colors cursor-pointer flex items-center justify-center gap-2"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Retry Camera &amp; Continue</span>
                </button>
              )}

              {activeWarningModal.type === 'face_missing' && (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 space-y-1">
                  <p className="font-bold flex items-center gap-1.5 text-amber-950">
                    <Camera className="w-3.5 h-3.5 text-amber-700" />
                    Face Visibility Required
                  </p>
                  <p className="text-3xs text-amber-800 leading-relaxed">
                    Please ensure you are centered in front of the camera and your face remains clearly visible before clicking continue.
                  </p>
                </div>
              )}

              <button
                type="button"
                onClick={acknowledgeWarning}
                className={`w-full py-2.5 px-4 rounded-xl font-bold text-xs text-white shadow-xs transition-colors cursor-pointer ${
                  activeWarningModal.count === 3
                    ? 'bg-rose-600 hover:bg-rose-700'
                    : 'bg-slate-800 hover:bg-slate-900'
                }`}
              >
                {activeWarningModal.type === 'face_missing'
                  ? 'I am in Frame — Continue Interview'
                  : activeWarningModal.count === 3
                  ? 'I Understand - Final Warning Acknowledged'
                  : 'Continue Interview'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
