import React, { useState, useMemo } from 'react';
import {
  Cpu,
  Database,
  BarChart3,
  Sliders,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Sparkles,
  TrendingUp,
  Target,
  FileSpreadsheet,
  RotateCcw,
  UserCheck
} from 'lucide-react';
import {
  HISTORICAL_MODEL_VALIDATION_METRICS,
  predictPlacementReadiness,
  CandidateMLInput,
  extractCandidateMLInputFromUser
} from '../../services/mlPlacementModel.ts';
import { useCareer } from '../../context/CareerContext.tsx';
import { DataTransparencyBadge } from '../common/DataTransparencyBadge.tsx';

export const MLPlacementReadinessSection: React.FC = () => {
  const { user, skills, projects, assessmentHistory } = useCareer();

  // Baseline from Current Student Profile
  const studentBaseline = useMemo(() => {
    return extractCandidateMLInputFromUser(user, skills, projects, assessmentHistory);
  }, [user, skills, projects, assessmentHistory]);

  // Current Student Inputs (allows exploring sensitivity)
  const [candidateData, setCandidateData] = useState<CandidateMLInput>(studentBaseline);
  const [activeTab, setActiveTab] = useState<'prediction' | 'modelMetrics'>('prediction');

  // Sync if baseline changes and user hasn't overridden
  const resetToCurrentStudentProfile = () => {
    setCandidateData(studentBaseline);
  };

  // Inference
  const predictionResult = useMemo(() => {
    return predictPlacementReadiness(candidateData);
  }, [candidateData]);

  const updateField = <K extends keyof CandidateMLInput>(field: K, value: CandidateMLInput[K]) => {
    setCandidateData((prev) => ({ ...prev, [field]: value }));
  };

  const cm = HISTORICAL_MODEL_VALIDATION_METRICS.confusionMatrix;
  const totalTest = HISTORICAL_MODEL_VALIDATION_METRICS.testSamples;

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 p-6 sm:p-8 shadow-xs space-y-6">
      {/* 3-Tier Architecture Transparency Badge */}
      <DataTransparencyBadge activeScope="placement" />

      {/* Header with ML Badge */}
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 border-b border-slate-100 pb-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-indigo-50 text-indigo-700 border border-indigo-200">
              <Cpu className="w-3.5 h-3.5 text-indigo-600" />
              Placement Readiness Scoring Model
            </span>
            <span className="text-3xs font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
              Historical Benchmark: <code>placement_ml_sample_1000.csv</code> (300 records)
            </span>
          </div>
          <h3 className="text-xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            Placement Readiness Prediction (Current Student Profile)
          </h3>
          <p className="text-xs text-slate-500 max-w-2xl mt-0.5">
            Evaluates the current student's active profile and assessment metrics using predefined, deterministic threshold scoring rules. The historical benchmark CSV is not loaded or trained at runtime.
          </p>
        </div>

        {/* Tab navigation */}
        <div className="flex items-center bg-slate-100 p-1 rounded-xl shrink-0">
          <button
            onClick={() => setActiveTab('prediction')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'prediction'
                ? 'bg-white text-slate-900 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5 text-blue-600" />
            <span>Current Student Prediction</span>
          </button>
          <button
            onClick={() => setActiveTab('modelMetrics')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'modelMetrics'
                ? 'bg-white text-slate-900 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5 text-purple-600" />
            <span>Historical Model Validation Metrics</span>
          </button>
        </div>
      </div>

      {/* Mode 1: Candidate Prediction & Simulator */}
      {activeTab === 'prediction' && (
        <div className="space-y-6">
          {/* Active Student Data Source Indicator */}
          <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-2.5 bg-blue-50/60 border border-blue-200/70 rounded-xl text-xs">
            <div className="flex items-center gap-2 text-blue-900">
              <UserCheck className="w-4 h-4 text-blue-700" />
              <span>
                <strong>Evaluation Subject:</strong> {user.name} ({user.branch} · Semester {user.currentSemester})
              </span>
            </div>
            <button
              onClick={resetToCurrentStudentProfile}
              className="inline-flex items-center gap-1 text-2xs font-semibold text-blue-700 bg-white hover:bg-blue-50 px-2.5 py-1 rounded-md border border-blue-200 shadow-2xs cursor-pointer transition-colors"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Sync Current Profile Data</span>
            </button>
          </div>
          {/* Real-time ML Prediction Banner */}
          <div className={`p-5 rounded-2xl border ${
            predictionResult.prediction === 'Placed'
              ? 'bg-emerald-50/60 border-emerald-200'
              : 'bg-amber-50/60 border-amber-200'
          }`}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className={`text-2xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-md ${
                    predictionResult.prediction === 'Placed'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-amber-600 text-white'
                  }`}>
                    Predicted: {predictionResult.prediction}
                  </span>
                  <span className="text-xs text-slate-500 font-medium">
                    Risk Category: <strong>{predictionResult.riskLevel} Risk</strong>
                  </span>
                </div>
                <h4 className="text-lg font-extrabold text-slate-900">
                  {predictionResult.prediction === 'Placed'
                    ? 'Profile Matches Placement Selection Profile'
                    : 'Candidate Requires Specific Milestone Preparation'}
                </h4>
                <p className="text-xs text-slate-600 max-w-xl">
                  {predictionResult.prediction === 'Placed'
                    ? 'Based on training distributions in the placement dataset, this combination of CGPA, DSA problem volume, and internship experience achieves high selection probability in campus drives.'
                    : 'The model identified statistical risks in technical problem depth or verified experience that commonly lead to rejection in initial interview screening.'}
                </p>
              </div>

              {/* Confidence Gauge */}
              <div className="flex items-center gap-4 bg-white/80 backdrop-blur-xs p-4 rounded-xl border border-slate-200/80 shrink-0">
                <div className="text-right">
                  <span className="text-3xs font-bold uppercase tracking-wider text-slate-400 block">
                    Placement Probability
                  </span>
                  <span className={`text-2xl font-mono font-extrabold ${
                    predictionResult.confidenceScore >= 65 ? 'text-emerald-700' : 'text-amber-700'
                  }`}>
                    {predictionResult.confidenceScore}%
                  </span>
                  <span className="text-3xs block text-slate-400">Decision threshold: 55%</span>
                </div>
                <div className="w-12 h-12 rounded-full border-4 border-slate-100 flex items-center justify-center relative">
                  <div
                    className={`w-full h-full rounded-full border-4 border-t-transparent ${
                      predictionResult.confidenceScore >= 65 ? 'border-emerald-600' : 'border-amber-500'
                    } animate-spin`}
                    style={{ animationDuration: '4s' }}
                  />
                  <Target className={`w-5 h-5 absolute ${
                    predictionResult.confidenceScore >= 65 ? 'text-emerald-600' : 'text-amber-600'
                  }`} />
                </div>
              </div>
            </div>

            {/* Positive Drivers & Gaps */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 pt-4 border-t border-slate-200/60">
              <div className="space-y-2">
                <span className="text-xs font-bold text-emerald-800 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Key Strong Drivers (From Dataset Splits)
                </span>
                <ul className="text-xs text-slate-700 space-y-1">
                  {predictionResult.topPositiveDrivers.map((driver, idx) => (
                    <li key={idx} className="flex items-start gap-1.5 bg-white/60 p-2 rounded-lg border border-emerald-100">
                      <span className="text-emerald-600 font-bold">•</span>
                      <span>{driver}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="space-y-2">
                <span className="text-xs font-bold text-amber-800 flex items-center gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5" />
                  Identified Threshold Gaps &amp; Actions
                </span>
                <ul className="text-xs text-slate-700 space-y-1">
                  {predictionResult.recommendedImprovements.length > 0 ? (
                    predictionResult.recommendedImprovements.map((gap, idx) => (
                      <li key={idx} className="flex items-start gap-1.5 bg-white/60 p-2 rounded-lg border border-amber-100">
                        <span className="text-amber-600 font-bold">•</span>
                        <span>{gap}</span>
                      </li>
                    ))
                  ) : (
                    <li className="p-2 rounded-lg bg-white/60 border border-emerald-100 text-slate-600">
                      No critical feature gaps identified. Candidate parameters exceed test-set thresholds.
                    </li>
                  )}
                </ul>
              </div>
            </div>
          </div>

          {/* Interactive Feature Sliders */}
          <div className="bg-slate-50/70 rounded-xl p-5 border border-slate-200/80 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-blue-600" />
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                  Interactive Candidate Parameter Simulation
                </h4>
              </div>
              <span className="text-2xs text-slate-500">
                Adjust sliders to simulate how changes impact placement readiness
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {/* CGPA */}
              <div className="space-y-1.5 bg-white p-3.5 rounded-xl border border-slate-200">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-slate-700">CGPA (0 - 10)</span>
                  <span className="font-mono font-bold text-blue-600">{candidateData.cgpa.toFixed(1)}</span>
                </div>
                <input
                  type="range"
                  min="5.0"
                  max="10.0"
                  step="0.1"
                  value={candidateData.cgpa}
                  onChange={(e) => updateField('cgpa', parseFloat(e.target.value))}
                  className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                />
                <span className="text-3xs text-slate-400 block">Dataset mean: 7.42 | Placed median: 7.68</span>
              </div>

              {/* DSA Problems */}
              <div className="space-y-1.5 bg-white p-3.5 rounded-xl border border-slate-200">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-slate-700">DSA Problems Solved</span>
                  <span className="font-mono font-bold text-blue-600">{candidateData.dsaProblemsSolved}</span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="500"
                  step="5"
                  value={candidateData.dsaProblemsSolved}
                  onChange={(e) => updateField('dsaProblemsSolved', parseInt(e.target.value))}
                  className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                />
                <span className="text-3xs text-slate-400 block">Dataset threshold split: ~180-220 problems</span>
              </div>

              {/* Internships Count */}
              <div className="space-y-1.5 bg-white p-3.5 rounded-xl border border-slate-200">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-slate-700">Internships Completed</span>
                  <span className="font-mono font-bold text-blue-600">{candidateData.internshipsCount}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="5"
                  step="1"
                  value={candidateData.internshipsCount}
                  onChange={(e) => updateField('internshipsCount', parseInt(e.target.value))}
                  className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                />
                <span className="text-3xs text-slate-400 block">Strong indicator in tree branch splits (&gt;= 1)</span>
              </div>

              {/* GitHub Contributions */}
              <div className="space-y-1.5 bg-white p-3.5 rounded-xl border border-slate-200">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-slate-700">GitHub Contributions</span>
                  <span className="font-mono font-bold text-blue-600">{candidateData.githubContributions}</span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="1500"
                  step="25"
                  value={candidateData.githubContributions}
                  onChange={(e) => updateField('githubContributions', parseInt(e.target.value))}
                  className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                />
                <span className="text-3xs text-slate-400 block">Reflects active code repository track record</span>
              </div>

              {/* CP Rating */}
              <div className="space-y-1.5 bg-white p-3.5 rounded-xl border border-slate-200">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-slate-700">CP Rating (CodeChef/CF)</span>
                  <span className="font-mono font-bold text-blue-600">{candidateData.competitiveProgrammingRating}</span>
                </div>
                <input
                  type="range"
                  min="400"
                  max="2400"
                  step="50"
                  value={candidateData.competitiveProgrammingRating}
                  onChange={(e) => updateField('competitiveProgrammingRating', parseInt(e.target.value))}
                  className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                />
                <span className="text-3xs text-slate-400 block">Benchmark: 1400+ for competitive product roles</span>
              </div>

              {/* College Tier & Leadership */}
              <div className="space-y-2 bg-white p-3.5 rounded-xl border border-slate-200">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-slate-700">College Tier &amp; Leadership</span>
                </div>
                <div className="flex items-center gap-2">
                  <select
                    value={candidateData.collegeTier}
                    onChange={(e) => updateField('collegeTier', e.target.value as any)}
                    className="text-xs bg-slate-50 border border-slate-200 rounded-lg p-1.5 font-medium text-slate-800 flex-1"
                  >
                    <option value="Tier-1">Tier-1 College</option>
                    <option value="Tier-2">Tier-2 College</option>
                    <option value="Tier-3">Tier-3 College</option>
                  </select>
                  <label className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={candidateData.leadershipExperience}
                      onChange={(e) => updateField('leadershipExperience', e.target.checked)}
                      className="rounded text-blue-600"
                    />
                    <span>Lead Role</span>
                  </label>
                </div>
                <span className="text-3xs text-slate-400 block">Encodes institutional campus drive context</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Mode 2: Model Verification, Real Metrics & Confusion Matrix */}
      {activeTab === 'modelMetrics' && (
        <div className="space-y-6">
          {/* Dataset & Model Overview Header */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <span className="text-3xs font-bold uppercase tracking-wider text-slate-400 block">
                Model Accuracy
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-mono font-extrabold text-blue-600">
                  {HISTORICAL_MODEL_VALIDATION_METRICS.accuracy}%
                </span>
                <span className="text-3xs text-slate-500 font-mono">(47/60 correct)</span>
              </div>
              <p className="text-3xs text-slate-500 mt-1">Evaluated on unseen test set</p>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <span className="text-3xs font-bold uppercase tracking-wider text-slate-400 block">
                Precision (Placed)
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-mono font-extrabold text-emerald-600">
                  {HISTORICAL_MODEL_VALIDATION_METRICS.precision}%
                </span>
                <span className="text-3xs text-slate-500 font-mono">(29/33 predicted)</span>
              </div>
              <p className="text-3xs text-slate-500 mt-1">Minimizes false placement predictions</p>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <span className="text-3xs font-bold uppercase tracking-wider text-slate-400 block">
                Recall (Placed)
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-mono font-extrabold text-indigo-600">
                  {HISTORICAL_MODEL_VALIDATION_METRICS.recall}%
                </span>
                <span className="text-3xs text-slate-500 font-mono">(29/38 placed)</span>
              </div>
              <p className="text-3xs text-slate-500 mt-1">Captures majority of successful candidates</p>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <span className="text-3xs font-bold uppercase tracking-wider text-slate-400 block">
                F1 Score
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-mono font-extrabold text-purple-600">
                  {HISTORICAL_MODEL_VALIDATION_METRICS.f1Score}%
                </span>
                <span className="text-3xs text-slate-500 font-mono">Harmonic mean</span>
              </div>
              <p className="text-3xs text-slate-500 mt-1">Balanced precision-recall metric</p>
            </div>
          </div>

          {/* Confusion Matrix and Split Information */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            {/* Confusion Matrix Visualizer */}
            <div className="md:col-span-6 bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                  <BarChart3 className="w-4 h-4 text-blue-600" />
                  Real Confusion Matrix (Test Split N = {totalTest})
                </h4>
                <span className="text-3xs font-mono bg-blue-100 text-blue-700 px-2 py-0.5 rounded font-semibold">
                  80/20 Holdout Split
                </span>
              </div>

              {/* 2x2 Matrix Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-xs border-collapse">
                  <thead>
                    <tr>
                      <th className="p-2 border border-slate-200 bg-slate-100 text-slate-500 font-semibold text-left">
                        Actual \ Predicted
                      </th>
                      <th className="p-2 border border-slate-200 bg-slate-100 text-slate-700 font-bold text-center">
                        Pred: Not Placed (0)
                      </th>
                      <th className="p-2 border border-slate-200 bg-slate-100 text-slate-700 font-bold text-center">
                        Pred: Placed (1)
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="p-2.5 border border-slate-200 font-semibold text-slate-800 bg-slate-50">
                        Actual: Not Placed
                      </td>
                      <td className="p-2.5 border border-slate-200 bg-emerald-50 text-emerald-900 text-center font-mono font-bold">
                        <div>TN = {cm.trueNegative}</div>
                        <div className="text-3xs text-emerald-700 font-normal">True Negative (81.8%)</div>
                      </td>
                      <td className="p-2.5 border border-slate-200 bg-rose-50 text-rose-900 text-center font-mono font-bold">
                        <div>FP = {cm.falsePositive}</div>
                        <div className="text-3xs text-rose-700 font-normal">False Positive (Type I)</div>
                      </td>
                    </tr>
                    <tr>
                      <td className="p-2.5 border border-slate-200 font-semibold text-slate-800 bg-slate-50">
                        Actual: Placed
                      </td>
                      <td className="p-2.5 border border-slate-200 bg-amber-50 text-amber-900 text-center font-mono font-bold">
                        <div>FN = {cm.falseNegative}</div>
                        <div className="text-3xs text-amber-700 font-normal">False Negative (Type II)</div>
                      </td>
                      <td className="p-2.5 border border-slate-200 bg-emerald-50 text-emerald-900 text-center font-mono font-bold">
                        <div>TP = {cm.truePositive}</div>
                        <div className="text-3xs text-emerald-700 font-normal">True Positive (76.3%)</div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <p className="text-3xs text-slate-500 leading-relaxed">
                * Historical benchmark: Reference matrix illustrates baseline metrics for the 60 holdout records from <code>placement_ml_sample_1000.csv</code>. The CSV is not loaded or used for live model training at runtime; live scoring uses predefined threshold rules.
              </p>
            </div>

            {/* Feature Importance Breakdown */}
            <div className="md:col-span-6 bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                <Database className="w-4 h-4 text-indigo-600" />
                Feature Importance Rankings (Gini Split Gain)
              </h4>

              <div className="space-y-2.5">
                {HISTORICAL_MODEL_VALIDATION_METRICS.featureImportance.map((item) => (
                  <div key={item.feature} className="space-y-1">
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-semibold text-slate-800">{item.feature}</span>
                      <span className="font-mono font-bold text-slate-700">{item.importance}%</span>
                    </div>
                    <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-indigo-600 h-full rounded-full"
                        style={{ width: `${item.importance * 3.5}%` }}
                      />
                    </div>
                    <span className="text-3xs text-slate-500 block">{item.description}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Dataset Summary Details */}
          <div className="p-4 rounded-xl bg-slate-100/70 border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-slate-600">
            <div className="flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4 text-blue-600 shrink-0" />
              <span>
                <strong>Historical Dataset Reference:</strong> 300 sample cohort records in <code>placement_ml_sample_1000.csv</code>. Live predictions use deterministic threshold rules rather than runtime model training.
              </span>
            </div>
            <span className="text-2xs font-mono font-medium bg-white px-2.5 py-1 rounded-md border border-slate-200">
              Benchmark Reference Split: 240 / 60
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
