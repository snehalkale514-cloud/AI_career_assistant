import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  X,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  RotateCcw,
  BookOpen,
  Award,
  Sparkles,
  TrendingUp,
  BrainCircuit,
  MessageSquareCode,
  Layers,
  Clock,
  Compass,
  SlidersHorizontal,
  ShieldCheck
} from 'lucide-react';
import {
  skillAssessmentService,
  SkillQuestion,
  SkillAssessmentResult
} from '../../services/skillAssessmentService.ts';

export interface SkillAssessmentModalProps {
  skillName: string;
  previousScore?: number;
  baselineScore?: number;
  initialDifficulty?: 'Easy' | 'Moderate' | 'Hard';
  mode?: 'skill' | 'validation';
  stageId?: string;
  stageTitle?: string;
  onClose: () => void;
  onSaveResult: (result: SkillAssessmentResult) => void;
}

export const SkillAssessmentModal: React.FC<SkillAssessmentModalProps> = ({
  skillName,
  previousScore,
  baselineScore,
  initialDifficulty = 'Moderate',
  mode = 'skill',
  stageId,
  stageTitle,
  onClose,
  onSaveResult
}) => {
  const navigate = useNavigate();

  const [difficulty, setDifficulty] = useState<'Easy' | 'Moderate' | 'Hard'>(initialDifficulty);
  const [step, setStep] = useState<'intro' | 'testing' | 'result'>('intro');
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [userAnswers, setUserAnswers] = useState<Record<string, number>>({});
  const [assessmentResult, setAssessmentResult] = useState<SkillAssessmentResult | null>(null);

  // Load questions matching chosen difficulty
  const questions = useMemo<SkillQuestion[]>(() => {
    return skillAssessmentService.getQuestionsForSkill(skillName, difficulty);
  }, [skillName, difficulty]);

  const currentQ = questions[currentIndex] || questions[0];
  const allTopics = Array.from(new Set(questions.map((q) => q.topic)));

  const handleSelectAnswer = (optionIdx: number) => {
    if (!currentQ) return;
    setUserAnswers((prev) => ({
      ...prev,
      [currentQ.id]: optionIdx
    }));
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      handleSubmitAssessment();
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
    }
  };

  const handleSubmitAssessment = () => {
    const result = skillAssessmentService.evaluateSkillAssessment({
      skillName,
      questions,
      userAnswers,
      previousScore: baselineScore !== undefined ? baselineScore : previousScore,
      difficulty,
      isValidation: mode === 'validation',
      stageId
    });

    setAssessmentResult(result);
    setStep('result');
    onSaveResult(result);
  };

  const handleRetake = () => {
    setUserAnswers({});
    setCurrentIndex(0);
    setAssessmentResult(null);
    setStep('testing');
  };

  const isValidation = mode === 'validation';

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[92vh] overflow-hidden flex flex-col shadow-2xl border border-slate-200">
        {/* Modal Top Bar */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold ${
              isValidation ? 'bg-indigo-50 text-indigo-600' : 'bg-blue-50 text-blue-600'
            }`}>
              {isValidation ? <ShieldCheck className="w-4 h-4" /> : <BrainCircuit className="w-4 h-4" />}
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                {step === 'intro'
                  ? isValidation
                    ? `Milestone Learning Validation: ${stageTitle || skillName}`
                    : `Assess Your ${skillName} Proficiency`
                  : step === 'testing'
                  ? `${skillName} Assessment (${difficulty})`
                  : `${skillName} Evaluation Report`}
              </h3>
              <span className="text-3xs text-slate-500 font-medium">
                {step === 'testing'
                  ? `Question ${currentIndex + 1} of ${questions.length} · ${difficulty} Difficulty`
                  : isValidation
                  ? 'Stage Completion Benchmark (75% Passing Threshold)'
                  : 'Objective Competency Verification'}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* STEP 1: INTRO & CONFIGURATION */}
          {step === 'intro' && (
            <div className="space-y-5">
              <div className={`p-4 rounded-xl border space-y-2 ${
                isValidation ? 'bg-indigo-50/70 border-indigo-200' : 'bg-blue-50/60 border-blue-200/80'
              }`}>
                <span className="text-xs font-bold text-slate-950 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                  {isValidation ? 'Roadmap Stage Learning Validation' : 'Verified Skill Assessment'}
                </span>
                <p className="text-xs text-slate-800 leading-relaxed">
                  {isValidation ? (
                    <>
                      Verify your practical understanding after completing learning modules for <strong>{stageTitle || skillName}</strong>. Scoring <strong>≥75%</strong> validates this stage, updates your skill score, and unlocks subsequent roadmap milestones.
                    </>
                  ) : (
                    <>
                      This skill evaluation assesses your practical working proficiency in <strong>{skillName}</strong>. Your score is calculated objectively from your answers without fabrication and updates your verified skill profile.
                    </>
                  )}
                </p>

                {baselineScore !== undefined && (
                  <div className="pt-1 flex items-center gap-3 text-2xs font-mono font-semibold text-indigo-950">
                    <span>Initial Baseline: {baselineScore}%</span>
                    {previousScore !== undefined && previousScore !== baselineScore && (
                      <span>· Prior Attempt: {previousScore}%</span>
                    )}
                  </div>
                )}
              </div>

              {/* Difficulty Level Selector */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1">
                    <SlidersHorizontal className="w-3 h-3 text-indigo-600" />
                    Validation Difficulty:
                  </span>
                  <span className="text-3xs text-slate-500">Benchmark Difficulty</span>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  {(['Easy', 'Moderate', 'Hard'] as const).map((diffOpt) => {
                    const isSelected = difficulty === diffOpt;
                    return (
                      <button
                        key={diffOpt}
                        type="button"
                        onClick={() => {
                          setDifficulty(diffOpt);
                          setUserAnswers({});
                          setCurrentIndex(0);
                        }}
                        className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                          isSelected
                            ? 'border-indigo-600 bg-indigo-50/80 text-indigo-950 font-bold ring-2 ring-indigo-400'
                            : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-medium'
                        }`}
                      >
                        <span className="text-xs block">{diffOpt}</span>
                        <span className="text-3xs text-slate-400 block font-normal">
                          {diffOpt === 'Easy' ? 'Foundational' : diffOpt === 'Moderate' ? 'Applied' : 'Advanced'}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Topics Evaluated */}
              <div className="space-y-2.5">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600">
                  Topics Covered in this Test ({allTopics.length}):
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {allTopics.map((topic) => (
                    <div
                      key={topic}
                      className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 flex items-center gap-2"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                      <span>{topic}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-3xs text-slate-500 space-y-1">
                <span className="font-bold text-slate-700 block">Assessment Format:</span>
                <p>• {questions.length} multiple-choice problem-solving and conceptual questions.</p>
                <p>• Immediate scoring upon submission; genuine performance without arbitrary overrides.</p>
                {isValidation && (
                  <p className="font-semibold text-indigo-900">• Minimum 75% required to earn &quot;Validated&quot; milestone status.</p>
                )}
              </div>

              <button
                type="button"
                onClick={() => setStep('testing')}
                className="w-full py-3 rounded-xl font-bold text-xs text-white bg-blue-600 hover:bg-blue-700 shadow-xs flex items-center justify-center gap-2 cursor-pointer transition-colors"
              >
                <span>Begin {difficulty} Assessment</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* STEP 2: ACTIVE QUESTION RUNNER */}
          {step === 'testing' && currentQ && (
            <div className="space-y-5">
              {/* Question Header */}
              <div className="space-y-2 pb-3 border-b border-slate-100">
                <div className="flex items-center justify-between text-2xs">
                  <div className="flex items-center gap-2">
                    <span className="font-bold uppercase tracking-wider text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                      Topic: {currentQ.topic}
                    </span>
                    <span className="font-bold uppercase px-2 py-0.5 rounded border border-slate-200 bg-slate-100 text-slate-700">
                      {difficulty}
                    </span>
                  </div>
                  <span className="font-mono text-slate-400">
                    {currentIndex + 1} of {questions.length}
                  </span>
                </div>

                <h4 className="text-sm sm:text-base font-bold text-slate-900 leading-snug">
                  {currentQ.question}
                </h4>

                {/* Code Snippet Box if available */}
                {currentQ.codeSnippet && (
                  <pre className="p-3 rounded-xl bg-slate-900 text-emerald-400 font-mono text-xs overflow-x-auto">
                    {currentQ.codeSnippet}
                  </pre>
                )}
              </div>

              {/* Options Radio List */}
              <div className="space-y-2.5">
                {currentQ.options.map((opt, idx) => {
                  const isSelected = userAnswers[currentQ.id] === idx;
                  return (
                    <div
                      key={idx}
                      onClick={() => handleSelectAnswer(idx)}
                      className={`p-3.5 rounded-xl border text-xs font-medium cursor-pointer transition-all flex items-start gap-3 ${
                        isSelected
                          ? 'bg-blue-50/70 border-blue-400 text-blue-950 shadow-2xs ring-1 ring-blue-300'
                          : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-800'
                      }`}
                    >
                      <div className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 mt-0.5 ${
                        isSelected ? 'border-blue-600 bg-blue-600 text-white' : 'border-slate-300'
                      }`}>
                        {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                      </div>
                      <span className="leading-relaxed">{opt}</span>
                    </div>
                  );
                })}
              </div>

              {/* Navigation Controls */}
              <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={handlePrev}
                  disabled={currentIndex === 0}
                  className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-600 hover:text-slate-900 disabled:opacity-30 cursor-pointer"
                >
                  Previous
                </button>

                <div className="flex items-center gap-2">
                  {currentIndex === questions.length - 1 ? (
                    <button
                      type="button"
                      onClick={handleSubmitAssessment}
                      disabled={userAnswers[currentQ.id] === undefined}
                      className="px-5 py-2 rounded-lg text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 shadow-xs cursor-pointer disabled:opacity-50 transition-colors"
                    >
                      {isValidation ? 'Submit Validation' : 'Submit Assessment'}
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={handleNext}
                      disabled={userAnswers[currentQ.id] === undefined}
                      className="px-5 py-2 rounded-lg text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 shadow-xs cursor-pointer disabled:opacity-50 transition-colors"
                    >
                      Next Question
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: RESULTS SCREEN */}
          {step === 'result' && assessmentResult && (
            <div className="space-y-6">
              {/* Validation Status Banner */}
              {isValidation && (
                <div className={`p-4 rounded-xl border flex items-center justify-between gap-3 ${
                  assessmentResult.calculatedScore >= 75
                    ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                    : 'bg-amber-50 border-amber-300 text-amber-950'
                }`}>
                  <div className="flex items-center gap-2.5">
                    {assessmentResult.calculatedScore >= 75 ? (
                      <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
                    ) : (
                      <AlertTriangle className="w-6 h-6 text-amber-600 shrink-0" />
                    )}
                    <div>
                      <h4 className="text-xs font-bold">
                        {assessmentResult.calculatedScore >= 75
                          ? 'Stage Validated & Milestone Unlocked!'
                          : 'Review Needed (Threshold: 75%)'}
                      </h4>
                      <p className="text-3xs text-slate-600">
                        {assessmentResult.calculatedScore >= 75
                          ? 'Your genuine performance confirmed mastery of this milestone. The next roadmap stage is now unlocked.'
                          : 'You scored below the 75% benchmark. Review the practice topics below to reinforce concepts before re-attempting.'}
                      </p>
                    </div>
                  </div>
                  <span className={`text-2xs font-bold font-mono px-2.5 py-1 rounded-md shrink-0 ${
                    assessmentResult.calculatedScore >= 75
                      ? 'bg-emerald-600 text-white'
                      : 'bg-amber-600 text-white'
                  }`}>
                    {assessmentResult.calculatedScore >= 75 ? 'PASSED' : 'REVIEW'}
                  </span>
                </div>
              )}

              {/* Score Header Card */}
              <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 text-center space-y-3">
                <span className="text-2xs font-bold uppercase tracking-wider text-slate-400">
                  {skillName} Verified Proficiency Score
                </span>

                <div className="flex items-center justify-center gap-4">
                  <div className="text-4xl font-mono font-extrabold text-blue-700">
                    {assessmentResult.calculatedScore}%
                  </div>
                  <div className="text-left border-l border-slate-200 pl-4">
                    <span className="text-2xs font-bold uppercase text-slate-400 block">Level:</span>
                    <span className="text-sm font-bold text-slate-900 block">
                      {assessmentResult.knowledgeLevel}
                    </span>
                    <span className="text-3xs text-slate-500 font-mono">
                      {assessmentResult.correctCount} / {assessmentResult.totalQuestions} Questions Correct ({assessmentResult.accuracy}% accuracy)
                    </span>
                  </div>
                </div>

                {/* Before vs After Score Comparison */}
                {baselineScore !== undefined && (
                  <div className="inline-flex items-center gap-3 px-3.5 py-1.5 rounded-lg bg-white border border-slate-200 text-xs">
                    <span className="text-slate-500">
                      Initial Baseline: <strong>{baselineScore}%</strong>
                    </span>
                    <span className="text-slate-300">→</span>
                    <span className="text-slate-800">
                      Validated: <strong>{assessmentResult.calculatedScore}%</strong>
                    </span>
                    {(() => {
                      const delta = assessmentResult.calculatedScore - baselineScore;
                      return (
                        <span className={`font-mono font-bold px-2 py-0.5 rounded text-3xs ${
                          delta >= 0
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                            : 'bg-rose-50 text-rose-800 border border-rose-200'
                        }`}>
                          {delta >= 0 ? `+${delta}% Growth` : `${delta}% Delta`}
                        </span>
                      );
                    })()}
                  </div>
                )}
              </div>

              {/* Strong Areas & Needs Improvement */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                {/* Strong Areas */}
                <div className="p-4 rounded-xl bg-white border border-emerald-200 space-y-2">
                  <span className="font-bold text-emerald-900 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    Strong Topics Demonstrated:
                  </span>
                  {assessmentResult.strongAreas.length > 0 ? (
                    <ul className="space-y-1 text-slate-700 text-2xs">
                      {assessmentResult.strongAreas.map((item, idx) => (
                        <li key={idx} className="flex items-center gap-1.5">
                          <span className="text-emerald-600 font-bold">•</span>
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-3xs text-slate-500 italic">
                      Review all foundational topics to build initial mastery.
                    </p>
                  )}
                </div>

                {/* Needs Improvement */}
                <div className="p-4 rounded-xl bg-white border border-amber-200 space-y-2">
                  <span className="font-bold text-amber-900 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                    Concepts Requiring Practice:
                  </span>
                  {assessmentResult.needsImprovement.length > 0 ? (
                    <ul className="space-y-1 text-slate-700 text-2xs">
                      {assessmentResult.needsImprovement.map((item, idx) => (
                        <li key={idx} className="flex items-center gap-1.5">
                          <span className="text-amber-600 font-bold">•</span>
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-3xs text-emerald-700 font-semibold">
                      Full mastery! 100% correct across all evaluated questions.
                    </p>
                  )}
                </div>
              </div>

              {/* Recommended Practice */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
                <span className="font-bold text-slate-900 flex items-center gap-1.5">
                  <BookOpen className="w-4 h-4 text-blue-600" />
                  Targeted Remediation &amp; Practice Tasks:
                </span>
                <ul className="space-y-1 text-slate-700 text-2xs">
                  {assessmentResult.recommendedPractice.map((rec, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <span className="text-blue-600 font-bold">•</span>
                      <span>{rec}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Actions */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={handleRetake}
                  className="w-full sm:w-auto px-4 py-2 rounded-lg text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Retake Test</span>
                </button>

                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      navigate('/assessment-history');
                    }}
                    className="flex-1 sm:flex-none px-4 py-2 rounded-lg text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 cursor-pointer"
                  >
                    View History &amp; Delts
                  </button>

                  <button
                    type="button"
                    onClick={onClose}
                    className="flex-1 sm:flex-none px-5 py-2 rounded-lg text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 shadow-xs cursor-pointer"
                  >
                    Done &amp; Return to Roadmap
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SkillAssessmentModal;
