import React, { useState, useEffect } from 'react';
import { X, Briefcase, Plus, Check, Sparkles, CheckCircle2, AlertCircle } from 'lucide-react';
import { CompanyJobPosting } from '../../types.ts';
import { useCompany } from '../../context/CompanyContext.tsx';

interface JobPostingModalProps {
  isOpen: boolean;
  onClose: () => void;
  postingToEdit?: CompanyJobPosting | null;
}

const POPULAR_SKILLS = [
  'Python',
  'SQL',
  'Power BI',
  'Excel',
  'Statistics',
  'Data Cleaning',
  'Machine Learning',
  'React',
  'JavaScript',
  'Java',
  'Docker',
  'Git',
  'AWS',
  'Tableau',
];

export const JobPostingModal: React.FC<JobPostingModalProps> = ({
  isOpen,
  onClose,
  postingToEdit,
}) => {
  const { createPosting, updatePosting, companyProfile } = useCompany();

  const [title, setTitle] = useState('');
  const [type, setType] = useState<CompanyJobPosting['type']>('Full-time');
  const [workplace, setWorkplace] = useState<CompanyJobPosting['workplace']>('Hybrid');
  const [location, setLocation] = useState('');
  const [experience, setExperience] = useState('0–1 years (College Freshers Eligible)');
  const [salary, setSalary] = useState('₹6.0 – 8.0 LPA');
  const [skills, setSkills] = useState<string[]>(['Python', 'SQL']);
  const [newSkillInput, setNewSkillInput] = useState('');
  const [description, setDescription] = useState('');
  const [responsibilitiesText, setResponsibilitiesText] = useState(
    'Extract operational data using optimized SQL queries\nBuild automated dashboard reporting pipelines\nCollaborate directly with cross-functional technical teams'
  );
  const [requirementsText, setRequirementsText] = useState(
    'BTech / BE degree in AI, Data Science, or Computer Science\nStrong foundational knowledge in relational databases\nClear verbal and written communication aptitude'
  );
  const [status, setStatus] = useState<CompanyJobPosting['status']>('Published');
  const [errorMessage, setErrorMessage] = useState('');
  const [skillFeedback, setSkillFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  useEffect(() => {
    if (postingToEdit) {
      setTitle(postingToEdit.title);
      setType(postingToEdit.type);
      setWorkplace(postingToEdit.workplace);
      setLocation(postingToEdit.location);
      setExperience(postingToEdit.experience);
      setSalary(postingToEdit.salary);
      setSkills(postingToEdit.requiredSkills || []);
      setDescription(postingToEdit.description);
      setResponsibilitiesText((postingToEdit.responsibilities || []).join('\n'));
      setRequirementsText((postingToEdit.requirements || []).join('\n'));
      setStatus(postingToEdit.status);
    } else {
      setTitle('');
      setType('Full-time');
      setWorkplace('Hybrid');
      setLocation(companyProfile?.location || 'Pune, Maharashtra');
      setExperience('0–1 years (College Freshers Eligible)');
      setSalary('₹6.0 – 8.0 LPA');
      setSkills(['Python', 'SQL', 'Excel']);
      setDescription('');
      setResponsibilitiesText(
        'Extract operational data using optimized SQL queries\nBuild automated dashboard reporting pipelines\nCollaborate directly with cross-functional technical teams'
      );
      setRequirementsText(
        'BTech / BE degree in AI, Data Science, or Computer Science\nStrong foundational knowledge in relational databases\nClear verbal and written communication aptitude'
      );
      setStatus('Published');
    }
    setErrorMessage('');
    setSkillFeedback(null);
  }, [postingToEdit, isOpen, companyProfile]);

  if (!isOpen) return null;

  const toggleSkill = (skill: string) => {
    if (skills.includes(skill)) {
      setSkills(skills.filter((s) => s !== skill));
    } else {
      setSkills([...skills, skill]);
    }
  };

  const handleAddCustomSkill = (e?: React.KeyboardEvent | React.MouseEvent) => {
    if (e && 'key' in e && e.key !== 'Enter') return;
    if (e) e.preventDefault();
    const clean = newSkillInput.trim();
    if (!clean) {
      setSkillFeedback({ type: 'error', message: 'Please enter a skill name before clicking Add.' });
      setTimeout(() => setSkillFeedback(null), 3500);
      return;
    }
    if (skills.some((s) => s.toLowerCase() === clean.toLowerCase())) {
      setSkillFeedback({ type: 'error', message: `"${clean}" is already in the required skills list.` });
      setTimeout(() => setSkillFeedback(null), 3500);
      return;
    }
    setSkills([...skills, clean]);
    setNewSkillInput('');
    setSkillFeedback({ type: 'success', message: `Added "${clean}" to job skills.` });
    setTimeout(() => setSkillFeedback(null), 3500);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setErrorMessage('Job title is required.');
      return;
    }

    const responsibilities = responsibilitiesText
      .split('\n')
      .map((l) => l.trim())
      .filter(Boolean);

    const requirements = requirementsText
      .split('\n')
      .map((l) => l.trim())
      .filter(Boolean);

    if (postingToEdit) {
      const result = updatePosting(postingToEdit.id, {
        title: title.trim(),
        type,
        workplace,
        location: location.trim(),
        experience: experience.trim(),
        salary: salary.trim(),
        requiredSkills: skills,
        description: description.trim() || `Exciting opportunity for ${title.trim()} at ${companyProfile?.name}.`,
        responsibilities,
        requirements,
        status,
      });

      if (!result.success) {
        setErrorMessage(result.error || 'Failed to update posting.');
        return;
      }
    } else {
      const result = createPosting({
        title: title.trim(),
        type,
        workplace,
        location: location.trim(),
        experience: experience.trim(),
        salary: salary.trim(),
        requiredSkills: skills,
        description: description.trim() || `Exciting opportunity for ${title.trim()} at ${companyProfile?.name}.`,
        responsibilities,
        requirements,
        status,
      });

      if (!result.success) {
        setErrorMessage(result.error || 'Failed to create posting.');
        return;
      }
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Modal Dialog */}
      <div className="relative bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-2xl w-full p-6 sm:p-7 z-10 my-8 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600">
              <Briefcase className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900">
                {postingToEdit ? 'Edit Opening' : 'Post New Opening'}
              </h2>
              <p className="text-2xs text-slate-500">
                {companyProfile?.name} &bull; Target college candidates & fresh graduates
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="overflow-y-auto flex-1 py-4 space-y-4 pr-1">
          {errorMessage && (
            <div className="p-3 text-xs text-rose-700 bg-rose-50 border border-rose-200 rounded-lg">
              {errorMessage}
            </div>
          )}

          {/* Job Title */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Position Title <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Junior Data Analyst or SDE Intern"
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600"
            />
          </div>

          {/* Type, Workplace, Location */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Opportunity Type
              </label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as any)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600"
              >
                <option value="Full-time">Full-time</option>
                <option value="Internship">Internship</option>
                <option value="Contract">Contract</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Workplace</label>
              <select
                value={workplace}
                onChange={(e) => setWorkplace(e.target.value as any)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600"
              >
                <option value="Hybrid">Hybrid</option>
                <option value="Remote">Remote</option>
                <option value="On-site">On-site</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Location</label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="e.g. Pune, Maharashtra"
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600"
              />
            </div>
          </div>

          {/* Experience & Salary */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Experience Requirement
              </label>
              <input
                type="text"
                value={experience}
                onChange={(e) => setExperience(e.target.value)}
                placeholder="e.g. 0–1 years / Freshers"
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Compensation / Stipend
              </label>
              <input
                type="text"
                value={salary}
                onChange={(e) => setSalary(e.target.value)}
                placeholder="e.g. ₹6.5 – 8.5 LPA or ₹25,000/mo"
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600"
              />
            </div>
          </div>

          {/* Required Skills */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Required Skills Benchmark
            </label>
            <div className="flex flex-wrap gap-1.5 mb-2">
              {POPULAR_SKILLS.map((skill) => {
                const isSelected = skills.includes(skill);
                return (
                  <button
                    key={skill}
                    type="button"
                    onClick={() => toggleSkill(skill)}
                    className={`px-2.5 py-1 text-2xs font-medium rounded-md transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-indigo-600 text-white shadow-2xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {skill} {isSelected && '✓'}
                  </button>
                );
              })}
            </div>

            {/* Custom Skill Add */}
            <div className="flex gap-2">
              <input
                type="text"
                value={newSkillInput}
                onChange={(e) => setNewSkillInput(e.target.value)}
                onKeyDown={handleAddCustomSkill}
                placeholder="Add custom skill (e.g. Snowflake, PySpark)..."
                className="flex-1 px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:border-indigo-600"
              />
              <button
                type="button"
                onClick={handleAddCustomSkill}
                className="px-3 py-1.5 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors cursor-pointer"
              >
                Add
              </button>
            </div>
            {skillFeedback && (
              <div
                className={`mt-1.5 p-2 rounded-lg text-2xs font-medium flex items-center gap-1.5 ${
                  skillFeedback.type === 'success'
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                    : 'bg-rose-50 text-rose-800 border border-rose-200'
                }`}
              >
                {skillFeedback.type === 'success' ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                ) : (
                  <AlertCircle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                )}
                <span>{skillFeedback.message}</span>
              </div>
            )}
            {skills.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-1">
                <span className="text-3xs text-slate-400 self-center">Selected:</span>
                {skills.map((s) => (
                  <span
                    key={s}
                    className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-3xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200/60"
                  >
                    {s}
                    <button
                      type="button"
                      onClick={() => toggleSkill(s)}
                      className="hover:text-rose-600"
                    >
                      &times;
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Role Summary & Team Description
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Provide a clear description of the team and role context..."
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600"
            />
          </div>

          {/* Responsibilities */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Core Responsibilities (one per line)
            </label>
            <textarea
              rows={3}
              value={responsibilitiesText}
              onChange={(e) => setResponsibilitiesText(e.target.value)}
              className="w-full px-3 py-2 text-xs font-mono bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600"
            />
          </div>

          {/* Requirements */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Candidate Requirements & Eligibility (one per line)
            </label>
            <textarea
              rows={3}
              value={requirementsText}
              onChange={(e) => setRequirementsText(e.target.value)}
              className="w-full px-3 py-2 text-xs font-mono bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600"
            />
          </div>

          {/* Status Selection */}
          <div className="flex items-center gap-4 pt-1">
            <span className="text-xs font-semibold text-slate-700">Posting Status:</span>
            <label className="flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer">
              <input
                type="radio"
                name="postingStatus"
                value="Published"
                checked={status === 'Published'}
                onChange={() => setStatus('Published')}
                className="text-indigo-600"
              />
              <span className="font-semibold text-emerald-700">Published (Live to Students)</span>
            </label>
            <label className="flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer">
              <input
                type="radio"
                name="postingStatus"
                value="Draft"
                checked={status === 'Draft'}
                onChange={() => setStatus('Draft')}
                className="text-indigo-600"
              />
              <span>Draft (Private)</span>
            </label>
            {postingToEdit && (
              <label className="flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer">
                <input
                  type="radio"
                  name="postingStatus"
                  value="Closed"
                  checked={status === 'Closed'}
                  onChange={() => setStatus('Closed')}
                  className="text-indigo-600"
                />
                <span className="text-slate-500">Closed (Archived)</span>
              </label>
            )}
          </div>

          {/* Footer buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs hover:shadow-sm transition-all cursor-pointer"
            >
              {postingToEdit ? 'Save Changes' : 'Publish Opening'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
