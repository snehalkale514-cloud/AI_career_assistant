import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useCompany } from '../../context/CompanyContext.tsx';

export const CompanyProtectedRoute: React.FC = () => {
  const { companyUser } = useCompany();

  if (!companyUser) {
    return <Navigate to="/company/login" replace />;
  }

  return <Outlet />;
};
