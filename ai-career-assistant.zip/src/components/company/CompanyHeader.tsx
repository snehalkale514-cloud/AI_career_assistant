import React from 'react';
import { Menu, Plus, Building2, ShieldCheck, ExternalLink } from 'lucide-react';
import { useCompany } from '../../context/CompanyContext.tsx';
import { Link } from 'react-router-dom';

interface CompanyHeaderProps {
  onMobileMenuToggle: () => void;
  onOpenCreateJob?: () => void;
}

export const CompanyHeader: React.FC<CompanyHeaderProps> = ({
  onMobileMenuToggle,
  onOpenCreateJob,
}) => {
  const { companyUser, companyProfile, postings, applicants } = useCompany();

  const activeJobsCount = postings.filter((p) => p.status === 'Published').length;

  return (
    <header className="sticky top-0 z-20 h-16 bg-white/95 backdrop-blur-xs border-b border-slate-200/80 px-4 sm:px-6 flex items-center justify-between">
      {/* Left: Mobile Toggle & Employer Context */}
      <div className="flex items-center gap-3">
        <button
          onClick={onMobileMenuToggle}
          className="p-2 -ml-2 text-slate-500 hover:text-slate-800 lg:hidden rounded-lg hover:bg-slate-100 cursor-pointer"
          aria-label="Toggle menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight leading-tight">
              {companyProfile?.name || 'Recruiter Workspace'}
            </h1>
            <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-3xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200/60">
              <ShieldCheck className="w-3 h-3 text-emerald-600" />
              Verified Employer
            </span>
          </div>
          <p className="hidden sm:block text-2xs text-slate-500">
            {activeJobsCount} active openings &bull; {applicants.length} total applications received
          </p>
        </div>
      </div>

      {/* Right: Actions & Profile Pill */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Switch to Student Portal quick button */}
        <Link
          to="/dashboard"
          className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-600 hover:text-blue-700 bg-slate-100 hover:bg-blue-50/60 rounded-lg transition-colors"
        >
          <span>Student Portal</span>
          <ExternalLink className="w-3 h-3" />
        </Link>

        {/* Post Job Button */}
        {onOpenCreateJob && (
          <button
            onClick={onOpenCreateJob}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs hover:shadow-sm transition-all cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Post Opening</span>
            <span className="sm:hidden">Post</span>
          </button>
        )}

        {/* Recruiter Pill */}
        <Link
          to="/company/profile"
          className="flex items-center gap-2 pl-2 sm:pl-3 border-l border-slate-200 cursor-pointer hover:opacity-85 transition-opacity"
        >
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-700 to-indigo-500 flex items-center justify-center text-white text-xs font-bold shadow-2xs">
            {companyUser?.name ? companyUser.name.charAt(0).toUpperCase() : 'R'}
          </div>
          <div className="hidden sm:block text-left">
            <span className="block text-xs font-bold text-slate-900 leading-tight">
              {companyUser?.name || 'Recruiter'}
            </span>
            <span className="block text-2xs text-indigo-600 font-medium">
              {companyUser?.jobTitle || 'Campus Hiring'}
            </span>
          </div>
        </Link>
      </div>
    </header>
  );
};
