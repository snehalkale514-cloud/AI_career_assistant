import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Briefcase,
  Users,
  Building2,
  PlusCircle,
  LogOut,
  Sparkles,
  X,
  ExternalLink,
  ShieldCheck,
  ChevronRight,
} from 'lucide-react';
import { useCompany } from '../../context/CompanyContext.tsx';

interface CompanySidebarProps {
  mobileOpen?: boolean;
  onMobileClose?: () => void;
  onOpenCreateJob?: () => void;
}

export const CompanySidebar: React.FC<CompanySidebarProps> = ({
  mobileOpen,
  onMobileClose,
  onOpenCreateJob,
}) => {
  const { companyUser, companyProfile, postings, applicants, logoutCompany } = useCompany();
  const navigate = useNavigate();

  const navItems = [
    { label: 'Overview', path: '/company/dashboard', icon: LayoutDashboard },
    {
      label: 'Job Postings',
      path: '/company/jobs',
      icon: Briefcase,
      badge: postings.length > 0 ? postings.length : undefined,
    },
    {
      label: 'Candidates',
      path: '/company/applicants',
      icon: Users,
      badge: applicants.length > 0 ? applicants.length : undefined,
    },
    { label: 'Company Profile', path: '/company/profile', icon: Building2 },
  ];

  const handleLogout = () => {
    logoutCompany();
    if (onMobileClose) onMobileClose();
    navigate('/company/login');
  };

  const navContent = (
    <div className="flex flex-col h-full bg-white border-r border-slate-200">
      {/* Brand header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
        <NavLink
          to="/company/dashboard"
          className="flex items-center gap-2.5 group"
          onClick={onMobileClose}
        >
          <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white shadow-xs group-hover:scale-105 transition-transform">
            <Building2 className="w-4 h-4" />
          </div>
          <div className="leading-tight">
            <span className="block text-sm font-bold text-slate-900 tracking-tight">
              {companyProfile?.name || 'Recruiter Portal'}
            </span>
            <div className="flex items-center gap-1 text-2xs text-indigo-600 font-semibold">
              <ShieldCheck className="w-3 h-3 text-emerald-500" />
              <span>Verified Employer</span>
            </div>
          </div>
        </NavLink>

        {mobileOpen && (
          <button
            onClick={onMobileClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-md lg:hidden cursor-pointer"
            aria-label="Close navigation"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Quick Action Button */}
      <div className="p-3 border-b border-slate-100">
        <button
          onClick={() => {
            if (onOpenCreateJob) onOpenCreateJob();
            if (onMobileClose) onMobileClose();
          }}
          className="w-full inline-flex items-center justify-center gap-2 px-3 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs hover:shadow-sm transition-all cursor-pointer"
        >
          <PlusCircle className="w-3.5 h-3.5" />
          <span>Post Internship / Job</span>
        </button>
      </div>

      {/* Navigation list */}
      <div className="flex-1 overflow-y-auto px-3 py-3 space-y-1">
        <div className="px-3 pb-1 text-3xs font-semibold text-slate-400 uppercase tracking-wider">
          Employer Workspace
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              onClick={onMobileClose}
              className={({ isActive }) =>
                `flex items-center justify-between px-3 py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                  isActive
                    ? 'bg-indigo-50 text-indigo-700 font-semibold shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`
              }
            >
              <div className="flex items-center gap-2.5">
                <Icon className="w-4 h-4 shrink-0 text-slate-500" />
                <span>{item.label}</span>
              </div>
              {item.badge !== undefined && (
                <span className="px-1.5 py-0.5 text-3xs font-bold rounded-full bg-indigo-100 text-indigo-700">
                  {item.badge}
                </span>
              )}
            </NavLink>
          );
        })}
      </div>

      {/* Cross-portal link & user footer */}
      <div className="p-3 border-t border-slate-200 bg-slate-50/60 space-y-2">
        {/* Switch to Student Portal */}
        <NavLink
          to="/dashboard"
          onClick={onMobileClose}
          className="flex items-center justify-between px-3 py-2 text-xs font-medium text-slate-600 hover:text-blue-700 hover:bg-blue-50/60 rounded-lg border border-dashed border-slate-200 transition-colors"
        >
          <div className="flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            <span>Student Portal</span>
          </div>
          <ExternalLink className="w-3 h-3 text-slate-400" />
        </NavLink>

        {/* Recruiter info & logout */}
        <div className="pt-1 flex items-center justify-between px-2">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-7 h-7 rounded-full bg-indigo-600 text-white font-bold text-2xs flex items-center justify-center shrink-0">
              {companyUser?.name ? companyUser.name.charAt(0).toUpperCase() : 'R'}
            </div>
            <div className="truncate text-left">
              <span className="block text-2xs font-bold text-slate-900 truncate">
                {companyUser?.name || 'Recruiter'}
              </span>
              <span className="block text-3xs text-slate-500 truncate">
                {companyUser?.jobTitle || 'Recruitment Lead'}
              </span>
            </div>
          </div>
          <button
            onClick={handleLogout}
            title="Log out from recruiter workspace"
            className="p-1.5 text-slate-400 hover:text-rose-600 rounded-md hover:bg-slate-100 transition-colors cursor-pointer"
            aria-label="Sign out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-64 shrink-0 h-screen sticky top-0">
        {navContent}
      </aside>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity"
            onClick={onMobileClose}
          />
          <div className="relative w-72 max-w-full z-10">{navContent}</div>
        </div>
      )}
    </>
  );
};
