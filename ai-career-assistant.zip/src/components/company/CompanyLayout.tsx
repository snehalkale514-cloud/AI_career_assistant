import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { CompanySidebar } from './CompanySidebar.tsx';
import { CompanyHeader } from './CompanyHeader.tsx';
import { JobPostingModal } from './JobPostingModal.tsx';

export const CompanyLayout: React.FC = () => {
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [createJobModalOpen, setCreateJobModalOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Recruiter Sidebar */}
      <CompanySidebar
        mobileOpen={mobileSidebarOpen}
        onMobileClose={() => setMobileSidebarOpen(false)}
        onOpenCreateJob={() => setCreateJobModalOpen(true)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        <CompanyHeader
          onMobileMenuToggle={() => setMobileSidebarOpen(true)}
          onOpenCreateJob={() => setCreateJobModalOpen(true)}
        />
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          <Outlet context={{ openCreateJobModal: () => setCreateJobModalOpen(true) }} />
        </main>
      </div>

      {/* Global Post Opening Modal */}
      <JobPostingModal
        isOpen={createJobModalOpen}
        onClose={() => setCreateJobModalOpen(false)}
      />
    </div>
  );
};
