import React from 'react';
import { useNavigate } from 'react-router-dom';
import { X, CheckCheck, Briefcase, Compass, Award, Bell, Sparkles, GitBranch, Share2 } from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';

interface NotificationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({ isOpen, onClose }) => {
  const { notifications, markNotificationAsRead, markAllNotificationsAsRead } = useCareer();
  const navigate = useNavigate();

  if (!isOpen) return null;

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const getIcon = (type: string) => {
    switch (type) {
      case 'job':
        return <Briefcase className="w-4 h-4 text-blue-600" />;
      case 'roadmap':
        return <Compass className="w-4 h-4 text-indigo-600" />;
      case 'assessment':
        return <Award className="w-4 h-4 text-amber-600" />;
      case 'achievement':
        return <Sparkles className="w-4 h-4 text-purple-600" />;
      case 'github':
        return <GitBranch className="w-4 h-4 text-emerald-600" />;
      case 'linkedin':
        return <Share2 className="w-4 h-4 text-blue-500" />;
      default:
        return <Bell className="w-4 h-4 text-slate-600" />;
    }
  };

  const handleAction = (id: string, actionUrl?: string) => {
    markNotificationAsRead(id);
    onClose();
    if (actionUrl) {
      navigate(actionUrl);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Backdrop */}
      <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity" onClick={onClose} />

      {/* Slide-over panel */}
      <div className="relative w-full max-w-sm sm:max-w-md bg-white h-full shadow-2xl border-l border-slate-200 z-10 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/70">
          <div className="flex items-center gap-2.5">
            <h3 className="text-base font-bold text-slate-900">Notifications</h3>
            {unreadCount > 0 && (
              <span className="bg-blue-100 text-blue-800 text-2xs font-bold font-mono px-2 py-0.5 rounded-full tabular-nums">
                {unreadCount} new
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            {unreadCount > 0 && (
              <button
                onClick={markAllNotificationsAsRead}
                className="text-2xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1 transition-colors px-2 py-1 rounded hover:bg-blue-50 cursor-pointer"
                title="Mark all as read"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                <span>Mark read</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content list */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
          {notifications.length === 0 ? (
            <div className="p-8 text-center text-slate-400">
              <Bell className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm font-medium">No new notifications</p>
              <p className="text-xs text-slate-400 mt-1">You are completely up to date!</p>
            </div>
          ) : (
            notifications.map((notif) => (
              <div
                key={notif.id}
                onClick={() => handleAction(notif.id, notif.actionUrl)}
                className={`p-4 transition-colors cursor-pointer flex items-start gap-3.5 ${
                  notif.isRead ? 'bg-white hover:bg-slate-50/80' : 'bg-blue-50/40 hover:bg-blue-50/70'
                }`}
              >
                <div className="p-2 rounded-lg bg-white border border-slate-200/80 shadow-2xs mt-0.5 shrink-0">
                  {getIcon(notif.type)}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <h4 className={`text-xs font-semibold truncate ${notif.isRead ? 'text-slate-800' : 'text-blue-900 font-bold'}`}>
                      {notif.title}
                    </h4>
                    <span className="text-2xs text-slate-400 font-mono whitespace-nowrap shrink-0">
                      {notif.timestamp}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">{notif.message}</p>
                  {notif.actionUrl && (
                    <span className="inline-block mt-2 text-2xs font-semibold text-blue-600 hover:underline">
                      View details →
                    </span>
                  )}
                </div>

                {!notif.isRead && (
                  <span className="w-2 h-2 rounded-full bg-blue-600 shrink-0 mt-2" />
                )}
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-100 text-center">
          <p className="text-2xs text-slate-500">
            Real-time placement alerts tailored to BTech AI &amp; DS (2028 batch)
          </p>
        </div>
      </div>
    </div>
  );
};

export default NotificationDrawer;
