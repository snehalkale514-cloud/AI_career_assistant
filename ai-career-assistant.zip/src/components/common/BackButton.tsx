import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

interface BackButtonProps {
  to?: string;
  fallback?: string;
  label?: string;
  className?: string;
}

export const BackButton: React.FC<BackButtonProps> = ({
  to,
  fallback,
  label = 'Back',
  className = '',
}) => {
  const navigate = useNavigate();
  const location = useLocation();

  const handleBack = () => {
    if (to) {
      navigate(to);
      return;
    }
    // Check if there is in-app history in the current session
    if (window.history.state && typeof window.history.state.idx === 'number' && window.history.state.idx > 0) {
      navigate(-1);
      return;
    }
    // Safe portal-aware fallback
    if (fallback) {
      navigate(fallback);
    } else if (location.pathname.startsWith('/company')) {
      navigate('/company/dashboard');
    } else {
      navigate('/dashboard');
    }
  };

  return (
    <button
      type="button"
      onClick={handleBack}
      data-testid="back-button"
      className={`inline-flex items-center gap-2 px-3.5 py-1.5 text-xs sm:text-sm font-semibold text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg shadow-xs focus:outline-hidden focus-visible:ring-2 focus-visible:ring-blue-500/40 transition-colors cursor-pointer shrink-0 ${className}`}
      aria-label={label || 'Back'}
    >
      <ArrowLeft className="w-4 h-4 text-slate-600" />
      <span className="font-semibold text-slate-800">{label}</span>
    </button>
  );
};

export default BackButton;
