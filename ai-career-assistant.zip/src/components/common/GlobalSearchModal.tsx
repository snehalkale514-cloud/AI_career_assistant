import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, X, Briefcase, Code, FolderGit2, Building2, BookOpen, ArrowRight, Award } from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({ isOpen, onClose }) => {
  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<'All' | 'Jobs' | 'Skills' | 'Projects' | 'Achievements' | 'Companies' | 'Courses'>('All');
  const { jobs, skills, projects, achievements } = useCareer();
  const navigate = useNavigate();

  // Curated demo courses list
  const courses = useMemo(
    () => [
      { id: 'c1', title: 'Data Analysis with Python & Pandas', provider: 'VPKBIET Placement Squad', duration: '14 hrs', path: '/roadmap' },
      { id: 'c2', title: 'Relational Database SQL & Window Functions Masterclass', provider: 'Campus Tech Prep', duration: '10 hrs', path: '/interview/sql' },
      { id: 'c3', title: 'Power BI Desktop for Business Analytics', provider: 'Microsoft Certified Path', duration: '16 hrs', path: '/roadmap' },
      { id: 'c4', title: 'Inferential Business Statistics for Placement Tests', provider: 'Analytics Academy', duration: '8 hrs', path: '/skill-analytics' },
    ],
    []
  );

  // Derive companies dynamically from the live jobs data source
  const companies = useMemo(() => {
    if (jobs.length > 0) {
      const companyMap = new Map<string, { name: string; industry: string; hiringRoles: string; openCount: number }>();
      jobs.forEach((j) => {
        if (!j.company || j.company === 'Not provided') return;
        const existing = companyMap.get(j.company);
        if (existing) {
          existing.openCount += 1;
        } else {
          companyMap.set(j.company, {
            name: j.company,
            industry: j.workplace === 'Remote' ? 'Remote Technology' : `${j.location} Technology`,
            hiringRoles: j.title,
            openCount: 1,
          });
        }
      });
      return Array.from(companyMap.values()).map((c, i) => ({
        id: `comp_live_${i}`,
        ...c,
      }));
    }
    return [];
  }, [jobs]);

  const filteredResults = useMemo(() => {
    const q = query.trim().toLowerCase();

    const matchedJobs = jobs
      .filter((j) => !q || j.title.toLowerCase().includes(q) || j.company.toLowerCase().includes(q) || j.requiredSkills.some((s) => s.toLowerCase().includes(q)))
      .map((j) => ({ ...j, itemType: 'Jobs' as const }));

    const matchedSkills = skills
      .filter((s) => !q || s.name.toLowerCase().includes(q) || s.category.toLowerCase().includes(q))
      .map((s) => ({ ...s, itemType: 'Skills' as const }));

    const matchedProjects = projects
      .filter((p) => !q || p.title.toLowerCase().includes(q) || p.skills.some((s) => s.toLowerCase().includes(q)))
      .map((p) => ({ ...p, itemType: 'Projects' as const }));

    const matchedAchievements = achievements
      .filter((a) => !q || a.title.toLowerCase().includes(q) || a.organization.toLowerCase().includes(q) || a.category.toLowerCase().includes(q))
      .map((a) => ({ ...a, itemType: 'Achievements' as const }));

    const matchedCompanies = companies
      .filter((c) => !q || c.name.toLowerCase().includes(q) || c.industry.toLowerCase().includes(q) || c.hiringRoles.toLowerCase().includes(q))
      .map((c) => ({ ...c, itemType: 'Companies' as const }));

    const matchedCourses = courses
      .filter((c) => !q || c.title.toLowerCase().includes(q) || c.provider.toLowerCase().includes(q))
      .map((c) => ({ ...c, itemType: 'Courses' as const }));

    return {
      Jobs: matchedJobs,
      Skills: matchedSkills,
      Projects: matchedProjects,
      Achievements: matchedAchievements,
      Companies: matchedCompanies,
      Courses: matchedCourses,
    };
  }, [query, jobs, skills, projects, achievements, companies, courses]);

  if (!isOpen) return null;

  const handleSelect = (path: string) => {
    onClose();
    navigate(path);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 px-4 pb-6 overflow-y-auto">
      <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity" onClick={onClose} />

      <div className="relative w-full max-w-2xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden z-10">
        {/* Search Input Bar */}
        <div className="flex items-center px-4 py-3.5 border-b border-slate-100 bg-slate-50/70">
          <Search className="w-5 h-5 text-slate-400 shrink-0" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search jobs, skills, projects, achievements, courses..."
            autoFocus
            className="w-full px-3 py-1 bg-transparent text-sm font-medium text-slate-800 placeholder-slate-400 focus:outline-hidden"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-slate-400 hover:text-slate-600 rounded-md"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <kbd className="hidden sm:inline-block ml-2 px-2 py-0.5 text-2xs font-mono font-medium text-slate-400 bg-white border border-slate-200 rounded">
            ESC
          </kbd>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-1 px-4 py-2 border-b border-slate-100 bg-white overflow-x-auto text-xs">
          {(['All', 'Jobs', 'Skills', 'Projects', 'Achievements', 'Companies', 'Courses'] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
                activeCategory === cat
                  ? 'bg-blue-50 text-blue-700 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Results List */}
        <div className="max-h-[60vh] overflow-y-auto p-3 space-y-4">
          {/* Jobs */}
          {(activeCategory === 'All' || activeCategory === 'Jobs') && filteredResults.Jobs.length > 0 && (
            <div>
              <div className="text-2xs font-bold uppercase tracking-wider text-slate-400 px-3 py-1 flex items-center gap-1.5">
                <Briefcase className="w-3.5 h-3.5 text-blue-600" />
                <span>Job Openings ({filteredResults.Jobs.length})</span>
              </div>
              <div className="space-y-1 mt-1">
                {filteredResults.Jobs.slice(0, 3).map((job) => (
                  <div
                    key={job.id}
                    onClick={() => handleSelect('/jobs')}
                    className="flex items-center justify-between p-2.5 rounded-lg hover:bg-slate-50 cursor-pointer transition-colors border border-transparent hover:border-slate-100"
                  >
                    <div>
                      <h4 className="text-sm font-semibold text-slate-900">{job.title}</h4>
                      <p className="text-xs text-slate-500">
                        {job.company} · {job.location} · <span className="font-mono text-emerald-600 font-medium">{job.matchScore}% Match</span>
                      </p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-400" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Skills */}
          {(activeCategory === 'All' || activeCategory === 'Skills') && filteredResults.Skills.length > 0 && (
            <div>
              <div className="text-2xs font-bold uppercase tracking-wider text-slate-400 px-3 py-1 flex items-center gap-1.5">
                <Code className="w-3.5 h-3.5 text-indigo-600" />
                <span>Skills &amp; Benchmarks ({filteredResults.Skills.length})</span>
              </div>
              <div className="space-y-1 mt-1">
                {filteredResults.Skills.slice(0, 4).map((skill) => (
                  <div
                    key={skill.id}
                    onClick={() => handleSelect('/skill-analytics')}
                    className="flex items-center justify-between p-2.5 rounded-lg hover:bg-slate-50 cursor-pointer transition-colors border border-transparent hover:border-slate-100"
                  >
                    <div className="flex items-center gap-3">
                      <div>
                        <h4 className="text-sm font-semibold text-slate-900">{skill.name}</h4>
                        <p className="text-xs text-slate-500">
                          {skill.category} · Status: <span className="font-medium text-slate-700">{skill.status}</span>
                        </p>
                      </div>
                    </div>
                    <span className="font-mono text-xs font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                      {skill.currentLevel}%
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Projects */}
          {(activeCategory === 'All' || activeCategory === 'Projects') && filteredResults.Projects.length > 0 && (
            <div>
              <div className="text-2xs font-bold uppercase tracking-wider text-slate-400 px-3 py-1 flex items-center gap-1.5">
                <FolderGit2 className="w-3.5 h-3.5 text-amber-600" />
                <span>Recommended Projects ({filteredResults.Projects.length})</span>
              </div>
              <div className="space-y-1 mt-1">
                {filteredResults.Projects.slice(0, 3).map((proj) => (
                  <div
                    key={proj.id}
                    onClick={() => handleSelect('/projects')}
                    className="flex items-center justify-between p-2.5 rounded-lg hover:bg-slate-50 cursor-pointer transition-colors border border-transparent hover:border-slate-100"
                  >
                    <div>
                      <h4 className="text-sm font-semibold text-slate-900">{proj.title}</h4>
                      <p className="text-xs text-slate-500">
                        {proj.difficulty} · {proj.skills.join(', ')}
                      </p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-400" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Achievements */}
          {(activeCategory === 'All' || activeCategory === 'Achievements') && filteredResults.Achievements.length > 0 && (
            <div>
              <div className="text-2xs font-bold uppercase tracking-wider text-slate-400 px-3 py-1 flex items-center gap-1.5">
                <Award className="w-3.5 h-3.5 text-blue-600" />
                <span>Achievements &amp; Certifications ({filteredResults.Achievements.length})</span>
              </div>
              <div className="space-y-1 mt-1">
                {filteredResults.Achievements.slice(0, 3).map((ach) => (
                  <div
                    key={ach.id}
                    onClick={() => handleSelect('/achievements')}
                    className="flex items-center justify-between p-2.5 rounded-lg hover:bg-slate-50 cursor-pointer transition-colors border border-transparent hover:border-slate-100"
                  >
                    <div>
                      <h4 className="text-sm font-semibold text-slate-900">{ach.title}</h4>
                      <p className="text-xs text-slate-500">
                        {ach.organization} · {ach.category} · {ach.date}
                      </p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-400" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Companies */}
          {(activeCategory === 'All' || activeCategory === 'Companies') && filteredResults.Companies.length > 0 && (
            <div>
              <div className="text-2xs font-bold uppercase tracking-wider text-slate-400 px-3 py-1 flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5 text-purple-600" />
                <span>Placement Partners &amp; Companies ({filteredResults.Companies.length})</span>
              </div>
              <div className="space-y-1 mt-1">
                {filteredResults.Companies.map((comp) => (
                  <div
                    key={comp.id}
                    onClick={() => handleSelect('/jobs')}
                    className="flex items-center justify-between p-2.5 rounded-lg hover:bg-slate-50 cursor-pointer transition-colors border border-transparent hover:border-slate-100"
                  >
                    <div>
                      <h4 className="text-sm font-semibold text-slate-900">{comp.name}</h4>
                      <p className="text-xs text-slate-500">
                        {comp.industry} · Hiring: {comp.hiringRoles}
                      </p>
                    </div>
                    <span className="text-2xs font-medium text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
                      {comp.openCount} openings
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Courses */}
          {(activeCategory === 'All' || activeCategory === 'Courses') && filteredResults.Courses.length > 0 && (
            <div>
              <div className="text-2xs font-bold uppercase tracking-wider text-slate-400 px-3 py-1 flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5 text-emerald-600" />
                <span>Learning Modules &amp; Courses ({filteredResults.Courses.length})</span>
              </div>
              <div className="space-y-1 mt-1">
                {filteredResults.Courses.map((c) => (
                  <div
                    key={c.id}
                    onClick={() => handleSelect(c.path)}
                    className="flex items-center justify-between p-2.5 rounded-lg hover:bg-slate-50 cursor-pointer transition-colors border border-transparent hover:border-slate-100"
                  >
                    <div>
                      <h4 className="text-sm font-semibold text-slate-900">{c.title}</h4>
                      <p className="text-xs text-slate-500">
                        {c.provider} · {c.duration}
                      </p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-400" />
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="px-4 py-2.5 bg-slate-50 border-t border-slate-100 text-2xs text-slate-500 flex items-center justify-between">
          <span>Pro tip: Press <kbd className="px-1.5 py-0.5 bg-white border border-slate-200 rounded font-mono">Esc</kbd> anytime to dismiss search</span>
          <span className="font-medium text-blue-600 cursor-pointer hover:underline" onClick={() => handleSelect('/dashboard')}>
            Go to Main Dashboard →
          </span>
        </div>
      </div>
    </div>
  );
};

export default GlobalSearchModal;
