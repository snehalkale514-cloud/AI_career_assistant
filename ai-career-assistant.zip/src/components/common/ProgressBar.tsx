import React from 'react';

interface ProgressBarProps {
  value: number; // 0 to 100
  max?: number;
  label?: string;
  sublabel?: string;
  showValueText?: boolean;
  color?: 'blue' | 'emerald' | 'amber' | 'indigo';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({
  value,
  max = 100,
  label,
  sublabel,
  showValueText = true,
  color = 'blue',
  size = 'md',
  className = '',
}) => {
  const percentage = Math.min(100, Math.max(0, Math.round((value / max) * 100)));

  const heightClasses = {
    sm: 'h-1.5',
    md: 'h-2.5',
    lg: 'h-3.5',
  }[size];

  const colorClasses = {
    blue: 'bg-blue-600',
    emerald: 'bg-emerald-600',
    amber: 'bg-amber-500',
    indigo: 'bg-indigo-600',
  }[color];

  return (
    <div className={`w-full ${className}`}>
      {(label || showValueText) && (
        <div className="flex items-center justify-between gap-2 mb-1.5 text-sm">
          <div className="flex items-center gap-2">
            {label && <span className="font-medium text-slate-800">{label}</span>}
            {sublabel && <span className="text-xs text-slate-500">{sublabel}</span>}
          </div>
          {showValueText && (
            <span className="font-mono text-xs font-semibold text-slate-700 tabular-nums">
              {percentage}%
            </span>
          )}
        </div>
      )}
      <div className={`w-full bg-slate-100 rounded-full overflow-hidden ${heightClasses} border border-slate-200/60`}>
        <div
          className={`${colorClasses} h-full rounded-full transition-all duration-500 ease-out`}
          style={{ width: `${percentage}%` }}
          role="progressbar"
          aria-valuenow={percentage}
          aria-valuemin={0}
          aria-valuemax={100}
        />
      </div>
    </div>
  );
};
