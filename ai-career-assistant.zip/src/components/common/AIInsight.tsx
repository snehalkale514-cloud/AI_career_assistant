import React from 'react';
import { Sparkles, ArrowRight } from 'lucide-react';

interface AIInsightProps {
  type?: 'AI INSIGHT' | 'AI RECOMMENDATION' | 'AI ANALYSIS' | 'AI FEEDBACK';
  title?: string;
  children: React.ReactNode;
  actionLabel?: string;
  onAction?: () => void;
  className?: string;
}

export const AIInsight: React.FC<AIInsightProps> = ({
  type = 'AI INSIGHT',
  title,
  children,
  actionLabel,
  onAction,
  className = '',
}) => {
  return (
    <div
      className={`relative overflow-hidden rounded-xl border border-blue-200/90 bg-gradient-to-br from-blue-50/70 via-indigo-50/40 to-white p-5 shadow-xs ${className}`}
    >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="space-y-1.5 flex-1">
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1.5 text-xs font-bold tracking-wider uppercase text-blue-700">
              <Sparkles className="w-3.5 h-3.5 text-blue-600 animate-pulse" />
              {type}
            </span>
            {title && (
              <>
                <span className="text-slate-300">·</span>
                <span className="text-xs font-semibold text-slate-800">{title}</span>
              </>
            )}
          </div>
          <div className="text-sm text-slate-700 leading-relaxed font-normal">{children}</div>
        </div>

        {actionLabel && onAction && (
          <button
            onClick={onAction}
            className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors whitespace-nowrap shrink-0 shadow-xs cursor-pointer"
          >
            <span>{actionLabel}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </div>
  );
};
