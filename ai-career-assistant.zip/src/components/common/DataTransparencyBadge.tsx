import React from 'react';
import { Database, UserCheck, Radio, ShieldCheck, Info } from 'lucide-react';

interface DataTransparencyBadgeProps {
  activeScope?: 'all' | 'placement' | 'jobs' | 'roadmap';
  className?: string;
}

export const DataTransparencyBadge: React.FC<DataTransparencyBadgeProps> = ({
  activeScope = 'all',
  className = ''
}) => {
  return (
    <div className={`p-4 rounded-xl border border-slate-200 bg-slate-50/80 space-y-3 ${className}`}>
      <div className="flex items-center justify-between">
        <span className="text-3xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
          <Info className="w-3.5 h-3.5 text-blue-600" />
          Data Architecture &amp; Origin Transparency
        </span>
        <span className="text-3xs font-mono font-medium text-slate-500 bg-white border border-slate-200 px-2 py-0.5 rounded">
          College Project Demonstration Architecture
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Tier 1: Historical Benchmark Data */}
        <div className={`p-2.5 rounded-lg border text-xs space-y-1 ${
          activeScope === 'placement' || activeScope === 'all'
            ? 'bg-purple-50/70 border-purple-200 text-purple-950'
            : 'bg-white border-slate-200 text-slate-600'
        }`}>
          <div className="flex items-center gap-1.5 font-bold">
            <Database className="w-3.5 h-3.5 text-purple-700" />
            <span>1. Historical Benchmark Data</span>
          </div>
          <p className="text-3xs text-purple-800 leading-normal">
            Historical benchmark dataset: <code>placement_ml_sample_1000.csv</code> (300 records). Live placement scoring currently uses predefined, deterministic threshold rules. The CSV is not loaded or used for model training at runtime.
          </p>
        </div>

        {/* Tier 2: Current Student Data */}
        <div className={`p-2.5 rounded-lg border text-xs space-y-1 ${
          activeScope === 'all' || activeScope === 'roadmap'
            ? 'bg-blue-50/70 border-blue-200 text-blue-950'
            : 'bg-white border-slate-200 text-slate-600'
        }`}>
          <div className="flex items-center gap-1.5 font-bold">
            <UserCheck className="w-3.5 h-3.5 text-blue-700" />
            <span>2. Current Student Data</span>
          </div>
          <p className="text-3xs text-blue-800 leading-normal">
            Active candidate's live profile, CGPA, assessment results, and verified competencies entered into the system.
          </p>
        </div>

        {/* Tier 3: Live Job Data */}
        <div className={`p-2.5 rounded-lg border text-xs space-y-1 ${
          activeScope === 'jobs' || activeScope === 'roadmap' || activeScope === 'all'
            ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
            : 'bg-white border-slate-200 text-slate-600'
        }`}>
          <div className="flex items-center gap-1.5 font-bold">
            <Radio className="w-3.5 h-3.5 text-emerald-700" />
            <span>3. Live Job Data</span>
          </div>
          <p className="text-3xs text-emerald-800 leading-normal">
            Real-time public job feed with timestamp and requirement tags. Drives live skill-gap analysis.
          </p>
        </div>
      </div>
    </div>
  );
};
