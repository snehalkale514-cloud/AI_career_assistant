import React, { useState } from 'react';
import { NavLink, useNavigate, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  User,
  GraduationCap,
  FileCheck2,
  BarChart2,
  Compass,
  FolderGit2,
  Briefcase,
  MessageSquareCode,
  ListTodo,
  TrendingUp,
  Settings,
  LogOut,
  Sparkles,
  X,
  ChevronDown,
  ChevronRight,
  Award,
  Globe,
  Share2,
  GitBranch,
  FileCheck
} from 'lucide-react';
import { useCareer } from '../../context/CareerContext.tsx';

interface SidebarProps {
  mobileOpen?: boolean;
  onMobileClose?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ mobileOpen, onMobileClose }) => {
  const { savedJobs, applications, achievements, githubProjects, certificates, linkedinPosts, logoutStudent } = useCareer();
  const navigate = useNavigate();
  const location = useLocation();

  const isCareerHubActive =
    location.pathname.startsWith('/career-hub') ||
    location.pathname.startsWith('/certificates') ||
    location.pathname.startsWith('/achievements') ||
    location.pathname.startsWith('/linkedin') ||
    location.pathname.startsWith('/github') ||
    location.pathname.startsWith('/portfolio');

  const [careerHubOpen, setCareerHubOpen] = useState(true);

  const mainNavItems = [
    { label: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { label: 'Profile', path: '/profile', icon: User },
    { label: 'Skill Assessment', path: '/assessment', icon: GraduationCap },
    { label: 'Skill Analytics', path: '/skill-analytics', icon: BarChart2 },
    { label: 'Career Roadmap', path: '/roadmap', icon: Compass },
    { label: 'Projects', path: '/projects', icon: FolderGit2 },
    { label: 'Resume Analyzer', path: '/resume-analyzer', icon: FileCheck2 },
    { label: 'Jobs', path: '/jobs', icon: Briefcase, badge: savedJobs.length > 0 ? savedJobs.length : undefined },
    { label: 'Interview Preparation', path: '/interview', icon: MessageSquareCode },
    {
      label: 'Applications',
      path: '/applications',
      icon: ListTodo,
      badge: applications.length > 0 ? applications.length : undefined,
    },
    { label: 'Placement Readiness', path: '/placement-readiness', icon: TrendingUp },
  ];

  const careerHubSubmenu = [
    { label: 'Hub Overview', path: '/career-hub', icon: Sparkles },
    { label: 'Certificates', path: '/certificates', icon: FileCheck, count: certificates.length },
    { label: 'Achievements', path: '/achievements', icon: Award, count: achievements.length },
    { label: 'GitHub Workflows', path: '/github', icon: GitBranch, count: githubProjects.length },
    { label: 'LinkedIn Growth', path: '/linkedin', icon: Share2, count: linkedinPosts.length },
    { label: 'Public Portfolio', path: '/portfolio', icon: Globe },
  ];

  const handleLogout = () => {
    if (onMobileClose) onMobileClose();
    logoutStudent();
    navigate('/login');
  };

  const navContent = (
    <div className="flex flex-col h-full bg-white border-r border-slate-200">
      {/* Brand header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
        <NavLink
          to="/dashboard"
          className="flex items-center gap-2.5 group"
          onClick={onMobileClose}
        >
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-xs group-hover:scale-105 transition-transform">
            <Sparkles className="w-4 h-4" />
          </div>
          <div className="leading-tight">
            <span className="block text-sm font-bold text-slate-900 tracking-tight">
              AI Career Assistant
            </span>
            <span className="block text-2xs text-blue-600 font-medium">Placement Mentor</span>
          </div>
        </NavLink>

        {mobileOpen && (
          <button
            onClick={onMobileClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-md lg:hidden"
            aria-label="Close navigation"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Navigation menu items */}
      <div className="flex-1 overflow-y-auto px-3 py-3 space-y-1">
        <div className="px-3 py-1 text-2xs font-bold uppercase tracking-wider text-slate-400">
          Career Workspace
        </div>

        {mainNavItems.slice(0, 6).map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              onClick={onMobileClose}
              className={({ isActive }) =>
                `flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
                  isActive
                    ? 'bg-blue-50/80 text-blue-700 font-semibold border border-blue-200/60 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`
              }
            >
              <div className="flex items-center gap-2.5 truncate">
                <Icon className="w-4 h-4 shrink-0 text-slate-500 group-hover:text-slate-800" />
                <span className="truncate">{item.label}</span>
              </div>
              {item.badge !== undefined && (
                <span className="font-mono text-2xs font-semibold px-1.5 py-0.2 rounded-full bg-slate-100 text-slate-700 tabular-nums">
                  {item.badge}
                </span>
              )}
            </NavLink>
          );
        })}

        {/* Career Hub with Submenu */}
        <div className="pt-1">
          <div
            onClick={() => setCareerHubOpen(!careerHubOpen)}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium cursor-pointer transition-colors ${
              isCareerHubActive
                ? 'bg-blue-50/50 text-blue-900 font-semibold'
                : 'text-slate-700 hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Sparkles className="w-4 h-4 text-blue-600" />
              <span>Career Hub</span>
            </div>
            {careerHubOpen ? (
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            ) : (
              <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
            )}
          </div>

          {careerHubOpen && (
            <div className="pl-4 pr-1 py-1 space-y-0.5 border-l-2 border-blue-200 ml-4 my-1">
              {careerHubSubmenu.map((sub) => {
                const SubIcon = sub.icon;
                return (
                  <NavLink
                    key={sub.path}
                    to={sub.path}
                    onClick={onMobileClose}
                    className={({ isActive }) =>
                      `flex items-center justify-between px-2.5 py-1.5 rounded-md text-xs transition-colors ${
                        isActive
                          ? 'bg-blue-600 text-white font-semibold shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                      }`
                    }
                  >
                    <div className="flex items-center gap-2 truncate">
                      <SubIcon className="w-3.5 h-3.5 shrink-0" />
                      <span className="truncate">{sub.label}</span>
                    </div>
                    {sub.count !== undefined && (
                      <span className="font-mono text-3xs px-1.5 py-0.2 rounded bg-black/10 tabular-nums">
                        {sub.count}
                      </span>
                    )}
                  </NavLink>
                );
              })}
            </div>
          )}
        </div>

        {/* Remaining Nav Items */}
        {mainNavItems.slice(6).map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              onClick={onMobileClose}
              className={({ isActive }) =>
                `flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
                  isActive
                    ? 'bg-blue-50/80 text-blue-700 font-semibold border border-blue-200/60 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`
              }
            >
              <div className="flex items-center gap-2.5 truncate">
                <Icon className="w-4 h-4 shrink-0 text-slate-500 group-hover:text-slate-800" />
                <span className="truncate">{item.label}</span>
              </div>
              {item.badge !== undefined && (
                <span className="font-mono text-2xs font-semibold px-1.5 py-0.2 rounded-full bg-slate-100 text-slate-700 tabular-nums">
                  {item.badge}
                </span>
              )}
            </NavLink>
          );
        })}
      </div>

      {/* Bottom Footer actions */}
      <div className="p-3 border-t border-slate-100 bg-slate-50/50 space-y-1">
        <NavLink
          to="/settings"
          onClick={onMobileClose}
          className={({ isActive }) =>
            `flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
              isActive
                ? 'bg-blue-50 text-blue-700 font-semibold'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`
          }
        >
          <Settings className="w-4 h-4 text-slate-500" />
          <span>Settings</span>
        </NavLink>

        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium text-rose-600 hover:text-rose-700 hover:bg-rose-50 transition-colors text-left cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop fixed sidebar */}
      <aside className="hidden lg:block w-64 h-screen sticky top-0 shrink-0 z-30">
        {navContent}
      </aside>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity"
            onClick={onMobileClose}
          />
          <div className="relative w-72 max-w-xs h-full z-10 shadow-2xl">
            {navContent}
          </div>
        </div>
      )}
    </>
  );
};

export default Sidebar;
