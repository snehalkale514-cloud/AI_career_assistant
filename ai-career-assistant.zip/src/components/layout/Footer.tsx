import React from 'react';
import { Link } from 'react-router-dom';
import { Sparkles, Mail, MapPin, ExternalLink } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer id="contact" className="bg-slate-950 text-slate-400 border-t border-slate-900 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 pb-12 border-b border-slate-800/80">
          {/* Brand Info */}
          <div className="space-y-4 md:col-span-1">
            <div className="flex items-center gap-2 text-white font-bold text-lg">
              <div className="w-7 h-7 rounded-md bg-blue-600 flex items-center justify-center text-white">
                <Sparkles className="w-3.5 h-3.5" />
              </div>
              <span>AI Career Assistant</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Your AI Mentor for Placements & Career Growth. Built specifically for engineering and college students preparing for technical recruitment, internships, and dream roles.
            </p>
            <div className="pt-2 text-2xs text-slate-400 space-y-1">
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-blue-400" />
                <span>Pune / Baramati Tech Corridor, MH, India</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-blue-400" />
                <span>careers@aicampusassistant.edu</span>
              </div>
            </div>
          </div>

          {/* Placement Modules */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-4">
              Placement Modules
            </h4>
            <ul className="space-y-2.5 text-xs">
              <li>
                <Link to="/app/resume-analyzer" className="hover:text-blue-400 transition-colors">
                  ATS Resume Scoring & Optimization
                </Link>
              </li>
              <li>
                <Link to="/app/assessment" className="hover:text-blue-400 transition-colors">
                  Interactive Skill Diagnostic Tests
                </Link>
              </li>
              <li>
                <Link to="/app/roadmap" className="hover:text-blue-400 transition-colors">
                  Personalized 9-Stage Career Roadmap
                </Link>
              </li>
              <li>
                <Link to="/app/interview-prep" className="hover:text-blue-400 transition-colors">
                  AI Mock Interview Practice
                </Link>
              </li>
              <li>
                <Link to="/app/readiness" className="hover:text-blue-400 transition-colors">
                  Campus Placement Readiness Score
                </Link>
              </li>
            </ul>
          </div>

          {/* Target Engineering Roles */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-4">
              Target Career Tracks
            </h4>
            <ul className="space-y-2.5 text-xs">
              <li>
                <Link to="/app/jobs" className="hover:text-blue-400 transition-colors">
                  Data Analyst & Business Intelligence
                </Link>
              </li>
              <li>
                <Link to="/app/jobs" className="hover:text-blue-400 transition-colors">
                  Data Scientist & ML Engineer
                </Link>
              </li>
              <li>
                <Link to="/app/jobs" className="hover:text-blue-400 transition-colors">
                  Software Development Engineer (SDE)
                </Link>
              </li>
              <li>
                <Link to="/app/jobs" className="hover:text-blue-400 transition-colors">
                  Full Stack Web Developer
                </Link>
              </li>
              <li>
                <Link to="/app/jobs" className="hover:text-blue-400 transition-colors">
                  AI & Quantitative Research Trainee
                </Link>
              </li>
            </ul>
          </div>

          {/* Academic & College Project Note */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-4">
              Academic Project
            </h4>
            <div className="bg-slate-900/80 rounded-lg p-3.5 border border-slate-800 text-2xs space-y-2 text-slate-300">
              <p className="font-semibold text-white">Department of Artificial Intelligence & Data Science</p>
              <p className="text-slate-400 leading-relaxed">
                Vidya Pratishthan's Kamalnayan Bajaj Institute of Engineering & Technology (VPKBIET)
              </p>
              <div className="pt-2 border-t border-slate-800 text-blue-400 flex items-center justify-between">
                <span>Class of 2028</span>
                <span className="flex items-center gap-1 font-mono text-2xs">
                  Pune University <ExternalLink className="w-3 h-3" />
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-4">
          <p>© 2026 AI Career Assistant. All rights reserved. Designed for student placement success.</p>
          <div className="flex items-center gap-5">
            <Link to="/company/login" className="text-indigo-400 hover:text-indigo-300 font-semibold transition-colors">
              Employer / Recruiter Portal
            </Link>
            <Link to="/dashboard" className="hover:text-slate-300 transition-colors">
              Student Portal
            </Link>
            <Link to="/login" className="hover:text-slate-300 transition-colors">
              Sign In
            </Link>
            <Link to="/signup" className="hover:text-slate-300 transition-colors">
              Register
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};
