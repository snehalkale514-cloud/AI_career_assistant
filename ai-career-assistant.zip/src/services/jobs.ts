/**
 * Job Service for Placement Recommendations
 */

import { JobItem } from '../types.ts';

export const jobsService = {
  /**
   * Calculates dynamic match percentage against user's verified competencies.
   */
  calculateMatchScore(userSkills: { name: string; currentLevel: number }[], requiredSkills: string[]) {
    if (!requiredSkills.length) return 80;

    let matchedCount = 0;
    let totalScoreWeight = 0;

    requiredSkills.forEach((req) => {
      const found = userSkills.find((u) => u.name.toLowerCase() === req.toLowerCase());
      if (found) {
        matchedCount++;
        totalScoreWeight += Math.min(100, found.currentLevel) / 100;
      }
    });

    const matchRatio = matchedCount / requiredSkills.length;
    const weightedScore = Math.round((matchRatio * 0.6 + (totalScoreWeight / (matchedCount || 1)) * 0.4) * 100);
    return Math.max(65, Math.min(96, weightedScore));
  },
};
