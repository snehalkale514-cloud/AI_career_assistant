/**
 * Pico Face Detection Engine (TypeScript implementation)
 * 
 * Based on the official pico.js implementation by Nenad Markuš.
 * Reference: https://github.com/nenadmarkus/picojs
 * Paper: Markuš et al. "A method for object detection based on pixel intensity comparisons,
 * organized in decision trees" (Neurocomputing 2014).
 * 
 * License Attribution:
 * Copyright (c) 2017 Nenad Markuš
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 */

export interface PicoImage {
  pixels: Uint8Array;
  nrows: number;
  ncols: number;
  ldim: number;
}

export interface PicoParams {
  shiftfactor: number;
  minsize: number;
  maxsize: number;
  scalefactor: number;
}

/**
 * Quadruplet [row, column, scale, score]
 */
export type PicoDetection = [number, number, number, number];

export type PicoClassifyRegionFn = (
  r: number,
  c: number,
  s: number,
  pixels: Uint8Array,
  ldim: number
) => number;

/**
 * Unpacks the binary cascade data and returns the classification function.
 */
export function unpackPicoCascade(bytes: Uint8Array): PicoClassifyRegionFn {
  const dview = new DataView(new ArrayBuffer(4));
  // Skip first 8 bytes (version & training metadata)
  let p = 8;

  // 1. Read tree depth (tdepth): 32-bit signed int
  dview.setUint8(0, bytes[p + 0]);
  dview.setUint8(1, bytes[p + 1]);
  dview.setUint8(2, bytes[p + 2]);
  dview.setUint8(3, bytes[p + 3]);
  const tdepth = dview.getInt32(0, true);
  p += 4;

  // 2. Read number of trees (ntrees): 32-bit signed int
  dview.setUint8(0, bytes[p + 0]);
  dview.setUint8(1, bytes[p + 1]);
  dview.setUint8(2, bytes[p + 2]);
  dview.setUint8(3, bytes[p + 3]);
  const ntrees = dview.getInt32(0, true);
  p += 4;

  // 3. Read actual trees and cascade thresholds
  const tcodesLs: number[] = [];
  const tpredsLs: number[] = [];
  const threshLs: number[] = [];

  const pow2tdepth = Math.pow(2, tdepth);

  for (let t = 0; t < ntrees; ++t) {
    // Read binary tests placed in internal tree nodes
    tcodesLs.push(0, 0, 0, 0);
    const sliceLen = 4 * pow2tdepth - 4;
    for (let k = 0; k < sliceLen; ++k) {
      tcodesLs.push(bytes[p + k]);
    }
    p += sliceLen;

    // Read leaf predictions
    for (let i = 0; i < pow2tdepth; ++i) {
      dview.setUint8(0, bytes[p + 0]);
      dview.setUint8(1, bytes[p + 1]);
      dview.setUint8(2, bytes[p + 2]);
      dview.setUint8(3, bytes[p + 3]);
      tpredsLs.push(dview.getFloat32(0, true));
      p += 4;
    }

    // Read threshold
    dview.setUint8(0, bytes[p + 0]);
    dview.setUint8(1, bytes[p + 1]);
    dview.setUint8(2, bytes[p + 2]);
    dview.setUint8(3, bytes[p + 3]);
    threshLs.push(dview.getFloat32(0, true));
    p += 4;
  }

  const tcodes = new Int8Array(tcodesLs);
  const tpreds = new Float32Array(tpredsLs);
  const thresh = new Float32Array(threshLs);

  // Construct region classification function
  function classifyRegion(
    r: number,
    c: number,
    s: number,
    pixels: Uint8Array,
    ldim: number
  ): number {
    r = 256 * r;
    c = 256 * c;
    let root = 0;
    let o = 0.0;
    const pow2 = pow2tdepth >> 0;

    for (let i = 0; i < ntrees; ++i) {
      let idx = 1;
      for (let j = 0; j < tdepth; ++j) {
        const p1Row = (r + tcodes[root + 4 * idx + 0] * s) >> 8;
        const p1Col = (c + tcodes[root + 4 * idx + 1] * s) >> 8;
        const p2Row = (r + tcodes[root + 4 * idx + 2] * s) >> 8;
        const p2Col = (c + tcodes[root + 4 * idx + 3] * s) >> 8;
        idx =
          2 * idx +
          (pixels[p1Row * ldim + p1Col] <= pixels[p2Row * ldim + p2Col] ? 1 : 0);
      }

      o += tpreds[pow2 * i + idx - pow2];

      if (o <= thresh[i]) {
        return -1;
      }
      root += 4 * pow2;
    }

    return o - thresh[ntrees - 1];
  }

  return classifyRegion;
}

/**
 * Runs the detection cascade across multi-scale candidate windows.
 */
export function runPicoCascade(
  image: PicoImage,
  classifyRegion: PicoClassifyRegionFn,
  params: PicoParams
): PicoDetection[] {
  const pixels = image.pixels;
  const nrows = image.nrows;
  const ncols = image.ncols;
  const ldim = image.ldim;
  const shiftfactor = params.shiftfactor;
  const minsize = params.minsize;
  const maxsize = params.maxsize;
  const scalefactor = params.scalefactor;

  let scale = minsize;
  const detections: PicoDetection[] = [];

  while (scale <= maxsize) {
    const step = Math.max((shiftfactor * scale) >> 0, 1);
    const offset = (scale / 2 + 1) >> 0;

    for (let r = offset; r <= nrows - offset; r += step) {
      for (let c = offset; c <= ncols - offset; c += step) {
        const q = classifyRegion(r, c, scale, pixels, ldim);
        if (q > 0.0) {
          detections.push([r, c, scale, q]);
        }
      }
    }

    scale = scale * scalefactor;
  }

  return detections;
}

/**
 * Calculates Intersection over Union (IoU) of two detections.
 */
function calculateIoU(det1: PicoDetection, det2: PicoDetection): number {
  const r1 = det1[0], c1 = det1[1], s1 = det1[2];
  const r2 = det2[0], c2 = det2[1], s2 = det2[2];

  const overr = Math.max(0, Math.min(r1 + s1 / 2, r2 + s2 / 2) - Math.max(r1 - s1 / 2, r2 - s2 / 2));
  const overc = Math.max(0, Math.min(c1 + s1 / 2, c2 + s2 / 2) - Math.max(c1 - s1 / 2, c2 - s2 / 2));

  return (overr * overc) / (s1 * s1 + s2 * s2 - overr * overc);
}

/**
 * Merges raw detections using Non-Maximum Suppression clustering.
 */
export function clusterPicoDetections(
  dets: PicoDetection[],
  iouThreshold = 0.2
): PicoDetection[] {
  // Sort descending by score
  const sorted = [...dets].sort((a, b) => b[3] - a[3]);

  const assignments = new Array(sorted.length).fill(0);
  const clusters: PicoDetection[] = [];

  for (let i = 0; i < sorted.length; ++i) {
    if (assignments[i] === 0) {
      let r = 0.0;
      let c = 0.0;
      let s = 0.0;
      let q = 0.0;
      let n = 0;

      for (let j = i; j < sorted.length; ++j) {
        if (calculateIoU(sorted[i], sorted[j]) > iouThreshold) {
          assignments[j] = 1;
          r += sorted[j][0];
          c += sorted[j][1];
          s += sorted[j][2];
          q += sorted[j][3];
          n += 1;
        }
      }

      clusters.push([r / n, c / n, s / n, q]);
    }
  }

  return clusters;
}

/**
 * Creates temporal rolling memory to smooth detections over consecutive frames.
 */
export function instantiatePicoDetectionMemory(
  size: number
): (dets: PicoDetection[]) => PicoDetection[] {
  let n = 0;
  const memory: PicoDetection[][] = [];
  for (let i = 0; i < size; ++i) {
    memory.push([]);
  }

  return function updateMemory(dets: PicoDetection[]): PicoDetection[] {
    memory[n] = dets;
    n = (n + 1) % memory.length;
    let merged: PicoDetection[] = [];
    for (let i = 0; i < memory.length; ++i) {
      merged = merged.concat(memory[i]);
    }
    return merged;
  };
}

/**
 * Transforms an RGBA canvas buffer to an 8-bit grayscale luminance array.
 * Uses ITU-R BT.601 perceptual luminance weights: 0.299 R + 0.587 G + 0.114 B.
 */
export function rgbaToGrayscale(
  rgba: Uint8ClampedArray | Uint8Array,
  nrows: number,
  ncols: number
): Uint8Array {
  const gray = new Uint8Array(nrows * ncols);
  for (let r = 0; r < nrows; ++r) {
    const rowOffset = r * ncols;
    const rgbaRowOffset = r * 4 * ncols;
    for (let c = 0; c < ncols; ++c) {
      const idx = rgbaRowOffset + 4 * c;
      gray[rowOffset + c] =
        (2 * rgba[idx] + 7 * rgba[idx + 1] + 1 * rgba[idx + 2]) / 10;
    }
  }
  return gray;
}
