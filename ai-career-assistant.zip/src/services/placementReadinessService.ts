/**
 * Placement Readiness Calculation Service
 * Deterministic, evidence-based recruitment preparedness engine.
 * Computes:
 * - Technical Skills (30%)
 * - Applied Projects (25%)
 * - ATS Resume Quality (25%)
 * - Interview Performance (20%)
 * Overall = Technical * 0.30 + Projects * 0.25 + ATS * 0.25 + Interview * 0.20
 * Clamped strictly between 0 and 100 without artificial minimum floors.
 */

import {
  getRoleBenchmarkSkills,
  areSkillsMatching,
  ROLE_BENCHMARKS
} from './liveJobsService.ts';

export interface PlacementReadinessComponentMetadata {
  available: boolean;
  score: number;
  status: 'completed' | 'not_attempted';
  label: string;
}

export interface PlacementReadinessStrength {
  title: string;
  score?: number;
  description: string;
}

export interface PlacementReadinessImprovement {
  title: string;
  score?: number;
  priority?: 'High' | 'Medium' | 'Low';
  description: string;
}

export interface PlacementReadinessAction {
  title: string;
  impact: string;
  category: string;
  link: string;
}

export interface PlacementReadinessResult {
  overallScore: number;
  technicalScore: number;
  projectsScore: number;
  atsScore: number;
  interviewScore: number;
  status: 'Needs Preparation' | 'Developing' | 'Competitive' | 'Placement Ready';
  strengths: PlacementReadinessStrength[];
  improvementAreas: PlacementReadinessImprovement[];
  recommendedActions: PlacementReadinessAction[];
  componentMetadata: {
    technical: PlacementReadinessComponentMetadata;
    projects: PlacementReadinessComponentMetadata;
    ats: PlacementReadinessComponentMetadata;
    interview: PlacementReadinessComponentMetadata;
  };
}

export function calculatePlacementReadiness(
  user?: any,
  skills: any[] = [],
  projects: any[] = [],
  resumeAnalysis?: any,
  interviewHistory: any[] = [],
  explicitTargetRole?: string
): PlacementReadinessResult {
  const targetRole = explicitTargetRole || user?.targetRole || 'Data Analyst';

  // =========================================================================
  // 1. Technical Skills Score (30% Weight)
  // Evaluated against target-role canonical benchmarks from Phase 2
  // =========================================================================
  const roleBenchmarks = getRoleBenchmarkSkills(targetRole);
  const benchmarkCount = Math.max(1, roleBenchmarks.length);

  // Match student verified/mastered skills against target role benchmarks
  const verifiedRoleSkills: { benchmarkName: string; currentLevel: number }[] = [];
  const missingRoleSkills: string[] = [];

  roleBenchmarks.forEach((benchmark) => {
    const matchingSkill = skills.find((s) => {
      const sName = typeof s === 'string' ? s : s?.name || '';
      const level = typeof s === 'object' && typeof s?.currentLevel === 'number' ? s.currentLevel : 70;
      const isVerified = s?.verified === true || s?.status === 'Strong' || s?.status === 'Good' || level >= 60;
      return areSkillsMatching(sName, benchmark.name) && isVerified;
    });

    if (matchingSkill) {
      verifiedRoleSkills.push({
        benchmarkName: benchmark.name,
        currentLevel: typeof matchingSkill === 'object' && typeof matchingSkill.currentLevel === 'number' ? matchingSkill.currentLevel : 75
      });
    } else {
      missingRoleSkills.push(benchmark.name);
    }
  });

  const technicalScore = skills.length > 0 && verifiedRoleSkills.length > 0
    ? Math.min(100, Math.round((verifiedRoleSkills.length / benchmarkCount) * 100))
    : 0;

  const technicalMetadata: PlacementReadinessComponentMetadata = {
    available: skills.length > 0,
    score: technicalScore,
    status: skills.length > 0 ? 'completed' : 'not_attempted',
    label: skills.length > 0 ? `${technicalScore}% Mastered` : 'Not Yet Attempted'
  };

  // =========================================================================
  // 2. Applied Projects & Portfolio Score (25% Weight)
  // Evaluated from actual verified completed projects (benchmark target: 3)
  // =========================================================================
  const completedProjects = projects.filter((p) => p && (p.status === 'Completed' || p.inPortfolio === true));
  const projectsScore = projects.length > 0 && completedProjects.length > 0
    ? Math.min(100, Math.round((completedProjects.length / 3) * 100))
    : 0;

  const projectsMetadata: PlacementReadinessComponentMetadata = {
    available: projects.length > 0 && completedProjects.length > 0,
    score: projectsScore,
    status: projects.length > 0 && completedProjects.length > 0 ? 'completed' : 'not_attempted',
    label: completedProjects.length > 0 ? `${completedProjects.length} Completed (${projectsScore}%)` : 'Not Yet Attempted'
  };

  // =========================================================================
  // 3. ATS Resume Quality Score (25% Weight)
  // Distinguishes unanalyzed/unuploaded placeholder from genuinely analyzed resumes
  // =========================================================================
  const hasUploadedResume = Boolean(
    resumeAnalysis &&
    (resumeAnalysis.hasUploadedResume === true ||
      (typeof resumeAnalysis.extractedTextLength === 'number' && resumeAnalysis.extractedTextLength > 0) ||
      (resumeAnalysis.analyzedFileName &&
        resumeAnalysis.analyzedFileName !== 'Snehal_Kale_Resume_DataAnalyst.pdf' &&
        resumeAnalysis.analyzedFileName !== ''))
  );

  const atsScore = hasUploadedResume && typeof resumeAnalysis?.atsScore === 'number'
    ? Math.min(100, Math.max(0, Math.round(resumeAnalysis.atsScore)))
    : 0;

  const atsMetadata: PlacementReadinessComponentMetadata = {
    available: hasUploadedResume,
    score: atsScore,
    status: hasUploadedResume ? 'completed' : 'not_attempted',
    label: hasUploadedResume ? `${atsScore}% Score` : 'Not Yet Attempted'
  };

  // =========================================================================
  // 4. Mock Interview Evaluation Score (20% Weight)
  // Distinguishes no interview history from completed attempts
  // =========================================================================
  const hasCompletedInterview = Boolean(
    interviewHistory &&
    interviewHistory.length > 0 &&
    interviewHistory.some((ih) => typeof ih?.score === 'number')
  );

  const latestInterview = hasCompletedInterview ? interviewHistory[0] : null;
  const interviewScore = latestInterview && typeof latestInterview.score === 'number'
    ? Math.min(100, Math.max(0, Math.round(latestInterview.score)))
    : 0;

  const interviewMetadata: PlacementReadinessComponentMetadata = {
    available: hasCompletedInterview,
    score: interviewScore,
    status: hasCompletedInterview ? 'completed' : 'not_attempted',
    label: hasCompletedInterview ? `${interviewScore}% Score` : 'Not Yet Attempted'
  };

  // =========================================================================
  // 5. Overall Placement Readiness Score
  // Weighted Formula: 30% Tech + 25% Projects + 25% ATS + 20% Interview
  // No artificial floor (Math.max(50, ...)). Range: 0 to 100.
  // =========================================================================
  const rawOverall = (technicalScore * 0.30) + (projectsScore * 0.25) + (atsScore * 0.25) + (interviewScore * 0.20);
  const overallScore = Math.min(100, Math.max(0, Math.round(rawOverall)));

  // Dynamic Tier Badge
  let status: 'Needs Preparation' | 'Developing' | 'Competitive' | 'Placement Ready';
  if (overallScore >= 80) {
    status = 'Placement Ready';
  } else if (overallScore >= 60) {
    status = 'Competitive';
  } else if (overallScore >= 40) {
    status = 'Developing';
  } else {
    status = 'Needs Preparation';
  }

  // =========================================================================
  // 6. Dynamic Strengths (Evidence-Based Only)
  // =========================================================================
  const strengths: PlacementReadinessStrength[] = [];

  verifiedRoleSkills.slice(0, 3).forEach((s) => {
    strengths.push({
      title: `${s.benchmarkName} Verified Proficiency`,
      score: s.currentLevel,
      description: `Demonstrated technical competency matching ${targetRole} requirements.`
    });
  });

  if (completedProjects.length >= 2) {
    strengths.push({
      title: `Applied Portfolio Depth (${completedProjects.length} Projects)`,
      score: projectsScore,
      description: 'Hands-on project deliverables showcasing problem-solving and implementation depth.'
    });
  }

  if (hasUploadedResume && atsScore >= 75) {
    strengths.push({
      title: 'ATS Resume Keyword Optimization',
      score: atsScore,
      description: `Optimized document format and high keyword match for ${targetRole} screening.`
    });
  }

  if (hasCompletedInterview && interviewScore >= 75) {
    strengths.push({
      title: 'Technical & Behavioral Articulation',
      score: interviewScore,
      description: 'Clear communicative reasoning and structured technical explanations in mock sessions.'
    });
  }

  // =========================================================================
  // 7. Dynamic Improvement Areas (Role-Aware & Evidence-Based)
  // =========================================================================
  const improvementAreas: PlacementReadinessImprovement[] = [];

  // 1. Missing role benchmark skills
  missingRoleSkills.slice(0, 3).forEach((skillName, idx) => {
    improvementAreas.push({
      title: `${skillName} Core Competency`,
      priority: idx === 0 ? 'High' : 'Medium',
      description: `Target ${targetRole} requisitions require demonstrated proficiency in ${skillName}.`
    });
  });

  // 2. Unattempted or low projects
  if (completedProjects.length < 2) {
    improvementAreas.push({
      title: 'Portfolio Project Volume',
      priority: 'High',
      description: `Aim for at least 2 completed ${targetRole} capstone projects to showcase implementation capability.`
    });
  }

  // 3. Unattempted or low ATS
  if (!hasUploadedResume || atsScore < 70) {
    improvementAreas.push({
      title: 'Resume ATS Alignment',
      priority: 'High',
      description: !hasUploadedResume
        ? 'Upload and analyze your resume in the ATS scanner to establish baseline parsability.'
        : `Boost ${targetRole} keywords and quantified impact metrics to elevate ATS score above 75%.`
    });
  }

  // 4. Unattempted or low Interview
  if (!hasCompletedInterview || interviewScore < 70) {
    improvementAreas.push({
      title: 'Mock Interview Practice',
      priority: !hasCompletedInterview ? 'High' : 'Medium',
      description: !hasCompletedInterview
        ? 'Complete a timed proctored mock interview to benchmark verbal articulation and coding.'
        : 'Refine technical concept definitions and STAR responses to boost mock interview score.'
    });
  }

  // =========================================================================
  // 8. Dynamic Recommended Next Actions
  // =========================================================================
  const recommendedActions: PlacementReadinessAction[] = [];

  // Action 1: Address primary missing skill
  if (missingRoleSkills.length > 0) {
    const topMissing = missingRoleSkills[0];
    recommendedActions.push({
      title: `Complete ${topMissing} Learning & Assessment Milestone`,
      impact: `+${Math.round(30 / benchmarkCount)}% Readiness`,
      category: 'Roadmap',
      link: '/app/roadmap'
    });
  }

  // Action 2: Resume optimization if needed
  if (!hasUploadedResume || atsScore < 75) {
    recommendedActions.push({
      title: !hasUploadedResume ? 'Upload Resume for ATS Diagnostic Scan' : `Optimize Resume for ${targetRole} Keywords`,
      impact: !hasUploadedResume
        ? 'Depends on ATS score (25% weight)'
        : `Up to +${Math.round((100 - atsScore) * 0.25)}% Readiness`,
      category: 'Resume',
      link: '/app/resume-analyzer'
    });
  }

  // Action 3: Interview prep if needed
  if (!hasCompletedInterview || interviewScore < 75) {
    recommendedActions.push({
      title: `Practice ${targetRole} Technical & Behavioral Interview Scenarios`,
      impact: '+5% Readiness',
      category: 'Interview Prep',
      link: '/app/interview-prep'
    });
  }

  // Action 4: Projects if needed
  if (completedProjects.length < 2) {
    recommendedActions.push({
      title: `Build & Deploy a ${targetRole} Capstone Project`,
      impact: '+8% Readiness',
      category: 'Projects',
      link: '/app/projects'
    });
  }

  return {
    overallScore,
    technicalScore,
    projectsScore,
    atsScore,
    interviewScore,
    status,
    strengths,
    improvementAreas: improvementAreas.slice(0, 4),
    recommendedActions: recommendedActions.slice(0, 3),
    componentMetadata: {
      technical: technicalMetadata,
      projects: projectsMetadata,
      ats: atsMetadata,
      interview: interviewMetadata
    }
  };
}
