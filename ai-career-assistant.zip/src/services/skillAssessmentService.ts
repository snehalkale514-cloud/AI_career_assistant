/**
 * Authentic Skill Assessment Service
 * Provides topic-based question pools and calculates exact evaluation scores,
 * knowledge level classifications, strong topics, and gap remediation roadmaps.
 */

export interface SkillQuestion {
  id: string;
  skillName: string;
  topic: string;
  question: string;
  codeSnippet?: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
  difficulty?: 'Easy' | 'Moderate' | 'Hard';
}

export interface SkillAssessmentResult {
  skillName: string;
  calculatedScore: number; // 0 - 100 strictly computed
  correctCount: number;
  totalQuestions: number;
  accuracy: number; // 0 - 100 percentage
  knowledgeLevel: 'Beginner' | 'Intermediate' | 'Advanced';
  strongAreas: string[];
  needsImprovement: string[];
  recommendedPractice: string[];
  topicBreakdown: Record<string, { total: number; correct: number; pct: number }>;
  previousScore?: number;
  improvementPct?: number;
  date: string;
  difficulty?: 'Easy' | 'Moderate' | 'Hard';
  isValidation?: boolean;
  isBaseline?: boolean;
  stageId?: string;
  status?: 'passed' | 'review_needed';
}

// Comprehensive verified question taxonomies
const SKILL_QUESTIONS_REPOSITORY: Record<string, SkillQuestion[]> = {
  Python: [
    {
      id: 'py_1',
      skillName: 'Python',
      topic: 'Variables and data types',
      question: 'Which of the following creates a distinct mutable set in Python with unique items?',
      options: ['s = {}', 's = set()', 's = []', 's = (1,)'],
      correctAnswerIndex: 1,
      explanation: 'In Python, s = {} creates an empty dictionary. To initialize an empty set, set() must be called explicitly.'
    },
    {
      id: 'py_2',
      skillName: 'Python',
      topic: 'Conditions',
      question: 'What is the boolean evaluation of the following condition in Python?',
      codeSnippet: 'bool([] or () or {} or 0 or "False")',
      options: ['False', 'True', 'TypeError', 'None'],
      correctAnswerIndex: 1,
      explanation: 'Empty containers and 0 evaluate to falsy in Python. However, the non-empty string "False" evaluates to True in boolean contexts.'
    },
    {
      id: 'py_3',
      skillName: 'Python',
      topic: 'Loops',
      question: 'What will the following loop construct output?',
      codeSnippet: 'for i in range(1, 4):\n    if i == 2:\n        continue\n    print(i, end="")\nelse:\n    print("D", end="")',
      options: ['13D', '123D', '13', '123'],
      correctAnswerIndex: 0,
      explanation: 'continue skips 2, printing 1 and 3. Because the loop completed naturally without a break statement, the else block runs, appending "D".'
    },
    {
      id: 'py_4',
      skillName: 'Python',
      topic: 'Functions',
      question: 'What is the danger of using a mutable default argument in Python functions, such as def add_item(item, lst=[]): ?',
      options: [
        'Python throws a SyntaxError during definition',
        'The list is evaluated once at definition time and shared across subsequent calls',
        'The list is recreated fresh on every function call',
        'Memory leaks occur in the garbage collector'
      ],
      correctAnswerIndex: 1,
      explanation: 'Default arguments are evaluated once at function definition time. A mutable default like [] retains mutations across invocations.'
    },
    {
      id: 'py_5',
      skillName: 'Python',
      topic: 'Lists, tuples, dictionaries and sets',
      question: 'What is the time complexity of checking membership (item in collection) in a Python dict/set vs a Python list?',
      options: [
        'O(1) average for dict/set; O(N) for list',
        'O(N) for dict/set; O(1) for list',
        'O(log N) for both',
        'O(N) for both'
      ],
      correctAnswerIndex: 0,
      explanation: 'Python dicts and sets use hash tables providing average O(1) lookup. Lists require a linear sequential scan of O(N).'
    },
    {
      id: 'py_6',
      skillName: 'Python',
      topic: 'OOP',
      question: 'In Python object-oriented programming, how does super().__init__() resolve parent initializers under multiple inheritance?',
      options: [
        'By invoking parent classes alphabetically',
        'By following the class Method Resolution Order (MRO) using the C3 linearization algorithm',
        'By calling only the very first base class listed in the declaration',
        'By creating duplicate instance namespaces'
      ],
      correctAnswerIndex: 1,
      explanation: 'Python utilizes the C3 Linearization algorithm to determine the Method Resolution Order (cls.__mro__) ensuring monotonic traversal.'
    },
    {
      id: 'py_7',
      skillName: 'Python',
      topic: 'Exception handling',
      question: 'In a try...except...else...finally block, when does the else block execute?',
      options: [
        'Always, right before finally',
        'Only when an exception was caught and handled in except',
        'Only when no exception was raised in the try block',
        'Whenever finally fails'
      ],
      correctAnswerIndex: 2,
      explanation: 'The else clause runs only if the code in the try block runs without raising any exceptions.'
    },
    {
      id: 'py_8',
      skillName: 'Python',
      topic: 'Basic problem solving',
      question: 'What is the result of the following list comprehension?',
      codeSnippet: '[x**2 for x in [1, 2, 3, 4] if x % 2 == 0]',
      options: ['[1, 4, 9, 16]', '[4, 16]', '[2, 4]', '[1, 9]'],
      correctAnswerIndex: 1,
      explanation: 'The filter x % 2 == 0 keeps even numbers 2 and 4, which are squared to 4 and 16.'
    }
  ],

  SQL: [
    {
      id: 'sql_1',
      skillName: 'SQL',
      topic: 'Basic SELECT & Filtering',
      question: 'Which SQL clause is used to eliminate duplicate rows from query results?',
      options: ['UNIQUE', 'DISTINCT', 'GROUP BY ALL', 'FILTER'],
      correctAnswerIndex: 1,
      explanation: 'SELECT DISTINCT removes duplicate rows from the final result set.'
    },
    {
      id: 'sql_2',
      skillName: 'SQL',
      topic: 'Aggregation & GROUP BY',
      question: 'What is the operational difference between WHERE and HAVING?',
      options: [
        'WHERE filters groups; HAVING filters rows',
        'WHERE filters rows before aggregation; HAVING filters aggregated groups after GROUP BY',
        'HAVING can only be used with subqueries',
        'They are synonymous across all ANSI SQL engines'
      ],
      correctAnswerIndex: 1,
      explanation: 'WHERE filters individual records prior to aggregation; HAVING applies condition predicates to aggregated summary groups.'
    },
    {
      id: 'sql_3',
      skillName: 'SQL',
      topic: 'JOIN Operations',
      question: 'What does a LEFT OUTER JOIN return if an employee does not have a matching department ID?',
      options: [
        'The employee row is omitted from results',
        'A database integrity error is thrown',
        'The employee record is returned with NULL in all Department columns',
        'The query converts to an INNER JOIN'
      ],
      correctAnswerIndex: 2,
      explanation: 'A LEFT JOIN guarantees all rows from the left table are returned; unmatched right table columns are populated with NULL.'
    },
    {
      id: 'sql_4',
      skillName: 'SQL',
      topic: 'Window Functions',
      question: 'What is the difference between RANK() and DENSE_RANK() when two employees tie for salary rank 1?',
      options: [
        'RANK() assigns 1, 1, 3; DENSE_RANK() assigns 1, 1, 2 without skipping ranks',
        'RANK() assigns 1, 2, 3; DENSE_RANK() assigns 1, 1, 1',
        'DENSE_RANK() ignores partitions',
        'Both produce identical numbering'
      ],
      correctAnswerIndex: 0,
      explanation: 'RANK leaves gaps following ties (1, 1, 3), whereas DENSE_RANK assigns consecutive rank values (1, 1, 2).'
    },
    {
      id: 'sql_5',
      skillName: 'SQL',
      topic: 'Subqueries & CTEs',
      question: 'What does the WITH keyword introduce in SQL?',
      options: [
        'A table lock statement',
        'A Common Table Expression (CTE) for modular readable query formulation',
        'A temporary disk-backed index',
        'A stored procedure definition'
      ],
      correctAnswerIndex: 1,
      explanation: 'The WITH clause defines a Common Table Expression (CTE), a temporary named result set within a single query statement.'
    },
    {
      id: 'sql_6',
      skillName: 'SQL',
      topic: 'Indexing & Optimization',
      question: 'Why does adding a B-Tree index on a column accelerate SELECT queries but potentially slow down high-volume INSERT operations?',
      options: [
        'Because INSERT operations must update both the base table and rebalance the B-Tree index structure',
        'Because B-Trees compress data irreversibly',
        'Because indexes lock the entire database buffer pool',
        'Because indexes disable foreign keys'
      ],
      correctAnswerIndex: 0,
      explanation: 'Every INSERT or UPDATE statement on indexed columns requires writing to the data page and rebalancing index leaf nodes.'
    },
    {
      id: 'sql_7',
      skillName: 'SQL',
      topic: 'Transactions & ACID Properties',
      question: 'Which ACID property guarantees that intermediate states of a transaction are invisible to concurrently executing transactions?',
      options: ['Atomicity', 'Consistency', 'Isolation', 'Durability'],
      correctAnswerIndex: 2,
      explanation: 'Isolation ensures concurrent transaction executions do not interfere with each other, preventing dirty reads and non-repeatable reads.'
    },
    {
      id: 'sql_8',
      skillName: 'SQL',
      topic: 'Database Normalization',
      question: 'To satisfy Third Normal Form (3NF), a table must already be in 2NF and must eliminate which type of functional dependency?',
      options: [
        'Partial key dependency',
        'Transitive dependency of non-prime attributes on candidate keys',
        'Trivial dependencies',
        'Foreign key constraints'
      ],
      correctAnswerIndex: 1,
      explanation: '3NF requires that no non-prime attribute is transitively dependent on any candidate key (every determinant must be a superkey).'
    }
  ],

  'Machine Learning': [
    {
      id: 'ml_1',
      skillName: 'Machine Learning',
      topic: 'Supervised vs Unsupervised Learning',
      question: 'Which of the following is an example of unsupervised learning?',
      options: ['Predicting house prices with linear regression', 'Customer segmentation with K-Means clustering', 'Spam email classification', 'Object detection with bounding boxes'],
      correctAnswerIndex: 1,
      explanation: 'K-Means clustering identifies intrinsic grouping patterns without ground-truth supervisory labels.'
    },
    {
      id: 'ml_2',
      skillName: 'Machine Learning',
      topic: 'Bias-Variance Tradeoff',
      question: 'A model with high variance and low bias typically exhibits which symptom?',
      options: ['Underfitting the training data', 'Overfitting the training data and failing to generalize to test data', 'High training error and high validation error', 'Linear decision boundaries'],
      correctAnswerIndex: 1,
      explanation: 'High variance indicates the model memorized nuances and noise in the training set (overfitting), resulting in poor test generalization.'
    },
    {
      id: 'ml_3',
      skillName: 'Machine Learning',
      topic: 'Evaluation Metrics',
      question: 'In a medical disease diagnosis model where missing a sick patient has catastrophic consequences, which metric should be prioritized?',
      options: ['Accuracy', 'Precision', 'Recall (Sensitivity)', 'Specificity'],
      correctAnswerIndex: 2,
      explanation: 'Recall measures TP / (TP + FN). Maximizing recall minimizes False Negatives (missing patients with the disease).'
    },
    {
      id: 'ml_4',
      skillName: 'Machine Learning',
      topic: 'Regularization',
      question: 'What is the primary operational characteristic of L1 Regularization (Lasso) compared to L2 (Ridge)?',
      options: [
        'L1 drives uninformative feature weights strictly to zero, performing automatic feature selection',
        'L1 shrinks weights smoothly without zeroing them',
        'L1 requires quadratic programming solvers only',
        'L1 is strictly for neural networks'
      ],
      correctAnswerIndex: 0,
      explanation: 'Lasso (L1) uses the absolute value penalty, producing sparse solutions where redundant feature coefficients equal 0.'
    },
    {
      id: 'ml_5',
      skillName: 'Machine Learning',
      topic: 'Ensemble Methods',
      question: 'How does Random Forest reduce the variance of individual decision trees?',
      options: [
        'By training trees sequentially on residual errors',
        'By averaging bootstrap-aggregated (bagged) trees split over random feature subsets',
        'By pruning the depth of the first tree only',
        'By using polynomial kernel transformations'
      ],
      correctAnswerIndex: 1,
      explanation: 'Random Forest uses bootstrap aggregation (bagging) and random feature subspace sampling to decorrelate individual trees and reduce overall variance.'
    },
    {
      id: 'ml_6',
      skillName: 'Machine Learning',
      topic: 'Feature Engineering & Preprocessing',
      question: 'Why is feature scaling (e.g. StandardScaler or MinMaxScaler) critical before applying distance-based algorithms like KNN or SVM?',
      options: [
        'Because features with larger numerical magnitudes will dominate Euclidean distance metrics regardless of relative importance',
        'Because scaling changes the underlying variance of distributions permanently',
        'Because unscaled features cause syntax errors in Scikit-Learn',
        'Because decision trees cannot branch without 0-to-1 scaling'
      ],
      correctAnswerIndex: 0,
      explanation: 'Distance calculations like Euclidean or Manhattan metrics are sensitive to magnitude differences; scaling balances feature weight contributions.'
    }
  ],

  'C++': [
    {
      id: 'cpp_1',
      skillName: 'C++',
      topic: 'Pointers & References',
      question: 'What is a fundamental difference between a C++ reference (int& ref = a;) and a pointer (int* ptr = &a;)?',
      options: [
        'References cannot be null and cannot be reseated to point to another object after initialization',
        'Pointers cannot access heap memory',
        'References take up more memory than pointers on 64-bit systems',
        'References require explicit dereference syntax (*ref)'
      ],
      correctAnswerIndex: 0,
      explanation: 'A reference is an alias established at initialization that cannot be reassigned or set to nullptr.'
    },
    {
      id: 'cpp_2',
      skillName: 'C++',
      topic: 'Memory Management & RAII',
      question: 'Which smart pointer in modern C++ enforces unique, non-copyable ownership of a heap resource?',
      options: ['std::shared_ptr', 'std::unique_ptr', 'std::weak_ptr', 'std::auto_ptr'],
      correctAnswerIndex: 1,
      explanation: 'std::unique_ptr has deleted copy constructors, allowing transfer of ownership only through move semantics (std::move).'
    },
    {
      id: 'cpp_3',
      skillName: 'C++',
      topic: 'OOP & Virtual Functions',
      question: 'Why should a base class destructor almost always be declared virtual in C++ if it has virtual methods?',
      options: [
        'To enable constructor delegation',
        'To ensure that deleting an object through a base pointer correctly invokes the derived class destructor, preventing memory leaks',
        'To speed up compilation times',
        'To make the class abstract'
      ],
      correctAnswerIndex: 1,
      explanation: 'Without a virtual destructor, deleting a derived object via a Base* pointer yields undefined behavior, skipping the derived destructor.'
    },
    {
      id: 'cpp_4',
      skillName: 'C++',
      topic: 'STL Containers',
      question: 'What is the internal data structure and search time complexity of std::map vs std::unordered_map?',
      options: [
        'std::map: Red-Black Tree (O(log N)); std::unordered_map: Hash Table (O(1) average)',
        'std::map: Hash Table; std::unordered_map: B-Tree',
        'Both use contiguous dynamic arrays with O(N) search',
        'std::map is sorted in O(1) time'
      ],
      correctAnswerIndex: 0,
      explanation: 'std::map is implemented as a self-balancing binary search tree (Red-Black Tree), while std::unordered_map uses a hash table.'
    },
    {
      id: 'cpp_5',
      skillName: 'C++',
      topic: 'Templates & Generic Programming',
      question: 'What is template instantiation in C++?',
      options: [
        'Runtime dynamic dispatch using vtables',
        'Compile-time code generation where the compiler generates concrete class or function code for each concrete type used',
        'Garbage collection pass for template types',
        'Linking object code with external DLLs'
      ],
      correctAnswerIndex: 1,
      explanation: 'C++ templates are zero-cost compile-time abstractions; the compiler generates distinct machine code for each type instantiation.'
    },
    {
      id: 'cpp_6',
      skillName: 'C++',
      topic: 'Move Semantics & rvalue references',
      question: 'What is the purpose of std::move in modern C++ (C++11 and newer)?',
      options: [
        'It moves bytes directly across physical memory addresses',
        'It casts an lvalue expression into an rvalue reference (type&&), enabling move constructors to steal resources without deep copies',
        'It deallocates the pointer immediately',
        'It terminates threads safely'
      ],
      correctAnswerIndex: 1,
      explanation: 'std::move is an unconditional static_cast to an rvalue reference, signaling that an object may be pilfered of its internal heap pointers.'
    }
  ],

  'Power BI': [
    {
      id: 'pbi_1',
      skillName: 'Power BI',
      topic: 'DAX Modeling',
      question: 'Which DAX function is used to modify the filter context of a calculation in Power BI?',
      options: ['SUMX', 'CALCULATE', 'RELATED', 'LOOKUPVALUE'],
      correctAnswerIndex: 1,
      explanation: 'CALCULATE evaluates an expression in a modified filter context specified by its arguments.'
    },
    {
      id: 'pbi_2',
      skillName: 'Power BI',
      topic: 'Star Schema & Data Modeling',
      question: 'In a dimensional star schema, what is the best practice relationship direction between Fact tables and Dimension tables?',
      options: [
        'Bi-directional (Both)',
        'Single direction from Dimension (1) to Fact (*)',
        'Single direction from Fact (1) to Dimension (*)',
        'No relationships; use flat denormalized tables only'
      ],
      correctAnswerIndex: 1,
      explanation: 'Best practice is a 1-to-many single direction relationship from Dimension tables (1) filtering Fact tables (*).'
    },
    {
      id: 'pbi_3',
      skillName: 'Power BI',
      topic: 'Power Query & ETL',
      question: 'What is query folding in Power Query?',
      options: [
        'Compressing data into zip files',
        'Pushing transformation steps back to the source database as native SQL queries',
        'Merging visuals into dashboards',
        'Hiding unused columns in report view'
      ],
      correctAnswerIndex: 1,
      explanation: 'Query folding translates Power Query M transformations into a single native database query, executing ETL at the database engine level.'
    },
    {
      id: 'pbi_4',
      skillName: 'Power BI',
      topic: 'Row-Level Security & Governance',
      question: 'How is dynamic Row-Level Security (RLS) commonly implemented in Power BI reports for multi-tenant organizations?',
      options: [
        'By creating separate PBIX files for every single user',
        'Using DAX functions like USERNAME() or USERPRINCIPALNAME() inside role definition filters mapped to an employee security table',
        'By password protecting individual visual charts',
        'By disabling the Power BI Service cloud gateway'
      ],
      correctAnswerIndex: 1,
      explanation: 'Dynamic RLS uses USERPRINCIPALNAME() evaluated against organizational directory tables to filter rows per authenticated viewer.'
    }
  ],

  Statistics: [
    {
      id: 'stat_1',
      skillName: 'Statistics',
      topic: 'Hypothesis Testing',
      question: 'What does a p-value of 0.03 indicate when testing at a significance level of alpha = 0.05?',
      options: [
        'The null hypothesis is 97% likely to be true',
        'Reject the null hypothesis as the result is statistically significant at the 5% level',
        'Fail to reject the null hypothesis',
        'The test was conducted with insufficient sample size'
      ],
      correctAnswerIndex: 1,
      explanation: 'When p-value < alpha (0.03 < 0.05), we reject the null hypothesis in favor of the alternative hypothesis.'
    },
    {
      id: 'stat_2',
      skillName: 'Statistics',
      topic: 'Distributions & Central Limit Theorem',
      question: 'According to the Central Limit Theorem, what happens to the distribution of sample means as sample size N increases?',
      options: [
        'It approaches a normal distribution regardless of the underlying population distribution shape',
        'It mirrors the exact shape of the population',
        'The variance increases proportionally with N',
        'It collapses into a uniform distribution'
      ],
      correctAnswerIndex: 0,
      explanation: 'The Central Limit Theorem establishes that sample means approximate a Gaussian normal distribution for sufficiently large sample sizes.'
    },
    {
      id: 'stat_3',
      skillName: 'Statistics',
      topic: 'Variance & Correlation',
      question: 'A Pearson correlation coefficient of r = 0.85 indicates what relationship between two variables?',
      options: [
        'Strong positive linear relationship',
        'No relationship',
        'Direct mathematical proof that X causes Y',
        'Negative exponential relationship'
      ],
      correctAnswerIndex: 0,
      explanation: 'r = +0.85 signifies a strong positive linear correlation (noting correlation does not imply causation).'
    },
    {
      id: 'stat_4',
      skillName: 'Statistics',
      topic: 'Type I and Type II Errors',
      question: 'What constitutes a Type II error (beta) in statistical hypothesis testing?',
      options: [
        'Failing to reject a false null hypothesis (False Negative)',
        'Rejecting a true null hypothesis (False Positive)',
        'Calculating the sample standard deviation incorrectly',
        'Setting alpha to 0.01 instead of 0.05'
      ],
      correctAnswerIndex: 0,
      explanation: 'A Type II error occurs when the null hypothesis is actually false, but the test fails to detect the effect (False Negative).'
    }
  ],

  Excel: [
    {
      id: 'xl_1',
      skillName: 'Excel',
      topic: 'Lookup Functions',
      question: 'Why is XLOOKUP preferred over traditional VLOOKUP in modern Excel spreadsheets?',
      options: [
        'XLOOKUP can search to the left, defaults to exact match, and does not break when columns are inserted',
        'XLOOKUP uses less RAM in 32-bit Excel',
        'XLOOKUP only works with numbers',
        'VLOOKUP has been deprecated completely'
      ],
      correctAnswerIndex: 0,
      explanation: 'XLOOKUP separates search and return arrays, searches both directions, defaults to exact matching, and eliminates column-index drift.'
    },
    {
      id: 'xl_2',
      skillName: 'Excel',
      topic: 'Aggregation & Pivot Tables',
      question: 'Which formula calculates the sum of column C only where column A equals "East" and column B is greater than 1000?',
      options: ['=SUMIF(A:A, "East", C:C)', '=SUMIFS(C:C, A:A, "East", B:B, ">1000")', '=VLOOKUP(C:C, "East", 1000)', '=COUNTIFS(A:A, "East")'],
      correctAnswerIndex: 1,
      explanation: 'SUMIFS takes sum_range first, followed by multiple criteria_range and criteria pairs.'
    },
    {
      id: 'xl_3',
      skillName: 'Excel',
      topic: 'INDEX and MATCH Multi-Criteria',
      question: 'What is the advantage of using INDEX & MATCH over legacy VLOOKUP in large computational models?',
      options: [
        'INDEX/MATCH does not require the lookup column to be the leftmost column and computes faster because only 2 specific columns are referenced',
        'INDEX/MATCH requires no arguments',
        'INDEX/MATCH converts text to binary',
        'INDEX/MATCH works only on Mac'
      ],
      correctAnswerIndex: 0,
      explanation: 'INDEX/MATCH decouples the return vector from the lookup vector, permitting lookups in any direction and reducing memory overhead.'
    },
    {
      id: 'xl_4',
      skillName: 'Excel',
      topic: 'Conditional Logic & Data Validation',
      question: 'Which Excel function allows evaluating multiple logical conditions without writing nested IF statements?',
      options: ['IFS', 'CONCAT', 'TEXTJOIN', 'TRIM'],
      correctAnswerIndex: 0,
      explanation: 'IFS evaluates multiple conditions in sequence (condition1, value1, condition2, value2) without deeply nested syntax.'
    }
  ],

  'Data Visualization': [
    {
      id: 'dv_1',
      skillName: 'Data Visualization',
      topic: 'Chart Selection & Storytelling',
      question: 'Which chart type is most appropriate to visualize the correlation and potential clustering between two continuous numerical variables?',
      options: ['Pie Chart', 'Scatter Plot', 'Stacked Bar Chart', 'Donut Chart'],
      correctAnswerIndex: 1,
      explanation: 'Scatter plots map two continuous variables along Cartesian axes, revealing correlations, clusters, and outliers.'
    },
    {
      id: 'dv_2',
      skillName: 'Data Visualization',
      topic: 'Data Density & Integrity',
      question: 'Why should 3D charts with artificial perspective almost always be avoided in professional executive dashboards?',
      options: [
        'They distort proportions and optical visual angles, making comparisons inaccurate',
        'They take up too much bandwidth to render',
        'Screen readers cannot parse colors',
        'They only work with categorical variables'
      ],
      correctAnswerIndex: 0,
      explanation: '3D perspective alters the geometric area and height of visual elements, misleading the viewer.'
    },
    {
      id: 'dv_3',
      skillName: 'Data Visualization',
      topic: 'Color Accessibility & Contrast Standards',
      question: 'When designing KPI heatmaps and status charts, why is relying solely on red and green indicators considered poor practice?',
      options: [
        'Red and green are indistinguishable for users with deuteranopia or protanopia (red-green color blindness)',
        'Red ink costs more on laser printers',
        'SVG does not support RGB values for green',
        'Browsers render green as yellow on mobile'
      ],
      correctAnswerIndex: 0,
      explanation: 'Approximately 8% of men have red-green color vision deficiency; accessible charts combine color with distinct icons or patterns.'
    },
    {
      id: 'dv_4',
      skillName: 'Data Visualization',
      topic: 'Dashboard Layout & Information Hierarchy',
      question: 'According to Edward Tufte and visualization best practices, what is the "data-ink ratio"?',
      options: [
        'The proportion of ink or visual pixels used to deliver actual data information compared to the total visual elements',
        'The print resolution of physical ink',
        'The ratio of text labels to numbers',
        'The thickness of grid lines'
      ],
      correctAnswerIndex: 0,
      explanation: 'Maximizing the data-ink ratio means eliminating non-data chartjunk (gratuitous backgrounds, excessive gridlines, heavy borders).'
    }
  ],

  Communication: [
    {
      id: 'comm_1',
      skillName: 'Communication',
      topic: 'STAR Method & Articulation',
      question: 'In behavioral and technical interview storytelling, what does the STAR acronym represent?',
      options: [
        'Situation, Task, Action, Result',
        'Strategy, Timing, Accuracy, Reliability',
        'Scope, Team, Assessment, Review',
        'Summary, Technology, Application, Release'
      ],
      correctAnswerIndex: 0,
      explanation: 'STAR stands for Situation, Task, Action, and Result, providing structured narrative progression.'
    },
    {
      id: 'comm_2',
      skillName: 'Communication',
      topic: 'Technical Stakeholder Translation',
      question: 'When presenting complex data analysis to non-technical executive stakeholders, what is the best strategy?',
      options: [
        'Present the raw source code and SQL queries line by line',
        'Focus on business implications, ROI, actionable recommendations, and key metric changes',
        'Avoid showing any graphs or charts',
        'Use maximum technical jargon to establish authority'
      ],
      correctAnswerIndex: 1,
      explanation: 'Executive stakeholders prioritize business impact, risk mitigation, and strategic decisions over implementation minutiae.'
    },
    {
      id: 'comm_3',
      skillName: 'Communication',
      topic: 'Handling Technical Conflict',
      question: 'During a code review or architectural disagreement with a peer engineer, which approach leads to the best technical outcome?',
      options: [
        'Argue personal seniority until the other person yields',
        'Anchor the discussion in objective benchmarks, architectural constraints, test coverage, and trade-offs rather than subjective preferences',
        'Immediately escalate to HR',
        'Silently overwrite their pull request'
      ],
      correctAnswerIndex: 1,
      explanation: 'Constructive engineering communication grounds design decisions in empirical metrics, maintainability trade-offs, and shared requirements.'
    },
    {
      id: 'comm_4',
      skillName: 'Communication',
      topic: 'Synthesizing Executive Summaries',
      question: 'What is the "BLUF" (Bottom Line Up Front) principle in corporate and technical communication?',
      options: [
        'Putting the conclusion, main recommendation, or key finding at the very beginning of the memo or message',
        'Always ending emails with apologies',
        'Writing in all capital letters',
        'Only communicating through bulleted spreadsheets'
      ],
      correctAnswerIndex: 0,
      explanation: 'BLUF places the vital decision, recommendation, or metric outcome in the first sentence so busy stakeholders understand the message immediately.'
    }
  ],
  React: [
    {
      id: 'react_1',
      skillName: 'React',
      topic: 'Component Lifecycle & Hooks',
      difficulty: 'Easy',
      question: 'Which React Hook is used to perform side effects such as data fetching or DOM subscriptions?',
      options: ['useMemo', 'useEffect', 'useReducer', 'useState'],
      correctAnswerIndex: 1,
      explanation: 'useEffect handles side effects and synchronization with external systems after render.'
    },
    {
      id: 'react_2',
      skillName: 'React',
      topic: 'State Management & Immutability',
      difficulty: 'Moderate',
      question: 'Why should state never be mutated directly in React (e.g., state.count = 5)?',
      options: [
        'React state variables are read-only at the JavaScript runtime level',
        'Direct mutation bypasses React reconciliation and does not trigger re-renders',
        'Direct mutation deletes the virtual DOM',
        'It causes memory allocation exceptions in browsers'
      ],
      correctAnswerIndex: 1,
      explanation: 'React compares object references (Object.is). Direct mutations do not change references, preventing re-renders.'
    },
    {
      id: 'react_3',
      skillName: 'React',
      topic: 'Performance Optimization',
      difficulty: 'Hard',
      question: 'When should useCallback and useMemo be used for performance optimization in React?',
      options: [
        'Wrap every single function and variable in every component unconditionally',
        'When passing callback references or expensive calculations to memoized children to prevent unnecessary downstream re-renders',
        'Only inside asynchronous web workers',
        'To replace Redux state stores'
      ],
      correctAnswerIndex: 1,
      explanation: 'useCallback preserves referential equality of callbacks passed to memoized children, avoiding unneeded child render passes.'
    }
  ],
  Docker: [
    {
      id: 'docker_1',
      skillName: 'Docker',
      topic: 'Container Basics',
      difficulty: 'Easy',
      question: 'What is the primary difference between a Docker image and a Docker container?',
      options: [
        'An image is a running process; a container is a static template file',
        'An image is an immutable build-time template; a container is a running instance of that image with an isolated filesystem layer',
        'Images are for Windows; containers are for Linux',
        'There is no functional difference'
      ],
      correctAnswerIndex: 1,
      explanation: 'An image is a read-only template with instructions; a container is a runnable isolated instance with a thin writable layer.'
    },
    {
      id: 'docker_2',
      skillName: 'Docker',
      topic: 'Multi-stage Builds',
      difficulty: 'Moderate',
      question: 'What is the key benefit of multi-stage Docker builds?',
      options: [
        'They automatically restart crashed containers',
        'They separate the build environment from the final runtime image, drastically reducing container size and attack surface',
        'They encrypt the source code during transmission',
        'They eliminate the need for ports'
      ],
      correctAnswerIndex: 1,
      explanation: 'Multi-stage builds compile artifacts in temporary builder stages and copy only final binaries into lightweight production images.'
    },
    {
      id: 'docker_3',
      skillName: 'Docker',
      topic: 'Networking & Compose',
      difficulty: 'Hard',
      question: 'How do containers within the same user-defined Docker bridge network resolve each other by default?',
      options: [
        'By hardcoded localhost loopback ports only',
        'Through an embedded automatic DNS resolver using container names and service aliases',
        'By broadcasting ARP packets over host Ethernet',
        'They cannot communicate without public IP addresses'
      ],
      correctAnswerIndex: 1,
      explanation: 'User-defined bridge networks feature automatic embedded DNS resolution based on container names and service keys.'
    }
  ]
};

function inferQuestionDifficulty(q: SkillQuestion): 'Easy' | 'Moderate' | 'Hard' {
  if (q.difficulty) return q.difficulty;
  const t = (q.topic + ' ' + q.question).toLowerCase();
  if (
    t.includes('mro') ||
    t.includes('c3') ||
    t.includes('window function') ||
    t.includes('dense_rank') ||
    t.includes('indexing') ||
    t.includes('acid') ||
    t.includes('3nf') ||
    t.includes('query folding') ||
    t.includes('rls') ||
    t.includes('central limit') ||
    t.includes('regularization') ||
    t.includes('dynamic array') ||
    t.includes('cross-filtering') ||
    t.includes('optimization') ||
    t.includes('concurrency')
  ) {
    return 'Hard';
  }
  if (
    t.includes('function') ||
    t.includes('join') ||
    t.includes('group by') ||
    t.includes('having') ||
    t.includes('calculate') ||
    t.includes('star schema') ||
    t.includes('hypothesis') ||
    t.includes('p-value') ||
    t.includes('xlookup') ||
    t.includes('vlookup') ||
    t.includes('bias-variance') ||
    t.includes('recall') ||
    t.includes('star method') ||
    t.includes('bluf') ||
    t.includes('exception') ||
    t.includes('data-ink')
  ) {
    return 'Moderate';
  }
  return 'Easy';
}

export const skillAssessmentService = {
  /**
   * Retrieves skill-specific question suite filtered or prioritized by difficulty
   */
  getQuestionsForSkill(skillName: string, difficulty?: 'Easy' | 'Moderate' | 'Hard'): SkillQuestion[] {
    const trimmed = skillName.trim();
    let rawList: SkillQuestion[] = [];

    if (SKILL_QUESTIONS_REPOSITORY[trimmed]) {
      rawList = SKILL_QUESTIONS_REPOSITORY[trimmed];
    } else {
      // Flexible case-insensitive / partial match
      const lower = trimmed.toLowerCase();
      const foundKey = Object.keys(SKILL_QUESTIONS_REPOSITORY).find((k) => {
        const kl = k.toLowerCase();
        return (
          kl === lower ||
          lower.includes(kl) ||
          kl.includes(lower) ||
          (lower === 'c++' && kl === 'c++') ||
          (lower === 'cpp' && kl === 'c++') ||
          (lower.includes('excel') && kl === 'Excel') ||
          (lower.includes('statistic') && kl === 'Statistics') ||
          (lower.includes('power bi') && kl === 'Power BI') ||
          (lower.includes('visual') && kl === 'Data Visualization') ||
          (lower.includes('communicat') && kl === 'Communication') ||
          (lower.includes('machine learning') && kl === 'Machine Learning') ||
          (lower === 'ml' && kl === 'Machine Learning') ||
          (lower.includes('react') && kl === 'React') ||
          (lower.includes('docker') && kl === 'Docker')
        );
      });

      if (foundKey) {
        rawList = SKILL_QUESTIONS_REPOSITORY[foundKey];
      }
    }

    if (rawList.length === 0) {
      // Dynamic intelligent fallback for custom skill
      rawList = [
        {
          id: `gen_1_${trimmed}`,
          skillName: trimmed,
          topic: 'Variables and data types',
          difficulty: 'Easy',
          question: `In production engineering with ${trimmed}, what is the recommended practice for state immutability and primitive data structures?`,
          options: [
            'Store all state in global mutable objects',
            'Use immutable structures and typed interfaces to prevent uncontrolled side-effects',
            'Avoid using data types altogether',
            'Rely exclusively on string casting'
          ],
          correctAnswerIndex: 1,
          explanation: 'Immutability and strict typing protect against concurrency races and unexpected state mutation.'
        },
        {
          id: `gen_2_${trimmed}`,
          skillName: trimmed,
          topic: 'Core Syntax & Fundamentals',
          difficulty: 'Easy',
          question: `When designing modular components in ${trimmed}, which principle provides the highest long-term maintainability?`,
          options: [
            'Minimizing modular boundaries into a single massive file',
            'Enforcing loose coupling, high cohesion, and explicit contracts',
            'Disabling static analysis and linting',
            'Hardcoding environment secrets'
          ],
          correctAnswerIndex: 1,
          explanation: 'Loose coupling and high cohesion ensure maintainability and testability across engineering teams.'
        },
        {
          id: `gen_3_${trimmed}`,
          skillName: trimmed,
          topic: 'Applied Logic & Handling',
          difficulty: 'Moderate',
          question: `How should unexpected runtime exceptions and edge cases be handled in production ${trimmed} applications?`,
          options: [
            'Silently catch all errors with empty pass blocks',
            'Log contextual error metadata, safely rollback state, and return structured status codes',
            'Terminate the server process immediately on every warning',
            'Expose full stack traces directly to end users'
          ],
          correctAnswerIndex: 1,
          explanation: 'Structured logging with contextual error tracking allows incident recovery without service disruption.'
        },
        {
          id: `gen_4_${trimmed}`,
          skillName: trimmed,
          topic: 'Memory & Performance Optimization',
          difficulty: 'Hard',
          question: `When optimizing high-throughput operations in ${trimmed}, which factor has the highest impact on latency?`,
          options: [
            'Variable identifier string length',
            'Algorithmic time complexity and minimizing redundant I/O operations',
            'Removing comments from production source files',
            'Indentation formatting'
          ],
          correctAnswerIndex: 1,
          explanation: 'Algorithmic efficiency (O(N) vs O(N^2)) and eliminating blocking network/disk I/O are the dominant factors.'
        }
      ];
    }

    // Attach inferred difficulty if not present
    const normalized = rawList.map((q) => ({
      ...q,
      difficulty: inferQuestionDifficulty(q)
    }));

    if (!difficulty) {
      return normalized;
    }

    const matches = normalized.filter((q) => q.difficulty === difficulty);
    if (matches.length >= 4) {
      return matches;
    }

    // If fewer than 4 exact matches, prioritize target difficulty first then include others
    const others = normalized.filter((q) => q.difficulty !== difficulty);
    return [...matches, ...others].slice(0, Math.max(5, matches.length));
  },

  /**
   * Generates a tailored role-appropriate diagnostic baseline assessment suite.
   * Tests core competencies for the target role at the requested difficulty.
   */
  getBaselineQuestions(
    targetRole: string = 'Data Analyst',
    difficulty: 'Easy' | 'Moderate' | 'Hard' = 'Moderate'
  ): (SkillQuestion & { category: string })[] {
    const roleLower = targetRole.toLowerCase().trim();

    let primarySkills: string[] = [];
    if (roleLower.includes('data') || roleLower.includes('analyst') || roleLower.includes('business')) {
      primarySkills = ['Python', 'SQL', 'Statistics', 'Power BI', 'Excel', 'Data Visualization'];
    } else if (roleLower.includes('machine learning') || roleLower.includes('ai') || roleLower.includes('data scientist')) {
      primarySkills = ['Python', 'Machine Learning', 'Statistics', 'SQL', 'Data Visualization'];
    } else if (roleLower.includes('frontend') || roleLower.includes('ui') || roleLower.includes('web')) {
      primarySkills = ['React', 'Python', 'Data Visualization', 'Communication'];
    } else if (roleLower.includes('devops') || roleLower.includes('cloud')) {
      primarySkills = ['Docker', 'Python', 'SQL', 'Communication'];
    } else {
      primarySkills = ['Python', 'SQL', 'Statistics', 'Power BI', 'Communication'];
    }

    const selected: (SkillQuestion & { category: string })[] = [];

    primarySkills.forEach((skill) => {
      const pool = this.getQuestionsForSkill(skill, difficulty);
      const match = pool.find((q) => q.difficulty === difficulty) || pool[0];
      if (match && !selected.some((s) => s.id === match.id)) {
        selected.push({
          ...match,
          category: skill
        });
      }
    });

    // If we have fewer than 6 questions, supplement from secondary skills
    if (selected.length < 6) {
      const extraPool = this.getQuestionsForSkill('Python', difficulty);
      extraPool.forEach((q) => {
        if (selected.length < 8 && !selected.some((s) => s.id === q.id)) {
          selected.push({ ...q, category: 'Python' });
        }
      });
    }

    return selected;
  },

  /**
   * Generates targeted validation questions for validating roadmap milestones.
   */
  getValidationQuestionsForStage(
    skillName: string,
    difficulty: 'Easy' | 'Moderate' | 'Hard' = 'Moderate'
  ): SkillQuestion[] {
    const questions = this.getQuestionsForSkill(skillName, difficulty);
    return questions.slice(0, 5);
  },

  /**
   * Evaluates candidate answers strictly against answer keys to compute genuine score
   * Score = (correctCount / totalQuestions) * 100
   * Real calculated percentage - NEVER assumed or fabricated.
   */
  evaluateSkillAssessment(params: {
    skillName: string;
    questions: SkillQuestion[];
    userAnswers: Record<string, number>;
    previousScore?: number;
    difficulty?: 'Easy' | 'Moderate' | 'Hard';
    isValidation?: boolean;
    isBaseline?: boolean;
    stageId?: string;
  }): SkillAssessmentResult {
    const {
      skillName,
      questions,
      userAnswers,
      previousScore,
      difficulty,
      isValidation,
      isBaseline,
      stageId
    } = params;

    let correctCount = 0;
    const topicBreakdown: Record<string, { total: number; correct: number; pct: number }> = {};

    questions.forEach((q) => {
      if (!topicBreakdown[q.topic]) {
        topicBreakdown[q.topic] = { total: 0, correct: 0, pct: 0 };
      }
      topicBreakdown[q.topic].total += 1;

      const isCorrect = userAnswers[q.id] === q.correctAnswerIndex;
      if (isCorrect) {
        correctCount += 1;
        topicBreakdown[q.topic].correct += 1;
      }
    });

    // Calculate percentage per topic
    Object.keys(topicBreakdown).forEach((topic) => {
      const t = topicBreakdown[topic];
      t.pct = Math.round((t.correct / t.total) * 100);
    });

    // Exact calculated score (NEVER fabricated or assumed)
    const calculatedScore = questions.length > 0 ? Math.round((correctCount / questions.length) * 100) : 0;
    const accuracy = calculatedScore;

    // Knowledge level
    let knowledgeLevel: 'Beginner' | 'Intermediate' | 'Advanced' = 'Beginner';
    if (calculatedScore >= 85) knowledgeLevel = 'Advanced';
    else if (calculatedScore >= 60) knowledgeLevel = 'Intermediate';

    // Strong areas (>= 80% correct in topic) vs Needs improvement (< 80% in topic)
    const strongAreas: string[] = [];
    const needsImprovement: string[] = [];
    const recommendedPractice: string[] = [];

    Object.entries(topicBreakdown).forEach(([topic, stats]) => {
      if (stats.pct >= 80) {
        strongAreas.push(topic);
      } else {
        needsImprovement.push(topic);
        recommendedPractice.push(`${skillName} ${topic} Exercises`);
      }
    });

    // Always provide targeted recommended practice items
    if (needsImprovement.length > 0) {
      recommendedPractice.push(`${skillName} practical problems and implementation practice`);
    } else {
      recommendedPractice.push(`Advanced ${skillName} architecture & production edge cases`);
    }

    const improvementPct = previousScore !== undefined ? calculatedScore - previousScore : undefined;

    return {
      skillName,
      calculatedScore,
      correctCount,
      totalQuestions: questions.length,
      accuracy,
      knowledgeLevel,
      strongAreas,
      needsImprovement,
      recommendedPractice,
      topicBreakdown,
      previousScore,
      improvementPct,
      difficulty,
      isValidation,
      isBaseline,
      stageId,
      status: calculatedScore >= 75 ? 'passed' : 'review_needed',
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
    };
  },

  /**
   * Evaluates a multi-skill diagnostic assessment based strictly on actual user answers.
   * Calculates authentic scores per category and overall percentage without arbitrary floors or overrides.
   */
  evaluateDiagnosticAssessment(
    questions: { id: string; category?: string; skillName?: string; correctAnswerIndex: number; difficulty?: 'Easy' | 'Moderate' | 'Hard' }[],
    userAnswers: Record<string, number>,
    difficulty: 'Easy' | 'Moderate' | 'Hard' = 'Moderate'
  ): {
    overall: number;
    breakdown: Record<string, number>;
    strengths: string[];
    weaknesses: string[];
    correctCount: number;
    totalQuestions: number;
    accuracy: number;
    difficulty: 'Easy' | 'Moderate' | 'Hard';
  } {
    if (!questions || questions.length === 0) {
      return {
        overall: 0,
        breakdown: {},
        strengths: [],
        weaknesses: [],
        correctCount: 0,
        totalQuestions: 0,
        accuracy: 0,
        difficulty
      };
    }

    let correctCount = 0;
    const categoryTotals: Record<string, { total: number; correct: number }> = {};

    questions.forEach((q) => {
      const categoryKey = q.category || q.skillName || 'General';
      if (!categoryTotals[categoryKey]) {
        categoryTotals[categoryKey] = { total: 0, correct: 0 };
      }
      categoryTotals[categoryKey].total += 1;

      // An answer is only counted as correct if explicitly matching correctAnswerIndex
      if (userAnswers[q.id] !== undefined && userAnswers[q.id] === q.correctAnswerIndex) {
        correctCount += 1;
        categoryTotals[categoryKey].correct += 1;
      }
    });

    const breakdown: Record<string, number> = {};
    const strengths: string[] = [];
    const weaknesses: string[] = [];

    Object.keys(categoryTotals).forEach((cat) => {
      const stats = categoryTotals[cat];
      const catScore = stats.total > 0 ? Math.round((stats.correct / stats.total) * 100) : 0;
      breakdown[cat] = catScore;
      if (catScore >= 75) {
        strengths.push(cat);
      } else {
        weaknesses.push(cat);
      }
    });

    const overall = Math.round((correctCount / questions.length) * 100);

    return {
      overall,
      breakdown,
      strengths,
      weaknesses,
      correctCount,
      totalQuestions: questions.length,
      accuracy: overall,
      difficulty
    };
  }
};

