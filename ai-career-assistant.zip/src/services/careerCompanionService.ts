/**
 * Career Companion Snapshot Service
 * Deterministic, role-aware synthesis of candidate career state for the AI Career Mentor.
 * Consumes the authoritative single source of truth from CareerContext and domain services.
 * Pure read-only snapshot builder: NO persistence, NO caching, NO duplicate calculations.
 */

import {
  UserProfile,
  SkillItem,
  RoadmapStage,
  ProjectItem,
  InterviewHistoryItem,
  ApplicationItem
} from '../types.ts';
import { ResumeAnalysisData } from '../context/CareerContext.tsx';
import {
  getRoleBenchmarkSkills,
  areSkillsMatching,
  RoleBenchmarkDefinition
} from './liveJobsService.ts';
import {
  calculatePlacementReadiness,
  PlacementReadinessResult
} from './placementReadinessService.ts';
import {
  getInterviewPracticeWeaknesses,
  InterviewPracticeWeakness
} from './interviewService.ts';

/**
 * Compact, privacy-preserving, role-aware snapshot of the candidate's career state.
 * Strictly distinguishes VERIFIED DATA from DERIVED DATA.
 * 100% JSON-serializable (no functions, no circular references, no undefined in critical keys).
 */
export interface CareerCompanionSnapshot {
  timestamp: string;

  student: {
    name: string;
    targetRole: string;
    experienceLevel: 'Beginner' | 'Intermediate' | 'Advanced';
    college?: string;
    degree?: string;
    graduationYear?: string;
    workPreference?: string;
  };

  skills: {
    verifiedCount: number;
    verifiedSkills: {
      name: string;
      currentLevel: number;
      category: string;
      status: string;
    }[];
    strongTopics: string[];
    weakTopics: string[];
    // DERIVED from role benchmark vs verified skills
    priorityGaps: {
      name: string;
      requiredLevel: number;
      category: string;
    }[];
  };

  roadmap: {
    totalStages: number;
    completedStagesCount: number;
    progressPercent: number;
    currentStage: {
      stepNumber: number;
      title: string;
      skillName: string;
      status: string;
      goal: string;
    } | null;
    upcomingStagesCount: number;
  };

  resume: {
    hasUploadedResume: boolean;
    status: 'analyzed' | 'not_attempted';
    atsScore: number | null;
    isEvaluatedScore: boolean;
    formattingScore: number | null;
    skillsMatch: number | null;
    analyzedFileName: string | null;
    detectedSkills: string[];
    missingSkills: string[];
    strengths: string[];
    topImprovements: {
      original: string;
      suggested: string;
      reason: string;
    }[];
  };

  interview: {
    status: 'attempted' | 'not_attempted';
    isMockPracticeOnly: true;
    environment: 'in_app_mock_interview_simulation';
    sessionsCompleted: number;
    latestSession: {
      date: string;
      interviewType: string;
      role: string;
      score: number;
      practiceStatus: string;
      status: string;
      feedback: string;
      categoryBreakdown: {
        technical: number;
        communication: number;
        confidence: number;
        completeness: number;
        coding?: number;
      };
    } | null;
    averageScore: number | null;
    // DERIVED: Unresolved practice weaknesses for current target role
    practiceWeaknesses: {
      topic: string;
      relatedSkill: string;
      questionTitle: string;
      lastAttemptScore: number;
      areasToImprove: string[];
    }[];
  };

  placementReadiness: {
    overallScore: number;
    tier: 'Needs Preparation' | 'Developing' | 'Competitive' | 'Placement Ready';
    pillars: {
      technical: number;
      projects: number;
      ats: number;
      interview: number;
    };
    pillarWeights: {
      technical: '30%';
      projects: '25%';
      ats: '25%';
      interview: '20%';
    };
    formulaNote: string;
    componentStatus: {
      technical: 'completed' | 'not_attempted';
      projects: 'completed' | 'not_attempted';
      ats: 'completed' | 'not_attempted';
      interview: 'completed' | 'not_attempted';
    };
    improvementAreas: {
      title: string;
      priority?: string;
      description: string;
    }[];
    recommendedActions: {
      title: string;
      impact: string;
      category: string;
    }[];
  };

  projects: {
    totalCount: number;
    completedCount: number;
    inProgressCount: number;
    hasGithubConnected: boolean;
    relevantProjectSummary: {
      title: string;
      status: string;
      difficulty: string;
      skills: string[];
    }[];
  };

  applications: {
    totalApplications: number;
    dataSource: 'in_app_student_tracker_records';
    isIndependentlyVerifiedByEmployer: false;
    disclaimer: string;
    activeApplications: {
      company: string;
      role: string;
      status: string;
      appliedDate: string;
      trackerNote?: string;
      nextStep?: string;
    }[];
  };
}

export interface BuildCareerCompanionSnapshotParams {
  user: UserProfile;
  skills: SkillItem[];
  roadmapStages: RoadmapStage[];
  resumeAnalysis?: ResumeAnalysisData | null;
  interviewHistory?: InterviewHistoryItem[] | null;
  projects?: ProjectItem[] | null;
  applications?: ApplicationItem[] | null;
  targetRoleOverride?: string;
}

/**
 * Builds a deterministic, role-aware career companion context snapshot
 * directly from the current CareerContext state.
 */
export function buildCareerCompanionSnapshot(
  params: BuildCareerCompanionSnapshotParams
): CareerCompanionSnapshot {
  const {
    user,
    skills = [],
    roadmapStages = [],
    resumeAnalysis,
    interviewHistory = [],
    projects = [],
    applications = [],
    targetRoleOverride
  } = params;

  const activeTargetRole = (targetRoleOverride || user?.targetRole || 'Software Engineer').trim();

  // 1. Skills: Verified skills + role-aware priority gaps
  const verifiedSkillsList = (skills || []).map((s) => ({
    name: s.name,
    currentLevel: s.currentLevel,
    category: s.category || 'Technical',
    status: s.status || 'Good'
  }));

  const allStrongTopics: string[] = [];
  const allWeakTopics: string[] = [];
  (skills || []).forEach((s) => {
    if (Array.isArray(s.strongTopics)) allStrongTopics.push(...s.strongTopics);
    if (Array.isArray(s.weakTopics)) allWeakTopics.push(...s.weakTopics);
  });

  // Calculate role-aware benchmark skill gaps using existing liveJobsService logic
  const roleBenchmarks: RoleBenchmarkDefinition[] = getRoleBenchmarkSkills(activeTargetRole, verifiedSkillsList);
  const priorityGaps: CareerCompanionSnapshot['skills']['priorityGaps'] = [];

  roleBenchmarks.forEach((benchmark) => {
    const matchingCandidateSkill = verifiedSkillsList.find((cs) =>
      areSkillsMatching(cs.name, benchmark.name)
    );
    // If candidate lacks the skill or is below benchmark requirement
    if (!matchingCandidateSkill || matchingCandidateSkill.currentLevel < benchmark.required) {
      priorityGaps.push({
        name: benchmark.name,
        requiredLevel: benchmark.required,
        category: 'Technical'
      });
    }
  });

  // 2. Roadmap: Progression analysis
  const totalStages = roadmapStages?.length || 0;
  const completedStagesCount = (roadmapStages || []).filter((s) => s.status === 'Completed').length;
  const progressPercent = totalStages > 0 ? Math.round((completedStagesCount / totalStages) * 100) : 0;
  
  const activeStage = (roadmapStages || []).find((s) => s.status === 'In Progress') ||
    (roadmapStages || []).find((s) => s.status !== 'Completed') || null;

  const currentStageSummary = activeStage
    ? {
        stepNumber: activeStage.stepNumber,
        title: activeStage.title,
        skillName: activeStage.skillName,
        status: activeStage.status,
        goal: activeStage.goal
      }
    : null;

  const upcomingStagesCount = (roadmapStages || []).filter((s) => s.status === 'Upcoming').length;

  // 3. Resume: Honest representation of upload/analysis state vs missing data
  const hasUploadedResume = Boolean(resumeAnalysis?.hasUploadedResume);
  let resumeSnapshot: CareerCompanionSnapshot['resume'];

  if (hasUploadedResume && resumeAnalysis) {
    const evaluatedScore = typeof resumeAnalysis.atsScore === 'number' ? resumeAnalysis.atsScore : null;
    resumeSnapshot = {
      hasUploadedResume: true,
      status: 'analyzed',
      atsScore: evaluatedScore,
      isEvaluatedScore: evaluatedScore !== null,
      formattingScore: typeof resumeAnalysis.formattingScore === 'number' ? resumeAnalysis.formattingScore : null,
      skillsMatch: typeof resumeAnalysis.skillsMatch === 'number' ? resumeAnalysis.skillsMatch : null,
      analyzedFileName: resumeAnalysis.analyzedFileName || 'uploaded_resume.pdf',
      detectedSkills: resumeAnalysis.detectedSkills || [],
      missingSkills: resumeAnalysis.missingSkills || [],
      strengths: (resumeAnalysis.strengths || []).slice(0, 5),
      topImprovements: (resumeAnalysis.improvements || []).slice(0, 4).map((imp) => ({
        original: imp.original,
        suggested: imp.suggested,
        reason: imp.reason
      }))
    };
  } else {
    // Zero-state: Never fabricate fake scores. Missing resume is NOT a score of zero.
    resumeSnapshot = {
      hasUploadedResume: false,
      status: 'not_attempted',
      atsScore: null,
      isEvaluatedScore: false,
      formattingScore: null,
      skillsMatch: null,
      analyzedFileName: null,
      detectedSkills: [],
      missingSkills: [],
      strengths: [],
      topImprovements: []
    };
  }

  // 4. Interview: Real practice session statistics (strictly in-app mock simulations, NOT real employer interviews)
  const completedSessions = interviewHistory || [];
  const sessionsCompletedCount = completedSessions.length;
  let interviewSnapshot: CareerCompanionSnapshot['interview'];

  if (sessionsCompletedCount > 0) {
    const latest = completedSessions[0];
    const totalScore = completedSessions.reduce((acc, curr) => acc + (curr.score || 0), 0);
    const averageScore = Math.round(totalScore / sessionsCompletedCount);

    // Active practice weaknesses from existing selector, strictly filtering for unresolved
    const rawWeaknesses: InterviewPracticeWeakness[] = getInterviewPracticeWeaknesses(
      completedSessions,
      activeTargetRole
    );
    const activeWeaknesses = rawWeaknesses
      .filter((w) => !w.isResolved)
      .slice(0, 5)
      .map((w) => ({
        topic: w.topic,
        relatedSkill: w.relatedSkill,
        questionTitle: w.questionTitle,
        lastAttemptScore: w.lastAttemptScore,
        areasToImprove: w.areasToImprove || []
      }));

    interviewSnapshot = {
      status: 'attempted',
      isMockPracticeOnly: true,
      environment: 'in_app_mock_interview_simulation',
      sessionsCompleted: sessionsCompletedCount,
      latestSession: {
        date: latest.date,
        interviewType: latest.interviewType,
        role: latest.role,
        score: latest.score,
        practiceStatus: latest.status,
        status: latest.status,
        feedback: latest.feedback,
        categoryBreakdown: {
          technical: latest.categoryBreakdown?.technical || 0,
          communication: latest.categoryBreakdown?.communication || 0,
          confidence: latest.categoryBreakdown?.confidence || 0,
          completeness: latest.categoryBreakdown?.completeness || 0,
          coding: latest.categoryBreakdown?.coding
        }
      },
      averageScore,
      practiceWeaknesses: activeWeaknesses
    };
  } else {
    // Zero-state: Never fabricate 0% failed interview
    interviewSnapshot = {
      status: 'not_attempted',
      isMockPracticeOnly: true,
      environment: 'in_app_mock_interview_simulation',
      sessionsCompleted: 0,
      latestSession: null,
      averageScore: null,
      practiceWeaknesses: []
    };
  }

  // 5. Placement Readiness: Single authoritative calculation via existing engine
  const prResult: PlacementReadinessResult = calculatePlacementReadiness(
    user,
    skills,
    projects || [],
    resumeAnalysis,
    interviewHistory || [],
    activeTargetRole
  );

  const placementReadinessSnapshot: CareerCompanionSnapshot['placementReadiness'] = {
    overallScore: prResult.overallScore,
    tier: prResult.status,
    pillars: {
      technical: prResult.technicalScore,
      projects: prResult.projectsScore,
      ats: prResult.atsScore,
      interview: prResult.interviewScore
    },
    pillarWeights: {
      technical: '30%',
      projects: '25%',
      ats: '25%',
      interview: '20%'
    },
    formulaNote: 'Overall = Math.round(Tech*0.30 + Projects*0.25 + ATS*0.25 + Interview*0.20). ATS Resume Quality carries a 25% weight. When no resume has been analyzed, atsScore defaults to 0 as an internal calculation placeholder in the weighted formula (contributing 0 points out of 25), while the ATS pillar status is strictly not_attempted (not evaluated or failed). If a resume is later analyzed with a new ATS score, the new overall readiness is recalculated with Math.round(Tech*0.30 + Projects*0.25 + newAtsScore*0.25 + Interview*0.20). The net change accounts for previous ATS contribution and integer rounding; it cannot be determined as a fixed number until analyzed. Never claim a 6% estimate exists or that 6% is a dashboard placeholder.',
    componentStatus: {
      technical: prResult.componentMetadata?.technical?.status || 'not_attempted',
      projects: prResult.componentMetadata?.projects?.status || 'not_attempted',
      ats: prResult.componentMetadata?.ats?.status || 'not_attempted',
      interview: prResult.componentMetadata?.interview?.status || 'not_attempted'
    },
    improvementAreas: (prResult.improvementAreas || []).slice(0, 5).map((imp) => ({
      title: imp.title,
      priority: imp.priority,
      description: imp.description
    })),
    recommendedActions: (prResult.recommendedActions || []).slice(0, 4).map((act) => ({
      title: act.title,
      impact: act.impact,
      category: act.category
    }))
  };

  // 6. Projects: Honest accounting of hands-on technical work
  const projectList = projects || [];
  const completedProjectsCount = projectList.filter((p) => p.status === 'Completed').length;
  const inProgressProjectsCount = projectList.filter((p) => p.status === 'In Progress').length;

  const relevantProjectSummary = projectList.slice(0, 6).map((p) => ({
    title: p.title,
    status: p.status,
    difficulty: p.difficulty,
    skills: p.skills || []
  }));

  // 7. Applications: In-app student job tracker records (demo/self-maintained records, NOT employer-verified)
  const appList = applications || [];
  const applicationsSnapshot: CareerCompanionSnapshot['applications'] = {
    totalApplications: appList.length,
    dataSource: 'in_app_student_tracker_records',
    isIndependentlyVerifiedByEmployer: false,
    disclaimer: 'All application records are in-app self-reported student tracker entries or starter demonstration data. They are NOT externally verified by employers, corporate recruiters, or college placement cells.',
    activeApplications: appList.map((app) => ({
      company: app.company,
      role: app.role,
      status: app.status,
      appliedDate: app.appliedDate,
      trackerNote: app.nextStep || undefined,
      nextStep: app.nextStep
    }))
  };

  return {
    timestamp: new Date().toISOString(),
    student: {
      name: user?.name || 'Candidate',
      targetRole: activeTargetRole,
      experienceLevel: user?.experienceLevel || 'Beginner',
      college: user?.college,
      degree: user?.degree,
      graduationYear: user?.graduationYear,
      workPreference: user?.workPreference
    },
    skills: {
      verifiedCount: verifiedSkillsList.length,
      verifiedSkills: verifiedSkillsList,
      strongTopics: Array.from(new Set(allStrongTopics)),
      weakTopics: Array.from(new Set(allWeakTopics)),
      priorityGaps
    },
    roadmap: {
      totalStages,
      completedStagesCount,
      progressPercent,
      currentStage: currentStageSummary,
      upcomingStagesCount
    },
    resume: resumeSnapshot,
    interview: interviewSnapshot,
    placementReadiness: placementReadinessSnapshot,
    projects: {
      totalCount: projectList.length,
      completedCount: completedProjectsCount,
      inProgressCount: inProgressProjectsCount,
      hasGithubConnected: Boolean(user?.githubConnected),
      relevantProjectSummary
    },
    applications: applicationsSnapshot
  };
}

/**
 * Sends a message to the AI Career Companion.
 * Rebuilds the fresh CareerCompanionSnapshot at the exact moment of message dispatch.
 */
export async function sendCareerCompanionMessage(
  message: string,
  params: BuildCareerCompanionSnapshotParams
): Promise<string> {
  const snapshot = buildCareerCompanionSnapshot(params);
  return sendCareerCompanionMessageWithSnapshot(message, snapshot);
}

/**
 * Sends a message along with a pre-built CareerCompanionSnapshot to /api/chat.
 */
export async function sendCareerCompanionMessageWithSnapshot(
  message: string,
  snapshot: CareerCompanionSnapshot
): Promise<string> {
  if (!message || !message.trim()) {
    throw new Error('Message cannot be empty.');
  }

  const response = await fetch('/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      message: message.trim(),
      careerContext: snapshot
    })
  });

  if (!response.ok) {
    let errorMsg = 'The career assistant is temporarily unavailable. Please try again.';
    try {
      const data = await response.json();
      if (data?.error) errorMsg = data.error;
    } catch {
      // fallback to default
    }
    throw new Error(errorMsg);
  }

  const data = await response.json();
  return data.reply || '';
}

