/**
 * GitHub Integration Service
 * Provides full working simulated and API-ready methods for repository management.
 */

import { GitHubProjectItem } from '../types.ts';

export const initialGitHubProjects: GitHubProjectItem[] = [
  {
    id: 'gh_1',
    name: 'Sales Data Analysis & Executive Dashboard',
    repoName: 'sales-data-analysis-powerbi',
    description: 'Automated Python ETL pipeline with PostgreSQL database star-schema modeling and 4 interactive Power BI drill-through dashboards.',
    visibility: 'public',
    projectType: 'Data Analytics & ETL',
    technologies: ['Python', 'PostgreSQL', 'Power BI', 'Pandas'],
    stars: 14,
    forks: 4,
    languages: { Python: 68, SQL: 22, DAX: 10 },
    lastUpdated: '2 days ago',
    url: 'https://github.com/snehalkale/sales-data-analysis-powerbi',
    inPortfolio: true,
  },
  {
    id: 'gh_2',
    name: 'Customer Churn Prediction & Retention System',
    repoName: 'customer-churn-ml-classifier',
    description: 'XGBoost & Random Forest classifier on 7,000+ subscriber records with SHAP interpretability analysis, achieving 86% ROC-AUC.',
    visibility: 'public',
    projectType: 'Machine Learning',
    technologies: ['Python', 'Scikit-Learn', 'XGBoost', 'SHAP'],
    stars: 19,
    forks: 6,
    languages: { Python: 85, Jupyter: 15 },
    lastUpdated: '1 week ago',
    url: 'https://github.com/snehalkale/customer-churn-ml-classifier',
    inPortfolio: true,
  },
  {
    id: 'gh_3',
    name: 'Book & E-Commerce Data EDA Engine',
    repoName: 'ecommerce-exploratory-analytics',
    description: 'Exploratory data analysis identifying pricing patterns, rating distributions, and automated outliers detection using Matplotlib and Seaborn.',
    visibility: 'public',
    projectType: 'Data Exploration',
    technologies: ['Python', 'Seaborn', 'NumPy', 'Pandas'],
    stars: 8,
    forks: 2,
    languages: { Python: 92, Shell: 8 },
    lastUpdated: '3 weeks ago',
    url: 'https://github.com/snehalkale/ecommerce-exploratory-analytics',
    inPortfolio: true,
  },
  {
    id: 'gh_4',
    name: 'AI Career Assistant & Placement Platform',
    repoName: 'ai-career-assistant-react',
    description: 'Modern student career & placement accelerator web application built with React, TypeScript, and Tailwind CSS.',
    visibility: 'public',
    projectType: 'Web Platform',
    technologies: ['React', 'TypeScript', 'Tailwind CSS', 'Vite'],
    stars: 32,
    forks: 11,
    languages: { TypeScript: 74, CSS: 18, HTML: 8 },
    lastUpdated: 'Just now',
    url: 'https://github.com/snehalkale/ai-career-assistant-react',
    inPortfolio: true,
  },
];

export const githubService = {
  /**
   * Simulates or authenticates with GitHub.
   */
  async connectAccount(username: string = 'snehalkale') {
    return {
      connected: true,
      username,
      avatarUrl: 'https://github.com/snehalkale.png',
      publicRepos: 12,
      followers: 48,
      following: 35,
    };
  },

  /**
   * Creates a repository on GitHub (simulated prototype with real API signature).
   */
  async createRepository(params: {
    name: string;
    description: string;
    visibility: 'public' | 'private';
    projectType: string;
    technologies: string[];
  }): Promise<GitHubProjectItem> {
    const slug = params.name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const newRepo: GitHubProjectItem = {
      id: `gh_${Date.now()}`,
      name: params.name,
      repoName: slug,
      description: params.description,
      visibility: params.visibility,
      projectType: params.projectType,
      technologies: params.technologies,
      stars: 1,
      forks: 0,
      languages: { Python: 80, SQL: 20 },
      lastUpdated: 'Just now',
      url: `https://github.com/snehalkale/${slug}`,
      inPortfolio: true,
    };
    return newRepo;
  },

  /**
   * Pushes a generated README.md to GitHub repository.
   */
  async pushReadme(repoName: string, markdown: string) {
    return {
      success: true,
      commitSha: 'a1b2c3d4e5f6',
      message: `docs: update README.md via AI Career Assistant`,
      repoUrl: `https://github.com/snehalkale/${repoName}`,
    };
  },
};
