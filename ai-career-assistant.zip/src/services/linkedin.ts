/**
 * LinkedIn Integration Service
 * Manages post drafting, AI generation, certificate analysis,
 * progress detection, and OAuth publishing.
 */

import {
  CertificateItem,
  CareerProgressEvent,
  LinkedInPostItem,
  LinkedInSettings
} from '../types.ts';

export const defaultLinkedInSettings: LinkedInSettings = {
  isConnected: true,
  profileName: 'Snehal Kale',
  profileHeadline: 'BTech AI & Data Science Candidate at VPKBIET | Aspiring Data Analyst',
  profileUrl: 'https://linkedin.com/in/snehalkale',
  avatarUrl: '',
  connectedAt: 'Sep 2026',
  postingPreference: 'ask_before_post', // Default per requirements!
  includeHashtags: true,
  autoPublishApprovedProgress: false,
  defaultTone: 'Professional',
  includeCredentialUrls: true,
  includeMetricsByDefault: true,
  monitoredEventTypes: [
    'Assessment',
    'Skill',
    'Roadmap',
    'Project',
    'Certificate',
    'Achievement',
    'Interview',
    'GitHub',
    'Placement'
  ]
};

export const initialCertificates: CertificateItem[] = [
  {
    id: 'cert_1',
    title: 'Python for Data Science & Machine Learning',
    organization: 'NPTEL (IIT Madras)',
    issueDate: 'Sep 15, 2026',
    credentialId: 'NPTEL26CS92817291',
    credentialUrl: 'https://nptel.ac.in/noc/Ecertificate/?q=NPTEL26CS92817291',
    certificateFileName: 'NPTEL_Python_DataScience_Certificate.pdf',
    certificateFileUrl: '',
    certificateType: 'Course',
    relatedSkill: 'Python',
    skillsGained: ['Python OOP', 'Pandas & NumPy', 'Computational Statistics', 'Data Structures'],
    description: '12-week comprehensive program covering exploratory data analysis, algorithmic optimization, and predictive inference.',
    verificationStatus: 'Verified',
    createdAt: 'Sep 15, 2026',
    linkedInPostGenerated: true,
    linkedInPostId: 'li_1'
  },
  {
    id: 'cert_2',
    title: 'Enterprise Business Intelligence & DAX Modeling',
    organization: 'Microsoft Learn / Coursera',
    issueDate: 'Sep 24, 2026',
    credentialId: 'MSFT-PL300-883921',
    credentialUrl: 'https://learn.microsoft.com/credentials/cert/MSFT-PL300-883921',
    certificateFileName: 'Microsoft_PowerBI_Enterprise.pdf',
    certificateFileUrl: '',
    certificateType: 'Training',
    relatedSkill: 'Power BI',
    skillsGained: ['DAX Calculations', 'Star Schema Architecture', 'Power Query ETL', 'Row-Level Security'],
    description: 'Hands-on credential focused on production dashboard design, multidimensional star schemas, and automated refresh pipelines.',
    verificationStatus: 'Verified',
    createdAt: 'Sep 24, 2026',
    linkedInPostGenerated: false
  },
  {
    id: 'cert_3',
    title: 'Data Analytics Virtual Experience Program',
    organization: 'Deloitte USI (Forage)',
    issueDate: 'Aug 18, 2026',
    credentialId: 'FORAGE-DELOITTE-77291',
    credentialUrl: 'https://www.theforage.com/simulations/deloitte/data-analytics',
    certificateFileName: 'Deloitte_Analytics_Internship_Certificate.pdf',
    certificateFileUrl: '',
    certificateType: 'Internship',
    relatedSkill: 'SQL',
    skillsGained: ['Data Cleansing', 'Executive Storytelling', 'Advanced SQL Joins', 'Dashboarding'],
    description: 'Simulated client advisory project analyzing telemetry logs, financial variance, and executive KPI summaries.',
    verificationStatus: 'Verified',
    createdAt: 'Aug 18, 2026',
    linkedInPostGenerated: true,
    linkedInPostId: 'li_3'
  }
];

export const initialProgressEvents: CareerProgressEvent[] = [
  {
    id: 'prog_1',
    date: 'Sep 18, 2026',
    eventType: 'Assessment',
    title: 'Python Assessment Score Improved',
    description: 'Verified assessment score increased through targeted testing of loops, OOP, and data structures.',
    relatedSkill: 'Python',
    previousValue: '62%',
    newValue: '78%',
    delta: '+16%',
    isMeaningful: true,
    linkedInStatus: 'Draft Ready',
    sourceMetadata: {
      skill: 'Python',
      strongTopics: ['Functions', 'Lists, tuples, dictionaries and sets'],
      weakTopics: ['OOP', 'Exception handling']
    }
  },
  {
    id: 'prog_2',
    date: 'Sep 22, 2026',
    eventType: 'Skill',
    title: 'SQL Skill Successfully Verified',
    description: 'Validated relational query competencies including multi-table joins, subqueries, and window ranking functions.',
    relatedSkill: 'SQL',
    previousValue: '60%',
    newValue: '72%',
    delta: '+12%',
    isMeaningful: true,
    linkedInStatus: 'Draft Ready',
    sourceMetadata: {
      skill: 'SQL',
      strongTopics: ['Basic SELECT & Filtering', 'JOIN Operations']
    }
  },
  {
    id: 'prog_3',
    date: 'Sep 24, 2026',
    eventType: 'Certificate',
    title: 'New Power BI Enterprise Certificate Added',
    description: 'Earned Microsoft Business Intelligence credential validating DAX measure formulation and star schemas.',
    relatedSkill: 'Power BI',
    newValue: 'Microsoft Learn Certified',
    isMeaningful: true,
    linkedInStatus: 'Draft Ready'
  },
  {
    id: 'prog_4',
    date: 'Sep 20, 2026',
    eventType: 'Roadmap',
    title: 'Completed "Advanced SQL & Query Optimization" Milestone',
    description: 'Finished 5 core technical modules and practice query optimization tasks on career pathway.',
    relatedSkill: 'SQL',
    newValue: 'Stage 3 Completed',
    isMeaningful: true,
    linkedInStatus: 'Published',
    linkedInPostId: 'li_2'
  },
  {
    id: 'prog_5',
    date: 'Sep 14, 2026',
    eventType: 'Project',
    title: 'Completed Sales & Operations Intelligence Dashboard',
    description: 'Built end-to-end data analytics pipeline analyzing 100K+ transactional records with PostgreSQL and Power BI.',
    relatedSkill: 'Power BI',
    newValue: 'Production Project',
    isMeaningful: true,
    linkedInStatus: 'Published',
    linkedInPostId: 'li_2'
  }
];

export const initialLinkedInPosts: LinkedInPostItem[] = [
  {
    id: 'li_1',
    title: 'Completed NPTEL Python for Data Science Certification',
    hook: '🚀 Delighted to share that I have completed the NPTEL Python for Data Science certification with Elite performance!',
    content:
      'I completed the 12-week NPTEL Python for Data Science certification from IIT Madras.\n\nDuring this program, I deepened my understanding of data wrangling with Pandas & NumPy, computational statistics, and object-oriented programming.\n\nSkills gained:\n• Python OOP & Data Structures\n• Exploratory Data Analysis\n• Statistical Hypothesis Testing\n\nSpecial thanks to our faculty at VPKBIET for continuous encouragement. Excited to apply these concepts in upcoming engineering and placement drives!\n\n#DataAnalytics #Python #NPTEL #ContinuousLearning #EngineeringStudents',
    hashtags: ['#DataAnalytics', '#Python', '#NPTEL', '#ContinuousLearning', '#EngineeringStudents'],
    date: '15 Sep 2026',
    certificateId: 'cert_1',
    postType: 'Certificate',
    status: 'Published',
    publishedUrl: 'https://www.linkedin.com/feed/update/urn:li:activity:724128919283719283/',
    likes: 64,
    comments: 12,
    tone: 'Professional',
    includeCredentialUrl: true,
    includeMetrics: true
  },
  {
    id: 'li_2',
    title: 'Sales & Operations Intelligence Dashboard Launch',
    hook: '📊 How can retail managers identify 14% inventory savings? Here is what I built using Python and Power BI.',
    content:
      'I recently built an executive sales intelligence dashboard analyzing 100,000+ transactional records.\n\nKey takeaways from the project:\n• Designed a star schema in PostgreSQL with 1-to-many relationship cardinality\n• Automated ETL pipelines in Python using Pandas\n• Authored 4 drill-through interactive Power BI reports with custom DAX measures\n\nCheck out the GitHub repository and live interactive demo!\n\n#PowerBI #DataVisualization #PostgreSQL #SQL #PortfolioProject',
    hashtags: ['#PowerBI', '#DataAnalytics', '#SQL', '#PortfolioProject'],
    date: '02 Sep 2026',
    projectId: 'proj_sales',
    progressEventId: 'prog_5',
    postType: 'Project Launch',
    status: 'Published',
    publishedUrl: 'https://www.linkedin.com/feed/update/urn:li:activity:723928172918273619/',
    likes: 89,
    comments: 18,
    tone: 'Professional'
  },
  {
    id: 'li_3',
    title: 'Deloitte Data Analytics Simulation Completion',
    hook: '🎓 Proud to complete the Deloitte USI Data Analytics Virtual Experience Program via Forage!',
    content:
      'Completed a practical corporate analytics simulation with Deloitte USI.\n\nWhat I worked on:\n• Transformed raw telemetry logs using SQL joins and window aggregation\n• Formulated executive summary dashboards for business unit leaders\n• Identified operational risk patterns in multi-region sales data\n\nGrateful for the structured industry exposure!\n\n#Deloitte #DataAnalytics #SQL #ContinuousLearning #Forage',
    hashtags: ['#Deloitte', '#DataAnalytics', '#SQL', '#ContinuousLearning'],
    date: '18 Aug 2026',
    certificateId: 'cert_3',
    postType: 'Certificate',
    status: 'Published',
    publishedUrl: 'https://www.linkedin.com/feed/update/urn:li:activity:723192837192837192/',
    likes: 112,
    comments: 24,
    tone: 'Professional'
  },
  {
    id: 'li_draft_py',
    title: 'Python Assessment Mastery Improvement',
    hook: '📈 Delighted with the progress: improved my verified Python assessment score from 62% to 78%!',
    content:
      'Over the past few weeks, I focused heavily on closing foundational programming gaps:\n\n• Refactored problem sets to master modular functions and container algorithms\n• Solved hands-on exercises in list comprehensions and dictionary hashing\n• Practiced object-oriented design and robust exception handling blocks\n\nConsistency and measurable benchmark testing make all the difference in placement readiness. Next target: bridging Advanced SQL and DAX modeling.\n\n#Python #CodeQuality #PlacementReadiness #CareerGrowth #LearningJourney',
    hashtags: ['#Python', '#CodeQuality', '#PlacementReadiness', '#CareerGrowth'],
    date: 'Sep 18, 2026',
    progressEventId: 'prog_1',
    postType: 'Assessment Progress',
    status: 'Draft',
    likes: 0,
    comments: 0,
    tone: 'Learning journey'
  }
];

export interface PostGenerationOptions {
  tone?: 'Professional' | 'Enthusiastic' | 'Learning journey' | 'Concise';
  includeHashtags?: boolean;
  includeMetrics?: boolean;
  includeCredentialUrl?: boolean;
}

export const linkedinService = {
  /**
   * Generates a structured LinkedIn post draft strictly from certificate data.
   * Structure strictly follows:
   * - What I completed
   * - What I learned
   * - Skills gained
   * - Organization / course name
   * - Professional reflection
   * - Relevant hashtags
   */
  generatePostFromCertificate(
    cert: CertificateItem,
    options: PostGenerationOptions = {}
  ): {
    title: string;
    hook: string;
    content: string;
    hashtags: string[];
    tone: 'Professional' | 'Enthusiastic' | 'Learning journey' | 'Concise';
  } {
    const tone = options.tone || 'Professional';
    const includeHashtags = options.includeHashtags ?? true;
    const includeCredentialUrl = options.includeCredentialUrl ?? true;
    const title = `Completed ${cert.title} Certification`;

    let hook = '';
    let reflection = '';

    if (tone === 'Enthusiastic') {
      hook = `🌟 Absolutely thrilled to announce that I have earned the "${cert.title}" credential from ${cert.organization}! 🚀`;
      reflection =
        `Diving deep into this coursework was an incredible experience. Every module pushed my technical boundaries and gave me practical problem-solving confidence. Can't wait to build real-world applications with these tools!`;
    } else if (tone === 'Learning journey') {
      hook = `🌱 Reflecting on my learning journey: proud to share the completion of "${cert.title}" with ${cert.organization}.`;
      reflection =
        `Engineering is built one milestone at a time. Balancing coursework at VPKBIET while methodically working through assignments taught me the value of structured discipline and continuous curiosity.`;
    } else if (tone === 'Concise') {
      hook = `Credential Earned: ${cert.title} — ${cert.organization}.`;
      reflection =
        `Key focus: Applied technical foundations, industry problem-solving workflows, and verified placement readiness.`;
    } else {
      // Professional default
      hook = `🎓 Delighted to share that I have earned the "${cert.title}" credential from ${cert.organization}!`;
      reflection =
        `Structured learning and hands-on exercises have helped me strengthen my foundational competencies. Eager to implement these skills in upcoming real-world projects and placement opportunities!`;
    }

    const skillsBullet =
      cert.skillsGained && cert.skillsGained.length > 0
        ? cert.skillsGained.map((s) => `• ${s}`).join('\n')
        : `• ${cert.relatedSkill} Core Foundations\n• Practical Application & Problem Solving`;

    let credentialSection = '';
    if (cert.credentialId) {
      credentialSection += `\nCredential ID: ${cert.credentialId}`;
    }
    if (includeCredentialUrl && cert.credentialUrl) {
      credentialSection += `\nVerification Link: ${cert.credentialUrl}`;
    }

    let hashtags: string[] = [];
    if (includeHashtags) {
      const cleanSkill = cert.relatedSkill.replace(/[^a-zA-Z0-9]/g, '');
      const cleanOrg = cert.organization.replace(/[^a-zA-Z0-9]/g, '');
      hashtags = [
        `#${cleanSkill}`,
        '#ContinuousLearning',
        `#${cleanOrg}`,
        '#DataAnalytics',
        '#PlacementPrep'
      ];
    }

    const hashtagLine = hashtags.length > 0 ? `\n\n${hashtags.join(' ')} #VPKBIET` : '';

    const content = `${hook}

What I completed:
Successfully completed the ${cert.certificateType.toLowerCase()} program "${cert.title}" issued by ${cert.organization} on ${cert.issueDate}.${credentialSection}

What I learned & Skills gained:
${skillsBullet}

${cert.description ? `Coursework overview:\n${cert.description}\n\n` : ''}Professional reflection:
${reflection}${hashtagLine}`;

    return { title, hook, content, hashtags, tone };
  },

  /**
   * Generates a LinkedIn post from an authentic Career Progress event
   */
  generatePostFromProgress(
    event: CareerProgressEvent,
    options: PostGenerationOptions = {}
  ): {
    title: string;
    hook: string;
    content: string;
    hashtags: string[];
    tone: 'Professional' | 'Enthusiastic' | 'Learning journey' | 'Concise';
  } {
    const tone = options.tone || 'Professional';
    const includeHashtags = options.includeHashtags ?? true;
    const includeMetrics = options.includeMetrics ?? true;

    let hook = `📈 Meaningful progress update: ${event.title}!`;
    let body = event.description;
    const skillName = event.relatedSkill || 'Data Analytics';
    const cleanSkill = skillName.replace(/[^a-zA-Z0-9]/g, '');

    if (event.eventType === 'Assessment') {
      const scoreText = includeMetrics && event.previousValue && event.newValue
        ? `from ${event.previousValue} to ${event.newValue} (${event.delta})`
        : 'with measurable score growth';

      if (tone === 'Enthusiastic') {
        hook = `🔥 Hard work paying off! Just boosted my verified ${skillName} assessment score ${scoreText}! 🎯`;
      } else if (tone === 'Learning journey') {
        hook = `💡 Embracing deliberate practice: improved my ${skillName} benchmark ${scoreText}.`;
      } else if (tone === 'Concise') {
        hook = `Assessment Milestone: ${skillName} score improved ${scoreText}.`;
      } else {
        hook = `📊 Consistent practice pays off: recently improved my verified ${skillName} assessment score ${scoreText}!`;
      }

      body = `As part of my ongoing career preparation at VPKBIET, I have been systematically identifying and testing technical skill gaps.

What went into this milestone:
• Targeted practice across core topics including algorithmic problem solving
• Reviewing mistake analysis and refactoring conceptual weak areas
• Standardized benchmark re-testing to verify true proficiency

Steadily building the technical depth required for top data and software roles. Onwards to the next milestone!`;
    } else if (event.eventType === 'Skill') {
      if (tone === 'Enthusiastic') {
        hook = `✨ Excited to announce: successfully verified my proficiency in ${skillName}! 💻`;
      } else if (tone === 'Learning journey') {
        hook = `🌱 Growth checkpoint: validating my practical skills in ${skillName}.`;
      } else if (tone === 'Concise') {
        hook = `Skill Verified: ${skillName} evaluated and certified.`;
      } else {
        hook = `💡 Technical milestone: verified my working proficiency in ${skillName}!`;
      }

      body = `I recently completed a comprehensive diagnostic evaluation for ${skillName}.

Key takeaways:
• Evaluated real-world query and algorithmic logic
• Identified both strong anchor areas and actionable growth goals
• Integrated weak topics directly into my structured learning roadmap

Excited to keep building hands-on portfolio projects around this!`;
    } else if (event.eventType === 'Roadmap') {
      if (tone === 'Enthusiastic') {
        hook = `🚀 Another milestone unlocked on my engineering roadmap: ${event.title}! 🎉`;
      } else if (tone === 'Learning journey') {
        hook = `🧭 Journey milestone: completed "${event.title}" on my learning pathway.`;
      } else if (tone === 'Concise') {
        hook = `Roadmap Progress: Completed ${event.title}.`;
      } else {
        hook = `🚀 Completed another milestone on my career roadmap: ${event.title}!`;
      }

      body = `One of the most rewarding aspects of engineering is seeing steady, incremental growth on a clear pathway.

${event.description}

Tracking every milestone against recruiter benchmarks keeps the preparation focused and disciplined. Looking forward to the next challenge!`;
    } else if (event.eventType === 'Project') {
      hook = `🛠️ Just wrapped up a new technical project: ${event.title}!`;
      body = `${event.description}

Building end-to-end applications from scratch is the most effective way to validate theoretical knowledge and test edge cases. Check out my GitHub for source code and architecture diagrams!`;
    } else if (event.eventType === 'Interview') {
      hook = `🎙️ Completed comprehensive mock interview practice for ${event.title}!`;
      body = `${event.description}

Practicing under simulated placement interview pressure—balancing technical correctness, structured communication, and edge-case reasoning—is sharpening my confidence for upcoming campus drives.`;
    } else if (event.eventType === 'Achievement') {
      hook = `🏆 Proud to share an achievement update: ${event.title}!`;
      body = `${event.description}

Collaborating with peers and competing in real-world scenarios continues to inspire my engineering journey.`;
    } else if (event.eventType === 'GitHub') {
      hook = `⚡ Open-source & portfolio sync: connected repository "${event.title}"!`;
      body = `${event.description}

Committing code consistently, maintaining documentation, and architecting clean modular structures.`;
    } else if (event.eventType === 'Placement') {
      hook = `🎯 Placement readiness milestone reached: ${event.title}!`;
      body = `${event.description}

Continuous benchmark testing, verified project repositories, and structured skill gap closures are coming together as I prepare for upcoming placement drives.`;
    }

    let hashtags: string[] = [];
    if (includeHashtags) {
      hashtags = [`#${cleanSkill}`, '#CareerGrowth', '#LearningInPublic', '#PlacementPrep'];
    }

    const hashtagLine = hashtags.length > 0 ? `\n\n${hashtags.join(' ')} #VPKBIET` : '';
    const content = `${hook}\n\n${body}${hashtagLine}`;

    return {
      title: event.title,
      hook,
      content,
      hashtags,
      tone
    };
  },

  /**
   * Intelligently extracts useful details from certificate file name or text
   * (Does not invent; uses provided cues or falls back to clear prompt for user input)
   */
  extractCertificateDetails(
    fileName: string,
    extractedText?: string
  ): Partial<CertificateItem> {
    const raw = `${fileName} ${extractedText || ''}`;
    const cleanName = fileName.replace(/\.[^/.]+$/, '').replace(/[_-]/g, ' ');
    const lower = raw.toLowerCase();

    let relatedSkill = 'Python';
    let certificateType: CertificateItem['certificateType'] = 'Course';
    let organization = 'Online Academy';
    const skillsGained: string[] = [];

    if (lower.includes('sql') || lower.includes('database')) {
      relatedSkill = 'SQL';
      skillsGained.push('Relational Data Modeling', 'Complex SQL Joins', 'Query Optimization');
    } else if (lower.includes('power bi') || lower.includes('powerbi') || lower.includes('dax')) {
      relatedSkill = 'Power BI';
      skillsGained.push('DAX Formulas', 'Interactive Dashboards', 'Data Modeling');
    } else if (lower.includes('machine learning') || lower.includes('ml')) {
      relatedSkill = 'Machine Learning';
      skillsGained.push('Supervised Learning', 'Model Evaluation', 'Feature Engineering');
    } else if (lower.includes('statist')) {
      relatedSkill = 'Statistics';
      skillsGained.push('Hypothesis Testing', 'Probability Distributions', 'Descriptive Analytics');
    } else if (lower.includes('excel')) {
      relatedSkill = 'Excel';
      skillsGained.push('VLOOKUP & XLOOKUP', 'Pivot Tables', 'Data Cleaning');
    } else if (lower.includes('c++') || lower.includes('cpp')) {
      relatedSkill = 'C++';
      skillsGained.push('OOP in C++', 'STL Containers', 'Pointers & Memory');
    } else {
      skillsGained.push('Core Programming Foundations', 'Applied Problem Solving');
    }

    if (lower.includes('internship') || lower.includes('intern')) certificateType = 'Internship';
    else if (lower.includes('workshop')) certificateType = 'Workshop';
    else if (lower.includes('hackathon')) certificateType = 'Hackathon';
    else if (lower.includes('training')) certificateType = 'Training';
    else if (lower.includes('professional') || lower.includes('industry')) certificateType = 'Professional';

    if (lower.includes('nptel')) organization = 'NPTEL (IIT)';
    else if (lower.includes('microsoft')) organization = 'Microsoft Learn';
    else if (lower.includes('coursera')) organization = 'Coursera';
    else if (lower.includes('deloitte')) organization = 'Deloitte USI';
    else if (lower.includes('tcs')) organization = 'Tata Consultancy Services';
    else if (lower.includes('aws') || lower.includes('amazon')) organization = 'Amazon Web Services';
    else if (lower.includes('google')) organization = 'Google Cloud';
    else if (lower.includes('udemy')) organization = 'Udemy';
    else if (lower.includes('forage')) organization = 'Forage';

    // Check for credential ID regex patterns in text
    let credentialId: string | undefined;
    const idMatch = raw.match(/(?:credential|id|cert|license|code)[:\s#]+([A-Z0-9-]{6,25})/i);
    if (idMatch && idMatch[1]) {
      credentialId = idMatch[1].trim();
    }

    return {
      title: cleanName.length > 5 ? cleanName : `${relatedSkill} Certification`,
      organization,
      relatedSkill,
      certificateType,
      credentialId,
      skillsGained,
      issueDate: new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      })
    };
  },

  /**
   * Builds direct LinkedIn share URL
   */
  getLinkedInShareUrl(postText: string, targetUrl?: string): string {
    if (targetUrl) {
      return `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(targetUrl)}`;
    }
    return `https://www.linkedin.com/feed/?shareActive=true&text=${encodeURIComponent(postText)}`;
  },

  /**
   * Real OAuth Authorization Status & Flow
   */
  async requestOAuthConnection(): Promise<{ success: boolean; settings: Partial<LinkedInSettings> }> {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          success: true,
          settings: {
            isConnected: true,
            profileName: 'Snehal Kale',
            profileHeadline: 'BTech AI & Data Science Candidate at VPKBIET | Aspiring Data Analyst',
            profileUrl: 'https://linkedin.com/in/snehalkale',
            connectedAt: new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
            postingPreference: 'ask_before_post'
          }
        });
      }, 500);
    });
  }
};
