import {
  AssessmentHistoryItem,
  LearningResource,
  PracticalExercise,
  RoadmapPhase,
  RoadmapStage,
  SimpleRoadmapStageGroup,
  SkillItem
} from '../types.ts';
import { areSkillsMatching, canonicalizeSkill } from './liveJobsService.ts';

/**
 * Verified Learning Resource Repository
 * All resources are official documentation, reputable educational platforms,
 * or free interactive tutorials with genuine, permanent direct URLs.
 */
export const VERIFIED_SKILL_RESOURCES: Record<string, LearningResource[]> = {
  Python: [
    {
      title: 'The Python Tutorial (Official 3.12 Documentation)',
      provider: 'Python Software Foundation',
      url: 'https://docs.python.org/3/tutorial/',
      cost: 'Free',
      isVerified: true,
      type: 'Official Guide',
    },
    {
      title: 'Python for Beginners & Interactive Syntax Exercises',
      provider: 'W3Schools',
      url: 'https://www.w3schools.com/python/',
      cost: 'Free',
      isVerified: true,
      type: 'Interactive Tutorial',
    },
  ],
  SQL: [
    {
      title: 'PostgreSQL Official Tutorial & Query Architecture',
      provider: 'PostgreSQL Global Development Group',
      url: 'https://www.postgresql.org/docs/current/tutorial.html',
      cost: 'Free',
      isVerified: true,
      type: 'Documentation',
    },
    {
      title: 'SQL Tutorial, Joins, Aggregations & Window Functions',
      provider: 'W3Schools',
      url: 'https://www.w3schools.com/sql/',
      cost: 'Free',
      isVerified: true,
      type: 'Interactive Tutorial',
    },
  ],
  'Power BI': [
    {
      title: 'Microsoft Power BI Official Guided Learning & Documentation',
      provider: 'Microsoft Learn',
      url: 'https://learn.microsoft.com/en-us/power-bi/',
      cost: 'Free',
      isVerified: true,
      type: 'Documentation',
    },
    {
      title: 'DAX (Data Analysis Expressions) Reference Guide',
      provider: 'Microsoft Learn',
      url: 'https://learn.microsoft.com/en-us/dax/',
      cost: 'Free',
      isVerified: true,
      type: 'Official Guide',
    },
  ],
  Statistics: [
    {
      title: 'Statistics and Probability Course',
      provider: 'Khan Academy',
      url: 'https://www.khanacademy.org/math/statistics-probability',
      cost: 'Free',
      isVerified: true,
      type: 'Interactive Tutorial',
    },
  ],
  Pandas: [
    {
      title: 'Getting Started with Pandas (Official User Guide)',
      provider: 'NumFOCUS / Pandas Dev Team',
      url: 'https://pandas.pydata.org/docs/getting_started/index.html',
      cost: 'Free',
      isVerified: true,
      type: 'Documentation',
    },
  ],
  NumPy: [
    {
      title: 'NumPy Quickstart for Absolute Beginners',
      provider: 'NumPy Developers',
      url: 'https://numpy.org/doc/stable/user/absolute_beginners.html',
      cost: 'Free',
      isVerified: true,
      type: 'Documentation',
    },
  ],
  HTML: [
    {
      title: 'HTML: Structuring the Web (MDN Web Docs)',
      provider: 'Mozilla MDN Web Docs',
      url: 'https://developer.mozilla.org/en-US/docs/Learn/HTML',
      cost: 'Free',
      isVerified: true,
      type: 'Documentation',
    },
  ],
  CSS: [
    {
      title: 'CSS Layout, Flexbox & Responsive Design (MDN Web Docs)',
      provider: 'Mozilla MDN Web Docs',
      url: 'https://developer.mozilla.org/en-US/docs/Learn/CSS/CSS_layout',
      cost: 'Free',
      isVerified: true,
      type: 'Documentation',
    },
  ],
  JavaScript: [
    {
      title: 'The Modern JavaScript Tutorial',
      provider: 'JavaScript.info',
      url: 'https://javascript.info/',
      cost: 'Free',
      isVerified: true,
      type: 'Interactive Tutorial',
    },
    {
      title: 'JavaScript Reference & Interactive Guide (MDN Web Docs)',
      provider: 'Mozilla MDN Web Docs',
      url: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript',
      cost: 'Free',
      isVerified: true,
      type: 'Documentation',
    },
  ],
  React: [
    {
      title: 'React Quick Start & Core Concepts',
      provider: 'React Team / Meta Open Source',
      url: 'https://react.dev/learn',
      cost: 'Free',
      isVerified: true,
      type: 'Official Guide',
    },
  ],
  Git: [
    {
      title: 'Pro Git Book & Official CLI Documentation',
      provider: 'Git-SCM / Software Freedom Conservancy',
      url: 'https://git-scm.com/doc',
      cost: 'Free',
      isVerified: true,
      type: 'Documentation',
    },
  ],
  'Node.js': [
    {
      title: 'Node.js Official Getting Started & Guides',
      provider: 'OpenJS Foundation',
      url: 'https://nodejs.org/en/learn',
      cost: 'Free',
      isVerified: true,
      type: 'Documentation',
    },
  ],
  'REST API': [
    {
      title: 'HTTP Overview & REST API Design Guidelines',
      provider: 'Mozilla MDN Web Docs',
      url: 'https://developer.mozilla.org/en-US/docs/Web/HTTP/Overview',
      cost: 'Free',
      isVerified: true,
      type: 'Documentation',
    },
  ],
  Docker: [
    {
      title: 'Docker Official Getting Started Guide',
      provider: 'Docker Inc.',
      url: 'https://docs.docker.com/get-started/',
      cost: 'Free',
      isVerified: true,
      type: 'Official Guide',
    },
  ],
  Linux: [
    {
      title: 'Linux Fundamentals & Command Line Navigation',
      provider: 'Linux Journey',
      url: 'https://linuxjourney.com/',
      cost: 'Free',
      isVerified: true,
      type: 'Interactive Tutorial',
    },
  ],
  Kubernetes: [
    {
      title: 'Kubernetes Interactive Basics Tutorial',
      provider: 'Cloud Native Computing Foundation (CNCF)',
      url: 'https://kubernetes.io/docs/tutorials/kubernetes-basics/',
      cost: 'Free',
      isVerified: true,
      type: 'Interactive Tutorial',
    },
  ],
  'Machine Learning': [
    {
      title: 'Getting Started with Machine Learning in Scikit-Learn',
      provider: 'Scikit-learn Developers',
      url: 'https://scikit-learn.org/stable/getting_started.html',
      cost: 'Free',
      isVerified: true,
      type: 'Documentation',
    },
  ],
  Excel: [
    {
      title: 'Excel Video Training & Formula Tutorials',
      provider: 'Microsoft Support',
      url: 'https://support.microsoft.com/en-us/excel',
      cost: 'Free',
      isVerified: true,
      type: 'Official Guide',
    },
  ],
  Tableau: [
    {
      title: 'Tableau Official Guided Learning & Documentation',
      provider: 'Tableau (Salesforce)',
      url: 'https://www.tableau.com/learn',
      cost: 'Free',
      isVerified: true,
      type: 'Official Guide',
    },
  ],
};

/**
 * Returns verified learning resources for a skill name, or an empty list if unverified.
 */
export function getVerifiedResourcesForSkill(skillName: string): LearningResource[] {
  const canonical = canonicalizeSkill(skillName) || skillName;
  for (const [key, resources] of Object.entries(VERIFIED_SKILL_RESOURCES)) {
    if (areSkillsMatching(canonical, key) || key.toLowerCase() === canonical.toLowerCase()) {
      return resources;
    }
  }

  const sLower = skillName.toLowerCase();
  if (sLower.includes('data cleaning') || sLower.includes('pandas')) {
    return [...VERIFIED_SKILL_RESOURCES['Pandas'], ...VERIFIED_SKILL_RESOURCES['NumPy']];
  }
  if (sLower.includes('analytic') || sLower.includes('business')) {
    return [...VERIFIED_SKILL_RESOURCES['SQL'], ...VERIFIED_SKILL_RESOURCES['Power BI']];
  }
  if (sLower.includes('portfolio') || sLower.includes('capstone')) {
    return VERIFIED_SKILL_RESOURCES['Git'];
  }
  if (sLower.includes('resume') || sLower.includes('baseline')) {
    return VERIFIED_SKILL_RESOURCES['Python'];
  }
  if (sLower.includes('interview')) {
    return VERIFIED_SKILL_RESOURCES['SQL'];
  }
  if (sLower.includes('pipeline') || sLower.includes('application')) {
    return VERIFIED_SKILL_RESOURCES['Python'];
  }
  if (sLower.includes('frontend')) {
    return VERIFIED_SKILL_RESOURCES['React'];
  }
  if (sLower.includes('backend')) {
    return VERIFIED_SKILL_RESOURCES['Node.js'];
  }
  if (sLower.includes('ai') || sLower.includes('ml')) {
    return VERIFIED_SKILL_RESOURCES['Python'];
  }
  if (sLower.includes('devops')) {
    return VERIFIED_SKILL_RESOURCES['Docker'];
  }

  return [];
}

export type RoadmapTaskDefinition = Omit<RoadmapStage, 'id' | 'stepNumber' | 'status'> & {
  taskKey: string;
};

/**
 * Role-Specific Learning Sequence Templates organized into six meaningful phases:
 * A. Foundations
 * B. Core role-specific skills
 * C. Applied practice
 * D. Portfolio project
 * E. Resume and interview preparation
 * F. Job application preparation
 */
export const ROLE_ROADMAP_TEMPLATES: Record<string, RoadmapTaskDefinition[]> = {
  // =========================================================================
  // 1. DATA ANALYST
  // =========================================================================
  'data analyst': [
    // Phase A: Foundations
    {
      taskKey: 'da_excel_foundations',
      title: 'Spreadsheet & Data Analysis Foundations',
      skillName: 'Excel',
      phase: 'Foundations',
      currentLevel: 60,
      targetLevel: 85,
      estimatedTime: '6 hrs',
      goal: 'Master spreadsheet formulas, lookups, sorting, filtering, PivotTables, and visual summaries.',
      whyItMatters: 'Spreadsheets are the universal foundation for exploring raw business data, rapid calculations, and executive summaries.',
      conceptsToLearn: [
        'Data types, cell formatting, and tabular data hygiene',
        'Summary formulas (SUM, AVERAGE, COUNTIF, SUMIFS)',
        'Lookup functions (VLOOKUP, XLOOKUP, INDEX/MATCH)',
        'PivotTables and dynamic charts for multi-dimensional business summaries'
      ],
      learningModules: [
        { title: 'Tabular structure and data cleansing', completed: false, hours: '2.0h' },
        { title: 'Lookup and conditional aggregation formulas', completed: false, hours: '2.0h' },
        { title: 'PivotTables and executive chart summaries', completed: false, hours: '2.0h' }
      ],
      practiceTasks: ['Format a messy sales transaction export', 'Build a summary pivot table and chart showing regional sales'],
      suggestedProject: 'E-Commerce Sales Summary Sheet',
      practicalExercise: {
        title: 'Sales Data Cleansing & Pivot Analysis',
        task: 'Clean a raw CSV of sales transactions in Excel, resolve missing customer records, and build a PivotTable with a chart calculating revenue by product category.',
        completionCriteria: 'Workbook contains zero formula errors and accurately summarizes category revenue with dynamic PivotTables.'
      },
      completionCriteria: 'Clean sales dataset and generate an automated PivotTable summary with charts.'
    },
    {
      taskKey: 'da_sql_foundations',
      title: 'Relational Databases & SQL Query Fundamentals',
      skillName: 'SQL',
      phase: 'Foundations',
      currentLevel: 45,
      targetLevel: 80,
      estimatedTime: '8 hrs',
      goal: 'Understand relational database schemas and write foundational SELECT, WHERE, filtering, and JOIN queries.',
      whyItMatters: 'Over 85% of analytical data lives in relational databases; SQL is the primary language used to extract it.',
      conceptsToLearn: [
        'Relational schema design, primary keys, and foreign keys',
        'Basic query syntax: SELECT, FROM, WHERE, ORDER BY, LIMIT',
        'Filtering conditions with AND, OR, IN, BETWEEN, and LIKE',
        'Combining tables with INNER JOIN and LEFT JOIN'
      ],
      learningModules: [
        { title: 'Relational table structure and querying fundamentals', completed: false, hours: '2.5h' },
        { title: 'Filtering, sorting, and pattern matching', completed: false, hours: '2.5h' },
        { title: 'Joining multiple relational tables', completed: false, hours: '3.0h' }
      ],
      practiceTasks: ['Write 10 basic SELECT queries on sample database', 'Join customer and order tables'],
      suggestedProject: 'Retail Orders Relational Extraction',
      practicalExercise: {
        title: 'Two-Table Relational Join Query',
        task: 'Write an SQL query that joins customers and orders to find all active customers who placed an order in the last 90 days.',
        completionCriteria: 'Query executes with correct join conditions and returns only matched rows without duplicates.'
      },
      completionCriteria: 'Write working INNER and LEFT JOIN queries against a normalized multi-table database.'
    },
    {
      taskKey: 'da_python_fundamentals',
      title: 'Python Fundamentals for Data Analysis',
      skillName: 'Python',
      phase: 'Foundations',
      currentLevel: 40,
      targetLevel: 80,
      estimatedTime: '8 hrs',
      goal: 'Master Python syntax essentials needed for analytics: functions, lists, dictionaries, loops, and script execution.',
      whyItMatters: 'Python provides programmatic power to automate data workflows and parse datasets too large or complex for spreadsheets.',
      conceptsToLearn: [
        'Python variables, numeric and string operations, and type casting',
        'Data structures for analytics: lists, tuples, dictionaries, and sets',
        'Control flow (if/else, for-loops, while-loops, list comprehensions)',
        'Defining modular reusable functions and handling basic file imports'
      ],
      learningModules: [
        { title: 'Core data types and control structures', completed: false, hours: '2.5h' },
        { title: 'Collections, dictionaries, and list comprehensions', completed: false, hours: '2.5h' },
        { title: 'Functions, parameter passing, and file reading', completed: false, hours: '3.0h' }
      ],
      practiceTasks: ['Parse a text-based sales transaction record with a Python dictionary', 'Write a custom discount calculation function'],
      suggestedProject: 'Command-Line Transaction Processor',
      practicalExercise: {
        title: 'Dictionary & Function Sales Processor',
        task: 'Write a Python script defining a function that processes a list of order dictionaries, computes subtotal and applicable discounts, and returns aggregated totals.',
        completionCriteria: 'Script executes cleanly with zero syntax errors and accurately aggregates totals across test cases.'
      },
      completionCriteria: 'Write and execute a modular Python script using functions, loops, and dictionaries.'
    },

    // Phase B: Core Role-Specific Skills
    {
      taskKey: 'da_statistics_applied',
      title: 'Applied Statistics & Probability for Analytics',
      skillName: 'Statistics',
      phase: 'Core Role-Specific Skills',
      prerequisites: ['Excel'],
      currentLevel: 45,
      targetLevel: 75,
      estimatedTime: '8 hrs',
      goal: 'Learn descriptive statistics, probability distributions, variance, standard deviation, correlation, and introductory hypothesis testing.',
      whyItMatters: 'Allows you to defend findings scientifically, evaluate sample sizes, and avoid misleading conclusions in senior management presentations.',
      conceptsToLearn: [
        'Measures of central tendency (mean, median, mode) and dispersion (variance, std dev)',
        'Probability distributions (normal, binomial), z-scores, and sampling',
        'Correlation coefficients (Pearson, Spearman) vs causation traps',
        'Hypothesis testing foundations: Null hypothesis, p-values, two-sample t-tests, and A/B test evaluation'
      ],
      learningModules: [
        { title: 'Descriptive metrics and distribution analysis', completed: false, hours: '2.5h' },
        { title: 'Correlation, sampling, and probability theory', completed: false, hours: '2.5h' },
        { title: 'Hypothesis testing, significance, and p-values', completed: false, hours: '3.0h' }
      ],
      practiceTasks: ['Calculate mean, median, and standard deviation of revenue', 'Compute p-value and correlation for marketing test data'],
      suggestedProject: 'A/B Conversion Significance Report',
      practicalExercise: {
        title: 'A/B Test Significance Analysis',
        task: 'Evaluate two conversion rate samples from an e-commerce checkout experiment, state the null hypothesis, and calculate whether the uplift is statistically significant at alpha = 0.05.',
        completionCriteria: 'Correctly report p-value, decision rule, and business recommendation.'
      },
      completionCriteria: 'Correctly calculate p-value and explain statistical significance for a business experiment.'
    },
    {
      taskKey: 'da_sql_advanced',
      title: 'Advanced SQL, Aggregations, Subqueries & Window Functions',
      skillName: 'SQL',
      phase: 'Core Role-Specific Skills',
      prerequisites: ['SQL'],
      currentLevel: 40,
      targetLevel: 85,
      estimatedTime: '12 hrs',
      goal: 'Master Common Table Expressions (CTEs), subqueries, GROUP BY with HAVING, and analytical window functions.',
      whyItMatters: 'Advanced SQL with window functions is tested in technical placement rounds by companies like Deloitte, TCS, and TechNova.',
      conceptsToLearn: [
        'GROUP BY aggregations with HAVING filtering vs WHERE',
        'Subqueries (correlated and non-correlated) and CTEs (WITH clause)',
        'Ranking window functions (ROW_NUMBER, RANK, DENSE_RANK)',
        'Offset functions (LEAD, LAG) for period-over-period comparisons'
      ],
      learningModules: [
        { title: 'Aggregation grouping and conditional HAVING logic', completed: false, hours: '3.0h' },
        { title: 'Multi-step queries with Common Table Expressions (CTEs)', completed: false, hours: '4.0h' },
        { title: 'Analytical window functions and running calculations', completed: false, hours: '5.0h' }
      ],
      practiceTasks: ['Solve 15 medium LeetCode/HackerRank SQL challenges', 'Write month-over-month revenue delta queries'],
      suggestedProject: 'Cohort Retention Query Suite',
      practicalExercise: {
        title: 'Customer Retention & Cohort Window Analysis',
        task: 'Write a SQL query using CTEs and LAG() to compute the monthly customer retention rate and revenue change for a subscription dataset.',
        completionCriteria: 'Query accurately calculates month-over-month deltas with zero syntax or join errors.'
      },
      completionCriteria: 'Successfully run a multi-CTE analytical query using window functions.'
    },
    {
      taskKey: 'da_python_pandas_eda',
      title: 'Python for Data Analysis: Pandas, NumPy & Data Cleaning',
      skillName: 'Data Cleaning',
      phase: 'Core Role-Specific Skills',
      prerequisites: ['Python'],
      currentLevel: 35,
      targetLevel: 80,
      estimatedTime: '10 hrs',
      goal: 'Clean raw data, manipulate DataFrames with Pandas, vectorize calculations with NumPy, and perform exploratory data analysis (EDA).',
      whyItMatters: 'Data analysts spend over 60% of their workflow preparing, cleaning, and exploring data before generating business reports.',
      conceptsToLearn: [
        'NumPy arrays, vectorization, and mathematical broadcasting',
        'Pandas Series, DataFrames, indexing, and Boolean filtering',
        'Data cleaning: imputing nulls, dropping duplicates, type coercion, string methods',
        'Exploratory data analysis (EDA): summary statistics, value_counts, groupby operations'
      ],
      learningModules: [
        { title: 'NumPy vectorized arrays and math fundamentals', completed: false, hours: '2.5h' },
        { title: 'Pandas DataFrames, filtering, and null cleansing', completed: false, hours: '3.5h' },
        { title: 'Exploratory aggregation and group operations', completed: false, hours: '4.0h' }
      ],
      practiceTasks: ['Clean a messy retail customer CSV with missing values', 'Compute group aggregations across customer cohorts'],
      suggestedProject: 'Automated CSV Cleansing & Profiling Pipeline',
      practicalExercise: {
        title: 'Pandas Data Cleaning & Exploratory Analysis',
        task: 'Load a raw customer churn CSV into Pandas, identify missing values, standardize date columns, remove outliers, and output summary descriptive metrics.',
        completionCriteria: 'Jupyter notebook or script cleans 100% of missing fields and outputs verified summary statistics without errors.'
      },
      completionCriteria: 'Build a repeatable Pandas pipeline that cleans raw tabular data and computes exploratory summary metrics.'
    },
    {
      taskKey: 'da_powerbi_modeling',
      title: 'Power BI: Power Query ETL & Star Schema Data Modeling',
      skillName: 'Power BI',
      phase: 'Core Role-Specific Skills',
      prerequisites: ['Excel', 'SQL'],
      currentLevel: 30,
      targetLevel: 75,
      estimatedTime: '8 hrs',
      goal: 'Connect to disparate data sources, cleanse records in Power Query, and build robust dimensional star schemas.',
      whyItMatters: 'Clean dimensional relationships (Fact and Dimension tables) prevent misleading data duplicates and enable lightning-fast business intelligence queries.',
      conceptsToLearn: [
        'Importing CSV, Excel, and SQL datasets into Power BI Desktop',
        'Power Query transformations: filtering, unpivoting, column splitting, and type handling',
        'Data modeling fundamentals: 1-to-many cardinality, cross-filter direction, and active relationships',
        'Designing clean star schemas: separating numerical Fact tables from categorical Dimension tables'
      ],
      learningModules: [
        { title: 'Data extraction and Power Query transformations', completed: false, hours: '2.5h' },
        { title: 'Table relationships, cardinalities, and filtering directions', completed: false, hours: '2.5h' },
        { title: 'Designing and validating star schemas', completed: false, hours: '3.0h' }
      ],
      practiceTasks: ['Import sales transactions and clean messy column names', 'Build a 4-table star schema with 1-to-many relationships'],
      suggestedProject: 'Retail Star Schema Data Model',
      practicalExercise: {
        title: 'Power Query Transformation & Star Schema Architecture',
        task: 'Extract raw multi-table sales records in Power BI, eliminate null rows using Power Query, and configure a verified star schema linking Sales Fact to Customers and Products Dimensions.',
        completionCriteria: 'Model diagram displays clean 1-to-many cardinalities with zero bidirectional ambiguities.'
      },
      completionCriteria: 'Successfully load raw datasets, transform them in Power Query, and configure a normalized star schema.'
    },
    {
      taskKey: 'da_powerbi_dax',
      title: 'Power BI: DAX Calculations & Interactive Dashboards',
      skillName: 'Power BI',
      phase: 'Core Role-Specific Skills',
      prerequisites: ['Power BI'],
      currentLevel: 35,
      targetLevel: 80,
      estimatedTime: '10 hrs',
      goal: 'Author essential DAX measures (CALCULATE, time intelligence) and assemble an interactive executive dashboard with slicers and drill-through pages.',
      whyItMatters: 'Interactive dashboards turn raw numbers into clear visual stories that business executives use daily to make hiring, sales, and investment decisions.',
      conceptsToLearn: [
        'Calculated columns vs DAX measures and when to use each',
        'Evaluating dynamic filter contexts using the CALCULATE function',
        'Time-intelligence DAX functions (TOTALYTD, SAMEPERIODLASTYEAR, DATEADD)',
        'Dashboard design: visual hierarchy, slicers, KPI metric cards, and drill-through investigation'
      ],
      learningModules: [
        { title: 'DAX measure syntax and CALCULATE filter context modifications', completed: false, hours: '3.5h' },
        { title: 'Time intelligence and period-over-period variance measures', completed: false, hours: '3.0h' },
        { title: 'Executive dashboard layout, visual formatting, and drill-throughs', completed: false, hours: '3.5h' }
      ],
      practiceTasks: ['Write 5 custom DAX measures for YTD sales and profit margins', 'Publish a 2-page dashboard with dynamic date slicers'],
      suggestedProject: 'Executive Sales Performance Dashboard',
      practicalExercise: {
        title: 'Executive Sales KPI Dashboard with CALCULATE Measures',
        task: 'Implement dynamic CALCULATE-based DAX measures for YoY revenue growth, profit margin %, and customer order count, and assemble an interactive dashboard with slicers and KPI summary cards.',
        completionCriteria: 'Dashboard dynamically recalibrates all measures upon slicer selection with verified DAX calculations and clean star schema.'
      },
      completionCriteria: 'Publish a functional interactive Power BI dashboard featuring custom CALCULATE measures and dynamic slicers.'
    },

    // Phase C: Applied Practice
    {
      taskKey: 'da_business_analytics',
      title: 'Business Analysis: Framing Questions, Defining KPIs & Storytelling',
      skillName: 'Business Analysis',
      phase: 'Applied Practice',
      prerequisites: ['SQL', 'Power BI'],
      currentLevel: 30,
      targetLevel: 80,
      estimatedTime: '10 hrs',
      goal: 'Translate business questions into KPIs, analyze trends and anomalies, interpret findings, and deliver evidence-based executive recommendations.',
      whyItMatters: 'Technical syntax alone does not make an analyst; companies hire candidates who understand business context and communicate ROI clearly.',
      conceptsToLearn: [
        'Translating ambiguous business questions into measurable analytical KPIs (CAC, LTV, Churn, Margin)',
        'Diagnosing trends, seasonality, and root causes behind sudden metric shifts',
        'Synthesizing data findings into executive summaries and structured briefs',
        'Communicating technical insights to non-technical business stakeholders'
      ],
      learningModules: [
        { title: 'Business problem framing and metric definition', completed: false, hours: '3.0h' },
        { title: 'SQL extraction and multi-metric aggregation', completed: false, hours: '4.0h' },
        { title: 'Synthesis into executive takeaways and recommendations', completed: false, hours: '3.0h' }
      ],
      practiceTasks: ['Analyze churn rates across customer segments', 'Draft a 1-page executive summary with recommendations'],
      suggestedProject: 'Customer Churn Root-Cause Analysis',
      practicalExercise: {
        title: 'Customer Churn Diagnostic Brief',
        task: 'Analyze customer subscription records using SQL and BI, identify the top two drivers of customer churn, and summarize the findings in a 1-page bulleted executive brief.',
        completionCriteria: 'Brief includes specific percentages, supporting charts, and concrete retention recommendations.'
      },
      completionCriteria: 'Complete an end-to-end business case study from raw SQL query to executive findings.'
    },

    // Phase D: Portfolio Project
    {
      taskKey: 'da_portfolio_capstone',
      title: 'End-to-End Analytics Capstone Project on GitHub',
      skillName: 'Portfolio Capstone',
      phase: 'Portfolio Project',
      prerequisites: ['SQL', 'Python', 'Power BI', 'Statistics'],
      currentLevel: 20,
      targetLevel: 85,
      estimatedTime: '16 hrs',
      goal: 'Build, document, and publish a comprehensive end-to-end analytics project combining Python/SQL data processing with an interactive dashboard and GitHub documentation.',
      whyItMatters: 'A public GitHub project with a real dataset, clean documentation, and a live dashboard sets you apart from hundreds of generic applicants.',
      conceptsToLearn: [
        'End-to-end analytical workflow: raw data, cleaning, modeling, insights',
        'GitHub repository organization and markdown documentation',
        'Creating clear architecture diagrams and data dictionaries',
        'Recording a concise 2-minute video or PDF walkthrough of findings'
      ],
      learningModules: [
        { title: 'Dataset curation and end-to-end data processing', completed: false, hours: '5.0h' },
        { title: 'Dashboard completion and storytelling polish', completed: false, hours: '5.0h' },
        { title: 'GitHub repository documentation and README showcase', completed: false, hours: '6.0h' }
      ],
      practiceTasks: ['Write comprehensive README.md', 'Publish dashboard link/screenshots on GitHub'],
      suggestedProject: 'Public Analytics Capstone Showcase',
      practicalExercise: {
        title: 'Publish Capstone Repository to GitHub',
        task: 'Publish your complete analysis to a public GitHub repository with an informative README, data dictionary, SQL scripts, Python analysis, and dashboard report screenshots.',
        completionCriteria: 'Repository is public and includes problem statement, dataset origin, findings, and setup instructions.'
      },
      completionCriteria: 'Publish a complete analytics project on GitHub with verified documentation and dashboard assets.'
    },

    // Phase E: Resume and Interview Preparation
    {
      taskKey: 'da_resume_alignment',
      title: 'Analytics Resume Optimization & Metric Bullets',
      skillName: 'Resume Scoring',
      phase: 'Resume and Interview Preparation',
      currentLevel: 70,
      targetLevel: 90,
      estimatedTime: '4 hrs',
      goal: 'Format technical projects using quantified impact metrics and align keywords with Data Analyst job descriptions.',
      whyItMatters: 'Recruiters and automated screening tools prioritize resumes with verifiable metrics and role-specific skills.',
      conceptsToLearn: [
        'ATS keyword alignment with Data Analyst requisitions',
        'Google X-Y-Z bullet formula: Accomplished [X] measured by [Y] by doing [Z]',
        'Highlighting SQL, Python, Power BI, Excel, and Capstone GitHub links cleanly',
        'Eliminating generic task descriptions in favor of business outcomes'
      ],
      learningModules: [
        { title: 'Target keyword audit for junior analyst roles', completed: false, hours: '2.0h' },
        { title: 'Rewriting project bullets with quantified metrics', completed: false, hours: '2.0h' }
      ],
      practiceTasks: ['Rewrite 3 resume bullet points with numbers', 'Verify clean single-page formatting'],
      suggestedProject: 'Tailored Data Analyst Single-Page Resume',
      practicalExercise: {
        title: 'Quantified Bullet Point Rewrite',
        task: 'Rewrite 3 project descriptions on your resume using the X-Y-Z formula, including exact metrics (e.g., analyzed 50K+ transactions, built 4-page dashboard).',
        completionCriteria: 'All 3 bullets contain measurable action verbs and specific metric outcomes.'
      },
      completionCriteria: 'Optimize resume with verified technical keywords and quantified project bullet points.'
    },
    {
      taskKey: 'da_interview_prep',
      title: 'Technical SQL & Analytics Case-Study Interview Prep',
      skillName: 'Interview Readiness',
      phase: 'Resume and Interview Preparation',
      prerequisites: ['SQL', 'Power BI'],
      currentLevel: 50,
      targetLevel: 85,
      estimatedTime: '10 hrs',
      goal: 'Practice live SQL whiteboard queries, project explanation, business scenario interpretation, and behavioral STAR responses.',
      whyItMatters: 'Technical interviews evaluate your structured thinking, query accuracy, project depth, and clear verbal communication.',
      conceptsToLearn: [
        'Live SQL whiteboard problem solving: clarifying questions and handling edge cases',
        'Explaining portfolio projects and trade-offs convincingly to technical managers',
        'Business case decomposition (e.g., investigating a sudden metric drop)',
        'Behavioral STAR framework: Situation, Task, Action, Result'
      ],
      learningModules: [
        { title: 'Live coding SQL scenarios and edge-case handling', completed: false, hours: '4.0h' },
        { title: 'Explaining analytics projects and technical trade-offs', completed: false, hours: '3.0h' },
        { title: 'Business analytics scenario questions and STAR practice', completed: false, hours: '3.0h' }
      ],
      practiceTasks: ['Complete 2 mock technical interview sessions', 'Practice explaining DAX logic and SQL queries aloud'],
      suggestedProject: 'Interview Question Decomposition Sheet',
      practicalExercise: {
        title: 'Mock Technical Interview Session',
        task: 'Complete a full mock technical interview session covering live SQL queries and business metric questions in the Mock Interview module.',
        completionCriteria: 'Answer SQL questions accurately and structure behavioral answers using the STAR method.'
      },
      completionCriteria: 'Complete at least one full technical interview simulation with structured feedback review.'
    },

    // Phase F: Job Application Preparation
    {
      taskKey: 'da_job_applications',
      title: 'Targeted Analytics Job Applications & Pipeline Tracking',
      skillName: 'Application Pipeline',
      phase: 'Job Application Preparation',
      currentLevel: 25,
      targetLevel: 85,
      estimatedTime: 'Ongoing',
      goal: 'Research verified entry-level Data Analyst job openings, confirm eligibility requirements, and track active applications.',
      whyItMatters: 'Systematically tracking applications prevents missed follow-ups and helps you tailor outreach to verified requirements.',
      conceptsToLearn: [
        'Reviewing job descriptions to identify verified core requirements',
        'Tailoring technical application notes with direct GitHub capstone links',
        'Maintaining an organized application tracker with dates, contacts, and statuses',
        'Professional email follow-up etiquette after campus or online submissions'
      ],
      learningModules: [
        { title: 'Target employer research and qualification alignment', completed: false, hours: '2.0h' },
        { title: 'Application submission and tracking pipeline management', completed: false, hours: '3.0h' }
      ],
      practiceTasks: ['Shortlist 5 verified matching entry-level openings', 'Log applications in the Application Tracker'],
      suggestedProject: 'Application Pipeline & Follow-Up Tracker',
      practicalExercise: {
        title: 'Application Pipeline Setup',
        task: 'Shortlist 5 target companies hiring for junior analyst positions, review their listed qualifications, and log active applications in the tracker.',
        completionCriteria: 'Record at least 5 active applications with verified company names and role titles.'
      },
      completionCriteria: 'Shortlist and log at least 5 verified job applications matching your target profile.'
    }
  ],

  // =========================================================================
  // 2. FRONTEND DEVELOPER
  // =========================================================================
  'frontend developer': [
    // Phase A: Foundations
    {
      taskKey: 'fe_html_semantics',
      title: 'Semantic HTML & Document Accessibility',
      skillName: 'HTML',
      phase: 'Foundations',
      currentLevel: 65,
      targetLevel: 85,
      estimatedTime: '6 hrs',
      goal: 'Master HTML5 semantic elements, accessible forms, document hierarchy, and SEO basics.',
      whyItMatters: 'Clean semantic HTML is the foundation of accessible, performant, and search-friendly web interfaces.',
      conceptsToLearn: [
        'Semantic tags: main, section, article, nav, header, footer',
        'Accessible forms: labels, input types, fieldset, validation attributes',
        'Web accessibility (a11y) basics: ARIA labels and alt attributes',
        'Document structure, meta tags, and OpenGraph headers'
      ],
      learningModules: [
        { title: 'Semantic markup and visual structure', completed: false, hours: '2.0h' },
        { title: 'Accessible forms and input validation', completed: false, hours: '2.0h' },
        { title: 'Accessibility guidelines and testing', completed: false, hours: '2.0h' }
      ],
      practiceTasks: ['Build an accessible multi-input registration form', 'Audit HTML using browser accessibility tools'],
      suggestedProject: 'Accessible Product Registration Page',
      practicalExercise: {
        title: 'Accessible Semantic Form Construction',
        task: 'Build a semantic registration form with proper label associations, keyboard navigation, and client-side validation attributes.',
        completionCriteria: 'Form passes basic accessibility checks with 100% associated labels and keyboard navigation.'
      },
      completionCriteria: 'Build an accessible, semantic HTML form with full keyboard accessibility.'
    },
    {
      taskKey: 'fe_css_layouts',
      title: 'Modern CSS, Flexbox & Responsive Layouts',
      skillName: 'CSS',
      phase: 'Foundations',
      prerequisites: ['HTML'],
      currentLevel: 60,
      targetLevel: 85,
      estimatedTime: '8 hrs',
      goal: 'Master CSS box model, Flexbox, CSS Grid, custom variables, and responsive media queries.',
      whyItMatters: 'Every modern UI requires responsive design that adapts smoothly across mobile, tablet, and desktop screens.',
      conceptsToLearn: [
        'CSS box model: margin, border, padding, and box-sizing',
        'Flexbox: direction, justify-content, align-items, flex-wrap',
        'CSS Grid: grid-template-columns, gaps, auto-fit and minmax',
        'Mobile-first responsive media queries and CSS custom properties'
      ],
      learningModules: [
        { title: 'Box model and modern positioning fundamentals', completed: false, hours: '2.5h' },
        { title: 'Flexbox and CSS Grid layout mastery', completed: false, hours: '3.0h' },
        { title: 'Mobile-first responsive breakpoints', completed: false, hours: '2.5h' }
      ],
      practiceTasks: ['Build a 3-column responsive card grid', 'Implement a mobile navigation drawer'],
      suggestedProject: 'Responsive Portfolio Landing Page',
      practicalExercise: {
        title: 'Responsive Card Grid Layout',
        task: 'Construct a responsive multi-card product grid that seamlessly adjusts from 1 column on mobile to 3 columns on desktop using CSS Flexbox or Grid.',
        completionCriteria: 'Layout adapts cleanly across viewport widths from 320px to 1200px without horizontal scroll.'
      },
      completionCriteria: 'Implement a mobile-first responsive layout that renders cleanly across all screen sizes.'
    },

    // Phase B: Core Role-Specific Skills
    {
      taskKey: 'fe_js_core',
      title: 'JavaScript Core Syntax, Scope & DOM Manipulation',
      skillName: 'JavaScript',
      phase: 'Core Role-Specific Skills',
      prerequisites: ['HTML', 'CSS'],
      currentLevel: 50,
      targetLevel: 80,
      estimatedTime: '10 hrs',
      goal: 'Master JavaScript data structures, functional array methods, scope, closures, and DOM events.',
      whyItMatters: 'JavaScript powers all interactive browser behavior and is required for mastering any modern UI framework.',
      conceptsToLearn: [
        'Data types, let/const, arrow functions, and scope',
        'Array methods: map, filter, reduce, find, some, every',
        'Object destructuring, rest/spread operators, and immutability',
        'DOM selection, event listeners, and event bubbling'
      ],
      learningModules: [
        { title: 'JavaScript syntax, scope, and closures', completed: false, hours: '3.0h' },
        { title: 'Functional array manipulation and immutability', completed: false, hours: '3.5h' },
        { title: 'Interactive DOM manipulation and event delegation', completed: false, hours: '3.5h' }
      ],
      practiceTasks: ['Build an interactive dynamic task list', 'Implement search filtering on an array of objects'],
      suggestedProject: 'Interactive Filterable Task Board',
      practicalExercise: {
        title: 'Dynamic Filterable Item List',
        task: 'Write JavaScript code that dynamically filters and renders an array of items based on user input, using event listeners and array methods.',
        completionCriteria: 'Search input dynamically updates the displayed items without page reloads.'
      },
      completionCriteria: 'Build an interactive DOM application utilizing array methods and event listeners.'
    },
    {
      taskKey: 'fe_js_async',
      title: 'Modern JavaScript: Promises, Async/Await & Fetch API',
      skillName: 'JavaScript',
      phase: 'Core Role-Specific Skills',
      prerequisites: ['JavaScript'],
      currentLevel: 45,
      targetLevel: 80,
      estimatedTime: '10 hrs',
      goal: 'Understand asynchronous JavaScript, Promises, async/await, and fetching remote JSON APIs.',
      whyItMatters: 'Frontend developers continuously interact with REST APIs to display live backend data.',
      conceptsToLearn: [
        'JavaScript event loop, call stack, and asynchronous callback queue',
        'Promises: creation, .then() chaining, and .catch() error handling',
        'Async/await syntax, try/catch blocks, and network status checks',
        'Fetch API, HTTP methods, headers, and parsing JSON responses'
      ],
      learningModules: [
        { title: 'Event loop and Promise mechanics', completed: false, hours: '3.0h' },
        { title: 'Async/await syntax and error boundaries', completed: false, hours: '3.5h' },
        { title: 'HTTP requests with Fetch API and state handling', completed: false, hours: '3.5h' }
      ],
      practiceTasks: ['Fetch data from public REST API', 'Handle loading and error states gracefully'],
      suggestedProject: 'Live Weather or GitHub User Card App',
      practicalExercise: {
        title: 'REST API Fetcher with Loading & Error States',
        task: 'Build a script that fetches user profiles from a public API, displays an active loading spinner while fetching, and gracefully handles 404/network errors.',
        completionCriteria: 'Application renders data on success and user-friendly error messages on network failure.'
      },
      completionCriteria: 'Write working async/await fetch calls with complete loading and error handling.'
    },
    {
      taskKey: 'fe_react_fundamentals',
      title: 'React Fundamentals: JSX, Components & State',
      skillName: 'React',
      phase: 'Core Role-Specific Skills',
      prerequisites: ['JavaScript'],
      currentLevel: 40,
      targetLevel: 80,
      estimatedTime: '12 hrs',
      goal: 'Learn React component architecture, JSX syntax, props, useState, and controlled forms.',
      whyItMatters: 'React is the most demanded frontend UI library across software engineering and product companies.',
      conceptsToLearn: [
        'JSX syntax rules and embedding dynamic JavaScript expressions',
        'Functional components and passing data via props',
        'State management with the useState hook',
        'Controlled form inputs, form submission, and conditional rendering'
      ],
      learningModules: [
        { title: 'JSX and component architecture', completed: false, hours: '3.5h' },
        { title: 'Component props and state management with useState', completed: false, hours: '4.5h' },
        { title: 'Controlled inputs and conditional UI rendering', completed: false, hours: '4.0h' }
      ],
      practiceTasks: ['Create a multi-component interactive widget', 'Manage controlled inputs with useState'],
      suggestedProject: 'Interactive React Expense Tracker',
      practicalExercise: {
        title: 'Interactive React State Counter & Form',
        task: 'Build a React component with stateful inputs and an item list where users can add and delete entries, triggering clean re-renders.',
        completionCriteria: 'State updates immutably and child components render dynamically based on props.'
      },
      completionCriteria: 'Build an interactive React application with controlled inputs and stateful components.'
    },
    {
      taskKey: 'fe_react_hooks_architecture',
      title: 'React Hooks, Component Architecture & Context',
      skillName: 'React',
      phase: 'Core Role-Specific Skills',
      prerequisites: ['React'],
      currentLevel: 35,
      targetLevel: 80,
      estimatedTime: '12 hrs',
      goal: 'Master useEffect for side effects, custom hooks, component modularity, and React Context API.',
      whyItMatters: 'Professional React code relies on clean hook encapsulation and shared state to maintain scalable codebases.',
      conceptsToLearn: [
        'The useEffect hook: dependency arrays, mounting, and cleanup functions',
        'Creating reusable custom hooks (e.g., useFetch, useLocalStorage)',
        'React Context API for cross-component theme and user state',
        'Component composition patterns and performance memoization'
      ],
      learningModules: [
        { title: 'Side effects and lifecycle handling with useEffect', completed: false, hours: '4.0h' },
        { title: 'Authoring custom hooks for reusable logic', completed: false, hours: '4.0h' },
        { title: 'Global state management with Context API', completed: false, hours: '4.0h' }
      ],
      practiceTasks: ['Write a custom useDebounce or useFetch hook', 'Create a global theme provider using Context'],
      suggestedProject: 'Multi-Page React Dashboard with Context',
      practicalExercise: {
        title: 'Custom Hook & Context State Provider',
        task: 'Implement a custom useFetch hook that handles data, loading, and error states, and integrate it into a Context provider for global app access.',
        completionCriteria: 'Custom hook runs without memory leaks and updates consumers via Context.'
      },
      completionCriteria: 'Implement a custom React hook and manage shared application state with Context.'
    },

    // Phase C: Applied Practice
    {
      taskKey: 'fe_applied_integration',
      title: 'Applied Frontend App: Responsive Layout & API Integration',
      skillName: 'Applied Frontend',
      phase: 'Applied Practice',
      prerequisites: ['React', 'CSS'],
      currentLevel: 30,
      targetLevel: 80,
      estimatedTime: '10 hrs',
      goal: 'Build an end-to-end responsive React application consuming live data with full loading, error, and empty states.',
      whyItMatters: 'Demonstrates your ability to deliver production-quality user interfaces rather than isolated code exercises.',
      conceptsToLearn: [
        'Structuring modular React projects with feature folders',
        'Building responsive, polished navigation, headers, and footers',
        'Integrating client-side routing (React Router) for multi-view apps',
        'Handling edge states: skeleton loaders, zero-data views, and retry prompts'
      ],
      learningModules: [
        { title: 'Project architecture and route layout', completed: false, hours: '3.0h' },
        { title: 'API integration and skeleton state polish', completed: false, hours: '4.0h' },
        { title: 'Responsive cross-device testing and cleanup', completed: false, hours: '3.0h' }
      ],
      practiceTasks: ['Add client-side routing to a React app', 'Implement skeleton loading states'],
      suggestedProject: 'E-Commerce Catalog with Cart & Search',
      practicalExercise: {
        title: 'Responsive Multi-View Web App',
        task: 'Develop a 2-page React application that fetches product catalog data, allows filtering by category, and maintains shopping cart state across pages.',
        completionCriteria: 'Application runs smoothly on both desktop and mobile viewports with working navigation.'
      },
      completionCriteria: 'Deliver an integrated responsive React application with working routing and API data.'
    },

    // Phase D: Portfolio Project
    {
      taskKey: 'fe_portfolio_capstone',
      title: 'Production Frontend Capstone Web App & Deployment',
      skillName: 'Portfolio Capstone',
      phase: 'Portfolio Project',
      prerequisites: ['React', 'JavaScript', 'CSS'],
      currentLevel: 25,
      targetLevel: 85,
      estimatedTime: '16 hrs',
      goal: 'Build, deploy, and document an original production web application with a live URL and clean GitHub repository.',
      whyItMatters: 'A live deployed application that recruiters can click and inspect is the strongest evidence of frontend capability.',
      conceptsToLearn: [
        'Production web app build optimization with Vite/webpack',
        'Deployment to platforms like Vercel, Netlify, or Cloud Run',
        'Writing a comprehensive GitHub README with demo GIF and feature breakdown',
        'Code linting, formatting (ESLint/Prettier), and clean component architecture'
      ],
      learningModules: [
        { title: 'Capstone feature completion and user polish', completed: false, hours: '6.0h' },
        { title: 'Production build, deployment, and live hosting', completed: false, hours: '4.0h' },
        { title: 'GitHub README documentation and visual showcase', completed: false, hours: '6.0h' }
      ],
      practiceTasks: ['Deploy app to free hosting platform', 'Write structured README.md with live link'],
      suggestedProject: 'Production SaaS Interface or Creative Tool',
      practicalExercise: {
        title: 'Deploy Capstone App & Publish Repo',
        task: 'Deploy your frontend capstone application to a live hosting service, verify production build assets, and link the live URL in your GitHub README.',
        completionCriteria: 'Live URL is accessible and GitHub repository includes architectural overview and setup instructions.'
      },
      completionCriteria: 'Publish a deployed live React application with a complete public GitHub repository.'
    },

    // Phase E: Resume and Interview Preparation
    {
      taskKey: 'fe_resume_alignment',
      title: 'Frontend Resume Alignment & Project Showcases',
      skillName: 'Resume Scoring',
      phase: 'Resume and Interview Preparation',
      currentLevel: 65,
      targetLevel: 90,
      estimatedTime: '4 hrs',
      goal: 'Format frontend project achievements with live demo URLs, modern stack keywords, and measurable impact.',
      whyItMatters: 'Ensures hiring managers immediately recognize your technical capabilities and can inspect your live work.',
      conceptsToLearn: [
        'Frontend ATS keywords: React, TypeScript, Responsive Design, REST APIs, Git',
        'Highlighting live deployed app URLs and GitHub profile prominently',
        'Quantifying project accomplishments (e.g. reduced load time, responsive support)',
        'Formatting a clean, single-page PDF resume with clear technical sections'
      ],
      learningModules: [
        { title: 'Frontend ATS keyword harmonization', completed: false, hours: '2.0h' },
        { title: 'Showcasing projects and verifiable repo links', completed: false, hours: '2.0h' }
      ],
      practiceTasks: ['Audit resume for modern frontend keywords', 'Add clickable live project links'],
      suggestedProject: 'Single-Page Frontend Developer Resume',
      practicalExercise: {
        title: 'Project Section Resume Polish',
        task: 'Rewrite the project section of your resume to prominently feature your capstone project with its tech stack, live URL, and specific technical contributions.',
        completionCriteria: 'Project entry clearly states role, stack, measurable deliverable, and public link.'
      },
      completionCriteria: 'Complete a tailored frontend developer resume with live links and verified keywords.'
    },
    {
      taskKey: 'fe_interview_prep',
      title: 'Frontend Technical & Coding Interview Preparation',
      skillName: 'Interview Readiness',
      phase: 'Resume and Interview Preparation',
      prerequisites: ['JavaScript', 'React'],
      currentLevel: 45,
      targetLevel: 85,
      estimatedTime: '10 hrs',
      goal: 'Practice live JavaScript problem solving, React mental model questions, and behavioral STAR stories.',
      whyItMatters: 'Frontend interviews routinely test DOM manipulation, async JavaScript, React re-render behavior, and communication.',
      conceptsToLearn: [
        'Live JavaScript coding: closures, array methods, debouncing, and throttling',
        'React concept deep dive: virtual DOM, component lifecycle, keys, and hooks rules',
        'CSS layout questions: centering elements, Flexbox vs Grid tradeoffs',
        'Behavioral STAR framework for technical teamwork and project delivery'
      ],
      learningModules: [
        { title: 'JavaScript live coding drills and algorithm practice', completed: false, hours: '4.0h' },
        { title: 'React architecture and interview question review', completed: false, hours: '3.0h' },
        { title: 'STAR behavioral response formulation', completed: false, hours: '3.0h' }
      ],
      practiceTasks: ['Implement a debounce function in JavaScript', 'Complete 2 mock technical interviews'],
      suggestedProject: 'Frontend Interview Concepts Cheat Sheet',
      practicalExercise: {
        title: 'Mock Frontend Technical Screening',
        task: 'Participate in a timed mock technical screening answering JavaScript and React concept questions with verbal explanations.',
        completionCriteria: 'Explain React re-render rules and solve live coding questions accurately.'
      },
      completionCriteria: 'Complete a mock frontend technical interview with constructive feedback review.'
    },

    // Phase F: Job Application Preparation
    {
      taskKey: 'fe_job_applications',
      title: 'Targeted Frontend Applications & Outreach',
      skillName: 'Application Pipeline',
      phase: 'Job Application Preparation',
      currentLevel: 25,
      targetLevel: 85,
      estimatedTime: 'Ongoing',
      goal: 'Identify verified junior frontend openings, verify prerequisite tech stacks, and maintain an application pipeline.',
      whyItMatters: 'Focusing on verified entry-level openings that match your React and JavaScript stack maximizes response rates.',
      conceptsToLearn: [
        'Screening job descriptions for matching tech stacks (HTML/CSS/JS/React)',
        'Attaching personalized portfolio links in application notes',
        'Tracking application statuses, recruiter contacts, and interview stages',
        'Professional networking and polite interview follow-up correspondence'
      ],
      learningModules: [
        { title: 'Requisition matching and employer shortlisting', completed: false, hours: '2.0h' },
        { title: 'Application pipeline tracking and follow-up cadence', completed: false, hours: '3.0h' }
      ],
      practiceTasks: ['Shortlist 5 verified entry-level frontend roles', 'Log applications in the tracker'],
      suggestedProject: 'Frontend Career Pipeline Tracker',
      practicalExercise: {
        title: 'Frontend Role Application Pipeline',
        task: 'Identify 5 target software companies hiring junior frontend developers, verify your profile alignment, and record submissions in the Application Tracker.',
        completionCriteria: 'Log at least 5 active applications with verified company names and job titles.'
      },
      completionCriteria: 'Submit and record at least 5 verified applications to target matching employers.'
    }
  ],

  // =========================================================================
  // 3. BACKEND DEVELOPER
  // =========================================================================
  'backend developer': [
    // Phase A: Foundations
    {
      taskKey: 'be_linux_git_foundations',
      title: 'Linux Command Line & Git Version Control',
      skillName: 'Linux',
      phase: 'Foundations',
      currentLevel: 55,
      targetLevel: 80,
      estimatedTime: '6 hrs',
      goal: 'Master Linux terminal navigation, file permissions, basic bash scripting, and Git collaborative workflows.',
      whyItMatters: 'Backend servers and cloud deployments run on Linux environments; Git is essential for all professional engineering.',
      conceptsToLearn: [
        'Terminal commands: navigation, file manipulation, grep, curl, and process management',
        'File permissions, environment variables, and SSH keys',
        'Git essentials: commits, branching, merging, and remote repository syncing',
        'Resolving Git merge conflicts and writing clean commit messages'
      ],
      learningModules: [
        { title: 'Linux file system and shell navigation', completed: false, hours: '2.0h' },
        { title: 'Process management and environment configuration', completed: false, hours: '2.0h' },
        { title: 'Git branching and collaborative workflows', completed: false, hours: '2.0h' }
      ],
      practiceTasks: ['Navigate Linux directories and grep log files', 'Create and merge a Git feature branch'],
      suggestedProject: 'CLI Automation Script',
      practicalExercise: {
        title: 'Bash Scripting & Git Feature Workflow',
        task: 'Write a simple bash script that automates log file inspection, and commit it to a feature branch on GitHub with a clean commit history.',
        completionCriteria: 'Script runs without errors and Git branch is merged cleanly into main.'
      },
      completionCriteria: 'Demonstrate Linux terminal competency and clean Git branching practices.'
    },
    {
      taskKey: 'be_programming_core',
      title: 'Backend Programming & Asynchronous I/O',
      skillName: 'Node.js',
      phase: 'Foundations',
      prerequisites: ['Linux'],
      currentLevel: 50,
      targetLevel: 80,
      estimatedTime: '8 hrs',
      goal: 'Master backend runtime fundamentals, asynchronous non-blocking I/O, event loops, and core data structures.',
      whyItMatters: 'Writing efficient, non-blocking backend code is required to handle concurrent requests under load.',
      conceptsToLearn: [
        'Runtime execution model: event loop, thread pool, and non-blocking I/O',
        'Working with the file system (fs) and streams',
        'Modular architecture: CommonJS vs ES Modules, npm package management',
        'Structured error handling and process exit handling'
      ],
      learningModules: [
        { title: 'Runtime architecture and event loop fundamentals', completed: false, hours: '2.5h' },
        { title: 'File streams and asynchronous data operations', completed: false, hours: '2.5h' },
        { title: 'Module organization and structured error handling', completed: false, hours: '3.0h' }
      ],
      practiceTasks: ['Read and parse a large log file asynchronously', 'Build a modular CLI utility'],
      suggestedProject: 'File Processing Utility',
      practicalExercise: {
        title: 'Asynchronous File Processing Script',
        task: 'Write a Node.js utility that reads a CSV dataset asynchronously using streams, computes summary statistics, and handles file not found errors.',
        completionCriteria: 'Script runs asynchronously with complete try/catch error handling.'
      },
      completionCriteria: 'Build an asynchronous backend utility demonstrating non-blocking I/O.'
    },

    // Phase B: Core Role-Specific Skills
    {
      taskKey: 'be_database_sql_design',
      title: 'Relational Database Design & SQL Architecture',
      skillName: 'SQL',
      phase: 'Core Role-Specific Skills',
      currentLevel: 45,
      targetLevel: 85,
      estimatedTime: '10 hrs',
      goal: 'Design normalized relational schemas, manage database migrations, and write high-performance SQL queries.',
      whyItMatters: 'Poor database design creates data corruption and severe latency bottlenecks across production systems.',
      conceptsToLearn: [
        'Database normalization: 1NF, 2NF, 3NF, and entity relationships',
        'Primary keys, foreign keys, constraints, and cascading deletes',
        'Indexes: B-Trees, unique indexes, and query execution plans (EXPLAIN)',
        'Database transactions (ACID properties, BEGIN/COMMIT/ROLLBACK)'
      ],
      learningModules: [
        { title: 'Relational schema design and normalization principles', completed: false, hours: '3.0h' },
        { title: 'Constraints, indexing strategies, and query performance', completed: false, hours: '3.5h' },
        { title: 'Transactions, ACID compliance, and concurrency', completed: false, hours: '3.5h' }
      ],
      practiceTasks: ['Design a normalized schema for an e-commerce platform', 'Analyze a query plan with EXPLAIN ANALYZE'],
      suggestedProject: 'Normalized E-Commerce Database Schema',
      practicalExercise: {
        title: 'Relational Schema Design & Migration',
        task: 'Design a 4-table normalized relational schema (Users, Orders, Items, Products) with foreign key constraints, indexes on lookup columns, and transactional order insertion.',
        completionCriteria: 'Schema enforces referential integrity and inserts orders inside a safe transaction.'
      },
      completionCriteria: 'Design a normalized database schema with verified foreign keys and index strategies.'
    },
    {
      taskKey: 'be_rest_api_architecture',
      title: 'RESTful API Architecture & Controller Design',
      skillName: 'REST API',
      phase: 'Core Role-Specific Skills',
      prerequisites: ['Node.js'],
      currentLevel: 40,
      targetLevel: 85,
      estimatedTime: '12 hrs',
      goal: 'Build modular REST APIs with Express, implementing standardized status codes, routing, and controller patterns.',
      whyItMatters: 'RESTful APIs are the primary communication layer between client applications and backend business logic.',
      conceptsToLearn: [
        'HTTP methods (GET, POST, PUT, PATCH, DELETE) and semantic status codes (200, 201, 400, 404, 500)',
        'Express framework setup, route parameters, and query strings',
        'Separation of concerns: routes, controllers, and services',
        'Request body parsing, input validation, and structured error responses'
      ],
      learningModules: [
        { title: 'REST principles and HTTP protocol semantics', completed: false, hours: '3.5h' },
        { title: 'Express routing and controller architecture', completed: false, hours: '4.5h' },
        { title: 'Input validation and centralized error middleware', completed: false, hours: '4.0h' }
      ],
      practiceTasks: ['Build full CRUD endpoints for a resource', 'Implement request validation middleware'],
      suggestedProject: 'Modular REST API for Resource Management',
      practicalExercise: {
        title: 'CRUD REST API with Controller Pattern',
        task: 'Build a modular Express REST API implementing CRUD operations for a resource, returning accurate HTTP status codes and handling invalid payloads.',
        completionCriteria: 'All endpoints adhere to REST conventions and return proper JSON error structures on invalid inputs.'
      },
      completionCriteria: 'Construct a complete CRUD REST API following clean architectural patterns.'
    },
    {
      taskKey: 'be_auth_security',
      title: 'Authentication, Middleware & API Security',
      skillName: 'REST API',
      phase: 'Core Role-Specific Skills',
      prerequisites: ['REST API'],
      currentLevel: 35,
      targetLevel: 80,
      estimatedTime: '10 hrs',
      goal: 'Implement secure user authentication with password hashing, JWT access tokens, and security middleware.',
      whyItMatters: 'Security and access control are critical non-negotiable requirements for all production backend systems.',
      conceptsToLearn: [
        'Password security: one-way salting and hashing with bcrypt',
        'Stateless authentication with JSON Web Tokens (JWT)',
        'Authentication and authorization middleware for protected routes',
        'API security fundamentals: CORS, rate limiting, and SQL injection prevention'
      ],
      learningModules: [
        { title: 'Password hashing and credential verification', completed: false, hours: '3.0h' },
        { title: 'JWT token signing, verification, and route protection', completed: false, hours: '3.5h' },
        { title: 'CORS, input sanitization, and security hardening', completed: false, hours: '3.5h' }
      ],
      practiceTasks: ['Implement JWT login and registration flow', 'Create middleware guarding private endpoints'],
      suggestedProject: 'Secure Authentication Microservice',
      practicalExercise: {
        title: 'JWT Authentication Flow with Protected Routes',
        task: 'Implement user registration with bcrypt password hashing, login returning a signed JWT, and an authorization middleware guarding private endpoints.',
        completionCriteria: 'Unauthenticated requests to protected endpoints return 401 Unauthorized.'
      },
      completionCriteria: 'Implement a secure authentication system with verified JWT token protection.'
    },
    {
      taskKey: 'be_docker_containers',
      title: 'Docker Containerization & Multi-Service Environments',
      skillName: 'Docker',
      phase: 'Core Role-Specific Skills',
      prerequisites: ['Linux'],
      currentLevel: 30,
      targetLevel: 80,
      estimatedTime: '8 hrs',
      goal: 'Containerize backend applications with Dockerfiles and manage multi-container environments with docker-compose.',
      whyItMatters: 'Docker guarantees that applications run identically in local development, testing, and production servers.',
      conceptsToLearn: [
        'Containerization vs virtualization concepts',
        'Writing production Dockerfiles: base images, layers, and caching',
        'Container lifecycle: build, run, stop, ports, and environment variables',
        'docker-compose orchestration linking an API to a PostgreSQL/MySQL database'
      ],
      learningModules: [
        { title: 'Docker image architecture and Dockerfile optimization', completed: false, hours: '2.5h' },
        { title: 'Container networking, ports, and volumes', completed: false, hours: '2.5h' },
        { title: 'Multi-container orchestration with docker-compose', completed: false, hours: '3.0h' }
      ],
      practiceTasks: ['Containerize an Express API with Dockerfile', 'Spin up API + PostgreSQL using docker-compose'],
      suggestedProject: 'Containerized API & Database Stack',
      practicalExercise: {
        title: 'Multi-Container Backend with Docker Compose',
        task: 'Create a Dockerfile for your backend application and a docker-compose.yml file that launches both the backend container and a PostgreSQL database.',
        completionCriteria: '`docker-compose up` starts both services and the API connects successfully to the database.'
      },
      completionCriteria: 'Containerize a backend service and run it alongside a database with Docker Compose.'
    },

    // Phase C: Applied Practice
    {
      taskKey: 'be_applied_integration',
      title: 'Applied Service Integration & Automated Testing',
      skillName: 'Applied Backend',
      phase: 'Applied Practice',
      prerequisites: ['REST API', 'SQL', 'Docker'],
      currentLevel: 25,
      targetLevel: 80,
      estimatedTime: '10 hrs',
      goal: 'Build an integrated backend service with automated integration tests, input validation, and database persistence.',
      whyItMatters: 'Automated tests ensure backend logic remains dependable when features are added and updated.',
      conceptsToLearn: [
        'Writing unit and integration tests for API endpoints with Node test runner or Jest',
        'Database seeding and test isolation strategies',
        'API documentation with OpenAPI / Swagger specifications',
        'Centralized configuration management with dotenv and environment validation'
      ],
      learningModules: [
        { title: 'Automated integration testing for HTTP routes', completed: false, hours: '3.5h' },
        { title: 'Database test fixture setup and teardown', completed: false, hours: '3.5h' },
        { title: 'API documentation with OpenAPI specification', completed: false, hours: '3.0h' }
      ],
      practiceTasks: ['Write integration tests verifying status codes', 'Document API endpoints with OpenAPI'],
      suggestedProject: 'Fully Tested REST Microservice',
      practicalExercise: {
        title: 'Automated API Test Suite',
        task: 'Write automated integration tests covering positive and negative test cases for your REST API endpoints, verifying status codes and response bodies.',
        completionCriteria: 'Test suite executes cleanly and verifies expected behavior on invalid payloads.'
      },
      completionCriteria: 'Implement an automated test suite verifying endpoint contracts and database persistence.'
    },

    // Phase D: Portfolio Project
    {
      taskKey: 'be_portfolio_capstone',
      title: 'Production Backend API Capstone & Cloud Deployment',
      skillName: 'Portfolio Capstone',
      phase: 'Portfolio Project',
      prerequisites: ['REST API', 'SQL', 'Docker'],
      currentLevel: 20,
      targetLevel: 85,
      estimatedTime: '16 hrs',
      goal: 'Build, deploy, and document an original production REST API with database persistence and public GitHub repository.',
      whyItMatters: 'Proves complete engineering execution from architecture and schema to Dockerization and cloud deployment.',
      conceptsToLearn: [
        'Complete backend system design: schema, endpoints, authentication, and logging',
        'Deploying containerized services to cloud environments (e.g. Cloud Run, Render)',
        'GitHub repository polish: Postman collection, architectural diagram, and README',
        'Database connection pooling and production logging'
      ],
      learningModules: [
        { title: 'System implementation and database migration', completed: false, hours: '6.0h' },
        { title: 'Cloud deployment and container verification', completed: false, hours: '4.0h' },
        { title: 'Documentation, Postman collection, and GitHub showcase', completed: false, hours: '6.0h' }
      ],
      practiceTasks: ['Deploy containerized API to live cloud host', 'Publish Postman collection and README'],
      suggestedProject: 'Production Backend Microservice Capstone',
      practicalExercise: {
        title: 'Publish Deployed Backend Capstone',
        task: 'Deploy your containerized backend API to a public cloud URL, verify live health endpoints, and document API routes in your public GitHub repository.',
        completionCriteria: 'API responds to public HTTP requests and repository contains full schema and documentation.'
      },
      completionCriteria: 'Publish a deployed containerized backend API with complete GitHub documentation.'
    },

    // Phase E: Resume and Interview Preparation
    {
      taskKey: 'be_resume_alignment',
      title: 'Backend Resume Optimization & Technical Impact',
      skillName: 'Resume Scoring',
      phase: 'Resume and Interview Preparation',
      currentLevel: 65,
      targetLevel: 90,
      estimatedTime: '4 hrs',
      goal: 'Highlight backend architectural competencies, database optimizations, and API performance metrics.',
      whyItMatters: 'Engineering recruiters screen backend resumes for clear technical keywords, concurrency understanding, and measurable results.',
      conceptsToLearn: [
        'Backend ATS keywords: Node.js, SQL, REST APIs, Docker, Database Design, Git',
        'Describing system throughput, response times, and database optimization using metrics',
        'Showcasing live API URLs, Postman documentation, and public GitHub repos',
        'Eliminating generic statements in favor of verifiable technical specifications'
      ],
      learningModules: [
        { title: 'Backend keyword audit and requisition alignment', completed: false, hours: '2.0h' },
        { title: 'Formulating metric-driven architectural bullet points', completed: false, hours: '2.0h' }
      ],
      practiceTasks: ['Rewrite resume bullets with performance metrics', 'Add direct links to deployed API'],
      suggestedProject: 'Single-Page Backend Developer Resume',
      practicalExercise: {
        title: 'Backend Project Bullet Optimization',
        task: 'Rewrite your project descriptions to emphasize database architecture, API endpoint counts, authentication mechanisms, and deployment strategies.',
        completionCriteria: 'Project entries include exact technologies, architectural role, and verifiable metrics.'
      },
      completionCriteria: 'Complete a tailored backend developer resume highlighting system design and verified links.'
    },
    {
      taskKey: 'be_interview_prep',
      title: 'Backend System Design & Technical Interview Prep',
      skillName: 'Interview Readiness',
      phase: 'Resume and Interview Preparation',
      prerequisites: ['REST API', 'SQL'],
      currentLevel: 45,
      targetLevel: 85,
      estimatedTime: '10 hrs',
      goal: 'Practice relational schema design questions, REST API conventions, concurrency scenarios, and STAR behavioral answers.',
      whyItMatters: 'Backend interviews specifically probe how you model data, handle failures, and reason through system trade-offs.',
      conceptsToLearn: [
        'Database design interview scenarios (e.g., modeling a ride-sharing or notification system)',
        'REST principles, idempotency, caching, and HTTP status codes',
        'Debugging concurrency issues, deadlocks, and connection pooling',
        'Behavioral STAR framework for explaining architectural decisions and incidents'
      ],
      learningModules: [
        { title: 'Data modeling and system architecture whiteboard drills', completed: false, hours: '4.0h' },
        { title: 'API design, error handling, and concurrency scenarios', completed: false, hours: '3.0h' },
        { title: 'STAR behavioral response practice', completed: false, hours: '3.0h' }
      ],
      practiceTasks: ['Whiteboard a relational database for an ordering system', 'Complete 2 mock technical interviews'],
      suggestedProject: 'Backend Interview System Design Cheat Sheet',
      practicalExercise: {
        title: 'Mock Backend Technical Interview',
        task: 'Participate in a timed mock backend screening answering schema design, indexing, and API architecture questions with clear verbal justifications.',
        completionCriteria: 'Demonstrate sound schema modeling and articulate architectural trade-offs.'
      },
      completionCriteria: 'Complete a mock backend technical screening with structured feedback analysis.'
    },

    // Phase F: Job Application Preparation
    {
      taskKey: 'be_job_applications',
      title: 'Targeted Backend Job Applications & Outreach',
      skillName: 'Application Pipeline',
      phase: 'Job Application Preparation',
      currentLevel: 25,
      targetLevel: 85,
      estimatedTime: 'Ongoing',
      goal: 'Identify verified junior backend engineering openings, verify qualification criteria, and track active applications.',
      whyItMatters: 'Directing your applications toward companies hiring for your specific language and database stack yields the highest response rate.',
      conceptsToLearn: [
        'Evaluating backend job descriptions for core technology alignment',
        'Highlighting live API endpoints and GitHub repos in application notes',
        'Managing application pipelines with contact details, deadlines, and statuses',
        'Professional correspondence and post-interview technical follow-ups'
      ],
      learningModules: [
        { title: 'Target employer research and requisition alignment', completed: false, hours: '2.0h' },
        { title: 'Application pipeline tracking and follow-up cadence', completed: false, hours: '3.0h' }
      ],
      practiceTasks: ['Shortlist 5 verified entry-level backend roles', 'Record submissions in the tracker'],
      suggestedProject: 'Backend Application Pipeline Tracker',
      practicalExercise: {
        title: 'Backend Job Application Pipeline',
        task: 'Shortlist 5 software companies with verified entry-level backend openings matching your stack, verify your eligibility, and log active applications in the tracker.',
        completionCriteria: 'Record at least 5 active applications with verified company names and job titles.'
      },
      completionCriteria: 'Submit and log at least 5 verified applications to target backend employers.'
    }
  ],

  // =========================================================================
  // 4. AI ENGINEER
  // =========================================================================
  'ai engineer': [
    // Phase A: Foundations
    {
      taskKey: 'ai_python_foundations',
      title: 'Python Programming Foundations for AI',
      skillName: 'Python',
      phase: 'Foundations',
      currentLevel: 60,
      targetLevel: 85,
      estimatedTime: '8 hrs',
      goal: 'Master Python syntax, data structures, list comprehensions, object-oriented concepts, and virtual environments.',
      whyItMatters: 'Python is the foundational language of modern artificial intelligence, machine learning, and data science ecosystems.',
      conceptsToLearn: [
        'Python syntax, variable scoping, and function definitions',
        'Core data structures: lists, dictionaries, sets, and tuples',
        'Object-oriented programming: classes, methods, and encapsulation',
        'Virtual environments (venv) and dependency management with pip'
      ],
      learningModules: [
        { title: 'Python syntax and data structure fundamentals', completed: false, hours: '2.5h' },
        { title: 'Object-oriented programming and modular structure', completed: false, hours: '2.5h' },
        { title: 'Virtual environments and package dependency management', completed: false, hours: '3.0h' }
      ],
      practiceTasks: ['Write a class-based data processor in Python', 'Configure a virtual environment with pip requirements'],
      suggestedProject: 'Modular Data Processing Package',
      practicalExercise: {
        title: 'Modular Python Data Processor',
        task: 'Build a modular Python class that ingests, cleans, and summarizes a dataset, packaged inside an isolated virtual environment.',
        completionCriteria: 'Code executes cleanly with type hints and passes basic unit test assertions.'
      },
      completionCriteria: 'Build an object-oriented Python package running in a verified virtual environment.'
    },
    {
      taskKey: 'ai_math_statistics',
      title: 'Mathematics, Linear Algebra & Probability for AI',
      skillName: 'Statistics',
      phase: 'Foundations',
      prerequisites: ['Python'],
      currentLevel: 50,
      targetLevel: 80,
      estimatedTime: '8 hrs',
      goal: 'Learn vector and matrix operations, dot products, loss gradients, and probability basics.',
      whyItMatters: 'Neural networks and machine learning models fundamentally operate on matrix transformations and gradient optimization.',
      conceptsToLearn: [
        'Vectors, matrices, dot products, and matrix multiplication',
        'Gradients, partial derivatives, and gradient descent intuition',
        'Loss functions: Mean Squared Error (MSE), Cross-Entropy Loss',
        'Probability distributions, conditional probability, and Bayes theorem'
      ],
      learningModules: [
        { title: 'Linear algebra: vectors, matrices, and tensor operations', completed: false, hours: '3.0h' },
        { title: 'Calculus intuition: gradients, loss surfaces, and descent', completed: false, hours: '2.5h' },
        { title: 'Probability distributions and statistical expectation', completed: false, hours: '2.5h' }
      ],
      practiceTasks: ['Perform matrix multiplication using pure Python and NumPy', 'Compute gradient descent step manually'],
      suggestedProject: 'Gradient Descent Optimization Simulator',
      practicalExercise: {
        title: 'Manual Gradient Descent Step Implementation',
        task: 'Implement a single-variable gradient descent optimization step from scratch in Python to minimize a quadratic loss function.',
        completionCriteria: 'Script converges toward minimum across iterations without numeric overflow.'
      },
      completionCriteria: 'Implement manual gradient descent step demonstrating mathematical understanding.'
    },

    // Phase B: Core Role-Specific Skills
    {
      taskKey: 'ai_numerical_computing',
      title: 'Numerical Computing with NumPy & Pandas',
      skillName: 'Pandas',
      phase: 'Core Role-Specific Skills',
      prerequisites: ['Python'],
      currentLevel: 45,
      targetLevel: 85,
      estimatedTime: '10 hrs',
      goal: 'Master tensor manipulations with NumPy and feature engineering/cleansing with Pandas.',
      whyItMatters: 'All AI models require numerical tensor representations; Pandas and NumPy are standard tools for preprocessing.',
      conceptsToLearn: [
        'NumPy N-dimensional arrays (ndarrays), broadcasting, and vectorization',
        'Array slicing, indexing, reshaping, and linear algebra operations',
        'Pandas DataFrames: data ingestion, missing value imputation, and grouping',
        'Feature engineering: one-hot encoding, normalization, and scaling'
      ],
      learningModules: [
        { title: 'NumPy array vectorization and broadcasting mechanics', completed: false, hours: '3.0h' },
        { title: 'Pandas DataFrame data manipulation and cleansing', completed: false, hours: '3.5h' },
        { title: 'Feature scaling, transformation, and dataset splitting', completed: false, hours: '3.5h' }
      ],
      practiceTasks: ['Normalize high-dimensional matrix in NumPy', 'Build a Pandas preprocessing pipeline for model inputs'],
      suggestedProject: 'Automated Feature Preprocessing Pipeline',
      practicalExercise: {
        title: 'Data Preprocessing Pipeline with Pandas',
        task: 'Write a Pandas and NumPy preprocessing pipeline that handles null values, encodes categorical variables, and scales numerical features.',
        completionCriteria: 'Pipeline outputs pure numerical arrays ready for model training without data leaks.'
      },
      completionCriteria: 'Build a verified numerical data transformation pipeline using NumPy and Pandas.'
    },
    {
      taskKey: 'ai_machine_learning_core',
      title: 'Machine Learning Algorithms with Scikit-Learn',
      skillName: 'Machine Learning',
      phase: 'Core Role-Specific Skills',
      prerequisites: ['Python', 'Statistics'],
      currentLevel: 40,
      targetLevel: 85,
      estimatedTime: '12 hrs',
      goal: 'Train supervised and unsupervised models with Scikit-learn, evaluate metrics, and avoid data leakage.',
      whyItMatters: 'Classical machine learning remains the industry workhorse for tabular prediction, classification, and ranking.',
      conceptsToLearn: [
        'Supervised learning: Linear/Logistic Regression, Decision Trees, Random Forests',
        'Unsupervised learning: K-Means clustering and Dimensionality Reduction (PCA)',
        'Train/test splitting, cross-validation, and hyperparameter tuning',
        'Evaluation metrics: Accuracy, Precision, Recall, F1-Score, ROC-AUC'
      ],
      learningModules: [
        { title: 'Supervised classification and regression algorithms', completed: false, hours: '4.0h' },
        { title: 'Model evaluation, validation curves, and metric tradeoffs', completed: false, hours: '4.0h' },
        { title: 'Pipeline encapsulation and hyperparameter search', completed: false, hours: '4.0h' }
      ],
      practiceTasks: ['Train a RandomForest classifier on tabular dataset', 'Evaluate confusion matrix and ROC-AUC'],
      suggestedProject: 'Predictive Classifier & Performance Benchmark',
      practicalExercise: {
        title: 'Scikit-Learn Classifier & Metric Evaluation',
        task: 'Train a RandomForest classifier using Scikit-Learn pipelines, perform 5-fold cross-validation, and plot precision-recall and ROC curves.',
        completionCriteria: 'Pipeline avoids data leakage and produces verified test set evaluation metrics.'
      },
      completionCriteria: 'Train and validate a supervised machine learning model using Scikit-Learn pipelines.'
    },
    {
      taskKey: 'ai_neural_networks',
      title: 'Deep Learning & Neural Network Architectures',
      skillName: 'Machine Learning',
      phase: 'Core Role-Specific Skills',
      prerequisites: ['Machine Learning'],
      currentLevel: 30,
      targetLevel: 80,
      estimatedTime: '12 hrs',
      goal: 'Understand multi-layer perceptrons, backpropagation, activation functions, and deep learning architectures.',
      whyItMatters: 'Deep neural networks form the foundation of computer vision, NLP, and modern generative AI models.',
      conceptsToLearn: [
        'Artificial neurons: weights, biases, and activation functions (ReLU, Sigmoid, Softmax)',
        'Multi-layer perceptron (MLP) architecture and backpropagation intuition',
        'Overfitting prevention: dropout, regularization, and early stopping',
        'Introduction to transformer attention mechanisms and embeddings'
      ],
      learningModules: [
        { title: 'Neural network forward pass and activation functions', completed: false, hours: '4.0h' },
        { title: 'Backpropagation and optimization techniques', completed: false, hours: '4.0h' },
        { title: 'Transformer attention mechanism and embedding models', completed: false, hours: '4.0h' }
      ],
      practiceTasks: ['Build a multi-layer neural network classifier', 'Experiment with dropout regularization'],
      suggestedProject: 'Neural Network Classification Benchmark',
      practicalExercise: {
        title: 'Neural Network Architecture Construction',
        task: 'Build a deep learning classifier with multiple dense layers, ReLU activations, and dropout, and track validation loss across training epochs.',
        completionCriteria: 'Training converges and validation loss stabilizes without severe overfitting.'
      },
      completionCriteria: 'Construct and train a multi-layer neural network with proper validation monitoring.'
    },
    {
      taskKey: 'ai_genai_rag_architecture',
      title: 'Generative AI, Embeddings & RAG Architecture',
      skillName: 'AI Architecture',
      phase: 'Core Role-Specific Skills',
      prerequisites: ['Machine Learning', 'Python'],
      currentLevel: 25,
      targetLevel: 85,
      estimatedTime: '12 hrs',
      goal: 'Master prompt engineering, vector embeddings, similarity search, and Retrieval-Augmented Generation (RAG).',
      whyItMatters: 'RAG and LLM application development is the fastest-growing hiring requisition in modern software engineering.',
      conceptsToLearn: [
        'Large Language Model (LLM) APIs, tokenization, and temperature sampling',
        'Vector embeddings: cosine similarity, chunking strategies, and metadata',
        'Vector databases and similarity indexing for document search',
        'Retrieval-Augmented Generation (RAG) architecture: retrieve, augment, generate'
      ],
      learningModules: [
        { title: 'LLM APIs, prompt patterns, and structured outputs', completed: false, hours: '4.0h' },
        { title: 'Document chunking, vector embeddings, and search', completed: false, hours: '4.0h' },
        { title: 'End-to-end RAG architecture and hallucination guardrails', completed: false, hours: '4.0h' }
      ],
      practiceTasks: ['Generate vector embeddings for document collection', 'Build a basic RAG pipeline over documentation'],
      suggestedProject: 'RAG Knowledge Assistant over Technical Docs',
      practicalExercise: {
        title: 'RAG Knowledge Search Pipeline',
        task: 'Build a Python pipeline that chunks a set of markdown files, computes vector embeddings, and uses semantic search to answer user queries with citations.',
        completionCriteria: 'Pipeline retrieves top-k relevant chunks and returns accurate grounded answers.'
      },
      completionCriteria: 'Build a functional RAG pipeline utilizing document embeddings and semantic search.'
    },

    // Phase C: Applied Practice
    {
      taskKey: 'ai_applied_service',
      title: 'Applied AI Deployment: API Endpoint & Containerization',
      skillName: 'Applied AI',
      phase: 'Applied Practice',
      prerequisites: ['Python', 'Docker', 'Machine Learning'],
      currentLevel: 20,
      targetLevel: 80,
      estimatedTime: '10 hrs',
      goal: 'Deploy an AI model or RAG service as a containerized REST API with FastAPI and Docker.',
      whyItMatters: 'AI models provide business value only when deployed into production systems accessible by client applications.',
      conceptsToLearn: [
        'Building high-performance inference APIs with FastAPI and Pydantic',
        'Model loading and caching in memory to minimize request latency',
        'Containerizing the inference API with a production Dockerfile',
        'Handling timeout limits, rate limiting, and structured JSON responses'
      ],
      learningModules: [
        { title: 'FastAPI inference service and request schema validation', completed: false, hours: '3.5h' },
        { title: 'Model caching and latency optimization', completed: false, hours: '3.0h' },
        { title: 'Docker containerization and health checks', completed: false, hours: '3.5h' }
      ],
      practiceTasks: ['Create FastAPI endpoint returning model predictions', 'Package inference server inside Docker'],
      suggestedProject: 'Containerized AI Inference Microservice',
      practicalExercise: {
        title: 'FastAPI Model Inference Server in Docker',
        task: 'Wrap an AI model inside a FastAPI application with input schema validation, and package it in a Docker container that runs on port 8000.',
        completionCriteria: 'Sending a POST request to `/predict` returns accurate JSON predictions with <200ms latency.'
      },
      completionCriteria: 'Deploy a containerized FastAPI model inference endpoint with verified request validation.'
    },

    // Phase D: Portfolio Project
    {
      taskKey: 'ai_portfolio_capstone',
      title: 'End-to-End AI Engineering Capstone on GitHub',
      skillName: 'Portfolio Capstone',
      phase: 'Portfolio Project',
      prerequisites: ['Python', 'Machine Learning', 'Docker'],
      currentLevel: 20,
      targetLevel: 85,
      estimatedTime: '16 hrs',
      goal: 'Publish a documented AI engineering capstone project on GitHub with live inference or video walkthrough.',
      whyItMatters: 'Demonstrating an end-to-end AI project proves to recruiters that you can take an AI concept from data to production.',
      conceptsToLearn: [
        'End-to-end AI lifecycle: dataset preparation, model/RAG architecture, API serving',
        'Comprehensive documentation: architecture diagram, latency benchmarks, README',
        'Publishing reproducible evaluation notebooks and benchmark tables',
        'Clean code structure, modular package design, and GitHub release polish'
      ],
      learningModules: [
        { title: 'System implementation and pipeline integration', completed: false, hours: '6.0h' },
        { title: 'Performance benchmarks and evaluation metrics', completed: false, hours: '4.0h' },
        { title: 'GitHub repository documentation and showcase', completed: false, hours: '6.0h' }
      ],
      practiceTasks: ['Document architectural choices and evaluation metrics', 'Publish public GitHub repo'],
      suggestedProject: 'Production AI System Capstone',
      practicalExercise: {
        title: 'Publish AI Capstone Repository',
        task: 'Publish your complete AI application to a public GitHub repository with an architecture diagram, reproducible evaluation results, and API usage examples.',
        completionCriteria: 'Repository is public and includes detailed setup instructions and metric evaluations.'
      },
      completionCriteria: 'Publish a complete AI engineering project on GitHub with verified benchmarks and documentation.'
    },

    // Phase E: Resume and Interview Preparation
    {
      taskKey: 'ai_resume_alignment',
      title: 'AI Engineer Resume Alignment & Metrics Optimization',
      skillName: 'Resume Scoring',
      phase: 'Resume and Interview Preparation',
      currentLevel: 65,
      targetLevel: 90,
      estimatedTime: '4 hrs',
      goal: 'Format AI project achievements highlighting model accuracy, latency, dataset size, and engineering deliverables.',
      whyItMatters: 'AI hiring managers prioritize resumes showing genuine engineering execution over vague conceptual claims.',
      conceptsToLearn: [
        'AI engineering ATS keywords: Python, PyTorch/Scikit-Learn, Docker, RAG, Embeddings, FastAPI',
        'Quantifying project accomplishments with accuracy, F1-scores, and latency reductions',
        'Prominently featuring public GitHub repository and evaluation notebook links',
        'Formatting a concise, single-page resume with clear technical competencies'
      ],
      learningModules: [
        { title: 'AI requisition keyword audit and alignment', completed: false, hours: '2.0h' },
        { title: 'Writing metric-driven AI project descriptions', completed: false, hours: '2.0h' }
      ],
      practiceTasks: ['Audit resume for modern AI and ML keywords', 'Add quantified model metrics to project bullets'],
      suggestedProject: 'Single-Page AI Engineer Resume',
      practicalExercise: {
        title: 'AI Project Resume Bullet Polish',
        task: 'Rewrite project descriptions to emphasize the exact models used, dataset scale, evaluation metrics (accuracy/F1), and deployed API endpoints.',
        completionCriteria: 'Bullets include measurable numbers, tools, and direct GitHub links.'
      },
      completionCriteria: 'Complete a tailored AI engineer resume highlighting verified technical achievements.'
    },
    {
      taskKey: 'ai_interview_prep',
      title: 'AI Algorithmic & System Design Interview Preparation',
      skillName: 'Interview Readiness',
      phase: 'Resume and Interview Preparation',
      prerequisites: ['Python', 'Machine Learning'],
      currentLevel: 45,
      targetLevel: 85,
      estimatedTime: '10 hrs',
      goal: 'Practice ML theory questions, Python data structure coding, AI system design, and STAR behavioral answers.',
      whyItMatters: 'Technical AI interviews assess both your mathematical fundamentals and practical software engineering skill.',
      conceptsToLearn: [
        'Machine learning theory: bias-variance tradeoff, regularization, evaluation metrics',
        'AI system design: designing a recommendation system, RAG pipeline, or visual search',
        'Live Python coding: array manipulation, algorithm implementation, edge-case handling',
        'Behavioral STAR framework for explaining project setbacks and technical decisions'
      ],
      learningModules: [
        { title: 'ML theory and algorithm whiteboard drills', completed: false, hours: '4.0h' },
        { title: 'AI system design and scalable inference questions', completed: false, hours: '3.0h' },
        { title: 'STAR behavioral response practice', completed: false, hours: '3.0h' }
      ],
      practiceTasks: ['Explain RAG vs fine-tuning tradeoffs aloud', 'Complete 2 mock technical interviews'],
      suggestedProject: 'AI Technical Interview Decomposition Sheet',
      practicalExercise: {
        title: 'Mock AI Technical Interview',
        task: 'Participate in a timed mock technical screening answering machine learning theory, Python coding, and AI architecture scenario questions.',
        completionCriteria: 'Articulate ML mathematical concepts clearly and reason through system design tradeoffs.'
      },
      completionCriteria: 'Complete a mock AI engineering technical screening with constructive feedback analysis.'
    },

    // Phase F: Job Application Preparation
    {
      taskKey: 'ai_job_applications',
      title: 'Targeted AI Applications & Career Pipeline',
      skillName: 'Application Pipeline',
      phase: 'Job Application Preparation',
      currentLevel: 25,
      targetLevel: 85,
      estimatedTime: 'Ongoing',
      goal: 'Identify verified AI and ML engineering job openings matching your profile, verify requirements, and track applications.',
      whyItMatters: 'Systematically tracking applications ensures tailored submissions matching verified qualifications.',
      conceptsToLearn: [
        'Screening job descriptions for matching prerequisites (Python, ML, RAG/APIs)',
        'Highlighting live GitHub repos and evaluation notebooks in application cover notes',
        'Maintaining an organized application tracker with dates, contacts, and statuses',
        'Professional networking and polite follow-up correspondence'
      ],
      learningModules: [
        { title: 'Target employer research and requisition alignment', completed: false, hours: '2.0h' },
        { title: 'Application pipeline tracking and follow-up cadence', completed: false, hours: '3.0h' }
      ],
      practiceTasks: ['Shortlist 5 verified entry-level AI/ML roles', 'Record submissions in the tracker'],
      suggestedProject: 'AI Engineering Application Pipeline Tracker',
      practicalExercise: {
        title: 'AI Engineering Job Application Pipeline',
        task: 'Shortlist 5 software companies with verified entry-level AI or ML openings, check eligibility requirements, and record submissions in the tracker.',
        completionCriteria: 'Record at least 5 active applications with verified company names and role titles.'
      },
      completionCriteria: 'Submit and record at least 5 verified applications to target matching employers.'
    }
  ]
};

// Aliases for related roles so every track receives its own appropriate specialized sequence
ROLE_ROADMAP_TEMPLATES['full stack developer'] = [
  ...ROLE_ROADMAP_TEMPLATES['frontend developer'].slice(0, 4),
  ...ROLE_ROADMAP_TEMPLATES['backend developer'].slice(2, 6),
  ROLE_ROADMAP_TEMPLATES['backend developer'][6], // Applied Practice
  ROLE_ROADMAP_TEMPLATES['backend developer'][7], // Portfolio Project
  ROLE_ROADMAP_TEMPLATES['backend developer'][8], // Resume
  ROLE_ROADMAP_TEMPLATES['backend developer'][9], // Interview
  ROLE_ROADMAP_TEMPLATES['backend developer'][10] // Applications
];

ROLE_ROADMAP_TEMPLATES['ml engineer'] = [
  ROLE_ROADMAP_TEMPLATES['ai engineer'][0], // Python
  ROLE_ROADMAP_TEMPLATES['ai engineer'][1], // Math
  ROLE_ROADMAP_TEMPLATES['ai engineer'][2], // NumPy/Pandas
  ROLE_ROADMAP_TEMPLATES['ai engineer'][3], // Scikit-learn
  ROLE_ROADMAP_TEMPLATES['ai engineer'][4], // Neural networks
  ROLE_ROADMAP_TEMPLATES['backend developer'][5], // Docker
  ROLE_ROADMAP_TEMPLATES['ai engineer'][6], // Applied
  ROLE_ROADMAP_TEMPLATES['ai engineer'][7], // Portfolio
  ROLE_ROADMAP_TEMPLATES['ai engineer'][8], // Resume
  ROLE_ROADMAP_TEMPLATES['ai engineer'][9], // Interview
  ROLE_ROADMAP_TEMPLATES['ai engineer'][10] // Applications
];

ROLE_ROADMAP_TEMPLATES['data scientist'] = [
  ROLE_ROADMAP_TEMPLATES['ai engineer'][0], // Python
  ROLE_ROADMAP_TEMPLATES['data analyst'][1], // SQL
  ROLE_ROADMAP_TEMPLATES['data analyst'][2], // Advanced SQL
  ROLE_ROADMAP_TEMPLATES['ai engineer'][2], // Pandas
  ROLE_ROADMAP_TEMPLATES['data analyst'][5], // Statistics
  ROLE_ROADMAP_TEMPLATES['ai engineer'][3], // Scikit-learn
  ROLE_ROADMAP_TEMPLATES['data analyst'][6], // Applied business case
  ROLE_ROADMAP_TEMPLATES['data analyst'][7], // Portfolio
  ROLE_ROADMAP_TEMPLATES['data analyst'][8], // Resume
  ROLE_ROADMAP_TEMPLATES['data analyst'][9], // Interview
  ROLE_ROADMAP_TEMPLATES['data analyst'][10] // Applications
];

ROLE_ROADMAP_TEMPLATES['devops engineer'] = [
  ROLE_ROADMAP_TEMPLATES['backend developer'][0], // Linux/Git
  ROLE_ROADMAP_TEMPLATES['backend developer'][1], // Backend Programming
  ROLE_ROADMAP_TEMPLATES['backend developer'][5], // Docker
  {
    taskKey: 'devops_cicd_automation',
    title: 'CI/CD Pipeline Automation with GitHub Actions',
    skillName: 'Docker',
    phase: 'Core Role-Specific Skills',
    prerequisites: ['Linux', 'Docker'],
    currentLevel: 30,
    targetLevel: 80,
    estimatedTime: '8 hrs',
    goal: 'Build automated continuous integration and continuous deployment pipelines for automated testing and container publishing.',
    whyItMatters: 'Automated CI/CD pipelines eliminate human error and enable dependable software delivery.',
    conceptsToLearn: [
      'GitHub Actions syntax: workflows, jobs, steps, runners',
      'Automated linting and test execution on pull requests',
      'Building and pushing container images to container registries',
      'Managing encrypted repository secrets and environment variables'
    ],
    learningModules: [
      { title: 'Workflow structure and event triggers', completed: false, hours: '2.5h' },
      { title: 'Automated testing and container image building', completed: false, hours: '3.0h' },
      { title: 'Secret management and deployment triggers', completed: false, hours: '2.5h' }
    ],
    practiceTasks: ['Write GitHub Actions test workflow', 'Automate Docker container build on merge'],
    suggestedProject: 'Automated CI/CD Workflow Repository',
    practicalExercise: {
      title: 'GitHub Actions CI Pipeline',
      task: 'Create a GitHub Actions workflow in `.github/workflows/ci.yml` that checks out code, installs dependencies, and runs tests on push.',
      completionCriteria: 'Workflow runs and displays green checkmark in GitHub Actions tab.'
    },
    completionCriteria: 'Configure an automated CI workflow that tests code on every pull request.'
  },
  {
    taskKey: 'devops_kubernetes_basics',
    title: 'Container Orchestration with Kubernetes Fundamentals',
    skillName: 'Kubernetes',
    phase: 'Core Role-Specific Skills',
    prerequisites: ['Docker'],
    currentLevel: 25,
    targetLevel: 75,
    estimatedTime: '10 hrs',
    goal: 'Learn Kubernetes cluster architecture, Pods, Deployments, Services, and declarative YAML manifests.',
    whyItMatters: 'Kubernetes is the standard enterprise platform for running and scaling containerized cloud applications.',
    conceptsToLearn: [
      'Kubernetes architecture: control plane, worker nodes, and kubelet',
      'Declarative manifests: Pods, Deployments, and replica sets',
      'Networking with Services (ClusterIP, NodePort, LoadBalancer)',
      'ConfigMaps, Secrets, and rolling updates'
    ],
    learningModules: [
      { title: 'Cluster architecture and core resource concepts', completed: false, hours: '3.0h' },
      { title: 'Deployments, replicas, and zero-downtime updates', completed: false, hours: '3.5h' },
      { title: 'Services, internal networking, and configuration', completed: false, hours: '3.5h' }
    ],
    practiceTasks: ['Write a deployment manifest for a container', 'Expose deployment via a Kubernetes Service'],
    suggestedProject: 'Kubernetes Local Cluster Deployment',
    practicalExercise: {
      title: 'Kubernetes Deployment & Service Manifest',
      task: 'Write YAML manifests creating a 3-replica Deployment of your containerized application and expose it via a ClusterIP Service.',
      completionCriteria: 'Manifests apply cleanly and deploy 3 active running pods.'
    },
    completionCriteria: 'Write valid Kubernetes Deployment and Service manifests for a containerized app.'
  },
  ROLE_ROADMAP_TEMPLATES['backend developer'][6], // Applied Practice
  ROLE_ROADMAP_TEMPLATES['backend developer'][7], // Portfolio Project
  ROLE_ROADMAP_TEMPLATES['backend developer'][8], // Resume
  ROLE_ROADMAP_TEMPLATES['backend developer'][9], // Interview
  ROLE_ROADMAP_TEMPLATES['backend developer'][10] // Applications
];

/**
 * Generate or calibrate a personalized roadmap for a candidate's specific target role,
 * existing skills, diagnostic assessment results, and identified skill gaps.
 *
 * Enforces:
 * 1. Meaningful phases: Foundations, Core Skills, Applied Practice, Portfolio, Resume/Interview, Applications
 * 2. Concept-level, achievable tasks in a logical prerequisite order
 * 3. Personalization with actual student evidence (skills, assessment history, demonstrated proficiency)
 * 4. Exactly ONE unambiguous recommended next step ("In Progress" / "Learning Now")
 * 5. Preservation of genuinely matching completed tasks when recalibrating or switching roles
 * 6. Honest evidence-based eligibility criteria without fabricated guarantees
 */
export function generatePersonalizedRoadmap(
  targetRole: string,
  studentSkills: SkillItem[] = [],
  liveMarketGaps: string[] = [],
  existingStages: RoadmapStage[] = [],
  assessmentHistory: AssessmentHistoryItem[] = []
): RoadmapStage[] {
  const roleClean = (targetRole || 'data analyst').toLowerCase().trim();

  // Find best matching template key
  let templateKey = 'data analyst';
  if (roleClean.includes('devops') || roleClean.includes('cloud') || roleClean.includes('infrastructure')) {
    templateKey = 'devops engineer';
  } else if (roleClean.includes('data scientist') || roleClean.includes('data science')) {
    templateKey = 'data scientist';
  } else if (roleClean.includes('ml') || roleClean.includes('machine learning')) {
    templateKey = 'ml engineer';
  } else if (roleClean.includes('ai') || roleClean.includes('artificial intelligence')) {
    templateKey = 'ai engineer';
  } else if (roleClean.includes('full stack') || roleClean.includes('fullstack')) {
    templateKey = 'full stack developer';
  } else if (roleClean.includes('backend') || roleClean.includes('software engineer') || roleClean.includes('software developer')) {
    templateKey = 'backend developer';
  } else if (roleClean.includes('frontend') || roleClean.includes('web developer') || roleClean.includes('ui developer')) {
    templateKey = 'frontend developer';
  } else if (roleClean.includes('analyst') || roleClean.includes('data') || roleClean.includes('business')) {
    templateKey = 'data analyst';
  }

  const rawTemplate = ROLE_ROADMAP_TEMPLATES[templateKey] || ROLE_ROADMAP_TEMPLATES['data analyst'];

  // Map existing completed stage identities to preserve progress ONLY when genuinely matching!
  const previousStageMap = new Map<string, RoadmapStage>();
  const completedTaskKeys = new Set<string>();
  const completedTaskTitles = new Set<string>();
  const completedSkills = new Set<string>();
  const completedUniversalPhases = new Set<string>();

  (existingStages || []).forEach((s) => {
    if (s.id) previousStageMap.set(s.id, s);
    if (s.taskKey) previousStageMap.set(s.taskKey.toLowerCase(), s);
    if (s.skillName) previousStageMap.set(s.skillName.toLowerCase().trim(), s);
    if (s.status === 'Completed') {
      const lowerSkill = s.skillName.toLowerCase().trim();
      completedSkills.add(lowerSkill);
      const lowerTitle = s.title.toLowerCase().trim();

      // Check for matching task keys or specific skills
      if (lowerSkill === 'career baseline' || lowerTitle.includes('profile setup')) {
        completedUniversalPhases.add('baseline');
      }
      if (lowerSkill === 'skill diagnostics' || lowerTitle.includes('skill assessment')) {
        completedUniversalPhases.add('diagnostics');
      }
      if (lowerSkill === 'resume scoring' || lowerTitle.includes('resume')) {
        completedUniversalPhases.add('resume');
      }
      if (lowerSkill === 'interview readiness' || lowerTitle.includes('interview')) {
        completedUniversalPhases.add('interview');
      }
      if (lowerSkill === 'application pipeline' || lowerTitle.includes('application')) {
        completedUniversalPhases.add('applications');
      }
      if (s.taskKey) {
        completedTaskKeys.add(s.taskKey.toLowerCase());
      }
      if (s.title) {
        completedTaskTitles.add(s.title.toLowerCase().trim());
      }
    }
  });

  // Diagnostic assessment history is the authoritative record of demonstrated proficiency
  const assessedSkillsMap = new Map<string, number>();
  (assessmentHistory || []).forEach((item) => {
    if (item && item.skillName && typeof item.overallScore === 'number') {
      const lower = item.skillName.toLowerCase().trim();
      assessedSkillsMap.set(lower, item.overallScore);
      const canon = canonicalizeSkill(item.skillName);
      if (canon) assessedSkillsMap.set(canon.toLowerCase().trim(), item.overallScore);
    }

    if (item && item.categoryScores && typeof item.categoryScores === 'object') {
      Object.entries(item.categoryScores).forEach(([cat, score]) => {
        if (typeof score === 'number') {
          const lower = cat.toLowerCase().trim();
          assessedSkillsMap.set(lower, score);
          const canon = canonicalizeSkill(cat);
          if (canon) assessedSkillsMap.set(canon.toLowerCase().trim(), score);
        }
      });
    }
  });

  // Track skills demonstrated with verified high proficiency (>= 75% assessed or tested)
  // CRITICAL: A missing or unassessed skill must NOT be treated as demonstrated proficiency.
  const demonstratedSkills = new Set<string>();
  assessedSkillsMap.forEach((score, skillKey) => {
    if (score >= 75) {
      demonstratedSkills.add(skillKey);
    }
  });

  (studentSkills || []).forEach((sk) => {
    const sLower = sk.name.toLowerCase().trim();
    const canon = canonicalizeSkill(sk.name)?.toLowerCase().trim();
    const assessedScore = assessedSkillsMap.get(sLower) ?? (canon ? assessedSkillsMap.get(canon) : undefined);

    // If there is an assessment score, that score is authoritative:
    if (assessedScore !== undefined) {
      if (assessedScore >= 75) {
        demonstratedSkills.add(sLower);
        if (canon) demonstratedSkills.add(canon);
      } else {
        // Explicitly NOT demonstrated if assessed score is under 75%
        demonstratedSkills.delete(sLower);
        if (canon) demonstratedSkills.delete(canon);
      }
      return;
    }

    // Only treat as demonstrated if the skill was genuinely tested (has a valid non-empty lastTestedDate),
    // is not marked as Priority Gap or Needs Improvement, and has currentLevel >= 75.
    // Unassessed or unverified skills (currentLevel === 0, no test date, Priority Gap) are NEVER demonstrated.
    const isVerifiedTested = Boolean(sk.lastTestedDate && sk.lastTestedDate.trim() !== '' && sk.lastTestedDate !== 'Never');
    const isProficientStatus = sk.status === 'Good' || sk.status === 'Strong';
    if (isVerifiedTested && isProficientStatus && sk.currentLevel >= 75) {
      demonstratedSkills.add(sLower);
      if (canon) demonstratedSkills.add(canon);
    }
  });

  // Step 1: Preliminary creation of candidate stages with evidence evaluation
  const candidateStages: (RoadmapTaskDefinition & {
    id: string;
    stepNumber: number;
    targetRole: string;
    isPriorityGap: boolean;
    isAssessed: boolean;
    assessmentScore: number | null;
    isCompletedCandidate: boolean;
    learningResources: LearningResource[];
  })[] = rawTemplate.map((taskTpl, idx) => {
    const stepNumber = idx + 1;
    const stageId = `stage_${templateKey.replace(/\s+/g, '_')}_${stepNumber}`;
    const skillLower = taskTpl.skillName.toLowerCase().trim();
    const canonSkill = canonicalizeSkill(taskTpl.skillName)?.toLowerCase().trim();

    // Check student assessment evidence
    let isAssessed = false;
    let assessmentScore: number | null = null;
    if (assessedSkillsMap.has(skillLower)) {
      isAssessed = true;
      assessmentScore = assessedSkillsMap.get(skillLower)!;
    } else if (canonSkill && assessedSkillsMap.has(canonSkill)) {
      isAssessed = true;
      assessmentScore = assessedSkillsMap.get(canonSkill)!;
    }

    // Match student profile skill
    const matchingSkill = studentSkills.find((s) => areSkillsMatching(s.name, taskTpl.skillName));
    const currentLevel = isAssessed && assessmentScore !== null
      ? assessmentScore
      : matchingSkill?.currentLevel ?? taskTpl.currentLevel;

    // Check if this skill matches an identified live market gap or assessed deficiency
    const isPriorityGap =
      liveMarketGaps.some((g) => areSkillsMatching(g, taskTpl.skillName)) ||
      matchingSkill?.status === 'Priority Gap' ||
      matchingSkill?.status === 'Needs Improvement' ||
      (isAssessed && assessmentScore !== null && assessmentScore < (taskTpl.targetLevel || 75));

    // Genuine completion matching (never carry over completion between unrelated skills)
    const matchesPreviousKey =
      Boolean(taskTpl.taskKey && completedTaskKeys.has(taskTpl.taskKey.toLowerCase())) ||
      completedTaskTitles.has(taskTpl.title.toLowerCase().trim());
    const matchesPreviousSkill =
      (completedSkills.has(skillLower) || Boolean(canonSkill && completedSkills.has(canonSkill))) &&
      (!taskTpl.prerequisites || taskTpl.prerequisites.length === 0);
    const matchesUniversalPhase =
      (taskTpl.phase === 'Resume and Interview Preparation' && (completedUniversalPhases.has('resume') || completedUniversalPhases.has('interview'))) ||
      (taskTpl.phase === 'Job Application Preparation' && completedUniversalPhases.has('applications'));

    // Students should not have to relearn skills they have already demonstrated via assessment or verified proficiency.
    // Foundational / beginner tasks are skipped when proficiency is demonstrated (>= 75% or Strong/Good status).
    // Advanced/Core tasks are only skipped if the student scored mastery (>= 85%) on that specific skill.
    const isFoundational = taskTpl.phase === 'Foundations';
    const isCoreRoleSkill = taskTpl.phase === 'Core Role-Specific Skills';
    const hasDemonstratedSkill =
      demonstratedSkills.has(skillLower) || Boolean(canonSkill && demonstratedSkills.has(canonSkill));

    const hasDemonstratedProficiency =
      (isFoundational && hasDemonstratedSkill) ||
      (isCoreRoleSkill && isAssessed && (assessmentScore ?? 0) >= 85 && hasDemonstratedSkill);

    const isCompletedCandidate = Boolean(
      matchesPreviousKey ||
      matchesPreviousSkill ||
      matchesUniversalPhase ||
      hasDemonstratedProficiency
    );

    // Determine learning stage difficulty (Easy, Moderate, Hard)
    let difficulty: 'Easy' | 'Moderate' | 'Hard' = taskTpl.difficulty || 'Moderate';
    if (!taskTpl.difficulty) {
      if (taskTpl.phase === 'Foundations' || taskTpl.phase === 'Job Application Preparation') {
        difficulty = 'Easy';
      } else if (taskTpl.phase === 'Core Role-Specific Skills' || taskTpl.phase === 'Resume and Interview Preparation') {
        difficulty = 'Moderate';
      } else if (taskTpl.phase === 'Applied Practice' || taskTpl.phase === 'Portfolio Project') {
        difficulty = 'Hard';
      }
    }

    // Preserve baseline and validation tracking from previous roadmap or student skill records
    const prevStage = previousStageMap.get(stageId) || (taskTpl.taskKey ? previousStageMap.get(taskTpl.taskKey.toLowerCase()) : undefined);
    const baselineScore = prevStage?.baselineScore ?? matchingSkill?.baselineScore ?? (isAssessed ? assessmentScore : null);
    const validatedScore = prevStage?.validatedScore ?? matchingSkill?.validatedScore ?? null;
    const validationStatus = prevStage?.validationStatus ?? matchingSkill?.validationStatus ?? (validatedScore && validatedScore >= 75 ? 'passed' : 'unvalidated');
    const lastValidatedDate = prevStage?.lastValidatedDate ?? matchingSkill?.lastTestedDate ?? undefined;

    // Attach verified learning resources
    const verifiedResources =
      taskTpl.learningResources && taskTpl.learningResources.length > 0
        ? taskTpl.learningResources
        : getVerifiedResourcesForSkill(taskTpl.skillName);

    return {
      ...taskTpl,
      id: stageId,
      stepNumber,
      targetRole: targetRole || 'Data Analyst',
      currentLevel,
      isPriorityGap: Boolean(isPriorityGap),
      isAssessed,
      assessmentScore,
      isCompletedCandidate: isCompletedCandidate || validationStatus === 'passed',
      learningResources: verifiedResources,
      difficulty,
      baselineScore,
      validatedScore,
      validationStatus,
      lastValidatedDate,
    };
  });

  // Step 2: Enforce Prerequisite Ordering and EXACTLY ONE Current Next Step ("In Progress")
  const completedSkillsInRoadmap = new Set<string>();
  candidateStages.forEach((s) => {
    if (s.isCompletedCandidate) {
      completedSkillsInRoadmap.add(s.skillName.toLowerCase().trim());
      const canon = canonicalizeSkill(s.skillName);
      if (canon) completedSkillsInRoadmap.add(canon.toLowerCase().trim());
    }
  });

  // Check if foundational tasks are still incomplete in the candidate roadmap
  const hasIncompleteFoundations = candidateStages.some(
    (s) => s.phase === 'Foundations' && !s.isCompletedCandidate
  );

  let hasAssignedActiveNextStep = false;

  const finalizedStages: RoadmapStage[] = candidateStages.map((stage) => {
    if (stage.isCompletedCandidate) {
      return {
        ...stage,
        status: 'Completed' as const,
      };
    }

    // Check prerequisites:
    // A task is unblocked if all prerequisites are either:
    // 1) already completed in the roadmap, OR
    // 2) demonstrated by the student
    const prerequisitesMet =
      !stage.prerequisites ||
      stage.prerequisites.length === 0 ||
      stage.prerequisites.every((prereq) => {
        const prereqLower = prereq.toLowerCase().trim();
        const canonPrereq = canonicalizeSkill(prereq)?.toLowerCase().trim();
        return (
          completedSkillsInRoadmap.has(prereqLower) ||
          (canonPrereq && completedSkillsInRoadmap.has(canonPrereq)) ||
          demonstratedSkills.has(prereqLower) ||
          (canonPrereq && demonstratedSkills.has(canonPrereq))
        );
      });

    // Foundational tasks take absolute precedence: if foundational tasks remain incomplete,
    // do not designate a non-foundational task as In Progress (e.g. Power BI must not be selected).
    const canBeAssignedActive = prerequisitesMet && (!hasIncompleteFoundations || stage.phase === 'Foundations');

    // Designate EXACTLY ONE task as the current focus ("In Progress")
    if (!hasAssignedActiveNextStep && canBeAssignedActive) {
      hasAssignedActiveNextStep = true;
      return {
        ...stage,
        status: 'In Progress' as const,
      };
    }

    // All upcoming/subsequent tasks must be marked "Upcoming"
    return {
      ...stage,
      status: 'Upcoming' as const,
    };
  });

  // Fallback: If no task was assigned because of strict prerequisites, designate the first incomplete task
  if (!hasAssignedActiveNextStep) {
    const firstIncomplete = finalizedStages.find((s) => s.status !== 'Completed');
    if (firstIncomplete) {
      firstIncomplete.status = 'In Progress';
    }
  }

  return finalizedStages;
}

/**
 * Glossary of common technical terms with clear, beginner-friendly explanations.
 */
export const TECHNICAL_TERM_GLOSSARY: Record<string, string> = {
  dashboard: 'A visual screen with charts and metrics that helps people quickly understand patterns and performance.',
  dashboards: 'Visual screens with charts and metrics that help people quickly understand patterns and performance.',
  etl: 'Extract, Transform, Load — pulling raw data from different sources, cleaning it, and saving it ready for analysis.',
  'star schema': 'A clean way to organize database tables into central numbers (facts) and descriptive categories (dimensions).',
  dax: 'Data Analysis Expressions — custom formulas in Power BI for calculating sums, ratios, and business metrics.',
  ctes: 'Common Table Expressions — temporary named query blocks that break complex SQL queries into easy-to-read steps.',
  sql: 'Structured Query Language — a standard language used to find, filter, and extract data stored in databases.',
  excel: 'A spreadsheet program used to organize data into rows and columns and perform calculations.',
  spreadsheets: 'Grid-based tools like Excel or Google Sheets for calculating and managing tabular data.',
  'data cleaning': 'Finding and fixing missing values, incorrect formats, and duplicates so data is accurate.',
  statistics: 'Mathematical methods to find averages, patterns, probabilities, and trends in data.',
  api: 'Application Programming Interface — a secure bridge allowing two software applications to exchange data.',
  'rest api': 'A standard format for sending and receiving data over the web using simple HTTP requests.',
  docker: 'A tool that packages an app and everything it needs into a lightweight container that runs reliably anywhere.',
  container: 'An isolated software package containing code, libraries, and settings so an application runs anywhere.',
  containerization: 'Packaging an application and everything it needs into a portable container.',
  'ci/cd': 'Continuous Integration & Continuous Delivery — automated testing and publishing whenever code changes.',
  kubernetes: 'An orchestration tool that automatically runs, restarts, and scales application containers in the cloud.',
  rag: 'Retrieval-Augmented Generation — connecting an AI model to custom documents so it answers questions with real facts.',
  embeddings: 'Converting words or documents into numbers so AI models can measure similarity and find relevant information.',
  'machine learning': 'Teaching computers to learn patterns from examples instead of writing rigid rules by hand.',
  'neural network': 'A computer model inspired by the human brain that recognizes complex patterns in images, text, and data.',
  git: 'A version control tool that records every change made to your code so you can track history and collaborate.',
  linux: 'A widely-used open-source operating system that powers most web servers and cloud infrastructure.',
  'cohort calibration': 'Measuring learning progress against standard student cohort milestones.',
  dom: 'Document Object Model — the live tree of buttons, text, and elements on a web page that code can update.',
  react: 'A popular library for building interactive user interfaces from reusable components.',
  jsx: 'A syntax extension for JavaScript that lets you write HTML-like markup inside code.'
};

/**
 * Returns plain English explanations for any technical terms detected in the text or skill name.
 */
export function getPlainEnglishExplanations(text: string): { term: string; plainEnglish: string }[] {
  if (!text) return [];
  const lower = text.toLowerCase();
  const found: { term: string; plainEnglish: string }[] = [];
  const seen = new Set<string>();

  for (const [term, explanation] of Object.entries(TECHNICAL_TERM_GLOSSARY)) {
    const regex = new RegExp(`\\b${term}\\b`, 'i');
    if (regex.test(lower) && !seen.has(term)) {
      seen.add(term);
      found.push({
        term: term.toUpperCase() === term ? term : term.charAt(0).toUpperCase() + term.slice(1),
        plainEnglish: explanation
      });
    }
  }

  return found;
}

/**
 * Groups full roadmap tasks into exactly 5 beginner-friendly stages for the selected target role.
 * Preserves all underlying tasks, resources, exercises, and user progress.
 */
export function groupRoadmapIntoStages(
  stages: RoadmapStage[],
  targetRole: string = 'Data Analyst'
): SimpleRoadmapStageGroup[] {
  const roleClean = (targetRole || 'data analyst').toLowerCase().trim();

  let stageDefs: { title: string; shortDescription: string }[] = [];
  let assignTaskToStageNumber: (task: RoadmapStage, idx: number) => number;

  if (roleClean.includes('frontend') || roleClean.includes('web developer')) {
    stageDefs = [
      {
        title: 'Learn the basics',
        shortDescription: 'Web building blocks with semantic HTML and responsive CSS layouts.'
      },
      {
        title: 'Learn core web programming',
        shortDescription: 'Modern JavaScript syntax, browser interactions, and fetching data from APIs.'
      },
      {
        title: 'Turn designs into interactive products',
        shortDescription: 'React component architecture, state management, and real API integration.'
      },
      {
        title: 'Build a real project',
        shortDescription: 'Create and deploy a production-ready web application on GitHub.'
      },
      {
        title: 'Prepare for jobs',
        shortDescription: 'Resume refinement, coding interview practice, and job applications.'
      }
    ];
    assignTaskToStageNumber = (task) => {
      if (task.phase === 'Foundations') return 1;
      if (task.phase === 'Portfolio Project') return 4;
      if (task.phase === 'Resume and Interview Preparation' || task.phase === 'Job Application Preparation') return 5;
      if (task.skillName.toLowerCase().includes('javascript')) return 2;
      return 3;
    };
  } else if (roleClean.includes('backend') && !roleClean.includes('full stack')) {
    stageDefs = [
      {
        title: 'Learn the basics',
        shortDescription: 'Linux terminal navigation, Git version control, and server scripting.'
      },
      {
        title: 'Work with databases and APIs',
        shortDescription: 'Relational database design, SQL queries, and RESTful API endpoints.'
      },
      {
        title: 'Secure and containerize services',
        shortDescription: 'User authentication, security middleware, Docker, and automated testing.'
      },
      {
        title: 'Build a real project',
        shortDescription: 'Develop and deploy a complete production backend service.'
      },
      {
        title: 'Prepare for jobs',
        shortDescription: 'Resume refinement, system design interview prep, and job applications.'
      }
    ];
    assignTaskToStageNumber = (task) => {
      if (task.phase === 'Foundations') return 1;
      if (task.phase === 'Portfolio Project') return 4;
      if (task.phase === 'Resume and Interview Preparation' || task.phase === 'Job Application Preparation') return 5;
      const sLower = task.skillName.toLowerCase();
      const tLower = task.title.toLowerCase();
      if (sLower === 'sql' || (sLower.includes('api') && !tLower.includes('security') && !tLower.includes('authentication'))) return 2;
      return 3;
    };
  } else if (roleClean.includes('full stack') || roleClean.includes('fullstack')) {
    stageDefs = [
      {
        title: 'Learn the basics',
        shortDescription: 'Web page structure, responsive styling, and basic programming.'
      },
      {
        title: 'Build frontend & backend logic',
        shortDescription: 'Asynchronous JavaScript, database querying, and server endpoints.'
      },
      {
        title: 'Connect and containerize full stack services',
        shortDescription: 'Authentication, Docker containers, and full-stack service integration.'
      },
      {
        title: 'Build a real project',
        shortDescription: 'Develop and deploy an end-to-end full stack application.'
      },
      {
        title: 'Prepare for jobs',
        shortDescription: 'Full stack resume refinement, technical interview prep, and applications.'
      }
    ];
    assignTaskToStageNumber = (task) => {
      if (task.phase === 'Foundations' || task.taskKey === 'fe_js_core') return 1;
      if (task.phase === 'Portfolio Project') return 4;
      if (task.phase === 'Resume and Interview Preparation' || task.phase === 'Job Application Preparation') return 5;
      if (task.taskKey === 'fe_js_async' || task.taskKey === 'be_database_sql_design' || task.taskKey === 'be_rest_api_architecture') return 2;
      return 3;
    };
  } else if (roleClean.includes('ai') || roleClean.includes('artificial intelligence')) {
    stageDefs = [
      {
        title: 'Learn the basics',
        shortDescription: 'Python programming fundamentals and core math concepts for AI.'
      },
      {
        title: 'Work with data and machine learning',
        shortDescription: 'Data wrangling with Pandas and training classical machine learning models.'
      },
      {
        title: 'Build intelligent applications',
        shortDescription: 'Deep learning neural networks, Generative AI models, and API deployment.'
      },
      {
        title: 'Build a real project',
        shortDescription: 'Build and document an end-to-end intelligent AI system on GitHub.'
      },
      {
        title: 'Prepare for jobs',
        shortDescription: 'AI resume refinement, algorithmic interview prep, and job applications.'
      }
    ];
    assignTaskToStageNumber = (task) => {
      if (task.phase === 'Foundations') return 1;
      if (task.phase === 'Portfolio Project') return 4;
      if (task.phase === 'Resume and Interview Preparation' || task.phase === 'Job Application Preparation') return 5;
      const sLower = task.skillName.toLowerCase();
      const tLower = task.title.toLowerCase();
      if (sLower.includes('pandas') || tLower.includes('scikit-learn')) return 2;
      return 3;
    };
  } else if (roleClean.includes('ml') || roleClean.includes('machine learning')) {
    stageDefs = [
      {
        title: 'Learn the basics',
        shortDescription: 'Python programming and foundational mathematical principles.'
      },
      {
        title: 'Train and evaluate models',
        shortDescription: 'Feature engineering with Pandas and machine learning algorithms.'
      },
      {
        title: 'Package and deploy models',
        shortDescription: 'Deep learning architectures, Docker containerization, and model serving.'
      },
      {
        title: 'Build a real project',
        shortDescription: 'Build a production machine learning pipeline documented on GitHub.'
      },
      {
        title: 'Prepare for jobs',
        shortDescription: 'ML resume refinement, system design interview prep, and job applications.'
      }
    ];
    assignTaskToStageNumber = (task) => {
      if (task.phase === 'Foundations') return 1;
      if (task.phase === 'Portfolio Project') return 4;
      if (task.phase === 'Resume and Interview Preparation' || task.phase === 'Job Application Preparation') return 5;
      const sLower = task.skillName.toLowerCase();
      const tLower = task.title.toLowerCase();
      if (sLower.includes('pandas') || tLower.includes('scikit-learn')) return 2;
      return 3;
    };
  } else if (roleClean.includes('data scientist') || roleClean.includes('data science')) {
    stageDefs = [
      {
        title: 'Learn the basics',
        shortDescription: 'Python programming and relational database extraction with SQL.'
      },
      {
        title: 'Clean data and explore patterns',
        shortDescription: 'Advanced SQL aggregations, Pandas data wrangling, and statistical tests.'
      },
      {
        title: 'Train models and discover insights',
        shortDescription: 'Machine learning algorithms and solving realistic business case studies.'
      },
      {
        title: 'Build a real project',
        shortDescription: 'End-to-end data science capstone project documented on GitHub.'
      },
      {
        title: 'Prepare for jobs',
        shortDescription: 'Resume refinement, technical case interviews, and job applications.'
      }
    ];
    assignTaskToStageNumber = (task) => {
      if (task.phase === 'Foundations') return 1;
      if (task.phase === 'Portfolio Project') return 4;
      if (task.phase === 'Resume and Interview Preparation' || task.phase === 'Job Application Preparation') return 5;
      const sLower = task.skillName.toLowerCase();
      const tLower = task.title.toLowerCase();
      if (tLower.includes('advanced sql') || sLower.includes('pandas') || sLower.includes('statistics')) return 2;
      return 3;
    };
  } else if (roleClean.includes('devops') || roleClean.includes('cloud') || roleClean.includes('infrastructure')) {
    stageDefs = [
      {
        title: 'Learn the basics',
        shortDescription: 'Linux terminal commands, Git version control, and scripting basics.'
      },
      {
        title: 'Containerize applications',
        shortDescription: 'Packaging applications and dependencies into lightweight Docker containers.'
      },
      {
        title: 'Automate pipelines and orchestrate clusters',
        shortDescription: 'Continuous integration workflows, Kubernetes clusters, and testing.'
      },
      {
        title: 'Build a real project',
        shortDescription: 'Production cloud deployment infrastructure project documented on GitHub.'
      },
      {
        title: 'Prepare for jobs',
        shortDescription: 'DevOps resume refinement, infrastructure interviews, and job applications.'
      }
    ];
    assignTaskToStageNumber = (task) => {
      if (task.phase === 'Foundations') return 1;
      if (task.phase === 'Portfolio Project') return 4;
      if (task.phase === 'Resume and Interview Preparation' || task.phase === 'Job Application Preparation') return 5;
      if (task.taskKey === 'be_docker_containers' || (task.skillName.toLowerCase() === 'docker' && !task.title.toLowerCase().includes('ci/cd'))) return 2;
      return 3;
    };
  } else {
    // Default: Data Analyst
    stageDefs = [
      {
        title: 'Learn the basics',
        shortDescription: 'Spreadsheets, SQL, and other required foundations.'
      },
      {
        title: 'Learn to work with data',
        shortDescription: 'Data cleaning, analysis, statistics, and role-specific tools.'
      },
      {
        title: 'Turn data into insights',
        shortDescription: 'Visualization and dashboards.'
      },
      {
        title: 'Build a real project',
        shortDescription: 'Apply the skills to a practical problem.'
      },
      {
        title: 'Prepare for jobs',
        shortDescription: 'Resume, interviews, and applications.'
      }
    ];
    assignTaskToStageNumber = (task) => {
      if (task.phase === 'Foundations') return 1;
      if (task.phase === 'Portfolio Project') return 4;
      if (task.phase === 'Resume and Interview Preparation' || task.phase === 'Job Application Preparation') return 5;
      const tLower = task.title.toLowerCase();
      const sLower = task.skillName.toLowerCase();
      if (tLower.includes('advanced sql') || tLower.includes('pandas') || sLower.includes('data cleaning') || tLower.includes('statistics')) return 2;
      return 3;
    };
  }

  const buckets: RoadmapStage[][] = [[], [], [], [], []];
  stages.forEach((task, idx) => {
    let stageNum = assignTaskToStageNumber(task, idx);
    if (stageNum < 1) stageNum = 1;
    if (stageNum > 5) stageNum = 5;
    buckets[stageNum - 1].push(task);
  });

  return stageDefs.map((def, idx) => {
    const stageNumber = idx + 1;
    const tasks = buckets[idx];
    const completedCount = tasks.filter((t) => t.status === 'Completed').length;
    const totalCount = tasks.length;

    let status: 'Completed' | 'In Progress' | 'Not Started';
    if (totalCount > 0 && completedCount === totalCount) {
      status = 'Completed';
    } else if (tasks.some((t) => t.status === 'In Progress') || (completedCount > 0 && completedCount < totalCount)) {
      status = 'In Progress';
    } else {
      status = 'Not Started';
    }

    return {
      id: `stage_group_${stageNumber}`,
      stageNumber,
      title: def.title,
      shortDescription: def.shortDescription,
      status,
      tasks,
      completedCount,
      totalCount
    };
  });
}
