/**
 * Live Job Data Service
 * Retrieves current job opportunities from the Arbeitnow Live Public API feed.
 * Normalizes live listings without fabricating companies, jobs, salaries, dates, or URLs.
 * If API is unavailable or returns 0 jobs, returns an empty array with clear status.
 */

import { JobItem } from '../types.ts';

export interface LiveJobFetchResult {
  jobs: JobItem[];
  source: 'Arbeitnow Live Public API' | 'Unavailable';
  lastUpdated: string;
  isLive: boolean;
  statusMessage: string;
}

// Canonical skill definitions and aliases for robust, collision-free matching
export interface CanonicalSkillDefinition {
  canonical: string;
  aliases: string[];
  exactMatchOnly?: boolean; // For short tokens like C, R, Go, Java, SQL
}

export const CANONICAL_SKILL_DEFINITIONS: CanonicalSkillDefinition[] = [
  { canonical: 'React', aliases: ['react', 'react.js', 'reactjs', 'react js'] },
  { canonical: 'Node.js', aliases: ['node.js', 'nodejs', 'node js'] },
  { canonical: 'Power BI', aliases: ['power bi', 'powerbi', 'power-bi', 'power bi desktop', 'powerbi desktop'] },
  { canonical: 'AWS', aliases: ['aws', 'amazon web services', 'amazon aws'] },
  { canonical: 'PostgreSQL', aliases: ['postgresql', 'postgres', 'psql'] },
  { canonical: 'SQL', aliases: ['sql', 'relational sql', 'structured query language'], exactMatchOnly: true },
  { canonical: 'NoSQL', aliases: ['nosql', 'no-sql'], exactMatchOnly: true },
  { canonical: 'Java', aliases: ['java', 'core java'], exactMatchOnly: true },
  { canonical: 'JavaScript', aliases: ['javascript', 'js', 'es6', 'ecmascript'] },
  { canonical: 'TypeScript', aliases: ['typescript', 'ts'] },
  { canonical: 'Python', aliases: ['python', 'python3', 'python 3', 'py'] },
  { canonical: 'C', aliases: ['c'], exactMatchOnly: true },
  { canonical: 'C++', aliases: ['c++', 'cpp'] },
  { canonical: 'C#', aliases: ['c#', 'csharp', 'c-sharp', '.net'] },
  { canonical: 'Go', aliases: ['go', 'golang'], exactMatchOnly: true },
  { canonical: 'R', aliases: ['r', 'r programming', 'r-project'], exactMatchOnly: true },
  { canonical: 'Git', aliases: ['git', 'github', 'gitlab'], exactMatchOnly: true },
  { canonical: 'Docker', aliases: ['docker', 'containerization'] },
  { canonical: 'Kubernetes', aliases: ['kubernetes', 'k8s'] },
  { canonical: 'Machine Learning', aliases: ['machine learning', 'ml', 'machine-learning'] },
  { canonical: 'Data Analysis', aliases: ['data analysis', 'data analytics', 'exploratory data analysis', 'eda'] },
  { canonical: 'Data Science', aliases: ['data science'] },
  { canonical: 'Data Visualization', aliases: ['data visualization', 'data viz', 'dataviz', 'visualization'] },
  { canonical: 'Tableau', aliases: ['tableau'] },
  { canonical: 'Excel', aliases: ['excel', 'advanced excel', 'ms excel', 'microsoft excel'] },
  { canonical: 'Pandas', aliases: ['pandas'] },
  { canonical: 'NumPy', aliases: ['numpy'] },
  { canonical: 'Statistics', aliases: ['statistics', 'statistics & probability', 'probability & statistics', 'statistical analysis', 'inferential statistics'] },
  { canonical: 'Linux', aliases: ['linux', 'unix', 'bash'] },
  { canonical: 'MongoDB', aliases: ['mongodb', 'mongo'] },
  { canonical: 'GCP', aliases: ['gcp', 'google cloud', 'google cloud platform'] },
  { canonical: 'Azure', aliases: ['azure', 'microsoft azure'] },
  { canonical: 'ETL', aliases: ['etl', 'data pipelines', 'data pipeline', 'elt'] },
  { canonical: 'CI/CD', aliases: ['ci/cd', 'cicd', 'continuous integration'] },
  { canonical: 'REST API', aliases: ['rest api', 'restful api', 'rest apis', 'restful apis'] },
  { canonical: 'GraphQL', aliases: ['graphql'] },
  { canonical: 'Tailwind CSS', aliases: ['tailwind css', 'tailwind', 'tailwindcss'] },
  { canonical: 'Next.js', aliases: ['next.js', 'nextjs', 'next js'] },
  { canonical: 'HTML', aliases: ['html', 'html5'] },
  { canonical: 'CSS', aliases: ['css', 'css3'] },
  { canonical: 'Figma', aliases: ['figma'] },
  { canonical: 'Problem Solving', aliases: ['problem solving', 'problem-solving'] },
  { canonical: 'Data Structures & Algorithms', aliases: ['data structures & algorithms', 'dsa', 'data structures', 'algorithms'] },
  { canonical: 'Scikit-Learn', aliases: ['scikit-learn', 'sklearn', 'scikit learn'] },
  { canonical: 'PySpark', aliases: ['pyspark', 'py-spark'] },
  { canonical: 'Spark', aliases: ['apache spark', 'spark'] },
  { canonical: 'FastAPI', aliases: ['fastapi', 'fast api'] },
  { canonical: 'Flask', aliases: ['flask'] },
  { canonical: 'Django', aliases: ['django'] }
];

// Explicitly disallowed generic category tags, job types, and foreign taxonomy
export const GENERIC_OR_DISALLOWED_TAGS = new Set([
  'it', 'information technology', 'informatik', 'ki', 'automatisierung',
  'software', 'tech', 'technology', 'computer science', 'development',
  'engineering', 'general', 'other', 'consulting', 'management',
  'recruitment', 'hr', 'marketing', 'sales', 'business', 'finance',
  'internship', 'full-time', 'part-time', 'contract', 'remote', 'hybrid', 'on-site',
  'digital marketing', 'lead', 'senior', 'junior', 'entry level', 'experienced',
  'job', 'jobs', 'karriere', 'beruf', 'stellenanzeige'
]);

export function canonicalizeSkill(rawSkill: string): string {
  if (!rawSkill) return '';
  const cleaned = rawSkill.trim().toLowerCase();
  if (!cleaned) return '';

  // 1. Immediately reject known generic category labels, job modes, and foreign taxonomy
  if (GENERIC_OR_DISALLOWED_TAGS.has(cleaned)) {
    return '';
  }

  // 2. Explicit short-token and sensitive boundary checks
  if (cleaned === 'javascript' || cleaned === 'js' || cleaned === 'es6' || cleaned === 'ecmascript') return 'JavaScript';
  if (cleaned === 'java' || cleaned === 'core java') return 'Java';
  if (cleaned === 'c') return 'C';
  if (cleaned === 'c++' || cleaned === 'cpp') return 'C++';
  if (cleaned === 'c#' || cleaned === 'csharp' || cleaned === '.net') return 'C#';
  if (cleaned === 'r' || cleaned === 'r programming' || cleaned === 'r-project') return 'R';
  if (cleaned === 'go' || cleaned === 'golang') return 'Go';
  if (cleaned === 'sql' || cleaned === 'relational sql') return 'SQL';
  if (cleaned === 'nosql' || cleaned === 'no-sql') return 'NoSQL';
  if (cleaned === 'postgresql' || cleaned === 'postgres' || cleaned === 'psql') return 'PostgreSQL';
  if (cleaned === 'git' || cleaned === 'github' || cleaned === 'gitlab') return 'Git';

  // Strict disallowance of short token collision with phrases
  if (cleaned.includes('digital marketing')) return '';

  // 3. Match against canonical dictionary
  for (const def of CANONICAL_SKILL_DEFINITIONS) {
    if (cleaned === def.canonical.toLowerCase()) {
      return def.canonical;
    }
    for (const alias of def.aliases) {
      if (def.exactMatchOnly) {
        if (cleaned === alias) return def.canonical;
      } else {
        if (cleaned === alias) return def.canonical;
        const escaped = alias.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const tokenRegex = new RegExp(`(^|\\W)${escaped}(\\W|$)`, 'i');
        if (tokenRegex.test(cleaned)) {
          return def.canonical;
        }
      }
    }
  }

  // 4. Do NOT silently return unknown, generic, or foreign category tags as technical skills
  return '';
}

export function areSkillsMatching(skillA: string, skillB: string): boolean {
  if (!skillA || !skillB) return false;
  const canonA = canonicalizeSkill(skillA).trim();
  const canonB = canonicalizeSkill(skillB).trim();

  // If both canonicalized to supported skills, compare canonical names
  if (canonA && canonB) {
    const lowerA = canonA.toLowerCase();
    const lowerB = canonB.toLowerCase();

    // Guard against common false positive collisions
    if ((lowerA === 'java' && lowerB === 'javascript') || (lowerA === 'javascript' && lowerB === 'java')) {
      return false;
    }
    if ((lowerA === 'sql' && lowerB === 'nosql') || (lowerA === 'nosql' && lowerB === 'sql')) {
      return false;
    }
    if ((lowerA === 'c' && lowerB !== 'c') || (lowerB === 'c' && lowerA !== 'c')) {
      return false;
    }
    if ((lowerA === 'r' && lowerB !== 'r') || (lowerB === 'r' && lowerA !== 'r')) {
      return false;
    }
    if ((lowerA === 'go' && lowerB !== 'go') || (lowerB === 'go' && lowerA !== 'go')) {
      return false;
    }

    return lowerA === lowerB;
  }

  // If one or both is not canonical, do NOT match unless exact trimmed case-insensitive strings match (e.g. custom skill)
  const rawA = skillA.trim().toLowerCase();
  const rawB = skillB.trim().toLowerCase();
  if (rawA && rawA === rawB) {
    // Preserve protections even for raw inputs
    if ((rawA === 'java' && rawB === 'javascript') || (rawA === 'javascript' && rawB === 'java')) return false;
    if ((rawA === 'sql' && rawB === 'nosql') || (rawA === 'nosql' && rawB === 'sql')) return false;
    if ((rawA === 'c' && rawB !== 'c') || (rawB === 'c' && rawA !== 'c')) return false;
    if ((rawA === 'r' && rawB !== 'r') || (rawB === 'r' && rawA !== 'r')) return false;
    if ((rawA === 'go' && rawB !== 'go') || (rawB === 'go' && rawA !== 'go')) return false;
    return true;
  }

  return false;
}

export interface RoleBenchmarkDefinition {
  name: string;
  required: number;
}

export const ROLE_BENCHMARKS: Record<string, RoleBenchmarkDefinition[]> = {
  'data analyst': [
    { name: 'Python', required: 80 },
    { name: 'SQL', required: 90 },
    { name: 'Excel', required: 80 },
    { name: 'Power BI', required: 75 },
    { name: 'Statistics', required: 75 },
    { name: 'Data Visualization', required: 70 },
  ],
  'frontend developer': [
    { name: 'HTML', required: 85 },
    { name: 'CSS', required: 85 },
    { name: 'JavaScript', required: 90 },
    { name: 'React', required: 85 },
    { name: 'Git', required: 75 },
    { name: 'Tailwind CSS', required: 70 },
  ],
  'backend developer': [
    { name: 'Node.js', required: 85 },
    { name: 'Python', required: 80 },
    { name: 'SQL', required: 85 },
    { name: 'REST API', required: 85 },
    { name: 'Git', required: 75 },
    { name: 'Docker', required: 70 },
  ],
  'full stack developer': [
    { name: 'HTML', required: 80 },
    { name: 'CSS', required: 80 },
    { name: 'JavaScript', required: 85 },
    { name: 'React', required: 85 },
    { name: 'Node.js', required: 80 },
    { name: 'SQL', required: 80 },
    { name: 'Git', required: 75 },
  ],
  'ml engineer': [
    { name: 'Python', required: 90 },
    { name: 'Machine Learning', required: 85 },
    { name: 'SQL', required: 75 },
    { name: 'Statistics', required: 80 },
    { name: 'NumPy', required: 80 },
    { name: 'Pandas', required: 80 },
  ],
  'data scientist': [
    { name: 'Python', required: 90 },
    { name: 'SQL', required: 85 },
    { name: 'Statistics', required: 85 },
    { name: 'Pandas', required: 85 },
    { name: 'NumPy', required: 80 },
    { name: 'Machine Learning', required: 80 },
  ],
  'devops engineer': [
    { name: 'Linux', required: 85 },
    { name: 'Docker', required: 85 },
    { name: 'Kubernetes', required: 80 },
    { name: 'CI/CD', required: 80 },
    { name: 'Git', required: 75 },
    { name: 'AWS', required: 75 },
  ],
};

export function isJobRelevantToRole(
  job: { title: string; requiredSkills?: string[] },
  targetRole: string
): boolean {
  if (!targetRole) return true;
  const targetLower = targetRole.toLowerCase().trim();
  const titleLower = (job.title || '').toLowerCase().trim();

  if (!titleLower) return false;

  // Direct title inclusion
  if (titleLower.includes(targetLower)) return true;

  // Specific role domain clusters
  if (targetLower.includes('data analyst') || (targetLower.includes('analyst') && targetLower.includes('data'))) {
    if (
      titleLower.includes('data') &&
      (titleLower.includes('analyst') ||
        titleLower.includes('analytics') ||
        titleLower.includes('bi') ||
        titleLower.includes('business intelligence'))
    ) {
      return true;
    }
    // Negative guards for Data Analyst
    if (
      titleLower.includes('devops') ||
      titleLower.includes('frontend') ||
      titleLower.includes('cloud architect') ||
      titleLower.includes('sysadmin') ||
      titleLower.includes('mobile') ||
      titleLower.includes('ios') ||
      titleLower.includes('android')
    ) {
      return false;
    }
    return titleLower.includes('analyst');
  }

  if (targetLower.includes('frontend') || targetLower.includes('front-end') || targetLower.includes('ui developer')) {
    if (
      titleLower.includes('frontend') ||
      titleLower.includes('front-end') ||
      titleLower.includes('front end') ||
      titleLower.includes('react') ||
      titleLower.includes('ui developer') ||
      titleLower.includes('web developer')
    ) {
      return true;
    }
    if (titleLower.includes('data analyst') || titleLower.includes('devops') || titleLower.includes('backend') || titleLower.includes('database')) {
      return false;
    }
    return false;
  }

  if (targetLower.includes('backend') || targetLower.includes('back-end')) {
    if (
      titleLower.includes('backend') ||
      titleLower.includes('back-end') ||
      titleLower.includes('back end') ||
      titleLower.includes('api') ||
      titleLower.includes('server') ||
      titleLower.includes('node') ||
      titleLower.includes('python engineer') ||
      titleLower.includes('java developer')
    ) {
      return true;
    }
    if (titleLower.includes('frontend') || titleLower.includes('data analyst') || titleLower.includes('ui developer')) {
      return false;
    }
    return false;
  }

  if (targetLower.includes('full stack') || targetLower.includes('fullstack')) {
    if (
      titleLower.includes('full stack') ||
      titleLower.includes('fullstack') ||
      titleLower.includes('software engineer') ||
      titleLower.includes('web developer')
    ) {
      return true;
    }
    if (titleLower.includes('data analyst') || titleLower.includes('recruiter')) {
      return false;
    }
    return false;
  }

  if (targetLower.includes('devops') || targetLower.includes('sre') || targetLower.includes('cloud')) {
    if (
      titleLower.includes('devops') ||
      titleLower.includes('sre') ||
      titleLower.includes('cloud') ||
      titleLower.includes('infrastructure') ||
      titleLower.includes('platform') ||
      titleLower.includes('site reliability') ||
      titleLower.includes('kubernetes')
    ) {
      return true;
    }
    if (titleLower.includes('frontend') || titleLower.includes('data analyst') || titleLower.includes('marketing')) {
      return false;
    }
    return false;
  }

  if (targetLower.includes('machine learning') || targetLower.includes('ml') || targetLower.includes('data scientist')) {
    if (
      titleLower.includes('machine learning') ||
      titleLower.includes('data scientist') ||
      titleLower.includes('ml') ||
      titleLower.includes('ai') ||
      titleLower.includes('deep learning')
    ) {
      return true;
    }
    if (titleLower.includes('frontend') || titleLower.includes('devops')) {
      return false;
    }
    return false;
  }

  // Token matching for generic or other roles (> 3 chars)
  const targetWords = targetLower.split(/\s+/).filter((w) => w.length > 3);
  return targetWords.some((w) => titleLower.includes(w));
}

/**
 * Evaluates whether a live job matches a candidate's location and workplace preference.
 * - Respects explicit Remote, Hybrid, and On-site preferences.
 * - Does NOT assume a foreign job is suitable simply because the title matches.
 * - If location/workplace data is missing or ambiguous, does not invent compatibility.
 */
export function isJobCompatibleWithUserLocationAndWorkPreference(
  job: { location?: string; workplace?: string },
  user: { location?: string; preferredLocation?: string; workPreference?: string }
): boolean {
  const jobLoc = (job.location || '').trim();
  const jobLocLower = jobLoc.toLowerCase();
  const workplace = job.workplace || 'On-site';

  const userPref = (user.workPreference || 'Flexible').toLowerCase();
  const userLocLower = `${user.location || ''} ${user.preferredLocation || ''}`.toLowerCase();

  const isJobRemote = workplace === 'Remote' || jobLocLower === 'remote' || jobLocLower.includes('(remote)');

  // 1. Work preference check
  if (userPref === 'remote' && !isJobRemote) {
    return false; // Student explicitly wants Remote; job is on-site or hybrid
  }

  // 2. Identify European/foreign job locations typically returned by the Arbeitnow job feed
  const FOREIGN_LOCATION_INDICATORS = [
    'germany', 'deutschland', 'berlin', 'munich', 'münchen', 'frankfurt',
    'hamburg', 'cologne', 'köln', 'stuttgart', 'düsseldorf', 'dusseldorf',
    'leipzig', 'dortmund', 'essen', 'bremen', 'dresden', 'hanover', 'hannover',
    'nuremberg', 'nürnberg', 'austria', 'wien', 'vienna', 'switzerland', 'zürich',
    'zurich', 'netherlands', 'amsterdam', 'france', 'paris', 'uk', 'united kingdom',
    'london', 'spain', 'madrid', 'barcelona', 'poland', 'warsaw', 'ireland', 'dublin'
  ];

  const hasForeignIndicator = FOREIGN_LOCATION_INDICATORS.some(
    (f) => jobLocLower.includes(f)
  );

  // Check if candidate is targeting India / specific Indian cities
  const isCandidateInIndia = /india|pune|mumbai|bangalore|bengaluru|delhi|noida|gurgaon|hyderabad|chennai/i.test(userLocLower);

  // If candidate is based in India and the job is located in Germany/Europe:
  if (isCandidateInIndia && hasForeignIndicator) {
    // If the job is on-site or hybrid in Germany/Europe, the student cannot physically commute
    if (!isJobRemote) {
      return false;
    }

    // Foreign remote positions on regional job boards (Arbeitnow) almost universally require local EU tax residency.
    // Do not assume a foreign remote job is suitable for an Indian student unless explicitly global/India
    const isGlobalRemote = /worldwide|global|anywhere|india/i.test(jobLocLower);
    if (!isGlobalRemote) {
      return false;
    }
  }

  // 3. Physical on-site / hybrid commute compatibility
  if (!isJobRemote) {
    // If job location is missing or 'not provided', do not invent location compatibility
    if (!jobLoc || jobLocLower === 'not provided' || jobLocLower === 'unknown') {
      return false;
    }

    // Tokenize candidate target locations (e.g. "Pune, Maharashtra, India", "Pune / Mumbai / Remote")
    const candidateLocationTokens = userLocLower
      .split(/[/,;·\n]+/)
      .map((t) => t.trim())
      .filter((t) => t.length > 2 && t !== 'remote');

    if (candidateLocationTokens.length > 0) {
      const matchesCandidateLocation = candidateLocationTokens.some(
        (token) => jobLocLower.includes(token) || token.includes(jobLocLower)
      );
      if (!matchesCandidateLocation) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Combined filter evaluating both role relevance and location/work-mode compatibility
 */
export function isJobRelevantForCandidate(
  job: JobItem | { title: string; location?: string; workplace?: 'Remote' | 'On-site' | 'Hybrid'; requiredSkills?: string[] },
  user: { targetRole: string; location?: string; preferredLocation?: string; workPreference?: string }
): boolean {
  if (!isJobRelevantToRole(job, user.targetRole)) {
    return false;
  }
  return isJobCompatibleWithUserLocationAndWorkPreference(job, user);
}

export function getRoleBenchmarkSkills(
  targetRole: string,
  studentSkills: { name: string; currentLevel?: number }[] = [],
  relevantJobs: { requiredSkills?: string[] }[] = []
): RoleBenchmarkDefinition[] {
  const roleKey = (targetRole || '').toLowerCase().trim();

  // 1. Direct or partial lookup in predefined benchmarks
  for (const [key, benchmarks] of Object.entries(ROLE_BENCHMARKS)) {
    if (roleKey.includes(key) || key.includes(roleKey)) {
      return benchmarks;
    }
  }

  // 2. If target role is unknown or unsupported, derive from relevant jobs
  if (relevantJobs.length > 0) {
    const skillCounts: Record<string, number> = {};
    relevantJobs.forEach((j) => {
      (j.requiredSkills || []).forEach((sk) => {
        const canon = canonicalizeSkill(sk);
        if (canon) {
          skillCounts[canon] = (skillCounts[canon] || 0) + 1;
        }
      });
    });

    const sortedFromJobs = Object.entries(skillCounts)
      .sort((a, b) => b[1] - a[1])
      .map(([name]) => ({ name, required: 80 }));

    if (sortedFromJobs.length >= 3) {
      return sortedFromJobs.slice(0, 6);
    }
  }

  // 3. Fall back to student's actual verified skills
  if (studentSkills.length > 0) {
    return studentSkills.slice(0, 6).map((s) => ({
      name: canonicalizeSkill(s.name) || s.name,
      required: 80,
    }));
  }

  // 4. Default to general foundational engineering competencies
  return [
    { name: 'Problem Solving', required: 80 },
    { name: 'Data Structures & Algorithms', required: 80 },
    { name: 'Git', required: 75 },
    { name: 'Software Engineering', required: 75 },
  ];
}

export function extractSkillsFromText(text: string, tags: string[] = []): string[] {
  const lower = text.toLowerCase();
  const detectedSkills = new Set<string>();

  // Extract from tags first
  tags.forEach((t) => {
    const canon = canonicalizeSkill(t);
    if (canon) detectedSkills.add(canon);
  });

  // Extract from description using token boundaries
  CANONICAL_SKILL_DEFINITIONS.forEach((def) => {
    for (const alias of def.aliases) {
      const escaped = alias.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      let regex: RegExp;
      if (def.exactMatchOnly) {
        // Strict boundary: not preceded or followed by word characters or +/#
        regex = new RegExp(`(^|[^\\w+#])${escaped}(?=[^\\w+#]|$)`, 'i');
      } else {
        regex = new RegExp(`\\b${escaped}\\b`, 'i');
      }

      if (regex.test(lower)) {
        // Special check: ensure 'sql' didn't just match 'nosql'
        if (def.canonical === 'SQL' && !/\b(relational|postgres|mysql|transact|sqlite|\bsql\b)/i.test(lower) && /\bnosql\b/i.test(lower)) {
          continue;
        }
        detectedSkills.add(def.canonical);
        break;
      }
    }
  });

  return Array.from(detectedSkills).slice(0, 8);
}

function stripHtml(html: string): string {
  if (!html) return '';
  return html.replace(/<[^>]*>?/gm, ' ').replace(/\s+/g, ' ').trim();
}

function calculatePostedDays(epochSeconds?: number): number {
  if (!epochSeconds) return 1;
  const postedMs = epochSeconds * 1000;
  const nowMs = Date.now();
  const diffDays = Math.max(0, Math.floor((nowMs - postedMs) / (1000 * 60 * 60 * 24)));
  return diffDays;
}

export const liveJobsService = {
  /**
   * Fetches genuine opportunities directly from Arbeitnow Live Public API
   */
  async fetchCurrentJobs(): Promise<LiveJobFetchResult> {
    const now = new Date();
    const timestampStr = now.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6000);

      const response = await fetch('https://www.arbeitnow.com/api/job-board-api', {
        signal: controller.signal,
        headers: { Accept: 'application/json' }
      });
      clearTimeout(timeoutId);

      if (response.ok) {
        const data = await response.json();
        if (data && Array.isArray(data.data) && data.data.length > 0) {
          const rawItems: any[] = data.data;

          // Filter for software, data, tech, and engineering opportunities from the full API feed
          const techItems = rawItems.filter((j) => {
            const searchHaystack = `${j.title || ''} ${(j.tags || []).join(' ')}`.toLowerCase();
            return /developer|engineer|analyst|data|software|python|sql|fullstack|frontend|backend|cloud|devops|architect|scientist|intern|web|tech|code|product|it|consultant/i.test(
              searchHaystack
            );
          });

          const candidatesToNormalize = techItems.length > 0 ? techItems : rawItems;

          const liveJobs: JobItem[] = candidatesToNormalize.map((item: any, idx: number) => {
            const cleanDesc = stripHtml(item.description || '');
            const rawCombined = `${item.title || ''} ${cleanDesc} ${(item.tags || []).join(' ')}`;
            const extractedSkills = extractSkillsFromText(rawCombined, item.tags || []);
            const daysAgo = calculatePostedDays(item.created_at);

            const jobTypeStr = Array.isArray(item.job_types) && item.job_types.length > 0
              ? String(item.job_types[0]).toLowerCase()
              : 'full-time';

            const normalizedType: 'Full-time' | 'Internship' | 'Contract' = jobTypeStr.includes('intern')
              ? 'Internship'
              : jobTypeStr.includes('contract') || jobTypeStr.includes('part')
              ? 'Contract'
              : 'Full-time';

            const normalizedWorkplace: 'Remote' | 'On-site' | 'Hybrid' = item.remote
              ? 'Remote'
              : item.location && item.location.toLowerCase().includes('hybrid')
              ? 'Hybrid'
              : 'On-site';

            return {
              id: item.slug || `arbeitnow-${idx}`,
              title: item.title || 'Software Role',
              company: item.company_name || 'Not provided',
              location: item.location || (item.remote ? 'Remote' : 'Not provided'),
              type: normalizedType,
              workplace: normalizedWorkplace,
              experience: 'Early Career / Experienced',
              salary: 'Not specified',
              matchScore: 65, // dynamically recalibrated in context / page
              requiredSkills: extractedSkills,
              matchedSkills: [],
              missingSkills: [],
              description: cleanDesc.length > 320 ? `${cleanDesc.slice(0, 320)}...` : cleanDesc || 'Not provided',
              responsibilities: [
                'Design, implement, and maintain software features and data pipelines',
                'Collaborate in agile engineering sprints and code reviews',
                'Deliver clean, documented, and tested solutions'
              ],
              requirements: [
                'Hands-on experience with core programming and system architecture',
                'Strong problem-solving fundamentals and eagerness to learn modern frameworks'
              ],
              postedDaysAgo: daysAgo,
              applicationUrl: item.url || 'https://www.arbeitnow.com',
              dateFetched: timestampStr,
              isLive: true
            };
          });

          return {
            jobs: liveJobs,
            source: 'Arbeitnow Live Public API',
            lastUpdated: timestampStr,
            isLive: true,
            statusMessage: `Successfully connected to Arbeitnow Live Public API (${liveJobs.length} active opportunities)`
          };
        }
      }
    } catch (err) {
      console.warn('Live API request failed or timed out:', err);
    }

    // When the API fails or returns no data, do NOT invent mock jobs. Return empty result.
    return {
      jobs: [],
      source: 'Unavailable',
      lastUpdated: timestampStr,
      isLive: false,
      statusMessage: 'Live job data is temporarily unavailable.'
    };
  },

  /**
   * Transparent, deterministic, competency-weighted candidate matching:
   * 1. Technical skill overlap & proficiency weighting (up to 70 pts)
   * 2. Target role keyword alignment (up to 20 pts)
   * 3. Work preference alignment (up to 10 pts)
   *
   * Zero technical skills strictly results in a genuine low score (0–10%),
   * without artificial minimum clamping or automatic 30-point inflation.
   */
  calculateSkillGaps(
    studentSkills: (string | { name: string; currentLevel?: number })[],
    jobRequiredSkills: string[],
    jobTitle = '',
    isRemote = false,
    targetRole = 'Data Analyst',
    userWorkPreference = 'Flexible'
  ) {
    // 1. Normalize student skills with assessed competency levels
    const normalizedStudentSkills: { name: string; canonical: string; currentLevel: number }[] = [];
    (studentSkills || []).forEach((s) => {
      const rawName = typeof s === 'string' ? s : s?.name || '';
      if (!rawName.trim()) return;
      const level = typeof s === 'object' && typeof s.currentLevel === 'number' ? s.currentLevel : 70;
      normalizedStudentSkills.push({
        name: rawName.trim(),
        canonical: canonicalizeSkill(rawName),
        currentLevel: Math.max(0, Math.min(100, level))
      });
    });

    // 2. Canonicalize job requirement tags
    const canonicalRequired: string[] = [];
    const seenReqs = new Set<string>();
    (jobRequiredSkills || []).forEach((r) => {
      const canon = canonicalizeSkill(r);
      if (canon && !seenReqs.has(canon.toLowerCase())) {
        seenReqs.add(canon.toLowerCase());
        canonicalRequired.push(canon);
      }
    });

    // 3. Match evaluation with strict token-aware matching & competency weighting
    const matched: string[] = [];
    const missing: string[] = [];
    let totalCompetencyWeight = 0;

    canonicalRequired.forEach((req) => {
      const match = normalizedStudentSkills.find((s) => areSkillsMatching(s.name, req));
      if (match) {
        matched.push(req);
        // Competency weights:
        // 90–100%: 1.0 (strong contribution)
        // 70–89%:  0.85 (good contribution)
        // 40–69%:  0.50 (partial contribution)
        // < 40%:   0.20 (weak contribution / priority gap)
        let weight = 0.20;
        if (match.currentLevel >= 90) weight = 1.0;
        else if (match.currentLevel >= 70) weight = 0.85;
        else if (match.currentLevel >= 40) weight = 0.50;

        totalCompetencyWeight += weight;
      } else {
        missing.push(req);
      }
    });

    // 4. Technical Skill Score (up to 70 points)
    // No artificial 30-point inflation if zero skills or empty requirements
    let skillScore = 0;
    if (canonicalRequired.length > 0) {
      skillScore = Math.round((totalCompetencyWeight / canonicalRequired.length) * 70);
    }

    // 5. Target Role Alignment (up to 20 points)
    let roleScore = 0;
    const titleClean = (jobTitle || '').toLowerCase();
    const targetClean = (targetRole || '').toLowerCase();

    if (targetClean && titleClean) {
      if (titleClean.includes(targetClean)) {
        roleScore = 20;
      } else {
        const targetWords = targetClean.split(/\s+/).filter((w) => w.length > 3);
        const hasWordMatch = targetWords.some((w) => titleClean.includes(w));
        if (hasWordMatch) {
          if (targetClean.includes('data') && (titleClean.includes('data') || titleClean.includes('analytics') || titleClean.includes('bi'))) {
            roleScore = 18;
          } else if (targetClean.includes('developer') && (titleClean.includes('engineer') || titleClean.includes('software'))) {
            roleScore = 15;
          } else {
            roleScore = 12;
          }
        } else if (titleClean.includes('intern') || titleClean.includes('trainee') || titleClean.includes('graduate')) {
          roleScore = 8;
        }
      }
    }

    // 6. Workplace Preference Alignment (up to 10 points)
    let workplaceScore = 0;
    const prefClean = (userWorkPreference || 'Flexible').toLowerCase();
    const isRemoteJob = Boolean(isRemote) || titleClean.includes('remote');

    if (prefClean === 'remote') {
      workplaceScore = isRemoteJob ? 10 : 2;
    } else if (prefClean === 'on-site' || prefClean === 'onsite') {
      workplaceScore = !isRemoteJob ? 10 : 4;
    } else if (prefClean === 'hybrid') {
      workplaceScore = 8;
    } else {
      workplaceScore = 7;
    }

    // 7. Deterministic Final Match Score Calculation
    // Remove artificial 25% minimum clamp. Zero matched skills strictly yields 0%–10%.
    let matchScore = 0;
    if (matched.length === 0) {
      const exploratoryScore = Math.round(roleScore * 0.35 + workplaceScore * 0.3);
      matchScore = Math.min(10, Math.max(0, exploratoryScore));
    } else {
      const rawSum = skillScore + roleScore + workplaceScore;
      matchScore = Math.max(12, Math.min(98, Math.round(rawSum)));
    }

    return {
      matched,
      missing,
      matchScore,
      skillScore,
      roleScore,
      workplaceScore
    };
  }
};
