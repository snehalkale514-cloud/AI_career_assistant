/**
 * Resume & ATS Analysis Service
 * Deterministic, evidence-based ATS evaluation utilizing canonical skill matching,
 * real client-side text extraction (TXT, PDF, DOCX), section detection, and metric density.
 */

import { inflate, inflateRaw } from 'pako';
import {
  CANONICAL_SKILL_DEFINITIONS,
  areSkillsMatching,
  getRoleBenchmarkSkills,
} from './liveJobsService.ts';

export interface ResumeAnalysisResult {
  atsScore: number;
  atsCompatibility: number;
  keywordMatch: number;
  formattingScore: number;
  skillsMatch: number;
  experienceMatch: number;
  strengths: string[];
  missingSkills: string[];
  keywordSuggestions: string[];
  improvements: { original: string; suggested: string; reason: string }[];
  analyzedFileName: string;
  warningMessage?: string;
  detectedSkills: string[];
  extractedTextLength: number;
}

/**
 * Extracts plain text from an uploaded file (TXT, PDF, or DOCX) in a pure client-side environment.
 */
export async function extractTextFromFile(
  file: File | { name: string; text?: () => Promise<string>; arrayBuffer?: () => Promise<ArrayBuffer>; textContent?: string }
): Promise<string> {
  const fileName = (file.name || '').toLowerCase();

  // 1. Direct text content if provided directly (e.g. in tests)
  if ('textContent' in file && typeof file.textContent === 'string') {
    return file.textContent;
  }

  // 2. Plain Text / Markdown files
  if (fileName.endsWith('.txt') || fileName.endsWith('.md') || fileName.endsWith('.text')) {
    if (typeof file.text === 'function') {
      return await file.text();
    }
  }

  // 3. Binary file reading for PDF and DOCX
  let buffer: ArrayBuffer | null = null;
  if (typeof file.arrayBuffer === 'function') {
    buffer = await file.arrayBuffer();
  }

  if (!buffer || buffer.byteLength === 0) {
    return '';
  }

  // 4. DOCX file text extraction (PKZip word/document.xml)
  if (fileName.endsWith('.docx') || fileName.endsWith('.doc')) {
    try {
      const docxText = parseDocxBuffer(buffer);
      if (docxText.trim().length > 0) {
        return docxText.trim();
      }
    } catch (err) {
      console.warn('DOCX extraction warning:', err);
    }
  }

  // 5. PDF file text extraction (decodes content streams and Tj / TJ operators)
  if (fileName.endsWith('.pdf')) {
    try {
      const pdfText = parsePdfBuffer(buffer);
      if (pdfText.trim().length > 0) {
        return pdfText.trim();
      }
    } catch (err) {
      console.warn('PDF extraction warning:', err);
    }
  }

  // 6. Generic TextDecoder fallback for text-based or exported files
  try {
    const fallbackText = new TextDecoder('utf-8', { fatal: false }).decode(new Uint8Array(buffer));
    const printableWords = fallbackText.match(/[A-Za-z0-9+#.-]{3,}/g) || [];
    if (printableWords.length >= 10) {
      return printableWords.join(' ');
    }
  } catch {
    // ignore
  }

  return '';
}

/**
 * Parses DOCX by unpacking word/document.xml from PKZip structure using pako.inflateRaw
 */
function parseDocxBuffer(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let pos = 0;
  while (pos < bytes.length - 30) {
    if (bytes[pos] === 0x50 && bytes[pos + 1] === 0x4b && bytes[pos + 2] === 0x03 && bytes[pos + 3] === 0x04) {
      const compMethod = bytes[pos + 8] | (bytes[pos + 9] << 8);
      const compSize = bytes[pos + 18] | (bytes[pos + 19] << 8) | (bytes[pos + 20] << 16) | (bytes[pos + 21] << 24);
      const fnLen = bytes[pos + 26] | (bytes[pos + 27] << 8);
      const extraLen = bytes[pos + 28] | (bytes[pos + 29] << 8);

      const fnBytes = bytes.slice(pos + 30, pos + 30 + fnLen);
      const entryName = new TextDecoder().decode(fnBytes);
      const dataStart = pos + 30 + fnLen + extraLen;
      const dataEnd = dataStart + compSize;

      if (entryName.includes('word/document.xml') && dataEnd <= bytes.length) {
        const compressedData = bytes.slice(dataStart, dataEnd);
        let xmlStr = '';
        if (compMethod === 8) {
          const inflated = inflateRaw(compressedData);
          xmlStr = new TextDecoder().decode(inflated);
        } else {
          xmlStr = new TextDecoder().decode(compressedData);
        }
        const matches = xmlStr.match(/<w:t[^>]*>([^<]+)<\/w:t>/g) || [];
        return matches.map((m) => m.replace(/<[^>]+>/g, '')).join(' ');
      }
      pos = dataEnd;
    } else {
      pos++;
    }
  }
  return '';
}

/**
 * Parses PDF by extracting stream content and text operators
 */
function parsePdfBuffer(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  const latin1 = new TextDecoder('latin1').decode(bytes);
  let extracted = '';

  const streamPattern = /stream\r?\n/g;
  let match;
  while ((match = streamPattern.exec(latin1)) !== null) {
    const streamStart = match.index + match[0].length;
    const endstreamPos = latin1.indexOf('endstream', streamStart);
    if (endstreamPos === -1) break;

    const streamChunk = bytes.slice(streamStart, endstreamPos);
    let streamText = '';
    try {
      const inflatedBytes = inflate(streamChunk);
      streamText = new TextDecoder('latin1').decode(inflatedBytes);
    } catch {
      streamText = new TextDecoder('latin1').decode(streamChunk);
    }

    // Parse (Text) Tj
    const tj = streamText.matchAll(/\(([^)]*)\)\s*Tj/g);
    for (const m of tj) {
      extracted += ' ' + m[1];
    }
    // Parse [(T)(e)(x)(t)] TJ
    const tjArr = streamText.matchAll(/\[(.*?)\]\s*TJ/g);
    for (const m of tjArr) {
      const parts = m[1].matchAll(/\(([^)]*)\)/g);
      for (const p of parts) {
        extracted += p[1];
      }
      extracted += ' ';
    }
  }

  if (extracted.trim().length < 15) {
    const words = latin1.match(/[A-Za-z0-9+#.-]{3,}/g) || [];
    const filtered = words.filter(
      (w) => !['obj', 'endobj', 'stream', 'endstream', 'xref', 'trailer', 'Catalog', 'Pages', 'Kids', 'Count', 'Length', 'Filter', 'FlateDecode'].includes(w)
    );
    extracted = filtered.join(' ');
  }

  return extracted.trim();
}

/**
 * Detects canonical skills in text using strict token boundary rules
 */
export function detectSkillsInText(text: string): string[] {
  if (!text) return [];
  const lower = text.toLowerCase();
  const detected = new Set<string>();

  CANONICAL_SKILL_DEFINITIONS.forEach((def) => {
    for (const alias of def.aliases) {
      const escaped = alias.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      let regex: RegExp;
      if (def.exactMatchOnly) {
        regex = new RegExp(`(^|[^\\w+#])${escaped}(?=[^\\w+#]|$)`, 'i');
      } else {
        regex = new RegExp(`\\b${escaped}\\b`, 'i');
      }

      if (regex.test(lower)) {
        // Special guard: 'SQL' must not match 'NoSQL'
        if (def.canonical === 'SQL' && !/\b(relational|postgres|mysql|sqlite|\bsql\b)/i.test(lower) && /\bnosql\b/i.test(lower)) {
          continue;
        }
        // Special guard: 'Git' must not match 'Digital'
        if (def.canonical === 'Git' && !/\b(git|github|gitlab)\b/i.test(lower) && lower.includes('digital')) {
          continue;
        }
        // Special guard: 'C' must not match 'Cloud', 'React', 'CSS'
        if (def.canonical === 'C') {
          const cRegex = /(^|[^\w+#])c(?=[^\w+#]|$)/i;
          if (!cRegex.test(text)) continue;
        }
        detected.add(def.canonical);
        break;
      }
    }
  });

  return Array.from(detected);
}

/**
 * Analyzes presence of standard ATS resume sections
 */
export function analyzeSections(text: string): {
  score: number;
  sectionsFound: string[];
  sectionsMissing: string[];
} {
  const sections = [
    { name: 'Education', regex: /\b(education|academic|qualification|university|college|btech|degree|cgpa|gpa)\b/i },
    { name: 'Skills', regex: /\b(skills|technical skills|competencies|technologies|tools|languages)\b/i },
    { name: 'Experience', regex: /\b(experience|employment|work history|internship|intern|trainee|professional experience)\b/i },
    { name: 'Projects', regex: /\b(projects|academic projects|personal projects|portfolio|key projects|capstone)\b/i },
  ];

  const sectionsFound: string[] = [];
  const sectionsMissing: string[] = [];

  sections.forEach((sec) => {
    if (sec.regex.test(text)) {
      sectionsFound.push(sec.name);
    } else {
      sectionsMissing.push(sec.name);
    }
  });

  const score = Math.round((sectionsFound.length / sections.length) * 100);

  return { score, sectionsFound, sectionsMissing };
}

/**
 * Analyzes action verbs and measurable metrics (Google X-Y-Z formula indicators)
 */
export function analyzeMeasurableImpact(text: string): {
  score: number;
  metricMatches: string[];
  actionVerbsFound: string[];
} {
  const ACTION_VERBS = [
    'developed', 'engineered', 'built', 'created', 'designed', 'implemented',
    'optimized', 'led', 'analyzed', 'automated', 'deployed', 'spearheaded',
    'managed', 'reduced', 'increased', 'trained', 'integrated', 'architected',
    'resolved', 'delivered', 'formulated', 'collaborated'
  ];
  const lower = text.toLowerCase();
  const actionVerbsFound = ACTION_VERBS.filter((v) => new RegExp(`\\b${v}\\b`, 'i').test(lower));

  const metricRegex = /\b\d+(\.\d+)?%|\b\d+([,.]\d+)?\s*(k|m|users|records|requests|transactions|students|peers|teams|clients|hours|days|months|years|weeks)\b|(\$|₹|rs\.?|inr|eur)\s*\d+|\b(100|[1-9]\d{1,5})\b/gi;
  const rawMatches = text.match(metricRegex) || [];
  const metricMatches = Array.from(new Set(rawMatches)).slice(0, 10);

  const verbScore = Math.min(50, actionVerbsFound.length * 10);
  const metricScore = Math.min(50, metricMatches.length * 10);
  const score = verbScore + metricScore;

  return { score, metricMatches, actionVerbsFound };
}

/**
 * Deterministic ATS Scoring Formula:
 * Overall ATS Score = (0.50 * SkillsMatch) + (0.30 * SectionCompleteness) + (0.20 * MeasurableImpact)
 * Empty or unreadable files strictly receive 0% - 12% without artificial inflation.
 */
export function analyzeResumeContent(
  rawText: string,
  fileName: string,
  targetRole = 'Data Analyst'
): ResumeAnalysisResult {
  const cleanedText = (rawText || '').trim();

  // 1. Handle Empty or Unreadable File
  if (!cleanedText || cleanedText.length < 20) {
    return {
      atsScore: 5,
      atsCompatibility: 8,
      keywordMatch: 0,
      formattingScore: 10,
      skillsMatch: 0,
      experienceMatch: 0,
      strengths: [],
      missingSkills: getRoleBenchmarkSkills(targetRole).map((b) => b.name),
      keywordSuggestions: getRoleBenchmarkSkills(targetRole).map((b) => b.name).slice(0, 5),
      improvements: [
        {
          original: 'No readable text content detected in uploaded file.',
          suggested: 'Upload a standard text, PDF, or DOCX document with selectable text and standard sections.',
          reason: 'ATS systems cannot index scanned image-only PDFs or empty files.'
        }
      ],
      analyzedFileName: fileName || 'empty_resume.txt',
      warningMessage: 'Uploaded file contains no readable text tokens. Please upload a standard text, PDF, or DOCX document.',
      detectedSkills: [],
      extractedTextLength: cleanedText.length
    };
  }

  // 2. Identify Role Benchmark Skills
  const roleBenchmarks = getRoleBenchmarkSkills(targetRole);
  const requiredCanonical = roleBenchmarks.map((b) => b.name);

  // 3. Detect Skills in Resume Text
  const detectedSkills = detectSkillsInText(cleanedText);

  // 4. Calculate Matched & Missing Skills
  const matchedSkills: string[] = [];
  const missingSkills: string[] = [];

  requiredCanonical.forEach((req) => {
    if (detectedSkills.some((det) => areSkillsMatching(det, req))) {
      matchedSkills.push(req);
    } else {
      missingSkills.push(req);
    }
  });

  // Pillar 1: Skills & Keyword Match (0–100)
  const skillsMatch = requiredCanonical.length > 0
    ? Math.round((matchedSkills.length / requiredCanonical.length) * 100)
    : Math.min(100, detectedSkills.length * 20);

  // Pillar 2: Section Completeness (0–100)
  const sections = analyzeSections(cleanedText);
  const formattingScore = sections.score;

  // Pillar 3: Measurable Impact & Action Verbs (0–100)
  const measurable = analyzeMeasurableImpact(cleanedText);
  const experienceMatch = measurable.score;

  // Text Parsability & ATS Compatibility (0–100)
  const lengthFactor = Math.min(100, Math.round(cleanedText.length / 8));
  const atsCompatibility = Math.round(0.6 * sections.score + 0.4 * lengthFactor);

  // Overall ATS Score (Transparent weighted average: 50% Skills, 30% Sections, 20% Impact)
  const rawAts = (0.50 * skillsMatch) + (0.30 * formattingScore) + (0.20 * experienceMatch);
  const atsScore = Math.max(0, Math.min(98, Math.round(rawAts)));

  // Dynamic Strengths based strictly on detected evidence
  const strengths: string[] = [];
  if (matchedSkills.length > 0) {
    strengths.push(`Verified competencies in ${matchedSkills.slice(0, 4).join(', ')} match ${targetRole} screening requisitions.`);
  }
  if (sections.sectionsFound.includes('Education')) {
    strengths.push('Clear academic / education section detected with standard heading structure.');
  }
  if (sections.sectionsFound.includes('Projects') || sections.sectionsFound.includes('Experience')) {
    const foundSecs = sections.sectionsFound.filter((s) => s === 'Projects' || s === 'Experience').join(' and ');
    strengths.push(`Includes dedicated ${foundSecs} section displaying hands-on technical depth.`);
  }
  if (measurable.metricMatches.length >= 2) {
    strengths.push(`Contains quantified metrics and outcomes (e.g. ${measurable.metricMatches.slice(0, 3).join(', ')}).`);
  }
  if (measurable.actionVerbsFound.length >= 3) {
    strengths.push(`Uses active action verbs (${measurable.actionVerbsFound.slice(0, 3).join(', ')}) demonstrating technical ownership.`);
  }
  if (strengths.length === 0) {
    strengths.push('Document text extracted successfully, but adding standard headings and role keywords is recommended.');
  }

  // Dynamic Keyword Suggestions from actual missing skills
  const keywordSuggestions = missingSkills.slice(0, 6);

  // Dynamic Action-Oriented Bullet Improvements
  const improvements = [
    {
      original: measurable.actionVerbsFound.length > 0
        ? `Used ${measurable.actionVerbsFound[0]} without specifying measurable metric baseline.`
        : 'Described project involvement without quantified outcomes.',
      suggested: `Accomplished [Impact Metric] by implementing [${matchedSkills[0] || targetRole} solution], improving efficiency by 15–25%.`,
      reason: 'Aligns phrasing with the Google X-Y-Z formula (Accomplished [X] as measured by [Y], by doing [Z]).'
    }
  ];

  return {
    atsScore,
    atsCompatibility,
    keywordMatch: skillsMatch,
    formattingScore,
    skillsMatch,
    experienceMatch,
    strengths,
    missingSkills,
    keywordSuggestions,
    improvements,
    analyzedFileName: fileName,
    detectedSkills,
    extractedTextLength: cleanedText.length
  };
}
