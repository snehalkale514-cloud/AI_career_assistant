import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {
  HISTORICAL_MODEL_VALIDATION_METRICS,
  predictPlacementReadiness
} from '../src/services/mlPlacementModel.ts';

describe('Historical ML Dataset Transparency & Description Accuracy', () => {
  // =========================================================================
  // 1. Dataset File Exists and Contains 300 Data Records
  // =========================================================================
  it('confirms placement_ml_sample_1000.csv contains exactly 300 data records', () => {
    const csvPath = path.resolve('src/data/placement_ml_sample_1000.csv');
    assert.ok(fs.existsSync(csvPath), 'CSV file must exist on disk');

    const content = fs.readFileSync(csvPath, 'utf-8');
    const lines = content.trim().split('\n').filter((l) => l.trim().length > 0);

    // 1 header row + 300 data rows
    assert.strictEqual(lines.length, 301, 'CSV must have 1 header line and exactly 300 data records');
  });

  // =========================================================================
  // 2. DataTransparencyBadge Copy Truthfulness
  // =========================================================================
  it('ensures DataTransparencyBadge uses truthful description without claiming runtime training', () => {
    const badgePath = path.resolve('src/components/common/DataTransparencyBadge.tsx');
    const content = fs.readFileSync(badgePath, 'utf-8');

    // Must contain truthful wording
    assert.match(
      content,
      /Historical benchmark dataset:.*placement_ml_sample_1000\.csv.*\(300 records\)\..*Live placement scoring currently uses predefined, deterministic threshold rules\..*The CSV is not loaded or used for model training at runtime\./s,
      'Badge must state CSV is not loaded or used for runtime model training'
    );

    // Must NOT claim CSV is used strictly as historical training data to fit decision thresholds at runtime
    assert.doesNotMatch(
      content,
      /Used strictly as historical training data to fit decision thresholds/i,
      'Must not claim CSV is actively used to fit thresholds at runtime'
    );
  });

  // =========================================================================
  // 3. MLPlacementReadinessSection Description Truthfulness
  // =========================================================================
  it('ensures MLPlacementReadinessSection clarifies predefined rules without claiming runtime training', () => {
    const sectionPath = path.resolve('src/components/readiness/MLPlacementReadinessSection.tsx');
    const content = fs.readFileSync(sectionPath, 'utf-8');

    // Header description must clarify predefined threshold rules
    assert.match(
      content,
      /The historical benchmark CSV is not loaded or trained at runtime/i,
      'Header must state CSV is not loaded or trained at runtime'
    );

    // Must not claim it evaluates against a runtime decision tree classifier
    assert.doesNotMatch(
      content,
      /against the historical decision tree classifier/i,
      'Must not claim live evaluation against a runtime classifier'
    );

    // Confusion matrix caption must clarify benchmark reference
    assert.match(
      content,
      /The CSV is not loaded or used for live model training at runtime; live scoring uses predefined threshold rules/i,
      'Confusion matrix caption must explain predefined threshold rules'
    );
  });

  // =========================================================================
  // 4. Model Service Metadata Truthfulness
  // =========================================================================
  it('ensures mlPlacementModel.ts metadata reflects predefined rules and reference nature', () => {
    assert.match(
      HISTORICAL_MODEL_VALIDATION_METRICS.datasetDescription,
      /CSV is not loaded or trained at runtime/i,
      'Service metadata must document that CSV is not loaded or trained at runtime'
    );

    assert.strictEqual(
      HISTORICAL_MODEL_VALIDATION_METRICS.totalDatasetSize,
      300,
      'Dataset size must be 300'
    );
  });

  // =========================================================================
  // 5. Existing Prediction Logic Remains Functional & Deterministic
  // =========================================================================
  it('preserves existing prediction logic and returns valid deterministic results', () => {
    const sampleCandidate = {
      cgpa: 8.5,
      dsaProblemsSolved: 250,
      competitiveProgrammingRating: 1650,
      githubContributions: 600,
      aptitudeScore: 80,
      communicationScore: 85,
      softSkillsScore: 80,
      internshipsCount: 2,
      projectsCount: 4,
      certificationsCount: 3,
      openSourceContributions: 50,
      hackathonsParticipated: 3,
      attendancePercentage: 88,
      leadershipExperience: true,
      collegeTier: 'Tier-2' as const,
      branch: 'AI & Data Science',
      studyHoursPerWeek: 20,
      extracurricularActivities: 2
    };

    const result = predictPlacementReadiness(sampleCandidate);

    assert.ok(result.prediction === 'Placed' || result.prediction === 'At Risk');
    assert.ok(result.confidenceScore >= 0 && result.confidenceScore <= 100);
    assert.ok(Array.isArray(result.topPositiveDrivers));
    assert.ok(Array.isArray(result.keyGaps));
    assert.ok(Array.isArray(result.recommendedImprovements));
  });
});
