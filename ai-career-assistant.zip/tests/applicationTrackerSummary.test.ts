import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { calculateApplicationTrackerSummary } from '../src/pages/applications/ApplicationTrackerPage.tsx';
import { initialApplications } from '../src/data/mockData.ts';
import { ApplicationItem } from '../src/types.ts';
import fs from 'node:fs';

describe('Application Tracker Summary Metrics Verification', () => {
  // =========================================================================
  // 1. Initial State Derived Dynamically from Live Data
  // =========================================================================
  it('derives initial summary directly from records without fabricated appointment dates', () => {
    const summary = calculateApplicationTrackerSummary(initialApplications);

    assert.strictEqual(summary.totalApps, initialApplications.length);
    assert.strictEqual(summary.interviewsCount, 1, 'Initial data has 1 Interview');
    assert.strictEqual(summary.interviewTrend.value, 'TechNova Solutions', 'Shows actual company name without fabricated (Fri) or appointment dates');
    assert.strictEqual(summary.interviewTrend.isPositive, true);

    assert.strictEqual(summary.offersCount, 1, 'Initial data has 1 Offer');
    assert.strictEqual(summary.offerTrend.value, 'Fractal Analytics');
    assert.strictEqual(summary.offerTrend.isPositive, true);
  });

  // =========================================================================
  // 2. Changing Status: Interview -> Rejected
  // =========================================================================
  it('updates the interview summary when an application status changes from Interview to Rejected', () => {
    // Modify app_1 from 'Interview' to 'Rejected'
    const updatedApps: ApplicationItem[] = initialApplications.map((app) => {
      if (app.id === 'app_1') {
        return { ...app, status: 'Rejected' };
      }
      return app;
    });

    const summary = calculateApplicationTrackerSummary(updatedApps);

    assert.strictEqual(summary.interviewsCount, 0, 'Interviews count must drop to 0');
    assert.strictEqual(summary.interviewTrend.value, 'No interview tracked', 'Must show neutral label instead of TechNova');
    assert.strictEqual(summary.interviewTrend.isPositive, false);
  });

  // =========================================================================
  // 3. Deleting Interview Record
  // =========================================================================
  it('removes company from interview summary when interview record is deleted', () => {
    // Delete app_1 (TechNova Solutions)
    const withoutInterview = initialApplications.filter((app) => app.id !== 'app_1');

    const summary = calculateApplicationTrackerSummary(withoutInterview);

    assert.strictEqual(summary.interviewsCount, 0);
    assert.strictEqual(summary.interviewTrend.value, 'No interview tracked');
    assert.strictEqual(summary.interviewTrend.isPositive, false);
  });

  // =========================================================================
  // 4. Deleting Offer Record
  // =========================================================================
  it('removes company from offer summary when offer record is deleted', () => {
    // Delete app_8 (Fractal Analytics)
    const withoutOffer = initialApplications.filter((app) => app.id !== 'app_8');

    const summary = calculateApplicationTrackerSummary(withoutOffer);

    assert.strictEqual(summary.offersCount, 0);
    assert.strictEqual(summary.offerTrend.value, 'No offer tracked');
    assert.strictEqual(summary.offerTrend.isPositive, false);
  });

  // =========================================================================
  // 5. Empty Tracker
  // =========================================================================
  it('does not display TechNova, Fractal Analytics, or appointment dates when tracker is empty', () => {
    const emptySummary = calculateApplicationTrackerSummary([]);

    assert.strictEqual(emptySummary.totalApps, 0);
    assert.strictEqual(emptySummary.interviewsCount, 0);
    assert.strictEqual(emptySummary.offersCount, 0);
    assert.strictEqual(emptySummary.shortlistedCount, 0);

    assert.strictEqual(emptySummary.interviewTrend.value, 'No interview tracked');
    assert.strictEqual(emptySummary.offerTrend.value, 'No offer tracked');

    assert.doesNotMatch(emptySummary.interviewTrend.value, /TechNova/i);
    assert.doesNotMatch(emptySummary.interviewTrend.value, /Fri/i);
    assert.doesNotMatch(emptySummary.offerTrend.value, /Fractal Analytics/i);
  });

  // =========================================================================
  // 6. Multiple Interviews & Offers Formatting
  // =========================================================================
  it('formats multiple interview and offer records correctly', () => {
    const multipleApps: ApplicationItem[] = [
      {
        id: 'int_1',
        company: 'Company A',
        role: 'Data Analyst',
        location: 'Pune',
        appliedDate: '10 Oct',
        status: 'Interview'
      },
      {
        id: 'int_2',
        company: 'Company B',
        role: 'Data Analyst',
        location: 'Remote',
        appliedDate: '11 Oct',
        status: 'Interview'
      },
      {
        id: 'off_1',
        company: 'Company C',
        role: 'Data Analyst',
        location: 'Mumbai',
        appliedDate: '12 Oct',
        status: 'Offer'
      },
      {
        id: 'off_2',
        company: 'Company D',
        role: 'Data Analyst',
        location: 'Bengaluru',
        appliedDate: '13 Oct',
        status: 'Offer'
      }
    ];

    const summary = calculateApplicationTrackerSummary(multipleApps);

    assert.strictEqual(summary.interviewsCount, 2);
    assert.strictEqual(summary.interviewTrend.value, 'Company A (+1)');

    assert.strictEqual(summary.offersCount, 2);
    assert.strictEqual(summary.offerTrend.value, 'Company C (+1)');
  });

  // =========================================================================
  // 7. Verify Source Code Contains No Hardcoded Trend Text
  // =========================================================================
  it('confirms ApplicationTrackerPage does not hardcode TechNova or Fractal Analytics into StatCards', () => {
    const source = fs.readFileSync('src/pages/applications/ApplicationTrackerPage.tsx', 'utf-8');

    assert.doesNotMatch(
      source,
      /trend=\{\{\s*value:\s*'Next:\s*TechNova\s*\(Fri\)'/i,
      'Hardcoded Next: TechNova (Fri) trend must be removed'
    );
    assert.doesNotMatch(
      source,
      /trend=\{\{\s*value:\s*'Fractal Analytics'/i,
      'Hardcoded Fractal Analytics trend must be removed'
    );

    // Verify subtext labels reflect self-tracked nature of entries
    assert.match(source, /Self-tracked interview rounds/i);
    assert.match(source, /Self-tracked offer records/i);
  });
});
