import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  canonicalizeSkill,
  areSkillsMatching,
  extractSkillsFromText,
  isJobRelevantToRole,
  isJobCompatibleWithUserLocationAndWorkPreference,
  isJobRelevantForCandidate,
  getRoleBenchmarkSkills,
  ROLE_BENCHMARKS
} from '../src/services/liveJobsService.ts';
import { initialUserProfile, initialSkills } from '../src/data/mockData.ts';
import { JobItem } from '../src/types.ts';

describe('Live Job Relevance & Skill Tag Accuracy Regression Tests', () => {
  // =========================================================================
  // 1. Generic tags such as IT do not become technical skills
  // =========================================================================
  it('ensures generic tags such as IT do not become technical skills', () => {
    assert.strictEqual(canonicalizeSkill('IT'), '', 'IT must not be canonicalized as a skill');
    assert.strictEqual(canonicalizeSkill('Information Technology'), '', 'Information Technology must not be a technical skill');
    assert.strictEqual(canonicalizeSkill('Software'), '', 'Software must not be a technical skill');
    assert.strictEqual(canonicalizeSkill('Tech'), '', 'Tech must not be a technical skill');
    assert.strictEqual(canonicalizeSkill('Management'), '', 'Management must not be a technical skill');
    assert.strictEqual(canonicalizeSkill('Digital Marketing'), '', 'Digital Marketing must not be a technical skill');

    const extracted = extractSkillsFromText('Role description with IT and management needs', ['IT', 'Software', 'Management']);
    assert.ok(!extracted.includes('IT'), 'Extracted skills must not include IT');
    assert.ok(!extracted.includes('Software'), 'Extracted skills must not include Software');
  });

  // =========================================================================
  // 2. German category tags do not become unsupported technical skill gaps
  // =========================================================================
  it('ensures German category tags from Arbeitnow do not become technical skills or skill gaps', () => {
    assert.strictEqual(canonicalizeSkill('Informatik'), '', 'Informatik must not be treated as a technical skill');
    assert.strictEqual(canonicalizeSkill('KI'), '', 'KI must not be treated as a technical skill');
    assert.strictEqual(canonicalizeSkill('Automatisierung'), '', 'Automatisierung must not be treated as a technical skill');
    assert.strictEqual(canonicalizeSkill('Karriere'), '', 'Karriere must not be treated as a technical skill');

    const extracted = extractSkillsFromText('Wir suchen einen Data Analyst im Bereich Informatik, KI und Automatisierung', [
      'Informatik',
      'KI',
      'Automatisierung'
    ]);

    assert.ok(!extracted.includes('Informatik'), 'Must not extract Informatik');
    assert.ok(!extracted.includes('KI'), 'Must not extract KI');
    assert.ok(!extracted.includes('Automatisierung'), 'Must not extract Automatisierung');
  });

  // =========================================================================
  // 3. Recognized technical tags are still extracted correctly
  // =========================================================================
  it('correctly canonicalizes and extracts valid technical skills', () => {
    assert.strictEqual(canonicalizeSkill('python'), 'Python');
    assert.strictEqual(canonicalizeSkill('Python3'), 'Python');
    assert.strictEqual(canonicalizeSkill('sql'), 'SQL');
    assert.strictEqual(canonicalizeSkill('Relational SQL'), 'SQL');
    assert.strictEqual(canonicalizeSkill('Excel'), 'Excel');
    assert.strictEqual(canonicalizeSkill('Advanced Excel'), 'Excel');
    assert.strictEqual(canonicalizeSkill('power bi'), 'Power BI');
    assert.strictEqual(canonicalizeSkill('PowerBI Desktop'), 'Power BI');
    assert.strictEqual(canonicalizeSkill('JavaScript'), 'JavaScript');
    assert.strictEqual(canonicalizeSkill('React'), 'React');
    assert.strictEqual(canonicalizeSkill('TypeScript'), 'TypeScript');
    assert.strictEqual(canonicalizeSkill('Docker'), 'Docker');
    assert.strictEqual(canonicalizeSkill('AWS'), 'AWS');
    assert.strictEqual(canonicalizeSkill('Data Visualization'), 'Data Visualization');

    const extracted = extractSkillsFromText('Requires Python, SQL, and Power BI experience', ['Python', 'SQL', 'Power BI']);
    assert.ok(extracted.includes('Python'), 'Must extract Python');
    assert.ok(extracted.includes('SQL'), 'Must extract SQL');
    assert.ok(extracted.includes('Power BI'), 'Must extract Power BI');
  });

  // =========================================================================
  // 4. Existing Java/JavaScript and SQL/NoSQL protections remain intact
  // =========================================================================
  it('preserves strict protections against false matches between Java/JavaScript and SQL/NoSQL', () => {
    assert.strictEqual(canonicalizeSkill('Java'), 'Java');
    assert.strictEqual(canonicalizeSkill('JavaScript'), 'JavaScript');
    assert.strictEqual(canonicalizeSkill('SQL'), 'SQL');
    assert.strictEqual(canonicalizeSkill('NoSQL'), 'NoSQL');

    assert.strictEqual(areSkillsMatching('Java', 'JavaScript'), false, 'Java must never match JavaScript');
    assert.strictEqual(areSkillsMatching('JavaScript', 'Java'), false, 'JavaScript must never match Java');
    assert.strictEqual(areSkillsMatching('SQL', 'NoSQL'), false, 'SQL must never match NoSQL');
    assert.strictEqual(areSkillsMatching('NoSQL', 'SQL'), false, 'NoSQL must never match SQL');
    assert.strictEqual(areSkillsMatching('C', 'C++'), false, 'C must not match C++');
    assert.strictEqual(areSkillsMatching('R', 'React'), false, 'R must not match React');
  });

  // =========================================================================
  // 5. Jobs irrelevant to the selected role do not influence market gaps
  // =========================================================================
  it('correctly filters out jobs irrelevant to the selected target role', () => {
    const dataAnalystJob: JobItem = {
      id: 'job_1',
      title: 'Senior Data Analyst',
      company: 'TechCorp',
      location: 'Pune, India',
      type: 'Full-time',
      workplace: 'Hybrid',
      experience: '2 years',
      salary: '₹8 LPA',
      matchScore: 80,
      requiredSkills: ['Python', 'SQL'],
      matchedSkills: [],
      missingSkills: [],
      description: 'Data analysis role',
      responsibilities: [],
      requirements: [],
      postedDaysAgo: 2,
      applicationUrl: 'https://example.com'
    };

    const frontendJob: JobItem = {
      id: 'job_2',
      title: 'Senior Frontend Developer',
      company: 'WebCo',
      location: 'Pune, India',
      type: 'Full-time',
      workplace: 'Hybrid',
      experience: '2 years',
      salary: '₹8 LPA',
      matchScore: 50,
      requiredSkills: ['React', 'CSS'],
      matchedSkills: [],
      missingSkills: [],
      description: 'Frontend role',
      responsibilities: [],
      requirements: [],
      postedDaysAgo: 3,
      applicationUrl: 'https://example.com'
    };

    assert.strictEqual(isJobRelevantToRole(dataAnalystJob, 'Data Analyst'), true);
    assert.strictEqual(isJobRelevantToRole(frontendJob, 'Data Analyst'), false, 'Frontend job must not match Data Analyst');
    assert.strictEqual(isJobRelevantToRole(dataAnalystJob, 'Frontend Developer'), false, 'Data analyst job must not match Frontend Developer');
    assert.strictEqual(isJobRelevantToRole(frontendJob, 'Frontend Developer'), true);
  });

  // =========================================================================
  // 6. Location and work-preference filtering follows actual available job data
  // =========================================================================
  it('enforces candidate location and work-preference filtering', () => {
    const studentInIndia = {
      targetRole: 'Data Analyst',
      location: 'Pune, Maharashtra, India',
      preferredLocation: 'Pune / Mumbai / Remote',
      workPreference: 'Hybrid' as const
    };

    const germanOnsiteJob = {
      title: 'Data Analyst',
      location: 'Berlin, Germany',
      workplace: 'On-site' as const
    };

    const germanHybridJob = {
      title: 'Data Analyst',
      location: 'Munich, Germany',
      workplace: 'Hybrid' as const
    };

    const germanRemoteJob = {
      title: 'Data Analyst',
      location: 'Berlin, Germany (Remote)',
      workplace: 'Remote' as const
    };

    const puneHybridJob = {
      title: 'Data Analyst',
      location: 'Pune, Maharashtra',
      workplace: 'Hybrid' as const
    };

    const globalRemoteJob = {
      title: 'Data Analyst',
      location: 'Worldwide Remote',
      workplace: 'Remote' as const
    };

    // German on-site/hybrid jobs cannot be attended by a student in Pune
    assert.strictEqual(isJobCompatibleWithUserLocationAndWorkPreference(germanOnsiteJob, studentInIndia), false);
    assert.strictEqual(isJobCompatibleWithUserLocationAndWorkPreference(germanHybridJob, studentInIndia), false);

    // Foreign-regional remote jobs on German boards are restricted to local tax residents
    assert.strictEqual(isJobCompatibleWithUserLocationAndWorkPreference(germanRemoteJob, studentInIndia), false);

    // Matching local job in Pune is compatible
    assert.strictEqual(isJobCompatibleWithUserLocationAndWorkPreference(puneHybridJob, studentInIndia), true);

    // Global remote job is compatible
    assert.strictEqual(isJobCompatibleWithUserLocationAndWorkPreference(globalRemoteJob, studentInIndia), true);

    // Respects explicit Remote preference
    const remoteOnlyStudent = {
      ...studentInIndia,
      workPreference: 'Remote' as const
    };
    assert.strictEqual(isJobCompatibleWithUserLocationAndWorkPreference(puneHybridJob, remoteOnlyStudent), false, 'Remote-only student rejects hybrid job');
    assert.strictEqual(isJobCompatibleWithUserLocationAndWorkPreference(globalRemoteJob, remoteOnlyStudent), true);
  });

  // =========================================================================
  // 7. Role-benchmark fallback works correctly when no suitable jobs remain
  // =========================================================================
  it('falls back cleanly to authoritative target role benchmarks when no matching jobs remain', () => {
    // When relevantJobs is empty, getRoleBenchmarkSkills returns canonical benchmarks
    const benchmarks = getRoleBenchmarkSkills('Data Analyst', initialSkills, []);

    assert.ok(benchmarks.length > 0, 'Must return benchmarks');
    const benchmarkNames = benchmarks.map((b) => b.name);

    assert.ok(benchmarkNames.includes('Python'), 'Benchmarks must include Python');
    assert.ok(benchmarkNames.includes('SQL'), 'Benchmarks must include SQL');
    assert.ok(benchmarkNames.includes('Excel'), 'Benchmarks must include Excel');
    assert.ok(benchmarkNames.includes('Power BI'), 'Benchmarks must include Power BI');
    assert.ok(benchmarkNames.includes('Statistics'), 'Benchmarks must include Statistics');

    // Never includes generic or German terms
    assert.ok(!benchmarkNames.includes('IT'));
    assert.ok(!benchmarkNames.includes('Informatik'));
    assert.ok(!benchmarkNames.includes('KI'));
    assert.ok(!benchmarkNames.includes('Automatisierung'));
  });
});
