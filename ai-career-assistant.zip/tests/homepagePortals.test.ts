import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

describe('Homepage Portal Cards Redesign Verification', () => {
  const landingPagePath = path.resolve('src/pages/LandingPage.tsx');
  const sourceCode = fs.readFileSync(landingPagePath, 'utf8');

  it('contains the Student Portal card with required copy and features', () => {
    assert.ok(sourceCode.includes('Student Portal'), 'Contains Student Portal heading');
    assert.ok(
      sourceCode.includes(
        'Build your skills, create an ATS-friendly resume, prepare for interviews, explore opportunities, and track your career growth.'
      ),
      'Contains exact Student Portal description'
    );
    assert.ok(sourceCode.includes('Personalized AI Career Roadmap'), 'Contains Roadmap feature');
    assert.ok(sourceCode.includes('Resume & ATS Analysis'), 'Contains Resume & ATS Analysis feature');
    assert.ok(sourceCode.includes('Skill Gap Analysis'), 'Contains Skill Gap Analysis feature');
    assert.ok(sourceCode.includes('Interview Preparation'), 'Contains Interview Preparation feature');
    assert.ok(sourceCode.includes('Internship & Job Applications'), 'Contains Job Applications feature');
    assert.ok(sourceCode.includes('Continue as Student'), 'Contains primary button label');
    assert.ok(sourceCode.includes("navigate('/login')"), 'Navigates to student login flow');
  });

  it('contains the Company Portal card with required copy and features', () => {
    assert.ok(sourceCode.includes('Company Portal'), 'Contains Company Portal heading');
    assert.ok(
      sourceCode.includes(
        'Discover talented students, publish internships and job openings, review applications, and connect with potential candidates.'
      ),
      'Contains exact Company Portal description'
    );
    assert.ok(sourceCode.includes('Post Jobs & Internships'), 'Contains Post Jobs feature');
    assert.ok(sourceCode.includes('Review Student Applications'), 'Contains Review Student Applications feature');
    assert.ok(sourceCode.includes('Shortlist Candidates'), 'Contains Shortlist Candidates feature');
    assert.ok(sourceCode.includes('Manage Recruitment'), 'Contains Manage Recruitment feature');
    assert.ok(sourceCode.includes('Review Shared Student Projects'), 'Contains Review Shared Projects feature');
    assert.ok(sourceCode.includes('Continue as Company'), 'Contains primary button label');
    assert.ok(sourceCode.includes("navigate('/company/login')"), 'Navigates to company login flow');
  });

  it('enforces clean hero and responsive 2-column desktop / 1-column mobile grid layout', () => {
    assert.ok(sourceCode.includes('Welcome to AI Career Assistant'), 'Contains required welcome heading');
    assert.ok(
      sourceCode.includes('One platform. Two portals. Better career opportunities.'),
      'Contains required subtitle'
    );
    assert.ok(sourceCode.includes('grid-cols-1 md:grid-cols-2'), 'Configures responsive side-by-side desktop layout');
    assert.ok(!sourceCode.includes('Testimonials'), 'Does not contain generic testimonials');
    assert.ok(!sourceCode.includes('faqs ='), 'Removes crowded FAQ sections from initial landing choice');
  });

  it('hides the floating Career Mentor widget on the public landing page', () => {
    const mentorPath = path.resolve('src/components/careerMentor/CareerMentor.tsx');
    const mentorSource = fs.readFileSync(mentorPath, 'utf8');
    assert.ok(
      mentorSource.includes("location.pathname === '/'"),
      'Hides floating career mentor on the public landing page so it never overlaps cards or buttons'
    );
  });
});
