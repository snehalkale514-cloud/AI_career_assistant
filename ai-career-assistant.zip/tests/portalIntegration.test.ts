import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  initialCompanyProfiles,
  initialCompanyUsers,
  initialCompanyJobPostings,
  initialCompanyApplicants,
} from '../src/data/companyMockData.ts';
import { initialUserProfile, initialSkills } from '../src/data/mockData.ts';
import { CompanyJobPosting, CompanyApplicantRecord, ApplicationItem, JobItem } from '../src/types.ts';
import { liveJobsService } from '../src/services/liveJobsService.ts';

describe('End-to-End Student and Company Portal Integration Audit', () => {
  // =========================================================================
  // WORKFLOW 1: COMPANY CREATES A JOB & LIFECYCLE
  // =========================================================================
  describe('1. Company Creates, Publishes, Edits, and Closes Job Postings', () => {
    it('creates job as draft or published, supports editing, and enforces ownership authorization', () => {
      const owningRecruiter = initialCompanyUsers.find((u) => u.companyId === 'comp_technova')!;
      const rivalRecruiter = initialCompanyUsers.find((u) => u.companyId === 'comp_analyticshub')!;

      // 1. Create a posting
      let jobStore: CompanyJobPosting[] = [...initialCompanyJobPostings];

      const newPosting: CompanyJobPosting = {
        id: `job_${owningRecruiter.companyId}_test_da`,
        companyId: owningRecruiter.companyId,
        companyName: 'TechNova Solutions',
        title: 'Junior Analytics Engineer',
        type: 'Full-time',
        workplace: 'Hybrid',
        location: 'Pune / Remote',
        experience: '0–1 years',
        salary: '₹6.5 – 8.5 LPA',
        requiredSkills: ['SQL', 'Python', 'Power BI'],
        description: 'Design analytics data pipelines and data marts',
        responsibilities: ['Build ETL/ELT pipelines', 'Validate semantic layer models'],
        requirements: ['B.Tech / B.E. Computer Science or Data Science'],
        status: 'Draft',
        postedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        applicantsCount: 0,
      };

      jobStore = [newPosting, ...jobStore];
      assert.strictEqual(jobStore[0].status, 'Draft', 'Posting starts as Draft');

      // 2. Ownership check on edit
      const canEdit = (user: typeof owningRecruiter, job: CompanyJobPosting) => {
        return user.role === 'company' && user.companyId === job.companyId;
      };

      assert.strictEqual(canEdit(owningRecruiter, newPosting), true, 'Owning company CAN edit posting');
      assert.strictEqual(canEdit(rivalRecruiter, newPosting), false, 'Rival company CANNOT edit posting');

      // 3. Publish posting
      newPosting.status = 'Published';
      newPosting.updatedAt = new Date().toISOString();
      assert.strictEqual(newPosting.status, 'Published', 'Posting successfully transitions to Published');

      // 4. Verify that student portal filters only PUBLISHED jobs
      const studentVisibleJobs = jobStore.filter((j) => j.status === 'Published');
      assert.ok(
        studentVisibleJobs.some((j) => j.id === newPosting.id),
        'Published company job is visible to students'
      );

      // 5. Close posting
      newPosting.status = 'Closed';
      newPosting.updatedAt = new Date().toISOString();
      assert.strictEqual(newPosting.status, 'Closed', 'Posting successfully closed');

      // 6. Verify that closed and draft jobs are excluded from student application availability
      const eligibleForApplication = (job: CompanyJobPosting) => job.status === 'Published';
      assert.strictEqual(
        eligibleForApplication(newPosting),
        false,
        'Closed job is NOT eligible for new student applications'
      );
    });
  });

  // =========================================================================
  // WORKFLOW 2: STUDENT APPLIES TO A COMPANY JOB
  // =========================================================================
  describe('2. Student Submits Application to Published Company Posting', () => {
    it('stores student profile data, prevents duplicate applications, and validates authentication', () => {
      const activeStudent = { ...initialUserProfile };
      const studentSkills = [...initialSkills];
      let applicantRecords: CompanyApplicantRecord[] = [...initialCompanyApplicants];
      let studentApplications: ApplicationItem[] = [];

      const targetJob: CompanyJobPosting = {
        id: 'job_technova_associate_da',
        companyId: 'comp_technova',
        companyName: 'TechNova Solutions',
        title: 'Associate Data Analyst',
        type: 'Full-time',
        workplace: 'Hybrid',
        location: 'Pune, Maharashtra',
        experience: '0–1 years',
        salary: '₹7.0 – 8.5 LPA',
        requiredSkills: ['SQL', 'Python', 'Power BI'],
        description: 'New associate data analyst opening',
        responsibilities: ['Data analysis', 'Dashboard creation'],
        requirements: ['Engineering degree'],
        status: 'Published',
        postedAt: '2026-10-14T00:00:00Z',
        updatedAt: '2026-10-14T00:00:00Z',
        applicantsCount: 0,
      };

      // Helper function mirroring submitStudentApplication logic
      const submitApplication = (
        isStudentLoggedIn: boolean,
        student: typeof activeStudent,
        job: CompanyJobPosting
      ) => {
        if (!isStudentLoggedIn) {
          return { success: false, error: 'Please sign in as a student to submit your application.' };
        }

        if (job.status !== 'Published') {
          return { success: false, error: 'This position is currently closed to new applications.' };
        }

        // Duplicate check
        const isDuplicate = applicantRecords.some(
          (a) =>
            a.jobId === job.id &&
            (a.studentId === student.id || a.candidateEmail.toLowerCase() === student.email.toLowerCase())
        );

        if (isDuplicate) {
          return { success: false, error: 'You have already submitted an application for this position.' };
        }

        // Calculate skill match
        const gap = liveJobsService.calculateSkillGaps(
          studentSkills.map((s) => ({ name: s.name, currentLevel: s.currentLevel })),
          job.requiredSkills,
          job.title,
          job.workplace === 'Remote',
          student.targetRole,
          student.workPreference
        );

        const newApplicant: CompanyApplicantRecord = {
          id: `appl_${Date.now()}_test`,
          jobId: job.id,
          jobTitle: job.title,
          companyId: job.companyId,
          studentId: student.id,
          candidateName: student.name,
          candidateEmail: student.email,
          candidateCollege: student.college,
          candidateDegree: student.degree,
          candidateBranch: student.branch,
          candidateGraduationYear: student.graduationYear,
          appliedDate: new Date().toISOString().split('T')[0],
          status: 'Applied',
          matchScore: gap.matchScore,
          verifiedSkills: studentSkills.map((s) => s.name),
          notes: `Direct campus drive application. ATS Score: 84/100.`,
          hasSharedResume: true,
          hasSharedPortfolio: true,
          resumeFileName: 'Snehal_Kale_Resume_DataAnalyst.pdf',
          nextStep: 'Application submitted. Pending recruiter screening.',
        };

        applicantRecords = [newApplicant, ...applicantRecords];

        const studentAppItem: ApplicationItem = {
          id: newApplicant.id,
          jobId: job.id,
          companyId: job.companyId,
          studentId: student.id,
          company: job.companyName,
          role: job.title,
          location: job.location,
          appliedDate: 'Today',
          status: 'Applied',
          salary: job.salary,
          notes: `Direct application submitted to ${job.companyName}. Match score: ${gap.matchScore}%.`,
          nextStep: 'Application under review by recruiter.',
          resumeFileName: 'Snehal_Kale_Resume_DataAnalyst.pdf',
          atsScore: 84,
        };

        studentApplications = [studentAppItem, ...studentApplications];

        return { success: true, applicant: newApplicant };
      };

      // 1. Unauthenticated student is blocked
      const unauthResult = submitApplication(false, activeStudent, targetJob);
      assert.strictEqual(unauthResult.success, false);
      assert.match(unauthResult.error || '', /sign in/i);

      // 2. Authenticated student applies successfully
      const authResult = submitApplication(true, activeStudent, targetJob);
      assert.strictEqual(authResult.success, true);
      assert.ok(authResult.applicant);
      assert.strictEqual(authResult.applicant?.candidateName, 'Snehal Kale');
      assert.strictEqual(authResult.applicant?.candidateCollege, activeStudent.college);
      assert.strictEqual(authResult.applicant?.jobId, targetJob.id);
      assert.strictEqual(authResult.applicant?.companyId, targetJob.companyId);
      assert.strictEqual(authResult.applicant?.status, 'Applied');

      // 3. Duplicate application is rejected with clear error message
      const duplicateResult = submitApplication(true, activeStudent, targetJob);
      assert.strictEqual(duplicateResult.success, false);
      assert.match(duplicateResult.error || '', /already submitted/i);

      // 4. Closed job is rejected
      const closedJob: CompanyJobPosting = { ...targetJob, id: 'job_closed', status: 'Closed' };
      const closedResult = submitApplication(true, activeStudent, closedJob);
      assert.strictEqual(closedResult.success, false);
      assert.match(closedResult.error || '', /closed/i);
    });
  });

  // =========================================================================
  // WORKFLOW 3: COMPANY REVIEWS APPLICATION & CANDIDATE PRIVACY
  // =========================================================================
  describe('3. Company Reviews Candidate, Updates Status, and Isolates Data', () => {
    it('company views only applications for its own jobs and updates applicant review notes', () => {
      const technovaRecruiter = initialCompanyUsers.find((u) => u.companyId === 'comp_technova')!;
      const analyticshubRecruiter = initialCompanyUsers.find((u) => u.companyId === 'comp_analyticshub')!;

      let applicantsList: CompanyApplicantRecord[] = [
        {
          id: 'appl_tech_101',
          jobId: 'job_technova_junior_da',
          jobTitle: 'Junior Data Analyst',
          companyId: 'comp_technova',
          studentId: 'std_snehal_kale',
          candidateName: 'Snehal Kale',
          candidateEmail: 'snehal.kale@vpkbiet.ac.in',
          candidateCollege: 'VPKBIET, Baramati',
          candidateDegree: 'B.E.',
          candidateBranch: 'Artificial Intelligence & Data Science',
          candidateGraduationYear: '2025',
          appliedDate: '2026-10-14',
          status: 'Applied',
          matchScore: 88,
          verifiedSkills: ['Python', 'SQL', 'Power BI'],
          notes: 'Candidate applied via Campus Recruitment Drive',
          hasSharedResume: true,
          hasSharedPortfolio: true,
          resumeFileName: 'Snehal_Kale_Resume_DataAnalyst.pdf',
          nextStep: 'Initial screening',
        },
      ];

      // Privacy rule: Recruiter can only view applicants belonging to their company
      const getScopedApplicants = (user: typeof technovaRecruiter) => {
        return applicantsList.filter((a) => a.companyId === user.companyId);
      };

      const technovaView = getScopedApplicants(technovaRecruiter);
      assert.strictEqual(technovaView.length, 1, 'TechNova recruiter can view their applicant');
      assert.strictEqual(technovaView[0].candidateName, 'Snehal Kale');

      const analyticshubView = getScopedApplicants(analyticshubRecruiter);
      assert.strictEqual(analyticshubView.length, 0, 'AnalyticsHub recruiter CANNOT view TechNova candidate');

      // Update recruitment stage & screening notes
      const updateApplicant = (
        user: typeof technovaRecruiter,
        applicantId: string,
        status: CompanyApplicantRecord['status'],
        notes: string,
        nextStep: string
      ) => {
        const target = applicantsList.find((a) => a.id === applicantId);
        if (!target || target.companyId !== user.companyId) {
          return { success: false, error: 'Forbidden' };
        }
        applicantsList = applicantsList.map((a) =>
          a.id === applicantId ? { ...a, status, notes, nextStep } : a
        );
        return { success: true };
      };

      // Rival attempt fails
      const rivalAttempt = updateApplicant(
        analyticshubRecruiter,
        'appl_tech_101',
        'Interview',
        'Rival note',
        'Rival step'
      );
      assert.strictEqual(rivalAttempt.success, false, 'Rival recruiter cannot modify candidate status');

      // TechNova recruiter advances candidate to Interview
      const updateResult = updateApplicant(
        technovaRecruiter,
        'appl_tech_101',
        'Interview',
        'Demonstrated strong SQL joins and aggregations in screening.',
        'Technical round scheduled for Friday 2 PM'
      );
      assert.strictEqual(updateResult.success, true);
      assert.strictEqual(applicantsList[0].status, 'Interview');
      assert.strictEqual(applicantsList[0].notes, 'Demonstrated strong SQL joins and aggregations in screening.');
      assert.strictEqual(applicantsList[0].nextStep, 'Technical round scheduled for Friday 2 PM');
    });
  });

  // =========================================================================
  // WORKFLOW 4: DATA CONSISTENCY & PERSISTENCE INTEGRITY
  // =========================================================================
  describe('4. Data Consistency and Multi-Portal State Synchronization', () => {
    it('maintains consistent state schema between company_job_postings and student jobs feed', () => {
      // Mock localStorage container
      const mockStorage: Record<string, string> = {};
      const storageSet = (k: string, v: any) => { mockStorage[k] = JSON.stringify(v); };
      const storageGet = <T>(k: string, fallback: T): T => {
        return mockStorage[k] ? JSON.parse(mockStorage[k]) : fallback;
      };

      // 1. Company creates job and saves to storage
      const initialJobs = [...initialCompanyJobPostings];
      storageSet('company_job_postings', initialJobs);

      // 2. Student portal reads postings from storage
      const loadedPostings = storageGet<CompanyJobPosting[]>('company_job_postings', []);
      assert.strictEqual(loadedPostings.length, initialJobs.length);
      assert.strictEqual(loadedPostings[0].id, initialJobs[0].id);

      // 3. Candidate applies and record is stored in company_applicant_records
      const testApplicant: CompanyApplicantRecord = {
        id: 'appl_sync_test',
        jobId: loadedPostings[0].id,
        jobTitle: loadedPostings[0].title,
        companyId: loadedPostings[0].companyId,
        studentId: 'std_snehal_kale',
        candidateName: 'Snehal Kale',
        candidateEmail: 'snehal.kale@vpkbiet.ac.in',
        candidateCollege: 'VPKBIET',
        candidateDegree: 'B.E.',
        candidateBranch: 'AI & DS',
        candidateGraduationYear: '2025',
        appliedDate: '2026-10-14',
        status: 'Applied',
        matchScore: 92,
        verifiedSkills: ['SQL', 'Python'],
        hasSharedResume: true,
        hasSharedPortfolio: true,
      };

      storageSet('company_applicant_records', [testApplicant]);

      // 4. Verify data persistence across re-instantiation (simulating refresh)
      const persistedApplicants = storageGet<CompanyApplicantRecord[]>('company_applicant_records', []);
      assert.strictEqual(persistedApplicants.length, 1);
      assert.strictEqual(persistedApplicants[0].candidateName, 'Snehal Kale');
      assert.strictEqual(persistedApplicants[0].jobId, loadedPostings[0].id);
    });
  });
});
