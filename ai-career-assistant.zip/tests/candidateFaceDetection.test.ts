import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  FacePresenceMonitor,
  FaceDetectorAdapter,
  FaceDetectionResult,
  FaceDetectorStatus,
  BrowserNativeFaceDetectorAdapter,
  UnsupportedFaceDetectorAdapter,
  createDefaultFaceDetectorAdapter
} from '../src/services/faceDetectionService.ts';
import { IntegrityViolationEvent } from '../src/services/interviewService.ts';
import { isViolationSuppressedByCooldown } from '../src/hooks/useInterviewProctoring.ts';

// Helper mock adapter
class MockFaceDetectorAdapter implements FaceDetectorAdapter {
  readonly name = 'MockFaceDetector';
  public supported = true;
  public initSucceeds = true;
  public faceDetectedState = true;
  public faceCount = 1;
  public throwErrorOnDetect = false;
  public throwErrorCount = 0;
  public isDestroyed = false;
  public detectCallCount = 0;

  isSupported(): boolean {
    return this.supported;
  }

  async init(): Promise<boolean> {
    return this.initSucceeds;
  }

  async detect(): Promise<FaceDetectionResult> {
    this.detectCallCount++;
    if (this.throwErrorOnDetect) {
      throw new Error('Simulated transient detector failure');
    }
    if (this.throwErrorCount > 0) {
      this.throwErrorCount--;
      throw new Error('Simulated single-frame glitch');
    }
    return {
      faceDetected: this.faceDetectedState,
      faceCount: this.faceDetectedState ? this.faceCount : 0
    };
  }

  destroy(): void {
    this.isDestroyed = true;
  }
}

describe('Candidate Face-Presence Detection Proctoring Tests', () => {
  // Mock element source getter
  const dummyVideoElement = {} as unknown as HTMLVideoElement;
  const mockSourceGetter = () => dummyVideoElement;

  it('1. Face present: no warning emitted', async () => {
    let fakeTime = 1000;
    const violations: Array<{ type: string; description: string }> = [];
    const adapter = new MockFaceDetectorAdapter();
    adapter.faceDetectedState = true;

    const monitor = new FacePresenceMonitor({
      adapter,
      intervalMs: 1000,
      gracePeriodMs: 5000,
      getCurrentTime: () => fakeTime,
      onViolation: (type, description) => {
        violations.push({ type, description });
      }
    });

    await monitor.start(mockSourceGetter);

    // Simulate 10 seconds of candidate facing the camera
    for (let i = 0; i < 10; i++) {
      fakeTime += 1000;
      await monitor.tick();
    }

    assert.strictEqual(violations.length, 0, 'No violations should occur when face is present');
    assert.strictEqual(monitor.getIsFacePresent(), true);
    assert.strictEqual(monitor.getStatus(), 'active');

    monitor.destroy();
  });

  it('2. Face absent beyond the grace period: warning recorded', async () => {
    let fakeTime = 0;
    const violations: Array<{ type: string; description: string }> = [];
    const adapter = new MockFaceDetectorAdapter();
    adapter.faceDetectedState = true;

    const monitor = new FacePresenceMonitor({
      adapter,
      intervalMs: 1000,
      gracePeriodMs: 5000,
      getCurrentTime: () => fakeTime,
      onViolation: (type, description) => {
        violations.push({ type, description });
      }
    });

    await monitor.start(mockSourceGetter);
    assert.strictEqual(violations.length, 0);

    // Candidate leaves camera frame at t = 1000
    adapter.faceDetectedState = false;
    fakeTime = 1000;
    await monitor.tick();
    assert.strictEqual(violations.length, 0, 'No warning immediately upon leaving (grace period active)');
    assert.strictEqual(monitor.getIsFacePresent(), false);

    // t = 3000 (2s absent)
    fakeTime = 3000;
    await monitor.tick();
    assert.strictEqual(violations.length, 0, 'No warning at 2s absent');

    // t = 5999 (4.999s absent)
    fakeTime = 5999;
    await monitor.tick();
    assert.strictEqual(violations.length, 0, 'No warning before 5s grace period expires');

    // t = 6000 (exactly 5s absent: 6000 - 1000 = 5000ms >= gracePeriodMs)
    fakeTime = 6000;
    await monitor.tick();
    assert.strictEqual(violations.length, 1, 'Warning must be recorded after grace period expires');
    assert.strictEqual(violations[0].type, 'face_missing');
    assert.match(violations[0].description, /not visible in camera view/i);

    monitor.destroy();
  });

  it('3. Face returns: absence timer resets', async () => {
    let fakeTime = 1000;
    const violations: Array<{ type: string; description: string }> = [];
    const adapter = new MockFaceDetectorAdapter();

    const monitor = new FacePresenceMonitor({
      adapter,
      intervalMs: 1000,
      gracePeriodMs: 5000,
      getCurrentTime: () => fakeTime,
      onViolation: (type, description) => {
        violations.push({ type, description });
      }
    });

    await monitor.start(mockSourceGetter);

    // Candidate leaves at t = 2000
    adapter.faceDetectedState = false;
    fakeTime = 2000;
    await monitor.tick();

    // Absent for 3 seconds (t = 5000)
    fakeTime = 5000;
    await monitor.tick();
    assert.strictEqual(violations.length, 0, 'No warning because absence was only 3 seconds');

    // Candidate returns to camera view at t = 6000
    adapter.faceDetectedState = true;
    fakeTime = 6000;
    await monitor.tick();
    assert.strictEqual(monitor.getIsFacePresent(), true);
    assert.strictEqual(monitor.getAbsenceDuration(), 0, 'Absence duration should be 0 when face returns');

    // Candidate leaves AGAIN at t = 7000
    adapter.faceDetectedState = false;
    fakeTime = 7000;
    await monitor.tick();

    // At t = 11000 (4 seconds after second departure, not 5)
    fakeTime = 11000;
    await monitor.tick();
    assert.strictEqual(violations.length, 0, 'Timer was reset; 4 seconds into new absence must not trigger warning');

    // At t = 12000 (5 seconds after second departure: 12000 - 7000 = 5000ms)
    fakeTime = 12000;
    await monitor.tick();
    assert.strictEqual(violations.length, 1, 'Warning issued once new continuous absence reaches grace period');

    monitor.destroy();
  });

  it('4. Temporary detector failure: tolerance avoids false warnings', async () => {
    let fakeTime = 1000;
    const violations: Array<{ type: string; description: string }> = [];
    const adapter = new MockFaceDetectorAdapter();
    adapter.faceDetectedState = true;
    adapter.throwErrorCount = 2; // Glitch for 2 frames, then recover

    const monitor = new FacePresenceMonitor({
      adapter,
      intervalMs: 1000,
      gracePeriodMs: 5000,
      maxTransientErrors: 3,
      getCurrentTime: () => fakeTime,
      onViolation: (type, description) => {
        violations.push({ type, description });
      }
    });

    await monitor.start(mockSourceGetter);

    // Frame 1 with glitch
    fakeTime += 1000;
    await monitor.tick();
    assert.strictEqual(violations.length, 0, 'Transient error 1 does not trigger violation');
    assert.strictEqual(monitor.getStatus(), 'active');

    // Frame 2 with glitch
    fakeTime += 1000;
    await monitor.tick();
    assert.strictEqual(violations.length, 0, 'Transient error 2 does not trigger violation');
    assert.strictEqual(monitor.getStatus(), 'active');

    // Frame 3 recovers
    fakeTime += 1000;
    await monitor.tick();
    assert.strictEqual(violations.length, 0);
    assert.strictEqual(monitor.getStatus(), 'active');
    assert.strictEqual(monitor.getIsFacePresent(), true);

    monitor.destroy();
  });

  it('5. Persistent detector error: transitions to error status without crashing or false violations', async () => {
    let fakeTime = 1000;
    const violations: Array<{ type: string; description: string }> = [];
    let recordedStatus: FaceDetectorStatus = 'idle';
    const adapter = new MockFaceDetectorAdapter();
    adapter.throwErrorOnDetect = true; // Always fails

    const monitor = new FacePresenceMonitor({
      adapter,
      intervalMs: 1000,
      gracePeriodMs: 5000,
      maxTransientErrors: 2,
      getCurrentTime: () => fakeTime,
      onViolation: (type, description) => {
        violations.push({ type, description });
      },
      onStatusChange: (status) => {
        recordedStatus = status;
      }
    });

    await monitor.start(mockSourceGetter);

    // Tick 1 (error 1)
    fakeTime += 1000;
    await monitor.tick();
    assert.strictEqual(violations.length, 0);

    // Tick 2 (error 2)
    fakeTime += 1000;
    await monitor.tick();
    assert.strictEqual(violations.length, 0);

    // Tick 3 (error 3 > maxTransientErrors of 2)
    fakeTime += 1000;
    await monitor.tick();
    assert.strictEqual(violations.length, 0, 'Detector error must not falsely trigger face missing violation');
    assert.strictEqual(monitor.getStatus(), 'error');
    assert.strictEqual(recordedStatus, 'error');

    monitor.destroy();
  });

  it('6. Detector unsupported or initialization failure: clear status and safe fallback behavior', async () => {
    // A: Unsupported environment
    const unsupportedAdapter = new UnsupportedFaceDetectorAdapter();
    assert.strictEqual(unsupportedAdapter.isSupported(), false);

    let statusUpdate = '';
    const violations: Array<{ type: string; description: string }> = [];

    const monitorUnsupported = new FacePresenceMonitor({
      adapter: unsupportedAdapter,
      onViolation: (type, description) => {
        violations.push({ type, description });
      },
      onStatusChange: (status, msg) => {
        statusUpdate = status;
      }
    });

    await monitorUnsupported.start(mockSourceGetter);
    assert.strictEqual(monitorUnsupported.getStatus(), 'unsupported');
    assert.strictEqual(statusUpdate, 'unsupported');
    assert.match(monitorUnsupported.getStatusMessage(), /unavailable/i);
    assert.strictEqual(violations.length, 0);

    // B: Initialization failure
    const failingInitAdapter = new MockFaceDetectorAdapter();
    failingInitAdapter.initSucceeds = false;

    let initFailStatus = '';
    const monitorInitFail = new FacePresenceMonitor({
      adapter: failingInitAdapter,
      onViolation: (type, description) => {
        violations.push({ type, description });
      },
      onStatusChange: (status) => {
        initFailStatus = status;
      }
    });

    await monitorInitFail.start(mockSourceGetter);
    assert.strictEqual(monitorInitFail.getStatus(), 'error');
    assert.strictEqual(initFailStatus, 'error');
    assert.strictEqual(violations.length, 0);

    monitorUnsupported.destroy();
    monitorInitFail.destroy();
  });

  it('7. No duplicate warnings during one continuous absence', async () => {
    let fakeTime = 1000;
    const violations: Array<{ type: string; description: string }> = [];
    const adapter = new MockFaceDetectorAdapter();
    adapter.faceDetectedState = false; // Absent from start

    const monitor = new FacePresenceMonitor({
      adapter,
      intervalMs: 1000,
      gracePeriodMs: 5000,
      getCurrentTime: () => fakeTime,
      onViolation: (type, description) => {
        violations.push({ type, description });
      }
    });

    await monitor.start(mockSourceGetter);

    // t = 1000..5000 (grace period)
    for (let t = 2000; t <= 5000; t += 1000) {
      fakeTime = t;
      await monitor.tick();
    }
    assert.strictEqual(violations.length, 0);

    // t = 6000 (5000ms elapsed since absence start at t=1000)
    fakeTime = 6000;
    await monitor.tick();
    assert.strictEqual(violations.length, 1, 'First warning triggered at grace period threshold');

    // Candidate continues to be absent for 10 more seconds (continuous absence)
    for (let t = 7000; t <= 17000; t += 1000) {
      fakeTime = t;
      await monitor.tick();
    }

    assert.strictEqual(
      violations.length,
      1,
      'No repeated warnings should be emitted during the same continuous absence'
    );

    monitor.destroy();
  });

  it('8. Existing warning escalation and termination behavior remains intact with face_missing', () => {
    // Simulate four integrity events, with face_missing participating in the 3-warning escalation and termination
    const testEvents: IntegrityViolationEvent[] = [];

    const handleViolation = (type: IntegrityViolationEvent['type'], desc: string) => {
      const event: IntegrityViolationEvent = {
        type,
        timestamp: '12:00:00',
        description: desc
      };
      testEvents.push(event);
      return testEvents.length;
    };

    // Violation 1: face_missing
    const c1 = handleViolation('face_missing', 'Candidate is not visible in camera view.');
    assert.strictEqual(c1, 1);
    assert.strictEqual(testEvents[0].type, 'face_missing');

    // Violation 2: fullscreen_exit
    const c2 = handleViolation('fullscreen_exit', 'Fullscreen was exited.');
    assert.strictEqual(c2, 2);

    // Violation 3: tab_switch
    const c3 = handleViolation('tab_switch', 'Interview page was left.');
    assert.strictEqual(c3, 3);

    // Violation 4: second face_missing event (after candidate left again) triggers termination threshold
    const c4 = handleViolation('face_missing', 'Candidate is not visible in camera view.');
    assert.strictEqual(c4, 4);

    // 4 violations triggers termination
    const shouldTerminate = c4 >= 4;
    assert.strictEqual(shouldTerminate, true, 'Fourth violation triggers termination flow');
    assert.strictEqual(testEvents.length, 4);
  });

  it('9. Cleanup occurs when the interview ends', async () => {
    const adapter = new MockFaceDetectorAdapter();
    const monitor = new FacePresenceMonitor({
      adapter,
      intervalMs: 1000,
      onViolation: () => {}
    });

    await monitor.start(mockSourceGetter);
    assert.strictEqual(monitor.getStatus(), 'active');
    assert.strictEqual(adapter.isDestroyed, false);

    monitor.destroy();
    assert.strictEqual(monitor.getStatus(), 'disposed');
    assert.strictEqual(adapter.isDestroyed, true, 'Adapter resources must be destroyed on cleanup');
  });

  it('10. Privacy verification: adapter does not retain frame buffers or transmit data', async () => {
    const adapter = new BrowserNativeFaceDetectorAdapter();
    // Verify adapter interface
    assert.strictEqual(adapter.name, 'BrowserNativeFaceDetector');
    assert.strictEqual(typeof adapter.isSupported, 'function');
    assert.strictEqual(typeof adapter.init, 'function');
    assert.strictEqual(typeof adapter.detect, 'function');
    assert.strictEqual(typeof adapter.destroy, 'function');

    // Default factory returns appropriate adapter for environment
    const defaultAdapter = createDefaultFaceDetectorAdapter();
    assert.ok(defaultAdapter);
    assert.strictEqual(typeof defaultAdapter.isSupported, 'function');
  });

  it('11. Cooldown suppression exemption: another violation within 1800ms does NOT suppress face_missing', async () => {
    // 1. Direct unit verification of isViolationSuppressedByCooldown:
    // Tab switch at t = 1000 with last violation at t = 0 (1000ms > 0): not suppressed
    assert.strictEqual(
      isViolationSuppressedByCooldown('tab_switch', 1000, 0, 1800),
      false,
      'Initial violation outside cooldown window should not be suppressed'
    );

    // Rapid second OS event at t = 1300 (only 300ms after t = 1000): suppressed
    assert.strictEqual(
      isViolationSuppressedByCooldown('window_blur', 1300, 1000, 1800),
      true,
      'Rapid concurrent OS event within 1800ms cooldown must be suppressed'
    );

    // face_missing at t = 1500 (only 500ms after t = 1000): MUST NOT BE SUPPRESSED
    assert.strictEqual(
      isViolationSuppressedByCooldown('face_missing', 1500, 1000, 1800),
      false,
      'face_missing must be exempt from 1800ms cooldown'
    );

    // 2. State-machine integration verification:
    // Simulate violation recorder state matching useInterviewProctoring
    let lastViolationTime = 0;
    const recordedEvents: IntegrityViolationEvent[] = [];

    const recordViolation = (type: IntegrityViolationEvent['type'], desc: string, eventTime: number) => {
      if (isViolationSuppressedByCooldown(type, eventTime, lastViolationTime, 1800)) {
        return false;
      }
      lastViolationTime = eventTime;
      recordedEvents.push({
        type,
        timestamp: new Date(eventTime).toISOString(),
        description: desc
      });
      return true;
    };

    // Step A: Candidate switches tabs at t = 1000 (Warning 1)
    const rec1 = recordViolation('tab_switch', 'Interview page was left.', 1000);
    assert.strictEqual(rec1, true, 'First event recorded');
    assert.strictEqual(recordedEvents.length, 1);

    // Step B: Window blur arrives 200ms later at t = 1200 -> suppressed by cooldown
    const rec2 = recordViolation('window_blur', 'Window lost focus.', 1200);
    assert.strictEqual(rec2, false, 'Rapid secondary OS event suppressed');
    assert.strictEqual(recordedEvents.length, 1);

    // Step C: Face monitor finishes continuous 5s absence check and emits face_missing at t = 1500
    // (only 500ms after tab_switch, within the 1800ms window)
    const rec3 = recordViolation(
      'face_missing',
      'Candidate is not visible in camera view. Please remain in front of the camera throughout the interview.',
      1500
    );
    assert.strictEqual(rec3, true, 'face_missing event successfully recorded despite falling within 1800ms cooldown');
    assert.strictEqual(recordedEvents.length, 2);
    assert.strictEqual(recordedEvents[1].type, 'face_missing');

    // Step D: Verify that continuous absence deduplication prevents repeated warnings
    const adapter = new MockFaceDetectorAdapter();
    adapter.faceDetectedState = false; // absent
    let fakeTime = 1500;
    const monitorViolations: string[] = [];

    const monitor = new FacePresenceMonitor({
      adapter,
      intervalMs: 1000,
      gracePeriodMs: 5000,
      getCurrentTime: () => fakeTime,
      onViolation: (type) => {
        monitorViolations.push(type);
      }
    });

    await monitor.start(mockSourceGetter);

    // Advance 5s to trigger violation
    fakeTime = 6500;
    await monitor.tick();
    assert.strictEqual(monitorViolations.length, 1);

    // Advance 10 more seconds while candidate remains absent: no duplicate violations
    for (let t = 7500; t <= 17500; t += 1000) {
      fakeTime = t;
      await monitor.tick();
    }
    assert.strictEqual(monitorViolations.length, 1, 'Continuous absence deduplication preserved');

    // Step E: Candidate returns -> absence timer resets
    adapter.faceDetectedState = true;
    fakeTime = 18500;
    await monitor.tick();
    assert.strictEqual(monitor.getIsFacePresent(), true);
    assert.strictEqual(monitor.getAbsenceDuration(), 0, 'Absence duration resets to 0 on return');

    monitor.destroy();
  });

  it('12. Reproducible 8-second continuous absence verification: warning triggers after 5s and deduplicates through 8s+', async () => {
    let fakeTime = 1000;
    const recordedViolations: Array<{ type: string; desc: string }> = [];
    const adapter = new MockFaceDetectorAdapter();
    adapter.faceDetectedState = true; // initially visible

    const monitor = new FacePresenceMonitor({
      adapter,
      intervalMs: 1000,
      gracePeriodMs: 5000,
      getCurrentTime: () => fakeTime,
      onViolation: (type, desc) => {
        recordedViolations.push({ type, desc });
      }
    });

    await monitor.start(mockSourceGetter);
    assert.strictEqual(monitor.getIsFacePresent(), true);
    assert.strictEqual(recordedViolations.length, 0);

    // Candidate leaves the frame at t = 2000
    adapter.faceDetectedState = false;
    fakeTime = 2000;
    await monitor.tick(); // Absence starts at t = 2000
    assert.strictEqual(monitor.getIsFacePresent(), false);
    assert.strictEqual(recordedViolations.length, 0, 'No warning at 0s of absence');
    assert.strictEqual(monitor.getAbsenceDuration(), 0);

    // 1 second out of frame (t = 3000)
    fakeTime = 3000;
    await monitor.tick();
    assert.strictEqual(recordedViolations.length, 0, 'No warning at 1s of absence');
    assert.strictEqual(monitor.getAbsenceDuration(), 1000);

    // 2 seconds out of frame (t = 4000)
    fakeTime = 4000;
    await monitor.tick();
    assert.strictEqual(recordedViolations.length, 0, 'No warning at 2s of absence');
    assert.strictEqual(monitor.getAbsenceDuration(), 2000);

    // 3 seconds out of frame (t = 5000)
    fakeTime = 5000;
    await monitor.tick();
    assert.strictEqual(recordedViolations.length, 0, 'No warning at 3s of absence');
    assert.strictEqual(monitor.getAbsenceDuration(), 3000);

    // 4 seconds out of frame (t = 6000)
    fakeTime = 6000;
    await monitor.tick();
    assert.strictEqual(recordedViolations.length, 0, 'No warning at 4s of absence');
    assert.strictEqual(monitor.getAbsenceDuration(), 4000);

    // 5 seconds out of frame (t = 7000, exactly 5000ms: 7000 - 2000 = 5000ms >= gracePeriodMs)
    fakeTime = 7000;
    await monitor.tick();
    assert.strictEqual(recordedViolations.length, 1, 'Warning triggers at exactly 5 seconds of absence');
    assert.strictEqual(recordedViolations[0].type, 'face_missing');
    assert.strictEqual(monitor.getAbsenceDuration(), 5000);

    // 6 seconds out of frame (t = 8000)
    fakeTime = 8000;
    await monitor.tick();
    assert.strictEqual(recordedViolations.length, 1, 'Continuous absence deduplicated at 6s');
    assert.strictEqual(monitor.getAbsenceDuration(), 6000);

    // 7 seconds out of frame (t = 9000)
    fakeTime = 9000;
    await monitor.tick();
    assert.strictEqual(recordedViolations.length, 1, 'Continuous absence deduplicated at 7s');
    assert.strictEqual(monitor.getAbsenceDuration(), 7000);

    // 8 seconds out of frame (t = 10000)
    fakeTime = 10000;
    await monitor.tick();
    assert.strictEqual(recordedViolations.length, 1, 'Continuous absence deduplicated at 8s');
    assert.strictEqual(monitor.getAbsenceDuration(), 8000);

    // Candidate returns at t = 11000
    adapter.faceDetectedState = true;
    fakeTime = 11000;
    await monitor.tick();
    assert.strictEqual(monitor.getIsFacePresent(), true);
    assert.strictEqual(monitor.getAbsenceDuration(), 0, 'Absence duration resets to 0 on candidate return');
    assert.strictEqual(recordedViolations.length, 1);

    monitor.destroy();
  });
});

