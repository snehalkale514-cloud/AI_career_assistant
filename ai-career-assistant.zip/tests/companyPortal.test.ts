import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  initialCompanyProfiles,
  initialCompanyUsers,
  initialCompanyJobPostings,
  initialCompanyApplicants,
} from '../src/data/companyMockData.ts';
import { CompanyProfile, CompanyUser, CompanyJobPosting, CompanyApplicantRecord } from '../src/types.ts';

describe('Company / Recruiter Portal Functional & Security Tests', () => {
  // =========================================================================
  // 1. Initial State & Data Model Integrity
  // =========================================================================
  it('initializes verified company profiles and recruiter accounts with company role', () => {
    assert.ok(initialCompanyProfiles.length >= 2, 'Must have at least 2 demo company profiles');
    
    const technova = initialCompanyProfiles.find((c) => c.id === 'comp_technova');
    assert.ok(technova, 'TechNova Solutions profile must exist');
    assert.strictEqual(technova?.verified, true);
    assert.strictEqual(technova?.name, 'TechNova Solutions');

    const technovaRecruiter = initialCompanyUsers.find((u) => u.companyId === 'comp_technova');
    assert.ok(technovaRecruiter, 'TechNova recruiter user must exist');
    assert.strictEqual(technovaRecruiter?.role, 'company', 'Must have role company');
    assert.strictEqual(technovaRecruiter?.email, 'recruiter@technova.com');
  });

  // =========================================================================
  // 2. Company Registration Validation
  // =========================================================================
  it('validates required fields on company registration', () => {
    // Pure logic validation simulating registerCompany
    const validateRegistration = (params: { companyName: string; recruiterEmail: string; recruiterName: string }) => {
      if (!params.companyName.trim() || !params.recruiterEmail.trim() || !params.recruiterName.trim()) {
        return { success: false, error: 'Company name, recruiter name, and work email are required.' };
      }
      return { success: true };
    };

    assert.strictEqual(
      validateRegistration({ companyName: '', recruiterEmail: 'hr@test.com', recruiterName: 'John' }).success,
      false,
      'Fails when company name is empty'
    );
    assert.strictEqual(
      validateRegistration({ companyName: 'Acme', recruiterEmail: '', recruiterName: 'John' }).success,
      false,
      'Fails when recruiter email is empty'
    );
    assert.strictEqual(
      validateRegistration({ companyName: 'Acme', recruiterEmail: 'hr@test.com', recruiterName: '' }).success,
      false,
      'Fails when recruiter name is empty'
    );
    assert.strictEqual(
      validateRegistration({ companyName: 'Acme', recruiterEmail: 'hr@test.com', recruiterName: 'John' }).success,
      true,
      'Succeeds when required fields are present'
    );
  });

  // =========================================================================
  // 3. Multi-Company Posting Isolation (RBAC)
  // =========================================================================
  it('prevents one company from editing or deleting postings belonging to another company', () => {
    const technovaUser: CompanyUser = initialCompanyUsers.find((u) => u.companyId === 'comp_technova')!;
    const analyticshubUser: CompanyUser = initialCompanyUsers.find((u) => u.companyId === 'comp_analyticshub')!;

    const technovaJob = initialCompanyJobPostings.find((j) => j.companyId === 'comp_technova')!;
    const analyticshubJob = initialCompanyJobPostings.find((j) => j.companyId === 'comp_analyticshub')!;

    // Isolation check logic as implemented in CompanyContext
    const canModifyPosting = (currentUser: CompanyUser, targetPosting: CompanyJobPosting) => {
      if (!currentUser || currentUser.role !== 'company') return false;
      return targetPosting.companyId === currentUser.companyId;
    };

    // TechNova recruiter can modify TechNova job
    assert.strictEqual(
      canModifyPosting(technovaUser, technovaJob),
      true,
      'TechNova recruiter CAN modify TechNova postings'
    );

    // TechNova recruiter CANNOT modify AnalyticsHub job
    assert.strictEqual(
      canModifyPosting(technovaUser, analyticshubJob),
      false,
      'TechNova recruiter CANNOT modify AnalyticsHub postings'
    );

    // AnalyticsHub recruiter CANNOT modify TechNova job
    assert.strictEqual(
      canModifyPosting(analyticshubUser, technovaJob),
      false,
      'AnalyticsHub recruiter CANNOT modify TechNova postings'
    );
  });

  // =========================================================================
  // 4. Candidate Privacy & Application Gating
  // =========================================================================
  it('strictly isolates student candidate records to the company they applied to', () => {
    const technovaUser = initialCompanyUsers.find((u) => u.companyId === 'comp_technova')!;
    const analyticshubUser = initialCompanyUsers.find((u) => u.companyId === 'comp_analyticshub')!;

    const canViewApplicant = (currentUser: CompanyUser, applicant: CompanyApplicantRecord) => {
      if (!currentUser || currentUser.role !== 'company') return false;
      return applicant.companyId === currentUser.companyId;
    };

    // Applicant specifically applied to TechNova
    const technovaApplicant = initialCompanyApplicants.find((a) => a.companyId === 'comp_technova')!;
    assert.strictEqual(
      canViewApplicant(technovaUser, technovaApplicant),
      true,
      'TechNova recruiter CAN view TechNova applicant'
    );

    // AnalyticsHub recruiter CANNOT view applicant who applied only to TechNova
    assert.strictEqual(
      canViewApplicant(analyticshubUser, technovaApplicant),
      false,
      'AnalyticsHub recruiter CANNOT view candidate who only applied to TechNova'
    );
  });

  // =========================================================================
  // 5. Job Posting Lifecycle: Create, Publish, Close, and Re-open
  // =========================================================================
  it('supports full lifecycle of job postings (Draft -> Published -> Closed -> Published)', () => {
    let posting: CompanyJobPosting = {
      id: 'job_test_1',
      companyId: 'comp_technova',
      companyName: 'TechNova Solutions',
      title: 'Data Science Intern',
      type: 'Internship',
      workplace: 'Remote',
      location: 'Pune / Remote',
      experience: '0–1 years',
      salary: '₹20,000 / month',
      requiredSkills: ['Python', 'SQL', 'Machine Learning'],
      description: 'Test internship opening',
      responsibilities: ['Build ML pipelines'],
      requirements: ['BTech AI & DS'],
      status: 'Draft',
      postedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      applicantsCount: 0,
    };

    assert.strictEqual(posting.status, 'Draft');

    // Publish
    posting = { ...posting, status: 'Published', updatedAt: new Date().toISOString() };
    assert.strictEqual(posting.status, 'Published');

    // Close
    posting = { ...posting, status: 'Closed', updatedAt: new Date().toISOString() };
    assert.strictEqual(posting.status, 'Closed');

    // Re-open
    posting = { ...posting, status: 'Published', updatedAt: new Date().toISOString() };
    assert.strictEqual(posting.status, 'Published');
  });

  // =========================================================================
  // 6. Applicant Status Progression & Next Steps Notes
  // =========================================================================
  it('records valid applicant recruitment stage progression', () => {
    const validStages: CompanyApplicantRecord['status'][] = [
      'Applied',
      'Screening',
      'Assessment',
      'Interview',
      'Shortlisted',
      'Offer',
      'Rejected',
    ];

    let candidate = { ...initialCompanyApplicants[0] };
    assert.strictEqual(candidate.status, 'Interview');

    for (const nextStage of validStages) {
      candidate = { ...candidate, status: nextStage, notes: `Advanced to ${nextStage}` };
      assert.strictEqual(candidate.status, nextStage);
      assert.strictEqual(candidate.notes, `Advanced to ${nextStage}`);
    }
  });
});
