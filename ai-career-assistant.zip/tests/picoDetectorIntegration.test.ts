import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {
  unpackPicoCascade,
  runPicoCascade,
  clusterPicoDetections,
  rgbaToGrayscale
} from '../src/services/picoDetector.ts';
import { getFacefinderModelBytes } from '../src/assets/facefinderModel.ts';
import {
  PicoCascadeFaceDetectorAdapter,
  BrowserNativeFaceDetectorAdapter,
  UnsupportedFaceDetectorAdapter,
  createDefaultFaceDetectorAdapter,
  FacePresenceMonitor
} from '../src/services/faceDetectionService.ts';
import {
  getRealFaceFixture,
  getBlankNoFaceFixture,
  getNoiseNoFaceFixture
} from './fixtures/faceFixtures.ts';

describe('Pico Face Detector & Genuine Model Verification Tests', () => {
  // =========================================================================
  // 1. Genuine Cascade Model Parsing and Checksum
  // =========================================================================
  it('correctly loads and validates the pinned official facefinder cascade model', () => {
    const bytes = getFacefinderModelBytes();

    // Check exact byte length
    assert.strictEqual(
      bytes.length,
      239632,
      'Model must match exact official byte count (239,632 bytes)'
    );

    // Check SHA-256 integrity
    const hash = crypto.createHash('sha256').update(bytes).digest('hex');
    assert.strictEqual(
      hash,
      'd8014993e7298c7b1865d1f8b855d6dbf4ec5c808bf879e2091ab6837abf90cd',
      'Model SHA-256 must match official pinned facefinder release'
    );

    // Unpack cascade and verify classification function closure
    const classifyRegion = unpackPicoCascade(bytes);
    assert.strictEqual(typeof classifyRegion, 'function');
  });

  // =========================================================================
  // 2. Real Face Image Fixture Detection (True Positive Verification)
  // =========================================================================
  it('detects a genuine face in the real image fixture with high confidence score', () => {
    const bytes = getFacefinderModelBytes();
    const classifyRegion = unpackPicoCascade(bytes);
    const fixture = getRealFaceFixture();

    const params = {
      shiftfactor: 0.1,
      minsize: 20,
      maxsize: 120,
      scalefactor: 1.1
    };

    const rawDets = runPicoCascade(
      {
        pixels: fixture.pixels,
        nrows: fixture.nrows,
        ncols: fixture.ncols,
        ldim: fixture.ncols
      },
      classifyRegion,
      params
    );

    assert.ok(rawDets.length > 0, 'Real face fixture must yield raw candidate detections');

    const clusters = clusterPicoDetections(rawDets, 0.2);
    assert.ok(clusters.length > 0, 'Clustering must yield at least one face cluster');

    const topCluster = clusters[0];
    const topScore = topCluster[3];

    // Real face confidence must comfortably exceed detection threshold (15.0)
    assert.ok(
      topScore >= 25.0,
      `Real face score (${topScore.toFixed(2)}) must exceed conservative confidence cutoff`
    );
  });

  // =========================================================================
  // 3. Genuine No-Face Fixtures (True Negative & Rejection Verification)
  // =========================================================================
  it('produces zero detections on blank camera frame (pitch black / covered camera)', () => {
    const bytes = getFacefinderModelBytes();
    const classifyRegion = unpackPicoCascade(bytes);
    const blank = getBlankNoFaceFixture();

    const params = {
      shiftfactor: 0.1,
      minsize: 20,
      maxsize: 120,
      scalefactor: 1.1
    };

    const rawDets = runPicoCascade(
      {
        pixels: blank.pixels,
        nrows: blank.nrows,
        ncols: blank.ncols,
        ldim: blank.ncols
      },
      classifyRegion,
      params
    );

    assert.strictEqual(rawDets.length, 0, 'Blank canvas must produce 0 raw detections');
    const clusters = clusterPicoDetections(rawDets, 0.2);
    assert.strictEqual(clusters.length, 0, 'Blank canvas must produce 0 clustered faces');
  });

  it('produces zero detections on pseudo-random noise texture', () => {
    const bytes = getFacefinderModelBytes();
    const classifyRegion = unpackPicoCascade(bytes);
    const noise = getNoiseNoFaceFixture();

    const params = {
      shiftfactor: 0.1,
      minsize: 20,
      maxsize: 120,
      scalefactor: 1.1
    };

    const rawDets = runPicoCascade(
      {
        pixels: noise.pixels,
        nrows: noise.nrows,
        ncols: noise.ncols,
        ldim: noise.ncols
      },
      classifyRegion,
      params
    );

    const clusters = clusterPicoDetections(rawDets, 0.2);
    const confidentFaces = clusters.filter((c) => c[3] >= 15.0);
    assert.strictEqual(confidentFaces.length, 0, 'Random noise must produce 0 confident faces');
  });

  // =========================================================================
  // 4. PicoCascadeFaceDetectorAdapter Lifecycle & Detection
  // =========================================================================
  it('initializes PicoCascadeFaceDetectorAdapter and detects real vs no-face source', async () => {
    const adapter = new PicoCascadeFaceDetectorAdapter();
    assert.strictEqual(adapter.name, 'PicoCascadeFaceDetector');
    assert.strictEqual(adapter.isSupported(), true);

    const initSuccess = await adapter.init();
    assert.strictEqual(initSuccess, true, 'Adapter initialization must succeed');

    // Create a mock canvas/source that provides real face grayscale pixels
    const realFixture = getRealFaceFixture();
    const realSourceMock = {
      width: realFixture.width,
      height: realFixture.height,
      _grayscalePixels: realFixture.pixels
    } as unknown as HTMLCanvasElement;

    const realResult = await adapter.detect(realSourceMock);
    assert.strictEqual(realResult.faceDetected, true);
    assert.ok(realResult.faceCount >= 1);
    assert.ok(realResult.confidence! >= 15.0);
    assert.ok(realResult.boundingBoxes!.length >= 1);

    // Create a mock source that provides blank no-face pixels
    const blankFixture = getBlankNoFaceFixture();
    const blankSourceMock = {
      width: blankFixture.width,
      height: blankFixture.height,
      _grayscalePixels: blankFixture.pixels
    } as unknown as HTMLCanvasElement;

    const blankResult = await adapter.detect(blankSourceMock);
    assert.strictEqual(blankResult.faceDetected, false);
    assert.strictEqual(blankResult.faceCount, 0);
    assert.strictEqual(blankResult.boundingBoxes!.length, 0);

    adapter.destroy();
  });

  // =========================================================================
  // 5. Integration with FacePresenceMonitor (5-Second Grace & Timer Reset)
  // =========================================================================
  it('integrates with FacePresenceMonitor: real face present produces no violation, 5s absence triggers violation', async () => {
    const adapter = new PicoCascadeFaceDetectorAdapter();
    await adapter.init();

    const realFixture = getRealFaceFixture();
    const blankFixture = getBlankNoFaceFixture();

    let currentPixels = realFixture.pixels;
    const sourceMock = {
      width: 160,
      height: 120,
      get _grayscalePixels() {
        return currentPixels;
      }
    } as unknown as HTMLCanvasElement;

    let fakeTime = 1000;
    const violations: Array<{ type: string; description: string }> = [];

    const monitor = new FacePresenceMonitor({
      adapter,
      intervalMs: 1000,
      gracePeriodMs: 5000,
      getCurrentTime: () => fakeTime,
      onViolation: (type, description) => {
        violations.push({ type, description });
      }
    });

    await monitor.start(() => sourceMock);

    // 1. Candidate is present for 5 ticks
    for (let i = 0; i < 5; i++) {
      fakeTime += 1000;
      await monitor.tick();
    }
    assert.strictEqual(violations.length, 0, 'No violations while face is detected');
    assert.strictEqual(monitor.getIsFacePresent(), true);

    // 2. Candidate leaves frame (switches to blank)
    currentPixels = blankFixture.pixels;
    fakeTime += 1000; // t = 7000 (absence begins)
    await monitor.tick();
    assert.strictEqual(violations.length, 0, 'Grace period active; no immediate warning');

    fakeTime += 3000; // t = 10000 (3s absent)
    await monitor.tick();
    assert.strictEqual(violations.length, 0, 'Still within 5-second grace window');

    fakeTime += 2000; // t = 12000 (5s absent: 12000 - 7000 = 5000ms)
    await monitor.tick();
    assert.strictEqual(violations.length, 1, 'Warning recorded when absence reaches 5000ms');
    assert.strictEqual(violations[0].type, 'face_missing');

    // 3. Continuous absence deduplication (stays away for 5 more ticks)
    for (let i = 0; i < 5; i++) {
      fakeTime += 1000;
      await monitor.tick();
    }
    assert.strictEqual(violations.length, 1, 'Continuous absence must not issue duplicate warnings');

    // 4. Candidate returns (switches back to real face)
    currentPixels = realFixture.pixels;
    fakeTime += 1000;
    await monitor.tick();
    assert.strictEqual(monitor.getIsFacePresent(), true);
    assert.strictEqual(monitor.getAbsenceDuration(), 0, 'Absence duration resets when candidate returns');

    // 5. Brief departure under 5 seconds resets cleanly
    currentPixels = blankFixture.pixels;
    fakeTime += 2000; // 2s absent
    await monitor.tick();
    currentPixels = realFixture.pixels; // returns before 5s
    fakeTime += 1000;
    await monitor.tick();
    assert.strictEqual(violations.length, 1, 'Brief absence under 5s must not trigger additional warnings');

    monitor.destroy();
  });

  // =========================================================================
  // 6. Factory Fallback Hierarchy & Graceful Degradation
  // =========================================================================
  it('createDefaultFaceDetectorAdapter chooses Pico when native is unavailable', () => {
    // In Node.js or browsers without window.FaceDetector, default adapter must be PicoCascadeFaceDetector
    const adapter = createDefaultFaceDetectorAdapter();
    assert.strictEqual(
      adapter.name,
      'PicoCascadeFaceDetector',
      'Should automatically select Pico when native FaceDetector is unavailable'
    );
    assert.strictEqual(adapter.isSupported(), true);
  });

  it('FacePresenceMonitor automatically falls back to Pico if native detector initialization fails', async () => {
    // Simulate an adapter that claims isSupported() = false or fails init()
    const unsupportedNative = new BrowserNativeFaceDetectorAdapter();
    let recordedStatus = '';

    const monitor = new FacePresenceMonitor({
      adapter: unsupportedNative,
      onViolation: () => {},
      onStatusChange: (status) => {
        recordedStatus = status;
      }
    });

    const realFixture = getRealFaceFixture();
    const sourceMock = {
      width: 160,
      height: 120,
      _grayscalePixels: realFixture.pixels
    } as unknown as HTMLCanvasElement;

    await monitor.start(() => sourceMock);

    // Monitor should have gracefully fallen back to Pico and reached 'active' status
    assert.strictEqual(monitor.getStatus(), 'active');
    assert.strictEqual(recordedStatus, 'active');

    monitor.destroy();
  });

  // =========================================================================
  // 7. Grayscale Converter Perceptual Weights Verification
  // =========================================================================
  it('correctly converts RGBA pixels to grayscale using ITU-R BT.601 weights', () => {
    // Pure Red: (2 * 255 + 0 + 0) / 10 = 51
    const redRgba = new Uint8Array([255, 0, 0, 255]);
    const redGray = rgbaToGrayscale(redRgba, 1, 1);
    assert.strictEqual(redGray[0], 51);

    // Pure Green: (0 + 7 * 255 + 0) / 10 = 178
    const greenRgba = new Uint8Array([0, 255, 0, 255]);
    const greenGray = rgbaToGrayscale(greenRgba, 1, 1);
    assert.strictEqual(greenGray[0], 178);

    // Pure Blue: (0 + 0 + 1 * 255) / 10 = 25
    const blueRgba = new Uint8Array([0, 0, 255, 255]);
    const blueGray = rgbaToGrayscale(blueRgba, 1, 1);
    assert.strictEqual(blueGray[0], 25);
  });
});
