import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { buildCareerCompanionSnapshot } from '../src/services/careerCompanionService.ts';
import { calculatePlacementReadiness } from '../src/services/placementReadinessService.ts';
import { SYSTEM_INSTRUCTION } from '../server.ts';
import { initialUserProfile, initialSkills, initialRoadmapStages, initialProjects, initialInterviewHistory } from '../src/data/mockData.ts';
import { ApplicationItem, InterviewHistoryItem } from '../src/types.ts';

describe('AI Career Mentor Accuracy Fixes', () => {
  const baseParams = {
    user: initialUserProfile,
    skills: initialSkills,
    roadmapStages: initialRoadmapStages,
    projects: initialProjects,
    interviewHistory: [],
    applications: []
  };

  // =========================================================================
  // ISSUE 1: Missing resume incorrectly described as ATS score 0
  // =========================================================================
  describe('Issue 1: Missing Resume vs. Genuine Numeric Zero', () => {
    it('sets atsScore to null and status to not_attempted when no resume has been uploaded', () => {
      const snapshot = buildCareerCompanionSnapshot({
        ...baseParams,
        resumeAnalysis: {
          hasUploadedResume: false,
          atsScore: 84, // Stored default before upload
          atsCompatibility: 84,
          keywordMatch: 78,
          formattingScore: 90,
          skillsMatch: 82,
          experienceMatch: 75,
          strengths: [],
          missingSkills: [],
          keywordSuggestions: [],
          improvements: [],
          analyzedFileName: ''
        }
      });

      assert.strictEqual(snapshot.resume.hasUploadedResume, false);
      assert.strictEqual(snapshot.resume.status, 'not_attempted');
      assert.strictEqual(snapshot.resume.atsScore, null);
      assert.strictEqual(snapshot.resume.isEvaluatedScore, false);
      assert.notStrictEqual(snapshot.resume.atsScore, 0, 'Missing resume atsScore must be null, NOT numeric zero');
    });

    it('distinguishes a genuine evaluated score of 0 from unattempted/missing data', () => {
      const snapshot = buildCareerCompanionSnapshot({
        ...baseParams,
        resumeAnalysis: {
          hasUploadedResume: true,
          atsScore: 0, // Genuine 0 evaluated from an actual document
          atsCompatibility: 0,
          keywordMatch: 0,
          formattingScore: 10,
          skillsMatch: 0,
          experienceMatch: 0,
          strengths: [],
          missingSkills: ['Python', 'SQL'],
          keywordSuggestions: [],
          improvements: [],
          analyzedFileName: 'blank_resume.pdf'
        }
      });

      assert.strictEqual(snapshot.resume.hasUploadedResume, true);
      assert.strictEqual(snapshot.resume.status, 'analyzed');
      assert.strictEqual(snapshot.resume.atsScore, 0);
      assert.strictEqual(snapshot.resume.isEvaluatedScore, true);
      assert.strictEqual(typeof snapshot.resume.atsScore, 'number');
    });

    it('instructs Career Mentor in system prompt to never claim ATS score 0 for unattempted resumes', () => {
      assert.match(SYSTEM_INSTRUCTION, /NEVER claim their ATS score is 0/i);
      assert.match(SYSTEM_INSTRUCTION, /Missing data is NOT a zero score/i);
      assert.match(SYSTEM_INSTRUCTION, /ONLY when careerContext\.resume\.status === "analyzed" AND careerContext\.resume\.atsScore === 0/i);
    });

    it('instructs Career Mentor to separate evaluation status from numerical calculation placeholder', () => {
      assert.match(SYSTEM_INSTRUCTION, /SEPARATE EVALUATION STATUS FROM NUMERICAL CALCULATION PLACEHOLDER/i);
      assert.match(SYSTEM_INSTRUCTION, /0 internally as a numerical placeholder/i);
      assert.match(SYSTEM_INSTRUCTION, /DO NOT confuse these two concepts/i);
      assert.match(SYSTEM_INSTRUCTION, /Never describe the ATS pillar as a "zero pillar"/i);
    });
  });

  // =========================================================================
  // ISSUE 2: Unsupported fixed readiness increase
  // =========================================================================
  describe('Issue 2: Unsupported Fixed Readiness Increase', () => {
    it('calculates ATS readiness pillar dynamically using 25% weight without hardcoded +6% boost', () => {
      // Benchmark candidate with unuploaded resume (ATS pillar = 0)
      const readinessWithoutResume = calculatePlacementReadiness(
        initialUserProfile,
        initialSkills,
        initialProjects,
        { hasUploadedResume: false, atsScore: 84 },
        [],
        'Data Analyst'
      );

      assert.strictEqual(readinessWithoutResume.componentMetadata.ats.status, 'not_attempted');
      assert.strictEqual(readinessWithoutResume.atsScore, 0);

      // Scenario A: Candidate uploads resume that scores 80
      const readinessWith80 = calculatePlacementReadiness(
        initialUserProfile,
        initialSkills,
        initialProjects,
        { hasUploadedResume: true, atsScore: 80, analyzedFileName: 'resume.pdf' },
        [],
        'Data Analyst'
      );

      // 80 * 0.25 = +20 overall points
      const diff80 = readinessWith80.overallScore - readinessWithoutResume.overallScore;
      assert.strictEqual(diff80, 20, 'ATS score of 80 should increase overall score by 20 points (80 * 0.25)');
      assert.notStrictEqual(diff80, 6, 'Should NOT be a fixed 6% increase');

      // Scenario B: Candidate uploads resume that scores 60
      const readinessWith60 = calculatePlacementReadiness(
        initialUserProfile,
        initialSkills,
        initialProjects,
        { hasUploadedResume: true, atsScore: 60, analyzedFileName: 'resume.pdf' },
        [],
        'Data Analyst'
      );

      // 60 * 0.25 = +15 overall points
      const diff60 = readinessWith60.overallScore - readinessWithoutResume.overallScore;
      assert.strictEqual(diff60, 15, 'ATS score of 60 should increase overall score by 15 points (60 * 0.25)');
      assert.notStrictEqual(diff60, 6, 'Should NOT be a fixed 6% increase');
    });

    it('ensures recommendedActions in placementReadinessService has no hardcoded +6% Readiness string', () => {
      const readinessWithoutResume = calculatePlacementReadiness(
        initialUserProfile,
        initialSkills,
        initialProjects,
        { hasUploadedResume: false, atsScore: 84 },
        [],
        'Data Analyst'
      );

      const resumeAction = readinessWithoutResume.recommendedActions?.find(
        (a) => a.category === 'Resume'
      );
      assert.ok(resumeAction, 'Resume action must exist in recommendedActions');
      assert.notStrictEqual(resumeAction.impact, '+6% Readiness', 'Must not have hardcoded +6% Readiness');
    });

    it('calculates score change accounting for prior ATS contribution when updating an existing resume', () => {
      // Prior analyzed resume with ATS score 60
      const readinessWith60 = calculatePlacementReadiness(
        initialUserProfile,
        initialSkills,
        initialProjects,
        { hasUploadedResume: true, atsScore: 60, analyzedFileName: 'v1.pdf' },
        [],
        'Data Analyst'
      );

      // Candidate improves resume to score 80
      const readinessWith80 = calculatePlacementReadiness(
        initialUserProfile,
        initialSkills,
        initialProjects,
        { hasUploadedResume: true, atsScore: 80, analyzedFileName: 'v2.pdf' },
        [],
        'Data Analyst'
      );

      // Net change is (80 - 60) * 0.25 = +5 points, NOT +20 points (80 * 0.25)
      const diff = readinessWith80.overallScore - readinessWith60.overallScore;
      assert.strictEqual(diff, 5, 'Improvement from 60 to 80 should be +5 points, not +20');
    });

    it('includes authoritative pillar weights and formula transparency in snapshot', () => {
      const snapshot = buildCareerCompanionSnapshot(baseParams);

      assert.deepStrictEqual(snapshot.placementReadiness.pillarWeights, {
        technical: '30%',
        projects: '25%',
        ats: '25%',
        interview: '20%'
      });
      assert.ok(snapshot.placementReadiness.formulaNote.includes('25% weight'));
    });

    it('instructs Career Mentor in system prompt to never promise fixed percentage boosts or claim 6% is a placeholder', () => {
      assert.match(SYSTEM_INSTRUCTION, /NEVER claim "uploading a resume will unlock a 6% boost"/i);
      assert.match(SYSTEM_INSTRUCTION, /ABSOLUTELY NEVER claim that "6%" is a dashboard placeholder/i);
      assert.match(SYSTEM_INSTRUCTION, /ATS Resume Quality carries a 25% weight/i);
      assert.match(SYSTEM_INSTRUCTION, /State that the exact change cannot be determined until the resume is uploaded/i);
      assert.match(SYSTEM_INSTRUCTION, /NEVER calculate a new total by simply adding 25% of the new ATS score/i);
    });
  });

  // =========================================================================
  // ISSUE 3: Mock interview results confused with real recruitment outcomes
  // =========================================================================
  describe('Issue 3: Mock Interview Results vs. Real Recruitment Outcomes', () => {
    it('explicitly flags in-app interview sessions as mock practice simulations', () => {
      const mockSession: InterviewHistoryItem = {
        id: 'ih_test',
        date: '28 Sep 2026',
        interviewType: 'Technical Interview',
        role: 'Junior Data Analyst',
        score: 84,
        durationMinutes: 18,
        status: 'Passed',
        feedback: 'Good SQL knowledge. Practice DAX filter contexts.',
        categoryBreakdown: {
          technical: 88,
          communication: 85,
          confidence: 80,
          completeness: 83
        }
      };

      const snapshot = buildCareerCompanionSnapshot({
        ...baseParams,
        interviewHistory: [mockSession]
      });

      assert.strictEqual(snapshot.interview.isMockPracticeOnly, true);
      assert.strictEqual(snapshot.interview.environment, 'in_app_mock_interview_simulation');
      assert.strictEqual(snapshot.interview.latestSession?.practiceStatus, 'Passed');
    });

    it('keeps real recruitment applications separate from mock practice history', () => {
      const mockSession: InterviewHistoryItem = {
        id: 'ih_test',
        date: '28 Sep 2026',
        interviewType: 'Technical Interview',
        role: 'Junior Data Analyst',
        score: 84,
        durationMinutes: 18,
        status: 'Passed',
        feedback: 'Good SQL knowledge.',
        categoryBreakdown: {
          technical: 88,
          communication: 85,
          confidence: 80,
          completeness: 83
        }
      };

      const realApplications: ApplicationItem[] = [
        {
          id: 'app_1',
          company: 'TechNova Solutions',
          role: 'Junior Data Analyst',
          location: 'Pune',
          appliedDate: '10 Sep 2026',
          status: 'Interview',
          nextStep: 'Submit online take-home assessment within 48 hours.'
        },
        {
          id: 'app_2',
          company: 'Fractal Analytics',
          role: 'Analyst Trainee',
          location: 'Mumbai',
          appliedDate: '01 Aug 2026',
          status: 'Offer',
          nextStep: 'Sign acceptance documentation by October 15th.'
        }
      ];

      const snapshot = buildCareerCompanionSnapshot({
        ...baseParams,
        interviewHistory: [mockSession],
        applications: realApplications
      });

      // Interview section remains strictly mock practice
      assert.strictEqual(snapshot.interview.isMockPracticeOnly, true);
      assert.strictEqual(snapshot.interview.sessionsCompleted, 1);

      // Application tracker records actual recruitment status independently
      assert.strictEqual(snapshot.applications.totalApplications, 2);
      assert.strictEqual(snapshot.applications.activeApplications[0].company, 'TechNova Solutions');
      assert.strictEqual(snapshot.applications.activeApplications[0].status, 'Interview');
      assert.strictEqual(snapshot.applications.activeApplications[1].company, 'Fractal Analytics');
      assert.strictEqual(snapshot.applications.activeApplications[1].status, 'Offer');
    });

    it('instructs Career Mentor in system prompt to never claim user passed real employer interviews from mock sessions', () => {
      assert.match(SYSTEM_INSTRUCTION, /All sessions in careerContext\.interview are in-app simulated practice sessions/i);
      assert.match(SYSTEM_INSTRUCTION, /ABSOLUTELY NEVER state or imply that the user "has passed technical interviews" with employers/i);
      assert.match(SYSTEM_INSTRUCTION, /Passing a mock practice session does NOT mean clearing real recruitment rounds/i);
      assert.match(SYSTEM_INSTRUCTION, /refer EXCLUSIVELY to careerContext\.applications/i);
    });
  });

  // =========================================================================
  // ISSUE 4: Application Tracker Honesty, Mock Data Disclosures & Company Recommendations
  // =========================================================================
  describe('Issue 4: Application Tracker Honesty & Company Recommendations', () => {
    it('labels application snapshot data as self-managed / demo tracker records and unverified by employers', () => {
      const realApplications: ApplicationItem[] = [
        {
          id: 'app_8',
          company: 'Fractal Analytics',
          role: 'Analyst Trainee',
          location: 'Mumbai',
          appliedDate: '01 Aug 2026',
          status: 'Offer',
          nextStep: 'Sign acceptance documentation by October 15th.'
        }
      ];

      const snapshot = buildCareerCompanionSnapshot({
        ...baseParams,
        applications: realApplications
      });

      assert.strictEqual(snapshot.applications.dataSource, 'in_app_student_tracker_records');
      assert.strictEqual(snapshot.applications.isIndependentlyVerifiedByEmployer, false);
      assert.ok(snapshot.applications.disclaimer.includes('NOT externally verified'));
      assert.strictEqual(snapshot.applications.activeApplications[0].trackerNote, 'Sign acceptance documentation by October 15th.');
    });

    it('instructs Career Mentor to use tracker-data language and never claim offers are confirmed or verified', () => {
      assert.match(SYSTEM_INSTRUCTION, /Your application tracker records an Offer status for Fractal Analytics/i);
      assert.match(SYSTEM_INSTRUCTION, /ABSOLUTELY NEVER claim or imply that an offer is "confirmed", "accepted", "official", "guaranteed", or "independently verified"/i);
      assert.match(SYSTEM_INSTRUCTION, /disclose that tracker entries reflect in-app demo\/self-managed tracker records/i);
    });

    it('instructs Career Mentor to never invent deadlines and only attribute notes to student tracker entries', () => {
      assert.match(SYSTEM_INSTRUCTION, /NEVER invent offer acceptance deadlines, recruiter follow-ups, interview dates/i);
      assert.match(SYSTEM_INSTRUCTION, /According to your application tracker notes/i);
    });

    it('instructs Career Mentor to avoid unsupported company-specific claims and provide general role advice without evidence', () => {
      assert.match(SYSTEM_INSTRUCTION, /NEVER claim a specific company has required tests, questions, or exercises/i);
      assert.match(SYSTEM_INSTRUCTION, /The system does NOT have proprietary employer question banks/i);
      assert.match(SYSTEM_INSTRUCTION, /Require verified evidence from context before offering company-specific recommendations; otherwise provide general role-based/i);
    });
  });

  // =========================================================================
  // AUTHORITATIVE READINESS VERIFICATION: Live calculation verification
  // =========================================================================
  describe('Authoritative Readiness Live Calculation Verification', () => {
    it('verifies that Technical 67, Projects 100, ATS 0, Interview 84 match authoritative live readiness service', () => {
      const liveReadiness = calculatePlacementReadiness(
        initialUserProfile,
        initialSkills,
        initialProjects,
        null, // No uploaded resume
        initialInterviewHistory,
        'Data Analyst'
      );

      // Verify each individual pillar matches the live calculation
      assert.strictEqual(liveReadiness.technicalScore, 67, 'Technical score must be 67 (4 verified out of 6 benchmark skills)');
      assert.strictEqual(liveReadiness.projectsScore, 100, 'Projects score must be 100 (3 completed out of benchmark target 3)');
      assert.strictEqual(liveReadiness.atsScore, 0, 'ATS score must be 0 for unattempted resume');
      assert.strictEqual(liveReadiness.componentMetadata.ats.status, 'not_attempted', 'ATS status must be not_attempted');
      assert.strictEqual(liveReadiness.interviewScore, 84, 'Interview score must be 84 from latest mock session');

      // Verify the formula: Math.round(67*0.30 + 100*0.25 + 0*0.25 + 84*0.20) = Math.round(20.1 + 25 + 0 + 16.8) = Math.round(61.9) = 62
      const computedRaw = (67 * 0.30) + (100 * 0.25) + (0 * 0.25) + (84 * 0.20);
      assert.strictEqual(Math.round(computedRaw), 62);
      assert.strictEqual(liveReadiness.overallScore, 62, 'Overall score must be 62 matching live calculation');
    });
  });
});

