import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { analyzeResumeContent, extractTextFromFile } from '../src/services/resumeAnalyzerService.ts';
import { calculatePlacementReadiness } from '../src/services/placementReadinessService.ts';
import { buildCareerCompanionSnapshot } from '../src/services/careerCompanionService.ts';
import {
  initialUserProfile,
  initialSkills,
  initialRoadmapStages,
  initialProjects,
  initialInterviewHistory
} from '../src/data/mockData.ts';
import fs from 'node:fs';

describe('Resume Analyzer Initial State & Evaluation Verification', () => {
  const baseContext = {
    user: initialUserProfile,
    skills: initialSkills,
    roadmapStages: initialRoadmapStages,
    projects: initialProjects,
    interviewHistory: initialInterviewHistory,
    applications: []
  };

  // =========================================================================
  // 1. Initial State with No Uploaded Resume
  // =========================================================================
  describe('Initial State when hasUploadedResume is false', () => {
    it('verifies that unattempted resume produces not_attempted in Placement Readiness', () => {
      const unattemptedAnalysis = {
        hasUploadedResume: false,
        atsScore: 84, // Stored default before student upload
        atsCompatibility: 84,
        keywordMatch: 78,
        formattingScore: 90,
        skillsMatch: 82,
        experienceMatch: 75,
        strengths: [],
        missingSkills: [],
        keywordSuggestions: [],
        improvements: [],
        analyzedFileName: 'Snehal_Kale_Resume_DataAnalyst.pdf'
      };

      const readiness = calculatePlacementReadiness(
        initialUserProfile,
        initialSkills,
        initialProjects,
        unattemptedAnalysis,
        initialInterviewHistory,
        'Data Analyst'
      );

      assert.strictEqual(readiness.atsScore, 0, 'ATS pillar score must be 0 for unattempted resume');
      assert.strictEqual(readiness.componentMetadata.ats.status, 'not_attempted');
      assert.strictEqual(readiness.componentMetadata.ats.available, false);
      assert.strictEqual(readiness.componentMetadata.ats.label, 'Not Yet Attempted');
    });

    it('verifies that unattempted resume produces atsScore: null in Career Mentor snapshot', () => {
      const snapshot = buildCareerCompanionSnapshot({
        ...baseContext,
        resumeAnalysis: {
          hasUploadedResume: false,
          atsScore: 84,
          atsCompatibility: 84,
          keywordMatch: 78,
          formattingScore: 90,
          skillsMatch: 82,
          experienceMatch: 75,
          strengths: [],
          missingSkills: [],
          keywordSuggestions: [],
          improvements: [],
          analyzedFileName: 'Snehal_Kale_Resume_DataAnalyst.pdf'
        }
      });

      assert.strictEqual(snapshot.resume.hasUploadedResume, false);
      assert.strictEqual(snapshot.resume.status, 'not_attempted');
      assert.strictEqual(snapshot.resume.atsScore, null);
      assert.strictEqual(snapshot.resume.isEvaluatedScore, false);
      assert.strictEqual(snapshot.resume.analyzedFileName, null);
    });

    it('confirms ResumeAnalyzerPage source code guards against displaying default 84% score when hasUploadedResume is false', () => {
      const pageSource = fs.readFileSync('src/pages/resume/ResumeAnalyzerPage.tsx', 'utf-8');

      // Verify the hasUploadedResume boolean flag is declared and used to guard results view
      assert.match(pageSource, /const hasUploadedResume = Boolean\(resumeAnalysis\?\.hasUploadedResume\);/);
      assert.match(pageSource, /Ready to Analyze Your Resume\?/);
      assert.match(pageSource, /Upload your resume to calculate your ATS score and receive personalized feedback/);
      assert.match(pageSource, /No resume uploaded yet/);

      // Verify results view is guarded by hasUploadedResume check
      assert.match(pageSource, /hasUploadedResume \? \(/);
    });
  });

  // =========================================================================
  // 2. Real Uploaded Resume Analysis
  // =========================================================================
  describe('Valid Text-Based Resume Upload & Genuine Results', () => {
    it('analyzes genuine candidate text and computes authentic score based on role benchmarks', () => {
      const sampleCandidateResume = `
        Aarav Sharma
        Email: aarav.sharma@example.com | Phone: +91 98765 43210
        Education: B.Tech in Artificial Intelligence & Data Science, 2026.
        Technical Skills: Python, SQL, PostgreSQL, Pandas, NumPy, Power BI, Statistics.
        Experience & Projects:
        - Engineered an automated sales analytics pipeline using Python and SQL for 50,000 records.
        - Designed interactive Power BI dashboards reducing executive reporting cycle time by 25%.
      `;

      const result = analyzeResumeContent(sampleCandidateResume, 'Aarav_Sharma_Resume.pdf', 'Data Analyst');

      assert.strictEqual(typeof result.atsScore, 'number');
      assert.ok(result.atsScore > 50, `Expected score > 50, got ${result.atsScore}`);
      assert.strictEqual(result.analyzedFileName, 'Aarav_Sharma_Resume.pdf');
      assert.ok(result.detectedSkills.includes('Python'));
      assert.ok(result.detectedSkills.includes('SQL'));
      assert.ok(result.detectedSkills.includes('Power BI'));
      assert.ok(result.strengths.length > 0);

      // Verify that this genuine score propagates into placement readiness when uploaded
      const readiness = calculatePlacementReadiness(
        initialUserProfile,
        initialSkills,
        initialProjects,
        {
          ...result,
          hasUploadedResume: true
        },
        initialInterviewHistory,
        'Data Analyst'
      );

      assert.strictEqual(readiness.atsScore, Math.round(result.atsScore));
      assert.strictEqual(readiness.componentMetadata.ats.status, 'completed');
      assert.strictEqual(readiness.componentMetadata.ats.available, true);
    });
  });

  // =========================================================================
  // 3. Empty or Unreadable File Handling
  // =========================================================================
  describe('Empty or Unreadable File Handling', () => {
    it('emits a clear warning message and baseline score without throwing unhandled exceptions', () => {
      const emptyContent = '   ';
      const result = analyzeResumeContent(emptyContent, 'corrupted_file.pdf', 'Data Analyst');

      assert.strictEqual(result.atsScore, 5);
      assert.strictEqual(result.analyzedFileName, 'corrupted_file.pdf');
      assert.ok(result.warningMessage, 'Expected warningMessage to be populated');
      assert.match(result.warningMessage, /contains no readable text tokens/i);
      assert.strictEqual(result.detectedSkills.length, 0);
    });

    it('extractTextFromFile handles unreadable or empty buffer gracefully', async () => {
      const mockEmptyFile = {
        name: 'empty.pdf',
        arrayBuffer: async () => new ArrayBuffer(0)
      };

      const extracted = await extractTextFromFile(mockEmptyFile as any);
      assert.strictEqual(extracted, '');
    });
  });
});
