import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { skillAssessmentService } from '../src/services/skillAssessmentService.ts';
import { assessmentQuestions } from '../src/data/mockData.ts';

describe('Skill Assessment Diagnostic Scoring Verification', () => {
  // =========================================================================
  // 1. All Correct Answers
  // =========================================================================
  it('calculates 100% for all categories and 100% overall when all answers are correct', () => {
    const perfectAnswers: Record<string, number> = {};
    assessmentQuestions.forEach((q) => {
      perfectAnswers[q.id] = q.correctAnswerIndex;
    });

    const result = skillAssessmentService.evaluateDiagnosticAssessment(
      assessmentQuestions,
      perfectAnswers
    );

    assert.strictEqual(result.overall, 100, 'Overall score must be 100% for all correct');
    assert.strictEqual(result.correctCount, assessmentQuestions.length);
    assert.strictEqual(result.totalQuestions, assessmentQuestions.length);

    // Every category must be 100%
    assert.strictEqual(result.breakdown['Power BI'], 100, 'Power BI must be 100%, not 42');
    assert.strictEqual(result.breakdown['SQL'], 100);
    assert.strictEqual(result.breakdown['Python'], 100);
    assert.strictEqual(result.breakdown['Statistics'], 100);
    assert.strictEqual(result.breakdown['Data Analysis'], 100);
    assert.strictEqual(result.breakdown['Machine Learning'], 100);
    assert.strictEqual(result.breakdown['Problem Solving'], 100);

    // Strengths must contain all categories
    assert.ok(result.strengths.includes('Power BI'));
    assert.ok(result.strengths.includes('Python'));
    assert.ok(result.strengths.includes('SQL'));
    assert.strictEqual(result.weaknesses.length, 0);
  });

  // =========================================================================
  // 2. All Incorrect Answers
  // =========================================================================
  it('calculates 0% for all categories and 0% overall without artificial minimum score floors', () => {
    const zeroAnswers: Record<string, number> = {};
    assessmentQuestions.forEach((q) => {
      // Pick an index different from correctAnswerIndex
      zeroAnswers[q.id] = (q.correctAnswerIndex + 1) % q.options.length;
    });

    const result = skillAssessmentService.evaluateDiagnosticAssessment(
      assessmentQuestions,
      zeroAnswers
    );

    assert.strictEqual(result.overall, 0, 'Overall score must be 0%, not clamped to 68%');
    assert.strictEqual(result.correctCount, 0);
    assert.strictEqual(result.totalQuestions, assessmentQuestions.length);

    // Every category must be 0%
    assert.strictEqual(result.breakdown['Power BI'], 0, 'Power BI must be 0%, not 42');
    assert.strictEqual(result.breakdown['SQL'], 0, 'SQL must be 0%, not 74');
    assert.strictEqual(result.breakdown['Python'], 0, 'Python must be 0%, not 72');
    assert.strictEqual(result.breakdown['Statistics'], 0, 'Statistics must be 0%, not 48');
    assert.strictEqual(result.breakdown['Data Analysis'], 0, 'Data Analysis must be 0%, not 68');
    assert.strictEqual(result.breakdown['Machine Learning'], 0, 'Machine Learning must be 0%, not 65');
    assert.strictEqual(result.breakdown['Problem Solving'], 0);

    // Strengths must be empty and weaknesses must contain all categories
    assert.strictEqual(result.strengths.length, 0);
    assert.ok(result.weaknesses.includes('Power BI'));
    assert.ok(result.weaknesses.includes('Python'));
    assert.ok(result.weaknesses.includes('SQL'));
  });

  // =========================================================================
  // 3. Mixed Answers & Specific Category Verification
  // =========================================================================
  it('calculates exact category scores based strictly on actual answers', () => {
    // Specifically answer ONLY Power BI (q7) and SQL q1 correctly (2 out of 8 correct)
    const mixedAnswers: Record<string, number> = {
      q1: assessmentQuestions.find((q) => q.id === 'q1')!.correctAnswerIndex, // SQL (1/2 correct = 50%)
      q2: 999, // SQL incorrect
      q3: 999, // Python incorrect
      q4: 999, // Statistics incorrect
      q5: 999, // Data Analysis incorrect
      q6: 999, // Machine Learning incorrect
      q7: assessmentQuestions.find((q) => q.id === 'q7')!.correctAnswerIndex, // Power BI (1/1 correct = 100%)
      q8: 999  // Problem Solving incorrect
    };

    const result = skillAssessmentService.evaluateDiagnosticAssessment(
      assessmentQuestions,
      mixedAnswers
    );

    // 2 out of 8 correct: Math.round(2 / 8 * 100) = 25%
    assert.strictEqual(result.correctCount, 2);
    assert.strictEqual(result.overall, 25, 'Overall must be 25% (2/8), not clamped to 68%');

    // Power BI answered correctly => 100%
    assert.strictEqual(result.breakdown['Power BI'], 100, 'Power BI score must be 100% when answered correctly');

    // SQL had 1 of 2 correct => 50%
    assert.strictEqual(result.breakdown['SQL'], 50, 'SQL score must be 50% for 1/2 correct');

    // Others incorrect => 0%
    assert.strictEqual(result.breakdown['Python'], 0);
    assert.strictEqual(result.breakdown['Statistics'], 0);
    assert.strictEqual(result.breakdown['Data Analysis'], 0);
  });

  it('correctly scores Power BI as 0% when Power BI question is answered incorrectly', () => {
    // Answer everything correctly EXCEPT Power BI (7 out of 8 correct)
    const answersExceptPowerBI: Record<string, number> = {};
    assessmentQuestions.forEach((q) => {
      if (q.category === 'Power BI') {
        answersExceptPowerBI[q.id] = (q.correctAnswerIndex + 1) % q.options.length; // Incorrect
      } else {
        answersExceptPowerBI[q.id] = q.correctAnswerIndex; // Correct
      }
    });

    const result = skillAssessmentService.evaluateDiagnosticAssessment(
      assessmentQuestions,
      answersExceptPowerBI
    );

    assert.strictEqual(result.correctCount, 7);
    assert.strictEqual(result.overall, Math.round((7 / 8) * 100)); // 88%
    assert.strictEqual(result.breakdown['Power BI'], 0, 'Power BI must be 0%, not hardcoded 42');
    assert.ok(result.weaknesses.includes('Power BI'));
  });

  // =========================================================================
  // 4. Unanswered Questions Handling
  // =========================================================================
  it('handles unanswered or omitted questions honestly as 0 without assuming completion', () => {
    const emptyAnswers: Record<string, number> = {}; // No answers submitted

    const result = skillAssessmentService.evaluateDiagnosticAssessment(
      assessmentQuestions,
      emptyAnswers
    );

    assert.strictEqual(result.correctCount, 0);
    assert.strictEqual(result.overall, 0);
    assert.strictEqual(result.breakdown['Power BI'], 0);
    assert.strictEqual(result.breakdown['SQL'], 0);
    assert.strictEqual(result.breakdown['Python'], 0);
  });

  it('handles empty questions list gracefully', () => {
    const result = skillAssessmentService.evaluateDiagnosticAssessment([], {});
    assert.strictEqual(result.overall, 0);
    assert.strictEqual(result.correctCount, 0);
    assert.strictEqual(result.totalQuestions, 0);
    assert.deepStrictEqual(result.breakdown, {});
  });
});
