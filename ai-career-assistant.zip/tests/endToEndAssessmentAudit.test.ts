import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { skillAssessmentService } from '../src/services/skillAssessmentService.ts';
import {
  generatePersonalizedRoadmap,
  ROLE_ROADMAP_TEMPLATES
} from '../src/services/careerRoadmapService.ts';
import { calculatePlacementReadiness } from '../src/services/placementReadinessService.ts';
import {
  initialUserProfile,
  initialSkills,
  initialProjects,
  initialAssessmentHistory,
  initialInterviewHistory,
  initialCompanyJobPostings
} from '../src/data/mockData.ts';
import {
  RoadmapStage,
  SkillItem,
  AssessmentHistoryItem,
  ResumeAnalysisData,
  UserProfile,
  ApplicationItem
} from '../src/types.ts';

describe('Phase 2 & Phase 3 Comprehensive Automated Quality Audit', () => {
  // =========================================================================
  // REQUIREMENT 1: Baseline scores calculated ONLY from submitted answers
  // =========================================================================
  describe('Requirement 1: Authentic Baseline Scoring Without Fabrication', () => {
    it('calculates score strictly from actual answers with zero floor or inflation', () => {
      const questions = skillAssessmentService.getBaselineQuestions('Data Analyst', 'Moderate');
      assert.ok(questions.length >= 6, 'Baseline test must provide at least 6 questions');

      // 0 correct
      const zeroAnswers: Record<string, number> = {};
      questions.forEach((q) => {
        zeroAnswers[q.id] = (q.correctAnswerIndex + 1) % q.options.length;
      });
      const zeroResult = skillAssessmentService.evaluateDiagnosticAssessment(questions, zeroAnswers, 'Moderate');
      assert.strictEqual(zeroResult.overall, 0, 'Score with 0 correct must be 0%');
      assert.strictEqual(zeroResult.correctCount, 0);

      // Exactly 3 of 6 correct = 50%
      const halfAnswers: Record<string, number> = {};
      questions.forEach((q, idx) => {
        halfAnswers[q.id] = idx < 3 ? q.correctAnswerIndex : (q.correctAnswerIndex + 1) % q.options.length;
      });
      const halfResult = skillAssessmentService.evaluateDiagnosticAssessment(questions, halfAnswers, 'Moderate');
      const expectedScore = Math.round((3 / questions.length) * 100);
      assert.strictEqual(halfResult.overall, expectedScore, `Score must strictly match (${3}/${questions.length}) = ${expectedScore}%`);
      assert.strictEqual(halfResult.correctCount, 3);
    });
  });

  // =========================================================================
  // REQUIREMENT 2: Easy, Moderate, and Hard Difficulty Scoring & Questions
  // =========================================================================
  describe('Requirement 2: Easy, Moderate, and Hard Question Suites and Valid Evaluation', () => {
    const difficulties: ('Easy' | 'Moderate' | 'Hard')[] = ['Easy', 'Moderate', 'Hard'];

    difficulties.forEach((diff) => {
      it(`retrieves and evaluates valid questions for difficulty: ${diff}`, () => {
        const questions = skillAssessmentService.getBaselineQuestions('Data Analyst', diff);
        assert.ok(questions.length > 0, `Must return questions for ${diff}`);

        // Every returned question has valid structure
        questions.forEach((q) => {
          assert.ok(q.id, 'Question must have id');
          assert.ok(q.question && q.question.length > 10, 'Question must have text');
          assert.ok(Array.isArray(q.options) && q.options.length >= 2, 'Must have at least 2 options');
          assert.ok(q.correctAnswerIndex >= 0 && q.correctAnswerIndex < q.options.length, 'Valid correctAnswerIndex');
          assert.ok(q.explanation && q.explanation.length > 5, 'Must have explanation');
        });

        // Test skill assessment evaluation with specific difficulty
        const pythonQuestions = skillAssessmentService.getQuestionsForSkill('Python', diff);
        assert.ok(pythonQuestions.length > 0, `Python questions must exist for ${diff}`);

        const perfectAnswers: Record<string, number> = {};
        pythonQuestions.forEach((q) => {
          perfectAnswers[q.id] = q.correctAnswerIndex;
        });

        const evalResult = skillAssessmentService.evaluateSkillAssessment({
          skillName: 'Python',
          questions: pythonQuestions,
          userAnswers: perfectAnswers,
          difficulty: diff
        });

        assert.strictEqual(evalResult.calculatedScore, 100);
        assert.strictEqual(evalResult.accuracy, 100);
        assert.strictEqual(evalResult.difficulty, diff);
        assert.strictEqual(evalResult.status, 'passed');
      });
    });
  });

  // =========================================================================
  // REQUIREMENT 3: Skill-Specific Tests for Every Relevant Roadmap Skill
  // =========================================================================
  describe('Requirement 3: Skill-Specific Question Availability for All Roadmap Skills', () => {
    it('provides valid questions for every skill present in all role roadmap templates', () => {
      const allRoleSkills = new Set<string>();

      Object.values(ROLE_ROADMAP_TEMPLATES).forEach((template) => {
        template.forEach((task) => {
          if (task.skillName && task.skillName.trim() !== '') {
            allRoleSkills.add(task.skillName.trim());
          }
        });
      });

      assert.ok(allRoleSkills.size > 10, 'Must have comprehensive collection of roadmap skills');

      allRoleSkills.forEach((skillName) => {
        const questions = skillAssessmentService.getQuestionsForSkill(skillName);
        assert.ok(
          Array.isArray(questions) && questions.length >= 3,
          `Skill "${skillName}" must have at least 3 valid assessment questions. Found: ${questions?.length}`
        );

        questions.forEach((q) => {
          assert.ok(q.id, `Question for "${skillName}" must have id`);
          assert.ok(q.question, `Question for "${skillName}" must have question text`);
          assert.ok(Array.isArray(q.options) && q.options.length >= 2, `Question for "${skillName}" must have options`);
          assert.ok(q.explanation, `Question for "${skillName}" must have explanation`);
        });
      });
    });
  });

  // =========================================================================
  // REQUIREMENT 4 & 5: Milestone Validation Threshold (>=75% Passes, <75% Fails)
  // =========================================================================
  describe('Requirement 4 & 5: Pass/Fail Threshold Validation at 75%', () => {
    it('marks milestone as passed when score is at least 75%', () => {
      const questions = skillAssessmentService.getValidationQuestionsForStage('Python', 'Moderate');
      const passAnswers: Record<string, number> = {};
      // 4 out of 5 correct = 80% (>= 75%)
      questions.forEach((q, idx) => {
        passAnswers[q.id] = idx < 4 ? q.correctAnswerIndex : 999;
      });

      const passResult = skillAssessmentService.evaluateSkillAssessment({
        skillName: 'Python',
        questions,
        userAnswers: passAnswers,
        difficulty: 'Moderate',
        isValidation: true,
        stageId: 'stage_test_1'
      });

      assert.strictEqual(passResult.calculatedScore, 80);
      assert.strictEqual(passResult.status, 'passed', 'Score 80% must receive status passed');
    });

    it('does NOT mark milestone as passed when score is below 75%', () => {
      const questions = skillAssessmentService.getValidationQuestionsForStage('Python', 'Moderate');
      const failAnswers: Record<string, number> = {};
      // 3 out of 5 correct = 60% (< 75%)
      questions.forEach((q, idx) => {
        failAnswers[q.id] = idx < 3 ? q.correctAnswerIndex : 999;
      });

      const failResult = skillAssessmentService.evaluateSkillAssessment({
        skillName: 'Python',
        questions,
        userAnswers: failAnswers,
        difficulty: 'Moderate',
        isValidation: true,
        stageId: 'stage_test_1'
      });

      assert.strictEqual(failResult.calculatedScore, 60);
      assert.strictEqual(failResult.status, 'review_needed', 'Score 60% must receive status review_needed');
      assert.notStrictEqual(failResult.status, 'passed');
    });
  });

  // =========================================================================
  // REQUIREMENT 6: Sequential Roadmap Unlocking & Prerequisites
  // =========================================================================
  describe('Requirement 6: Roadmap Prerequisites & Sequential Unlocking', () => {
    it('keeps later stages upcoming if earlier prerequisite stages are incomplete', () => {
      // Inexperienced student with 0 completed stages
      const blankStages: RoadmapStage[] = [];
      const unassessedSkills: SkillItem[] = initialSkills.map((s) => ({
        ...s,
        currentLevel: 30,
        status: 'Needs Improvement',
        lastTestedDate: 'Never',
      }));

      const roadmap = generatePersonalizedRoadmap(
        'Data Analyst',
        unassessedSkills,
        [],
        blankStages,
        []
      );

      // The first task should be In Progress, while downstream tasks requiring prerequisites must NOT be In Progress
      const firstTask = roadmap[0];
      assert.strictEqual(firstTask.status, 'In Progress', 'First foundational task must be In Progress');

      const advancedTasks = roadmap.filter((s) => s.stepNumber > 3);
      advancedTasks.forEach((adv) => {
        if (adv.prerequisites && adv.prerequisites.length > 0) {
          assert.strictEqual(
            adv.status,
            'Upcoming',
            `Stage ${adv.stepNumber} (${adv.title}) requiring prerequisites must remain Upcoming when unfulfilled`
          );
        }
      });
    });

    it('unlocks downstream stages once prerequisites are fulfilled or verified', () => {
      // Simulate completing stage 1 (Foundations)
      const initialRoadmap = generatePersonalizedRoadmap(
        'Data Analyst',
        initialSkills,
        [],
        [],
        initialAssessmentHistory
      );

      const completedStep1Roadmap = initialRoadmap.map((st, idx) => {
        if (idx === 0) {
          return { ...st, status: 'Completed' as const, validationStatus: 'passed' as const };
        }
        return st;
      });

      const nextRoadmap = generatePersonalizedRoadmap(
        'Data Analyst',
        initialSkills,
        [],
        completedStep1Roadmap,
        initialAssessmentHistory
      );

      assert.strictEqual(nextRoadmap[0].status, 'Completed');
      // Step 2 or first incomplete unblocked step should now be In Progress
      const activeStep = nextRoadmap.find((s) => s.status === 'In Progress');
      assert.ok(activeStep, 'Must have an active In Progress step');
      assert.ok(activeStep.stepNumber > 1, 'In Progress step should advance past step 1');
    });
  });

  // =========================================================================
  // REQUIREMENT 7: Completing Learning Task Alone Does NOT False-Inject Proficiency
  // =========================================================================
  describe('Requirement 7: Task Completion vs. Demonstrated Proficiency Separation', () => {
    it('does not falsely establish demonstrated proficiency for unverified skills merely from checklist completion', () => {
      // A student marks a general task complete, but their actual skill has currentLevel 40 and no test date
      const weakSkill: SkillItem = {
        id: 'sk_weak_sql',
        name: 'SQL',
        category: 'Technical',
        currentLevel: 40,
        requiredLevel: 75,
        status: 'Priority Gap',
        lastTestedDate: 'Never',
      };

      const roadmap = generatePersonalizedRoadmap(
        'Data Analyst',
        [weakSkill],
        ['SQL'],
        [],
        [] // no assessment history
      );

      // The SQL task in Core Role-Specific Skills must NOT be marked completed
      const sqlCoreTask = roadmap.find((s) => s.skillName.toLowerCase() === 'sql' && s.phase === 'Core Role-Specific Skills');
      if (sqlCoreTask) {
        assert.notStrictEqual(
          sqlCoreTask.status,
          'Completed',
          'Core SQL task must not be automatically marked Completed without verified proficiency >= 75%'
        );
      }
    });
  });

  // =========================================================================
  // REQUIREMENT 8 & 9: History Recording, Detail Preservation, and Retakes
  // =========================================================================
  describe('Requirement 8 & 9: Attempt History Recording & Preservation Across Retakes', () => {
    it('records attempt date, scores, difficulty, and preserves previous attempts upon retake', () => {
      const historyList: AssessmentHistoryItem[] = [...initialAssessmentHistory];
      const initialCount = historyList.length;

      // First attempt
      const attempt1: AssessmentHistoryItem = {
        id: 'ash_test_1',
        date: 'Oct 01, 2026',
        skillName: 'Python',
        targetRole: 'Data Analyst',
        overallScore: 60,
        status: 'Completed',
        categoryScores: { Python: 60 },
        strongSkills: ['Variables and data types'],
        weakSkills: ['OOP'],
        strongTopics: ['Variables and data types'],
        weakTopics: ['OOP'],
        difficulty: 'Moderate',
        isValidation: false,
        questionCount: 5,
        correctCount: 3,
        accuracy: 60,
      };

      const updatedHistory1 = [attempt1, ...historyList];
      assert.strictEqual(updatedHistory1.length, initialCount + 1);

      // Retake attempt (higher score)
      const attempt2: AssessmentHistoryItem = {
        id: 'ash_test_2',
        date: 'Oct 15, 2026',
        skillName: 'Python',
        targetRole: 'Data Analyst',
        overallScore: 85,
        previousScore: 60,
        improvementPct: 25,
        status: 'Completed',
        categoryScores: { Python: 85 },
        strongSkills: ['Variables and data types', 'OOP'],
        weakSkills: [],
        strongTopics: ['Variables and data types', 'OOP'],
        weakTopics: [],
        difficulty: 'Moderate',
        isValidation: true,
        questionCount: 5,
        correctCount: 4,
        accuracy: 80,
      };

      const updatedHistory2 = [attempt2, ...updatedHistory1];
      assert.strictEqual(updatedHistory2.length, initialCount + 2);

      // Verify attempt 1 was preserved completely
      const foundAttempt1 = updatedHistory2.find((a) => a.id === 'ash_test_1');
      assert.ok(foundAttempt1, 'Attempt 1 must still exist after retake');
      assert.strictEqual(foundAttempt1?.overallScore, 60);

      // Verify attempt 2 is latest
      assert.strictEqual(updatedHistory2[0].id, 'ash_test_2');
      assert.strictEqual(updatedHistory2[0].overallScore, 85);
      assert.strictEqual(updatedHistory2[0].previousScore, 60);
      assert.strictEqual(updatedHistory2[0].improvementPct, 25);
    });
  });

  // =========================================================================
  // REQUIREMENT 10 & 11: Baseline Preservation & Accurate Deltas
  // =========================================================================
  describe('Requirement 10 & 11: Baseline Preservation & Exact Mathematical Deltas', () => {
    it('preserves the original baseline score and calculates exact percentage-point deltas', () => {
      const baselineScore = 62;
      const validatedScore = 82;
      const expectedDelta = 20;

      const delta = validatedScore - baselineScore;
      assert.strictEqual(delta, expectedDelta, '82 - 62 must equal exactly 20 percentage points');

      // Check skill baseline preservation in SkillItem
      const originalSkill: SkillItem = {
        id: 'sk_py',
        name: 'Python',
        category: 'Technical',
        currentLevel: 62,
        baselineScore: 62,
        requiredLevel: 75,
        status: 'Needs Improvement',
      };

      // Simulating validation update
      const updatedSkill: SkillItem = {
        ...originalSkill,
        currentLevel: validatedScore,
        validatedScore,
        validationStatus: 'passed',
        baselineScore: originalSkill.baselineScore, // Baseline preserved!
        improvementPct: validatedScore - (originalSkill.baselineScore ?? 0),
        status: 'Strong',
      };

      assert.strictEqual(updatedSkill.baselineScore, 62, 'Baseline must remain 62');
      assert.strictEqual(updatedSkill.validatedScore, 82);
      assert.strictEqual(updatedSkill.improvementPct, 20);
    });
  });

  // =========================================================================
  // REQUIREMENT 12: Missing Assessments Display as Unavailable, Not Fabricated
  // =========================================================================
  describe('Requirement 12: Missing Assessment & Data Transparency', () => {
    it('marks unattempted resume as not_attempted without claiming evaluated zero score', () => {
      const unattemptedResume: ResumeAnalysisData = {
        hasUploadedResume: false,
        atsScore: 84, // default template object
        atsCompatibility: 84,
        keywordMatch: 78,
        formattingScore: 90,
        skillsMatch: 82,
        experienceMatch: 75,
        strengths: [],
        missingSkills: [],
        keywordSuggestions: [],
        improvements: []
      };

      const readiness = calculatePlacementReadiness(
        initialUserProfile,
        initialSkills,
        initialProjects,
        unattemptedResume,
        [],
        'Data Analyst'
      );

      assert.strictEqual(
        readiness.componentMetadata.ats.status,
        'not_attempted',
        'Unattempted resume must have status not_attempted'
      );
      assert.strictEqual(
        readiness.componentMetadata.ats.isEvaluatedScore,
        false,
        'Unattempted resume must have isEvaluatedScore false'
      );
      assert.strictEqual(
        readiness.componentMetadata.interview.status,
        'not_attempted',
        'Zero interview attempts must have status not_attempted'
      );
    });
  });

  // =========================================================================
  // REQUIREMENT 13: Changing Target Role Preserves Historical Assessment Results
  // =========================================================================
  describe('Requirement 13: Target Role Switching Preserves Historical Assessment Logs', () => {
    it('does not corrupt or wipe assessmentHistory when switching role from Data Analyst to Frontend Developer', () => {
      const historyBefore = [...initialAssessmentHistory];
      const initialCount = historyBefore.length;

      // Calibrate roadmap for Frontend Developer
      const newRoadmap = generatePersonalizedRoadmap(
        'Frontend Developer',
        initialSkills,
        [],
        [],
        historyBefore
      );

      // Roadmap adjusted to Frontend Developer
      assert.ok(newRoadmap.length > 0);
      assert.ok(newRoadmap.some((s) => s.skillName.toLowerCase().includes('react') || s.title.toLowerCase().includes('html')));

      // Historical assessment history must remain identical
      assert.strictEqual(historyBefore.length, initialCount);
      assert.strictEqual(historyBefore[0].id, initialAssessmentHistory[0].id);
      assert.strictEqual(historyBefore[0].overallScore, initialAssessmentHistory[0].overallScore);
    });
  });

  // =========================================================================
  // REQUIREMENT 14: Refresh Persistence Integrity
  // =========================================================================
  describe('Requirement 14: Storage & Refresh Persistence Check', () => {
    it('reloads saved roadmap stages directly from storage when available', () => {
      const customSavedStage: RoadmapStage = {
        id: 'stage_custom_saved_1',
        stepNumber: 1,
        title: 'Custom Verified Milestone',
        status: 'Completed',
        skillName: 'Python',
        currentLevel: 90,
        targetLevel: 80,
        estimatedTime: '2 weeks',
        goal: 'Master Python',
        whyItMatters: 'Foundational programming',
        learningModules: [],
        practiceTasks: [],
        suggestedProject: 'CLI Tool',
        validatedScore: 90,
        validationStatus: 'passed',
        baselineScore: 60,
      };

      const storedStages = [customSavedStage];

      // Simulate storage load logic:
      const loaded = Array.isArray(storedStages) && storedStages.length > 0 ? storedStages : [];
      assert.strictEqual(loaded.length, 1);
      assert.strictEqual(loaded[0].id, 'stage_custom_saved_1');
      assert.strictEqual(loaded[0].validationStatus, 'passed');
      assert.strictEqual(loaded[0].validatedScore, 90);
    });
  });

  // =========================================================================
  // PHASE 3: Student-Company Integration Automated Verification
  // =========================================================================
  describe('Phase 3: Student-Company Integration Audit', () => {
    it('prevents duplicate applications for the same candidate and job posting', () => {
      const existingApps: ApplicationItem[] = [
        {
          id: 'app_1',
          jobId: 'cjp_1',
          company: 'Acme Corp',
          role: 'Data Analyst',
          appliedDate: '2026-10-01',
          status: 'Applied',
          matchScore: 85,
        }
      ];

      const isDuplicate = existingApps.some((a) => a.jobId === 'cjp_1');
      assert.strictEqual(isDuplicate, true, 'Must identify duplicate job application by jobId');

      const isNotDuplicate = existingApps.some((a) => a.jobId === 'cjp_999');
      assert.strictEqual(isNotDuplicate, false, 'New jobId must not be rejected as duplicate');
    });

    it('enforces company job posting ownership during edits or closures', () => {
      const testPostings = [
        {
          id: 'post_101',
          companyId: 'comp_alpha',
          title: 'Junior React Engineer',
          status: 'Published' as const,
        },
        {
          id: 'post_102',
          companyId: 'comp_beta',
          title: 'Backend Node Engineer',
          status: 'Published' as const,
        }
      ];

      // User logged in as comp_alpha tries to close post_102 (belonging to comp_beta)
      const currentCompanyId = 'comp_alpha';
      const targetPosting = testPostings.find((p) => p.id === 'post_102');

      assert.ok(targetPosting);
      const isOwner = targetPosting.companyId === currentCompanyId;
      assert.strictEqual(isOwner, false, 'Non-owning company must be denied edit/close authorization');

      // Authorized owner edit
      const ownPosting = testPostings.find((p) => p.id === 'post_101');
      assert.ok(ownPosting);
      assert.strictEqual(ownPosting.companyId === currentCompanyId, true, 'Owning company is authorized');
    });

    it('syncs company job postings visibility based on Published vs Draft status', () => {
      const samplePostings = [
        { id: 'p1', title: 'Data Analyst', status: 'Published' },
        { id: 'p2', title: 'Internal Tooling', status: 'Draft' },
        { id: 'p3', title: 'Archived Role', status: 'Closed' },
      ];

      const studentVisible = samplePostings.filter((p) => p.status === 'Published');
      assert.strictEqual(studentVisible.length, 1);
      assert.strictEqual(studentVisible[0].id, 'p1');
    });
  });
});
