import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

describe('Add Actions & Button Handlers Integration Regression Tests', () => {
  const jobPostingModalPath = path.resolve('src/components/company/JobPostingModal.tsx');
  const profilePagePath = path.resolve('src/pages/profile/ProfilePage.tsx');
  const careerContextPath = path.resolve('src/context/CareerContext.tsx');
  const skillAnalyticsPath = path.resolve('src/pages/analytics/SkillAnalyticsPage.tsx');
  const onboardingPath = path.resolve('src/pages/onboarding/OnboardingPage.tsx');
  const appTrackerPath = path.resolve('src/pages/applications/ApplicationTrackerPage.tsx');

  it('1. Company JobPostingModal "Add" button has complete validation, onClick handler, and visual feedback', () => {
    const code = fs.readFileSync(jobPostingModalPath, 'utf8');

    // Button identification & exact text
    assert.ok(code.includes('onClick={handleAddCustomSkill}'), 'Add button must have onClick handler');
    assert.ok(/Add\s*<\/button>/.test(code), 'Contains exact Add button text');

    // Handler validation
    assert.ok(code.includes('Please enter a skill name before clicking Add'), 'Validates empty skill name with user feedback');
    assert.ok(code.includes('already in the required skills list'), 'Validates duplicate skills with user feedback');
    assert.ok(code.includes('skillFeedback'), 'Maintains visual feedback state for Add action');
    assert.ok(code.includes('Added "${clean}" to job skills'), 'Provides clear success message on adding skill');
  });

  it('2. ProfilePage "Add Skill" form has both onClick and onSubmit handlers, validation, and visual feedback', () => {
    const code = fs.readFileSync(profilePagePath, 'utf8');

    // Button & form handlers
    assert.ok(code.includes('onSubmit={handleAddNewSkill}'), 'Form must have onSubmit handler');
    assert.ok(code.includes('onClick={handleAddNewSkill}'), 'Add Skill button must have onClick handler');

    // Validation & feedback
    assert.ok(code.includes('Please enter a skill name before clicking Add Skill'), 'Validates empty input with clear error message');
    assert.ok(code.includes('already present in your technical profile'), 'Validates duplicate skill with clear error message');
    assert.ok(code.includes('successfully added to your profile'), 'Displays prominent success message upon adding skill');
    assert.ok(code.includes('skillMessage'), 'Renders skillMessage UI element');
  });

  it('3. CareerContext addSkill immediately persists data to storage and returns structured result', () => {
    const code = fs.readFileSync(careerContextPath, 'utf8');

    assert.ok(code.includes('addSkill: (name: string'), 'Declares addSkill in context');
    assert.ok(code.includes("safeSetStorage('career_skills'"), 'addSkill directly persists to career_skills storage');
    assert.ok(code.includes('return { success: true, skill: newSkill }'), 'Returns success result with created skill item');
    assert.ok(code.includes('return { success: false, error:'), 'Returns descriptive error on failure');
  });

  it('4. SkillAnalyticsPage "Add to Roadmap" actually creates/persists the skill item', () => {
    const code = fs.readFileSync(skillAnalyticsPath, 'utf8');

    assert.ok(code.includes('handleAddToRoadmap'), 'Defines handleAddToRoadmap handler');
    assert.ok(code.includes('addSkill(skillName)'), 'Calls addSkill to create and persist skill when missing from inventory');
  });

  it('5. OnboardingPage "Add Skill" has explicit onClick, input validation, and visual confirmation', () => {
    const code = fs.readFileSync(onboardingPath, 'utf8');

    assert.ok(code.includes('onClick={handleAddCustomSkill}'), 'Add Skill button has onClick handler');
    assert.ok(code.includes('Please enter a skill name before clicking Add Skill'), 'Handles empty input validation');
    assert.ok(code.includes('skillFeedback'), 'Renders feedback banner on Add Skill action');
  });

  it('6. ApplicationTrackerPage displays persistent success banner when an application is added', () => {
    const code = fs.readFileSync(appTrackerPath, 'utf8');

    assert.ok(code.includes('statusMessage'), 'Maintains statusMessage state');
    assert.ok(code.includes('recorded successfully!'), 'Displays confirmation feedback when application is recorded');
  });
});
