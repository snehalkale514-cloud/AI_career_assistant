import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { initialRoadmapStages, initialUserProfile, initialSkills } from '../src/data/mockData.ts';
import {
  generatePersonalizedRoadmap,
  getVerifiedResourcesForSkill,
  ROLE_ROADMAP_TEMPLATES,
  VERIFIED_SKILL_RESOURCES,
  groupRoadmapIntoStages,
  getPlainEnglishExplanations,
  TECHNICAL_TERM_GLOSSARY
} from '../src/services/careerRoadmapService.ts';
import { RoadmapStage, SkillItem, AssessmentHistoryItem, SimpleRoadmapStageGroup } from '../src/types.ts';

describe('Personalized Career Roadmap & Verified Learning Resources', () => {
  // =========================================================================
  // Requirement 1 & 2: Complete Roadmap Stage Structure Across 6 Phases
  // =========================================================================
  describe('Roadmap Stage Data Structure Completeness', () => {
    it('verifies initial roadmap stages contain all required enriched fields across logical phases', () => {
      assert.strictEqual(initialRoadmapStages.length, 13, 'Should have 13 stages across 6 phases in Data Analyst roadmap');

      const phasesFound = new Set(initialRoadmapStages.map((s) => s.phase));
      assert.ok(phasesFound.has('Foundations'), 'Must contain Foundations phase');
      assert.ok(phasesFound.has('Core Role-Specific Skills'), 'Must contain Core Role-Specific Skills phase');
      assert.ok(phasesFound.has('Applied Practice'), 'Must contain Applied Practice phase');
      assert.ok(phasesFound.has('Portfolio Project'), 'Must contain Portfolio Project phase');
      assert.ok(phasesFound.has('Resume and Interview Preparation'), 'Must contain Resume and Interview Preparation phase');
      assert.ok(phasesFound.has('Job Application Preparation'), 'Must contain Job Application Preparation phase');

      initialRoadmapStages.forEach((stage, idx) => {
        // Basic fields
        assert.ok(stage.id, `Stage ${idx + 1} must have an id`);
        assert.ok(stage.stepNumber, `Stage ${idx + 1} must have a stepNumber`);
        assert.ok(stage.title, `Stage ${idx + 1} must have a title`);
        assert.ok(stage.skillName, `Stage ${idx + 1} must have a skillName`);
        assert.ok(stage.goal, `Stage ${idx + 1} must have a goal`);
        assert.ok(stage.phase, `Stage ${idx + 1} must have a phase`);

        // Beginner-friendly why it matters
        assert.ok(
          stage.whyItMatters && stage.whyItMatters.trim().length > 15,
          `Stage ${idx + 1} must have a beginner-friendly explanation of why it matters`
        );

        // Specific concepts to learn
        assert.ok(
          Array.isArray(stage.conceptsToLearn) && stage.conceptsToLearn.length > 0,
          `Stage ${idx + 1} must have conceptsToLearn array with at least 1 concept`
        );

        // Verified learning resources
        assert.ok(
          Array.isArray(stage.learningResources) && stage.learningResources.length > 0,
          `Stage ${idx + 1} must have learningResources array with at least 1 resource`
        );

        stage.learningResources?.forEach((res) => {
          assert.ok(res.title && res.title.length > 3, 'Resource must have a title');
          assert.ok(res.provider && res.provider.length > 2, 'Resource must have a provider');
          assert.ok(res.url && res.url.startsWith('https://'), 'Resource URL must be https');
          assert.ok(['Free', 'Free Option Available', 'Paid'].includes(res.cost), 'Resource cost must be verified');
          assert.strictEqual(res.isVerified, true, 'Resource must be marked verified');
        });

        // Practical exercise
        assert.ok(stage.practicalExercise, `Stage ${idx + 1} must have practicalExercise`);
        assert.ok(stage.practicalExercise?.title, `Stage ${idx + 1} practicalExercise must have a title`);
        assert.ok(stage.practicalExercise?.task, `Stage ${idx + 1} practicalExercise must have a task description`);
        assert.ok(
          stage.practicalExercise?.completionCriteria,
          `Stage ${idx + 1} practicalExercise must have completionCriteria`
        );

        // Simple completion criteria
        assert.ok(
          stage.completionCriteria && stage.completionCriteria.trim().length > 10,
          `Stage ${idx + 1} must have a clear completion criterion`
        );
      });
    });
  });

  // =========================================================================
  // Requirement 3: Verified Established Resources
  // =========================================================================
  describe('Resource Reliability & No Fabricated Links', () => {
    it('only uses reputable, verified domains for learning resources', () => {
      const allowedDomainFragments = [
        'docs.python.org',
        'postgresql.org',
        'learn.microsoft.com',
        'support.microsoft.com',
        'khanacademy.org',
        'pandas.pydata.org',
        'numpy.org',
        'developer.mozilla.org',
        'javascript.info',
        'react.dev',
        'git-scm.com',
        'nodejs.org',
        'docs.docker.com',
        'linuxjourney.com',
        'kubernetes.io',
        'scikit-learn.org',
        'w3schools.com',
        'tableau.com'
      ];

      for (const [skill, resources] of Object.entries(VERIFIED_SKILL_RESOURCES)) {
        assert.ok(resources.length > 0, `Skill ${skill} should have verified resources`);
        resources.forEach((r) => {
          const isAllowed = allowedDomainFragments.some((domain) => r.url.includes(domain));
          assert.ok(
            isAllowed,
            `Resource URL "${r.url}" for skill "${skill}" must come from a verified official platform`
          );
          assert.strictEqual(r.cost, 'Free', 'Verified resources should explicitly state Free for open docs');
        });
      }
    });

    it('returns empty array for unsupported or fabricated skills rather than inventing URLs', () => {
      const result = getVerifiedResourcesForSkill('NonExistentFictionalFramework999');
      assert.deepStrictEqual(result, [], 'Must return empty array for unverified skill');
    });
  });

  // =========================================================================
  // Requirement 4 & 5: Concept-Level Breakdowns & Role Sequences
  // =========================================================================
  describe('Concept-Level Breakdowns & Role-Specific Differentiation', () => {
    it('breaks broad skills like Power BI into manageable sequential concept tasks', () => {
      const daRoadmap = generatePersonalizedRoadmap('Data Analyst', initialSkills);
      const powerBiStages = daRoadmap.filter((s) => s.skillName === 'Power BI');

      assert.strictEqual(powerBiStages.length, 2, 'Power BI must be broken into separate achievable tasks');
      const [stageModeling, stageDax] = powerBiStages;

      // First task covers ETL and data modeling
      assert.ok(
        stageModeling.title.toLowerCase().includes('power query') || stageModeling.title.toLowerCase().includes('data modeling'),
        'First Power BI task must focus on Power Query and data modeling'
      );
      assert.ok(
        stageModeling.conceptsToLearn?.some((c) => c.toLowerCase().includes('star schema')),
        'First task must teach star schema'
      );

      // Second task covers DAX and interactive dashboards
      assert.ok(
        stageDax.title.toLowerCase().includes('dax') || stageDax.title.toLowerCase().includes('dashboards'),
        'Second Power BI task must focus on DAX measures and interactive dashboards'
      );
      assert.ok(
        stageDax.conceptsToLearn?.some((c) => c.toLowerCase().includes('calculate')),
        'Second task must teach CALCULATE measures'
      );
    });

    it('generates distinct, non-identical learning sequences for each role', () => {
      const analystRoadmap = generatePersonalizedRoadmap('Data Analyst', initialSkills);
      const frontendRoadmap = generatePersonalizedRoadmap('Frontend Developer', initialSkills);
      const backendRoadmap = generatePersonalizedRoadmap('Backend Developer', initialSkills);
      const aiRoadmap = generatePersonalizedRoadmap('AI Engineer', initialSkills);
      const devopsRoadmap = generatePersonalizedRoadmap('DevOps Engineer', initialSkills);

      const analystSkills = analystRoadmap.map((s) => s.skillName);
      const frontendSkills = frontendRoadmap.map((s) => s.skillName);
      const backendSkills = backendRoadmap.map((s) => s.skillName);
      const aiSkills = aiRoadmap.map((s) => s.skillName);
      const devopsSkills = devopsRoadmap.map((s) => s.skillName);

      // Unique role skills
      assert.ok(analystSkills.includes('Power BI'), 'Data Analyst includes Power BI');
      assert.ok(frontendSkills.includes('React'), 'Frontend includes React');
      assert.ok(backendSkills.includes('Node.js'), 'Backend includes Node.js');
      assert.ok(aiSkills.includes('Machine Learning'), 'AI Engineer includes Machine Learning');
      assert.ok(devopsSkills.includes('Kubernetes'), 'DevOps includes Kubernetes');

      // They must not share identical skill sequences
      assert.notDeepStrictEqual(analystSkills, frontendSkills);
      assert.notDeepStrictEqual(frontendSkills, backendSkills);
      assert.notDeepStrictEqual(backendSkills, aiSkills);
    });
  });

  // =========================================================================
  // Requirement 6: Prerequisite Ordering & Single Active Next Step
  // =========================================================================
  describe('Prerequisite Ordering & Unambiguous Next Step', () => {
    it('guarantees exactly ONE task is designated In Progress ("Learning Now")', () => {
      const roadmap = generatePersonalizedRoadmap('Data Analyst', initialSkills);
      const inProgressStages = roadmap.filter((s) => s.status === 'In Progress');

      assert.strictEqual(
        inProgressStages.length,
        1,
        'There must be exactly ONE recommended next step with In Progress status'
      );
    });

    it('ensures upcoming tasks are marked Upcoming ("Not Started"), not simultaneously Learning Now', () => {
      // Provide multiple live market gaps
      const liveMarketGaps = ['SQL', 'Power BI', 'Statistics'];
      const roadmap = generatePersonalizedRoadmap('Data Analyst', initialSkills, liveMarketGaps);

      const inProgressStages = roadmap.filter((s) => s.status === 'In Progress');
      assert.strictEqual(
        inProgressStages.length,
        1,
        'Multiple skill gaps must NOT cause duplicate In Progress statuses'
      );

      const upcomingStages = roadmap.filter((s) => s.status === 'Upcoming');
      assert.ok(upcomingStages.length > 0, 'Subsequent tasks must be marked Upcoming');
    });

    it('respects prerequisites and does not recommend advanced tasks before foundations are complete', () => {
      // Beginner student with zero skills
      const beginnerSkills: SkillItem[] = [
        { id: 's1', name: 'SQL', currentLevel: 0, requiredLevel: 80, category: 'Technical', status: 'Priority Gap' },
        { id: 's2', name: 'Power BI', currentLevel: 0, requiredLevel: 75, category: 'Tools', status: 'Needs Improvement' }
      ];

      const roadmap = generatePersonalizedRoadmap('Data Analyst', beginnerSkills);
      const activeStage = roadmap.find((s) => s.status === 'In Progress');

      assert.ok(activeStage, 'Must have an active stage');
      assert.strictEqual(
        activeStage?.phase,
        'Foundations',
        'A beginner with no completed foundations must have an active stage in Phase A: Foundations'
      );
      assert.notStrictEqual(
        activeStage?.skillName,
        'Power BI',
        'Cannot recommend Power BI before foundational spreadsheets/SQL are completed'
      );
    });

    it('allows skipping foundations if student has already demonstrated proficiency via assessment', () => {
      const assessedHistory: AssessmentHistoryItem[] = [
        {
          id: 'ash_1',
          date: 'Oct 11, 2026',
          skillName: 'Excel',
          targetRole: 'Data Analyst',
          overallScore: 90,
          previousScore: 60,
          improvementPct: 30,
          knowledgeLevel: 'Advanced',
          strongTopics: ['Pivot Tables'],
          weakTopics: [],
          recommendedPractice: [],
          status: 'Completed',
          categoryScores: { Excel: 90 },
          strongSkills: ['Excel'],
          weakSkills: []
        },
        {
          id: 'ash_2',
          date: 'Oct 11, 2026',
          skillName: 'SQL',
          targetRole: 'Data Analyst',
          overallScore: 85,
          previousScore: 50,
          improvementPct: 35,
          knowledgeLevel: 'Advanced',
          strongTopics: ['JOINs', 'CTEs'],
          weakTopics: [],
          recommendedPractice: [],
          status: 'Completed',
          categoryScores: { SQL: 85 },
          strongSkills: ['SQL'],
          weakSkills: []
        }
      ];

      const roadmap = generatePersonalizedRoadmap('Data Analyst', initialSkills, [], [], assessedHistory);

      // Foundational Excel and SQL should be marked Completed based on demonstrated assessment results
      const excelStage = roadmap.find((s) => s.skillName === 'Excel');
      assert.strictEqual(excelStage?.status, 'Completed', 'Demonstrated Excel must be marked Completed');

      const sqlFoundations = roadmap.find((s) => s.taskKey === 'da_sql_foundations');
      assert.strictEqual(sqlFoundations?.status, 'Completed', 'Demonstrated SQL Foundations must be marked Completed');

      // The next active step should now be an advanced topic whose prerequisites are met
      const activeStage = roadmap.find((s) => s.status === 'In Progress');
      assert.ok(activeStage, 'Must have an active stage');
      assert.notStrictEqual(activeStage?.taskKey, 'da_excel_foundations');
      assert.notStrictEqual(activeStage?.taskKey, 'da_sql_foundations');
    });
  });

  // =========================================================================
  // Requirement 7: Accurate Progress Percentages & Preservation
  // =========================================================================
  describe('Accurate Progress Percentages & Genuine Progress Preservation', () => {
    it('calculates completion percentages strictly from actual completed task count', () => {
      const roadmap = generatePersonalizedRoadmap('Data Analyst', initialSkills);
      const total = roadmap.length;
      const completed = roadmap.filter((s) => s.status === 'Completed').length;
      const expectedPct = Math.round((completed / total) * 100);

      const calculatedPct = Math.round((completed / total) * 100);
      assert.strictEqual(calculatedPct, expectedPct, 'Percentage must strictly equal completed/total * 100');
      assert.ok(calculatedPct >= 0 && calculatedPct <= 100, 'Percentage must be between 0 and 100');
    });

    it('preserves completed tasks when switching roles ONLY if they genuinely correspond to the same skill', () => {
      const previousStages: RoadmapStage[] = [
        {
          id: 'stage_da_1',
          stepNumber: 1,
          title: 'Spreadsheet Foundations',
          skillName: 'Excel',
          status: 'Completed',
          currentLevel: 100,
          targetLevel: 100,
          estimatedTime: '6 hrs',
          goal: 'Excel',
          whyItMatters: 'Excel',
          learningModules: [],
          practiceTasks: [],
          suggestedProject: ''
        },
        {
          id: 'stage_da_2',
          stepNumber: 2,
          title: 'Relational Databases & SQL Query Fundamentals',
          skillName: 'SQL',
          status: 'Completed',
          currentLevel: 85,
          targetLevel: 85,
          estimatedTime: '8 hrs',
          goal: 'SQL',
          whyItMatters: 'SQL',
          learningModules: [],
          practiceTasks: [],
          suggestedProject: ''
        }
      ];

      // Switching from Data Analyst to Backend Developer:
      // Backend Developer has SQL, which genuinely matches!
      const backendRoadmap = generatePersonalizedRoadmap('Backend Developer', initialSkills, [], previousStages);
      const backendSqlStage = backendRoadmap.find((s) => s.skillName === 'SQL');
      assert.strictEqual(
        backendSqlStage?.status,
        'Completed',
        'SQL stage in Backend track should preserve Completed status from genuine previous SQL completion'
      );

      // Switching from Data Analyst to Frontend Developer:
      // Frontend Developer has HTML, CSS, JavaScript. It does NOT have SQL!
      const frontendRoadmap = generatePersonalizedRoadmap('Frontend Developer', initialSkills, [], previousStages);
      const htmlStage = frontendRoadmap.find((s) => s.skillName === 'HTML');
      const jsStage = frontendRoadmap.find((s) => s.skillName === 'JavaScript');

      assert.notStrictEqual(
        htmlStage?.status,
        'Completed',
        'Completing Excel in Data Analyst must NOT falsely mark HTML complete in Frontend'
      );
      assert.notStrictEqual(
        jsStage?.status,
        'Completed',
        'Completing SQL in Data Analyst must NOT falsely mark JavaScript complete in Frontend'
      );
    });
  });

  // =========================================================================
  // Requirement 8: Separation of Learning & No Fabricated Placement Claims
  // =========================================================================
  describe('Separation of Learning from Placement Activities & Honest Claims', () => {
    it('clearly distinguishes Technical Learning phases from Placement Preparation phases', () => {
      const roadmap = generatePersonalizedRoadmap('Data Analyst', initialSkills);

      const learningPhases = roadmap.filter(
        (s) =>
          s.phase === 'Foundations' ||
          s.phase === 'Core Role-Specific Skills' ||
          s.phase === 'Applied Practice' ||
          s.phase === 'Portfolio Project'
      );

      const placementPhases = roadmap.filter(
        (s) => s.phase === 'Resume and Interview Preparation' || s.phase === 'Job Application Preparation'
      );

      assert.ok(learningPhases.length >= 6, 'Must contain technical learning and portfolio phases');
      assert.ok(placementPhases.length >= 3, 'Must contain distinct resume, interview, and application phases');
    });

    it('contains no unsupported claims of guaranteed placement or arbitrary 85% rules', () => {
      for (const [role, templates] of Object.entries(ROLE_ROADMAP_TEMPLATES)) {
        templates.forEach((t) => {
          const text = `${t.title} ${t.goal} ${t.whyItMatters}`.toLowerCase();
          assert.strictEqual(
            text.includes('guaranteed job') || text.includes('guaranteed placement') || text.includes('verified 85%+ skill profile'),
            false,
            `Role ${role} task ${t.title} must not contain unsupported guarantee claims`
          );
        });
      }
    });

    it('clearly flags unassessed skills with isAssessed false and assessmentScore null', () => {
      const unassessedSkills: SkillItem[] = [];
      const roadmap = generatePersonalizedRoadmap('Data Analyst', unassessedSkills);

      const unassessedStage = roadmap.find((s) => s.skillName === 'Statistics');
      assert.ok(unassessedStage, 'Statistics stage must exist');
      assert.strictEqual(unassessedStage?.isAssessed, false, 'Unassessed skill must have isAssessed false');
      assert.strictEqual(unassessedStage?.assessmentScore, null, 'Unassessed skill must have assessmentScore null');
    });
  });

  // =========================================================================
  // Requirement 9: 5-Stage Beginner Grouping & Simplified Learning Journey
  // =========================================================================
  describe('5 Simple Stages Grouping & Beginner-Friendly Learning Journey', () => {
    it('groups Data Analyst tasks into exactly 5 beginner-friendly stages without discarding tasks', () => {
      const roadmap = generatePersonalizedRoadmap('Data Analyst', initialSkills);
      const groups = groupRoadmapIntoStages(roadmap, 'Data Analyst');

      assert.strictEqual(groups.length, 5, 'Must have exactly 5 simple stages');

      // Verify titles and descriptions match user requirements
      assert.strictEqual(groups[0].title, 'Learn the basics');
      assert.ok(groups[0].shortDescription.includes('foundations') || groups[0].shortDescription.includes('Spreadsheets'));

      assert.strictEqual(groups[1].title, 'Learn to work with data');
      assert.ok(groups[1].shortDescription.includes('cleaning') || groups[1].shortDescription.includes('data'));

      assert.strictEqual(groups[2].title, 'Turn data into insights');
      assert.ok(groups[2].shortDescription.includes('Visualization') || groups[2].shortDescription.includes('dashboards'));

      assert.strictEqual(groups[3].title, 'Build a real project');
      assert.ok(groups[3].shortDescription.includes('practical') || groups[3].shortDescription.includes('Apply'));

      assert.strictEqual(groups[4].title, 'Prepare for jobs');
      assert.ok(groups[4].shortDescription.includes('Resume') || groups[4].shortDescription.includes('interviews'));

      // Total count of tasks inside groups must strictly equal roadmap length (no dropped tasks)
      const totalGroupedTasks = groups.reduce((acc, g) => acc + g.tasks.length, 0);
      assert.strictEqual(totalGroupedTasks, roadmap.length, 'No tasks must be dropped when grouped');

      // Every stage must have a valid simple status
      groups.forEach((g) => {
        assert.ok(['Completed', 'In Progress', 'Not Started'].includes(g.status), `Stage ${g.stageNumber} must have a valid simple status`);
      });
    });

    it('generates role-appropriate 5 stages for all supported careers', () => {
      const supportedRoles = [
        'Frontend Developer',
        'Backend Developer',
        'Full Stack Developer',
        'AI Engineer',
        'ML Engineer',
        'Data Scientist',
        'DevOps Engineer'
      ];

      supportedRoles.forEach((role) => {
        const roadmap = generatePersonalizedRoadmap(role, initialSkills);
        const groups = groupRoadmapIntoStages(roadmap, role);

        assert.strictEqual(groups.length, 5, `Role ${role} must produce exactly 5 stages`);
        const totalTasksInGroups = groups.reduce((acc, g) => acc + g.tasks.length, 0);
        assert.strictEqual(totalTasksInGroups, roadmap.length, `Role ${role} must not drop any tasks`);

        // Check that stages have non-empty titles, descriptions, and tasks
        groups.forEach((g) => {
          assert.ok(g.title.length > 3, `Role ${role} stage ${g.stageNumber} must have a title`);
          assert.ok(g.shortDescription.length > 5, `Role ${role} stage ${g.stageNumber} must have a short description`);
          assert.ok(g.tasks.length > 0, `Role ${role} stage ${g.stageNumber} must have at least 1 task`);
        });
      });
    });

    it('accurately updates stage status and progress when tasks are completed', () => {
      const roadmap = generatePersonalizedRoadmap('Data Analyst', initialSkills);
      // Mark all tasks in Stage 1 as Completed
      const modifiedRoadmap = roadmap.map((t, idx) => {
        if (idx === 0 || idx === 1) {
          return { ...t, status: 'Completed' as const };
        }
        return t;
      });

      const groups = groupRoadmapIntoStages(modifiedRoadmap, 'Data Analyst');
      assert.strictEqual(groups[0].status, 'Completed', 'Stage 1 must be marked Completed when all its tasks are completed');
      assert.strictEqual(groups[0].completedCount, groups[0].totalCount, 'Stage 1 completedCount must equal totalCount');
    });

    it('provides plain English explanations for technical jargon', () => {
      const glossary = TECHNICAL_TERM_GLOSSARY;
      assert.ok(glossary['dashboard'], 'Must explain dashboard in plain English');
      assert.ok(glossary['etl'], 'Must explain ETL in plain English');
      assert.ok(glossary['dax'], 'Must explain DAX in plain English');
      assert.ok(glossary['sql'], 'Must explain SQL in plain English');
      assert.ok(glossary['ctes'], 'Must explain CTEs in plain English');

      const explanations = getPlainEnglishExplanations('Build an interactive dashboard and query SQL with CTEs and ETL pipelines');
      assert.ok(explanations.length >= 3, 'Must detect technical terms and explain them');
    });
  });

  // =========================================================================
  // Requirement 10: Balanced Data Analyst Skill Coverage & Evidence Personalization
  // =========================================================================
  describe('Balanced Data Analyst Skill Coverage & Objective Personalization', () => {
    it('provides complete coverage across all 8 essential Data Analyst competencies', () => {
      const roadmap = generatePersonalizedRoadmap('Data Analyst', initialSkills);

      // 1. Excel: formulas, lookups, PivotTables, charts
      const excelTask = roadmap.find((s) => s.skillName === 'Excel');
      assert.ok(excelTask, 'Must include Excel task');
      const excelConcepts = (excelTask?.conceptsToLearn || []).join(' ').toLowerCase();
      assert.ok(excelConcepts.includes('formula') || excelConcepts.includes('pivottable') || excelConcepts.includes('lookup'));

      // 2. SQL: filtering, aggregations, joins, subqueries, CTEs, window functions
      const sqlTasks = roadmap.filter((s) => s.skillName === 'SQL');
      assert.ok(sqlTasks.length >= 2, 'Must include at least 2 distinct SQL tasks (foundations + advanced)');
      const sqlAllConcepts = sqlTasks.flatMap((t) => t.conceptsToLearn || []).join(' ').toLowerCase();
      assert.ok(sqlAllConcepts.includes('join'), 'SQL must cover joins');
      assert.ok(sqlAllConcepts.includes('cte') || sqlAllConcepts.includes('with'), 'SQL must cover CTEs');
      assert.ok(sqlAllConcepts.includes('window') || sqlAllConcepts.includes('rank'), 'SQL must cover window functions');

      // 3. Python: fundamentals for analysis
      const pythonTask = roadmap.find((s) => s.skillName === 'Python');
      assert.ok(pythonTask, 'Must include Python fundamentals task');
      const pyConcepts = (pythonTask?.conceptsToLearn || []).join(' ').toLowerCase();
      assert.ok(pyConcepts.includes('function') || pyConcepts.includes('list') || pyConcepts.includes('dictionary'));

      // 4. Data Cleaning & Exploratory Data Analysis: Pandas & NumPy
      const cleaningTask = roadmap.find((s) => s.skillName === 'Data Cleaning' || s.title.toLowerCase().includes('pandas'));
      assert.ok(cleaningTask, 'Must include Pandas / Data Cleaning task');
      const cleanConcepts = (cleaningTask?.conceptsToLearn || []).join(' ').toLowerCase();
      assert.ok(cleanConcepts.includes('pandas') || cleanConcepts.includes('numpy') || cleanConcepts.includes('null') || cleanConcepts.includes('exploratory'));

      // 5. Statistics: distributions, variance, standard deviation, correlation, hypothesis testing
      const statsTask = roadmap.find((s) => s.skillName === 'Statistics');
      assert.ok(statsTask, 'Must include Statistics task');
      const statsConcepts = (statsTask?.conceptsToLearn || []).join(' ').toLowerCase();
      assert.ok(statsConcepts.includes('mean') || statsConcepts.includes('variance') || statsConcepts.includes('deviation'));
      assert.ok(statsConcepts.includes('hypothesis') || statsConcepts.includes('p-value') || statsConcepts.includes('correlation'));

      // 6. Data Visualization & BI: Power BI / dashboards / DAX
      const biTasks = roadmap.filter((s) => s.skillName === 'Power BI');
      assert.strictEqual(biTasks.length, 2, 'Power BI must cover both data modeling and DAX/dashboards');

      // 7. Business Analysis: KPIs, business questions, insights
      const bizTask = roadmap.find((s) => s.skillName === 'Business Analysis');
      assert.ok(bizTask, 'Must include Business Analysis task');
      const bizConcepts = (bizTask?.conceptsToLearn || []).join(' ').toLowerCase();
      assert.ok(bizConcepts.includes('kpi') || bizConcepts.includes('question') || bizConcepts.includes('stakeholder'));

      // 8. Practical Projects & Placement Prep
      const capstoneTask = roadmap.find((s) => s.phase === 'Portfolio Project');
      assert.ok(capstoneTask, 'Must include Portfolio Capstone Project');

      const resumeTask = roadmap.find((s) => s.skillName === 'Resume Scoring');
      assert.ok(resumeTask, 'Must include Resume Optimization');

      const interviewTask = roadmap.find((s) => s.skillName === 'Interview Readiness');
      assert.ok(interviewTask, 'Must include Technical Interview Prep');

      const appTask = roadmap.find((s) => s.phase === 'Job Application Preparation');
      assert.ok(appTask, 'Must include Job Application Preparation');
    });

    it('does NOT force Power BI as the next step when a student has other higher-priority gaps', () => {
      // Student who already mastered Power BI (90%) but needs SQL (40%) and Statistics (45%)
      const studentWithBiStrength: SkillItem[] = [
        { id: 's_pbi', name: 'Power BI', currentLevel: 90, requiredLevel: 75, category: 'Tools', status: 'Good' },
        { id: 's_sql', name: 'SQL', currentLevel: 40, requiredLevel: 80, category: 'Technical', status: 'Priority Gap' },
        { id: 's_stat', name: 'Statistics', currentLevel: 45, requiredLevel: 75, category: 'Analytical', status: 'Needs Improvement' }
      ];

      const assessmentHist: AssessmentHistoryItem[] = [
        {
          id: 'ash_bi',
          date: 'Oct 12, 2026',
          skillName: 'Power BI',
          targetRole: 'Data Analyst',
          overallScore: 90,
          status: 'Completed',
          categoryScores: { 'Power BI': 90 },
          strongSkills: ['DAX', 'Star Schema'],
          weakSkills: []
        }
      ];

      const roadmap = generatePersonalizedRoadmap('Data Analyst', studentWithBiStrength, ['SQL', 'Statistics'], [], assessmentHist);
      const activeTask = roadmap.find((s) => s.status === 'In Progress');

      assert.ok(activeTask, 'Must have an active task');
      assert.notStrictEqual(activeTask?.skillName, 'Power BI', 'Must NOT recommend Power BI when student is already proficient in Power BI');
      assert.ok(activeTask?.skillName === 'Excel' || activeTask?.skillName === 'SQL', 'Must recommend foundational spreadsheet or SQL gap');
    });

    it('ensures each task has a real practical exercise and verifiable completion criteria', () => {
      const roadmap = generatePersonalizedRoadmap('Data Analyst', initialSkills);
      roadmap.forEach((task, idx) => {
        assert.ok(task.practicalExercise?.title, `Task ${idx + 1} must have practicalExercise title`);
        assert.ok(task.practicalExercise?.task, `Task ${idx + 1} must have practicalExercise task`);
        assert.ok(task.practicalExercise?.completionCriteria, `Task ${idx + 1} must have practicalExercise completionCriteria`);
        assert.ok(task.completionCriteria, `Task ${idx + 1} must have overall completionCriteria`);
      });
    });
  });

  // =========================================================================
  // Requirement 9: Beginner Ordering, Prerequisites, Demonstrated Skills & Progress Preservation
  // =========================================================================
  describe('Sensible Learning Order, Prerequisite Enforcement & Progress Preservation', () => {
    it('enforces exact sensible beginner learning order for Data Analyst', () => {
      // Complete beginner with no demonstrated skills
      const beginnerRoadmap = generatePersonalizedRoadmap('Data Analyst', []);

      assert.strictEqual(beginnerRoadmap.length, 13, 'Must have 13 tasks total');

      const expectedSkillSequence = [
        'Excel',
        'SQL',
        'Python',
        'Statistics',
        'SQL',
        'Data Cleaning',
        'Power BI',
        'Power BI',
        'Business Analysis',
        'Portfolio Capstone',
        'Resume Scoring',
        'Interview Readiness',
        'Application Pipeline'
      ];

      beginnerRoadmap.forEach((task, idx) => {
        assert.strictEqual(
          task.skillName,
          expectedSkillSequence[idx],
          `Step ${idx + 1} skill should be ${expectedSkillSequence[idx]}, but got ${task.skillName}`
        );
      });

      // Step 1: Excel Foundations must be In Progress for beginner
      assert.strictEqual(beginnerRoadmap[0].status, 'In Progress', 'Step 1 (Excel) must be In Progress');
      assert.strictEqual(beginnerRoadmap[0].title, 'Spreadsheet & Data Analysis Foundations');

      // Step 4 is Statistics, not Power BI
      assert.strictEqual(beginnerRoadmap[3].skillName, 'Statistics');
      assert.strictEqual(beginnerRoadmap[3].status, 'Upcoming');

      // Power BI tasks must be Step 7 and Step 8 (not Step 4)
      assert.strictEqual(beginnerRoadmap[6].skillName, 'Power BI');
      assert.strictEqual(beginnerRoadmap[6].status, 'Upcoming');
      assert.strictEqual(beginnerRoadmap[7].skillName, 'Power BI');
      assert.strictEqual(beginnerRoadmap[7].status, 'Upcoming');

      // Exactly ONE task In Progress
      const inProgressCount = beginnerRoadmap.filter((t) => t.status === 'In Progress').length;
      assert.strictEqual(inProgressCount, 1, 'Exactly one task must be In Progress');
    });

    it('ensures missing or unassessed skills are never treated as demonstrated proficiency, and foundational tasks take precedence', () => {
      // Student with unassessed skills (level 0, no test date, Priority Gap)
      const studentWithUnassessed: SkillItem[] = [
        { id: 'sk_excel', name: 'Excel', currentLevel: 0, requiredLevel: 80, category: 'Tools', status: 'Priority Gap' },
        { id: 'sk_sql', name: 'SQL', currentLevel: 0, requiredLevel: 90, category: 'Technical', status: 'Priority Gap' },
        { id: 'sk_python', name: 'Python', currentLevel: 0, requiredLevel: 80, category: 'Technical', status: 'Priority Gap' }
      ];

      const roadmap = generatePersonalizedRoadmap('Data Analyst', studentWithUnassessed);

      // Unassessed foundations must NOT be marked Completed
      assert.notStrictEqual(roadmap[0].status, 'Completed', 'Unassessed Excel must not be Completed');
      assert.notStrictEqual(roadmap[1].status, 'Completed', 'Unassessed SQL must not be Completed');
      assert.notStrictEqual(roadmap[2].status, 'Completed', 'Unassessed Python must not be Completed');

      // Foundational task must be chosen for In Progress, never Power BI or advanced task
      const activeTask = roadmap.find((t) => t.status === 'In Progress');
      assert.ok(activeTask, 'Must have an active task');
      assert.strictEqual(activeTask?.phase, 'Foundations', 'Active task must be in Foundations');
      assert.strictEqual(activeTask?.skillName, 'Excel', 'Excel Foundations must be active next step');

      // Power BI must remain Upcoming because foundational prerequisites are unmet
      const powerBiTask = roadmap.find((t) => t.skillName === 'Power BI');
      assert.strictEqual(powerBiTask?.status, 'Upcoming', 'Power BI must remain Upcoming when foundations are incomplete');
    });

    it('correctly marks already-demonstrated skills via diagnostic assessment and selects next eligible incomplete step', () => {
      // Student who has verified Excel assessment (90%) and Python assessment (88%), but SQL is deficient (55%)
      const studentSkills: SkillItem[] = [
        { id: 's_excel', name: 'Excel', currentLevel: 90, requiredLevel: 80, category: 'Tools', status: 'Strong', lastTestedDate: 'Oct 1, 2026' },
        { id: 's_python', name: 'Python', currentLevel: 88, requiredLevel: 80, category: 'Technical', status: 'Good', lastTestedDate: 'Oct 2, 2026' },
        { id: 's_sql', name: 'SQL', currentLevel: 55, requiredLevel: 90, category: 'Technical', status: 'Priority Gap', lastTestedDate: 'Oct 3, 2026' }
      ];

      const assessedHistory: AssessmentHistoryItem[] = [
        {
          id: 'ash_ex',
          date: 'Oct 1, 2026',
          skillName: 'Excel',
          targetRole: 'Data Analyst',
          overallScore: 90,
          status: 'Completed',
          categoryScores: { Excel: 90 },
          strongSkills: ['Pivot Tables'],
          weakSkills: []
        },
        {
          id: 'ash_py',
          date: 'Oct 2, 2026',
          skillName: 'Python',
          targetRole: 'Data Analyst',
          overallScore: 88,
          status: 'Completed',
          categoryScores: { Python: 88 },
          strongSkills: ['Lists', 'Functions'],
          weakSkills: []
        },
        {
          id: 'ash_sq',
          date: 'Oct 3, 2026',
          skillName: 'SQL',
          targetRole: 'Data Analyst',
          overallScore: 55,
          status: 'Completed',
          categoryScores: { SQL: 55 },
          strongSkills: [],
          weakSkills: ['JOINs', 'Window Functions']
        }
      ];

      const roadmap = generatePersonalizedRoadmap('Data Analyst', studentSkills, ['SQL'], [], assessedHistory);

      // Excel foundations: Completed (assessed 90%)
      const excelTask = roadmap.find((t) => t.taskKey === 'da_excel_foundations');
      assert.strictEqual(excelTask?.status, 'Completed', 'Excel foundations must be marked Completed');

      // Python fundamentals: Completed (assessed 88%)
      const pythonTask = roadmap.find((t) => t.taskKey === 'da_python_fundamentals');
      assert.strictEqual(pythonTask?.status, 'Completed', 'Python fundamentals must be marked Completed');

      // SQL foundations: assessed 55% (< 75%), so it must be In Progress!
      const sqlFoundationsTask = roadmap.find((t) => t.taskKey === 'da_sql_foundations');
      assert.strictEqual(sqlFoundationsTask?.status, 'In Progress', 'Deficient SQL foundations must be In Progress');

      // Power BI must NOT be In Progress because SQL prerequisite is incomplete
      const powerBiTask = roadmap.find((t) => t.skillName === 'Power BI');
      assert.strictEqual(powerBiTask?.status, 'Upcoming', 'Power BI must not be In Progress when SQL foundation is incomplete');
    });

    it('faithfully preserves genuine user-completed tasks and assessment results across roadmap updates', () => {
      const previouslyCompletedStages: RoadmapStage[] = [
        {
          id: 'stage_da_1',
          taskKey: 'da_excel_foundations',
          stepNumber: 1,
          title: 'Spreadsheet & Data Analysis Foundations',
          skillName: 'Excel',
          status: 'Completed',
          currentLevel: 80,
          targetLevel: 85,
          estimatedTime: '6 hrs',
          goal: 'Excel',
          whyItMatters: 'Excel',
          learningModules: [],
          practiceTasks: [],
          suggestedProject: ''
        },
        {
          id: 'stage_da_2',
          taskKey: 'da_sql_foundations',
          stepNumber: 2,
          title: 'Relational Databases & SQL Query Fundamentals',
          skillName: 'SQL',
          status: 'Completed',
          currentLevel: 85,
          targetLevel: 80,
          estimatedTime: '8 hrs',
          goal: 'SQL',
          whyItMatters: 'SQL',
          learningModules: [],
          practiceTasks: [],
          suggestedProject: ''
        }
      ];

      const recomputedRoadmap = generatePersonalizedRoadmap('Data Analyst', initialSkills, [], previouslyCompletedStages);

      // Both previously completed tasks must be preserved as Completed
      const preservedExcel = recomputedRoadmap.find((t) => t.taskKey === 'da_excel_foundations');
      assert.strictEqual(preservedExcel?.status, 'Completed', 'Excel task completion must be preserved');

      const preservedSql = recomputedRoadmap.find((t) => t.taskKey === 'da_sql_foundations');
      assert.strictEqual(preservedSql?.status, 'Completed', 'SQL foundations completion must be preserved');

      // The new roadmap must still have all 13 current stages
      assert.strictEqual(recomputedRoadmap.length, 13, 'Must have 13 stages in updated template');

      // Completed count must be accurate (no phantom steps completed)
      const completedCount = recomputedRoadmap.filter((t) => t.status === 'Completed').length;
      assert.ok(completedCount >= 2, 'Must have preserved completions');
    });
  });
});

