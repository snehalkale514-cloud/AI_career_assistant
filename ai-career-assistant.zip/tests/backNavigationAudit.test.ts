import test from 'node:test';
import assert from 'node:assert';
import fs from 'node:fs';
import path from 'node:path';
import React from 'react';
import ReactDOMServer from 'react-dom/server';
import { MemoryRouter } from 'react-router-dom';
import { BackButton } from '../src/components/common/BackButton.tsx';

test('Back Navigation Audit across Student and Company Portals', async (t) => {
  await t.test('BackButton component safety and history fallback logic', () => {
    const backButtonCode = fs.readFileSync(path.resolve('src/components/common/BackButton.tsx'), 'utf-8');
    assert.ok(backButtonCode.includes('type="button"'), 'BackButton explicitly specifies type="button" to avoid submitting forms');
    assert.ok(backButtonCode.includes('window.history.state'), 'Checks browser window.history.state');
    assert.ok(backButtonCode.includes('navigate(-1)'), 'Calls navigate(-1) when previous in-app history exists');
    assert.ok(backButtonCode.includes('/company/dashboard'), 'Provides fallback to /company/dashboard for company portal pages');
    assert.ok(backButtonCode.includes('/dashboard'), 'Provides fallback to /dashboard for student portal pages');
    assert.ok(backButtonCode.includes('ArrowLeft'), 'Uses ArrowLeft Lucide icon for visual consistency');
  });

  await t.test('BackButton renders visible button with ArrowLeft icon and text "Back"', () => {
    const html = ReactDOMServer.renderToString(
      React.createElement(MemoryRouter, null, React.createElement(BackButton, { fallback: '/dashboard' }))
    );
    assert.ok(html.includes('data-testid="back-button"'), 'Renders button element with testid');
    assert.ok(html.includes('lucide-arrow-left'), 'Renders Lucide ArrowLeft icon svg');
    assert.ok(html.includes('>Back</span>'), 'Renders visible text "Back"');
    assert.ok(html.includes('type="button"'), 'Has type="button" to prevent form submission');
  });

  await t.test('All Student Portal pages include BackButton navigation', () => {
    const studentPages = [
      'src/pages/dashboard/DashboardPage.tsx',
      'src/pages/profile/ProfilePage.tsx',
      'src/pages/assessment/SkillAssessmentPage.tsx',
      'src/pages/assessment/AssessmentHistoryPage.tsx',
      'src/pages/resume/ResumeAnalyzerPage.tsx',
      'src/pages/resume/ResumeBuilderPage.tsx',
      'src/pages/analytics/SkillAnalyticsPage.tsx',
      'src/pages/roadmap/CareerRoadmapPage.tsx',
      'src/pages/projects/ProjectsPage.tsx',
      'src/pages/jobs/JobRecommendationsPage.tsx',
      'src/pages/jobs/SavedJobsPage.tsx',
      'src/pages/interview/InterviewPrepPage.tsx',
      'src/components/interview/InterviewSetupScreen.tsx',
      'src/components/interview/InterviewResultsScreen.tsx',
      'src/pages/applications/ApplicationTrackerPage.tsx',
      'src/pages/readiness/PlacementReadinessPage.tsx',
      'src/pages/careerhub/CareerHubPage.tsx',
      'src/pages/careerhub/CertificatesPage.tsx',
      'src/pages/careerhub/AchievementsPage.tsx',
      'src/pages/careerhub/GithubPage.tsx',
      'src/pages/careerhub/LinkedinPage.tsx',
      'src/pages/careerhub/PortfolioPage.tsx',
      'src/pages/settings/SettingsPage.tsx',
    ];

    studentPages.forEach((filePath) => {
      const content = fs.readFileSync(path.resolve(filePath), 'utf-8');
      assert.ok(
        content.includes('BackButton'),
        `Expected ${filePath} to import and render BackButton`
      );
    });
  });

  await t.test('All Company Portal pages include BackButton navigation', () => {
    const companyPages = [
      'src/pages/company/CompanyDashboardPage.tsx',
      'src/pages/company/CompanyPostingsPage.tsx',
      'src/pages/company/CompanyApplicantsPage.tsx',
      'src/pages/company/CompanyProfilePage.tsx',
    ];

    companyPages.forEach((filePath) => {
      const content = fs.readFileSync(path.resolve(filePath), 'utf-8');
      assert.ok(
        content.includes('BackButton'),
        `Expected ${filePath} to import and render BackButton`
      );
    });
  });

  await t.test('Authentication & Onboarding flows include non-interfering Back navigation', () => {
    const authPages = [
      'src/pages/auth/LoginPage.tsx',
      'src/pages/auth/SignupPage.tsx',
      'src/pages/auth/ForgotPasswordPage.tsx',
      'src/pages/company/CompanyLoginPage.tsx',
      'src/pages/company/CompanyRegisterPage.tsx',
      'src/pages/onboarding/OnboardingPage.tsx',
    ];

    authPages.forEach((filePath) => {
      const content = fs.readFileSync(path.resolve(filePath), 'utf-8');
      assert.ok(
        content.includes('BackButton'),
        `Expected ${filePath} to provide BackButton navigation`
      );
    });
  });
});
